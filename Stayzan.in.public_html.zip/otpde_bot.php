<?php

$botToken = "8315366253:AAEbJsUM61tlqNBUrGFW5tJCy4fHntXXVyA";
$update = json_decode(file_get_contents("php://input"), true);

if(isset($update["message"])) {
    $chatId = $update["message"]["chat"]["id"];
    $text = $update["message"]["text"];

    if(strpos($text, "/start") === 0) {
        $parts = explode(" ", $text);
        if (isset($parts[1])) {
            $mobile = $parts[1];

            $conn = new mysqli("localhost", "u976552851_hellogovind", "Govind@00#", "u976552851_hellogovind");

            // 🔍 Check if this chat_id already has an account
            $check = $conn->prepare("SELECT mobile FROM mobile_otp WHERE chat_id = ?");
            $check->bind_param("s", $chatId);
            $check->execute();
            $res = $check->get_result();

            if ($res->num_rows > 0) {
                // Already registered
                $row = $res->fetch_assoc();
                $msg = "❌ You already have an account with mobile: " . $row['mobile'];
                file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=".urlencode($msg));
            } else {
                // ✅ New registration allowed
                $otp = rand(1000, 9999);

                $stmt = $conn->prepare("INSERT INTO mobile_otp (chat_id, mobile, otp, created_at) VALUES (?, ?, ?, NOW())");
                $stmt->bind_param("sss", $chatId, $mobile, $otp);
                $stmt->execute();

                $msg = "✅ Your OTP for signup is: $otp\n\nEnter this OTP on the website to complete registration.";
                file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=".urlencode($msg));
            }

            $check->close();
            $conn->close();
        } else {
            file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=Send /start <your_mobile_number>");
        }
    }
}
?>
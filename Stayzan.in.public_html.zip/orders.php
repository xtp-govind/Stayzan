<?php
// 1. सेशन शुरू करें (यदि उपयोगकर्ता लॉगिन आवश्यक है)
session_start();

// --- डेटाबेस कनेक्शन ---
$host = "localhost";
$user = "u976552851_hellogovind"; // अपना डेटाबेस उपयोगकर्ता नाम बदलें
$password = "Govind@00#"; // अपना डेटाबेस पासवर्ड बदलें
$database = "u976552851_hellogovind"; // अपना डेटाबेस नाम बदलें

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// उपयोगकर्ता की unique_id सेशन से प्राप्त करें
// यदि लॉगिन सिस्टम नहीं है, तो परीक्षण के लिए इसे हार्डकोड करें
$session_unique_id = $_SESSION['unique_id'] ?? 'USER_12345'; // 'USER_12345' को एक वास्तविक unique_id से बदलें

// --- डेटाबेस से रिकॉर्ड प्राप्त करें ---

// Fast Parity रिकॉर्ड
$fastparity_records = [];
$stmt_fp = $conn->prepare("SELECT period_id, bet_type, bet_value, amount, status, created_at FROM fastparity_bets WHERE unique_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt_fp->bind_param("s", $session_unique_id);
$stmt_fp->execute();
$result_fp = $stmt_fp->get_result();
while ($row = $result_fp->fetch_assoc()) {
    $fastparity_records[] = $row;
}
$stmt_fp->close();

// Parity रिकॉर्ड (मान लें कि टेबल का नाम 'parity_bets' है)

$parity_records = [];
  $stmt_p = $conn->prepare("SELECT period_id, bet_type, bet_value, amount, status, created_at FROM parity_bets WHERE unique_id = ? ORDER BY created_at DESC LIMIT 50");
  $stmt_p->bind_param("s", $session_unique_id);
  $stmt_p->execute();
  $result_p = $stmt_p->get_result();
  while ($row = $result_p->fetch_assoc()) {
     $parity_records[] = $row;
  }
   $stmt_p->close();


// Aviator रिकॉर्ड (मान लें कि टेबल का नाम 'aviator_bets' है)
$aviator_records = [];
// इसी तरह Aviator के लिए कोड यहाँ लिखें...


// रिकॉर्ड को एक एसोसिएटिव ऐरे में व्यवस्थित करें
$game_data = [
    'fast-parity' => $fastparity_records,
    'parity' => $parity_records,
    'aviator' => $aviator_records,
    'mine' => [], // Mine गेम के लिए डेटा यहाँ डालें
    'spare' => [], // Spare गेम के लिए डेटा यहाँ डालें
];

// डिफ़ॉल्ट रूप से सक्रिय टैब
$active_tab = 'fast-parity';

?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Records</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a90e2;
            --background-color: #f0f2f5;
            --card-background: #ffffff;
            --text-primary: #333;
            --text-secondary: #666;
            --border-color: #e9ecef;
            --win-color: #28a745;
            --loss-color: #dc3545;
            --win-bg: #e9f7ec;
            --loss-bg: #fbe9eb;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--background-color);
            color: var(--text-primary);
            margin: 0;
            padding-top: 120px; /* हेडर के लिए जगह */
        }
        .fixed-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--border-color);
        }

        .top-bar {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 5px 15px;
            gap: 25px;
        }
        .top-bar .back-btn {
            background: none;
            border: none;
            font-size: 1.4em;
            color: var(--text-primary);
            cursor: pointer;
            margin-right: 15px;
        }
        
        .top-bar .help-btn {
            background: none;
            border: none;
            font-size: 1.4em;
            color: var(--text-primary);
            cursor: pointer;
            margin-left: 15px;
        }
        
        .top-bar .title {
            font-size: 1.2em;
            font-weight: 600;
        }
        
        .game-tabs-container {
            overflow-x: auto;
            white-space: nowrap;
            padding: 10px 15px;
            -ms-overflow-style: none; /* IE and Edge */
            scrollbar-width: none; /* Firefox */
        }
        .game-tabs-container::-webkit-scrollbar {
            display: none; /* Chrome, Safari, and Opera */
        }
        .game-tab {
            display: inline-block;
            padding: 8px 18px;
            margin-right: 10px;
            border: 1px solid var(--border-color);
            border-radius: 20px;
            background-color: #f8f9fa;
            color: var(--text-secondary);
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .game-tab.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        .container {
            padding: 15px;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
            animation: fadeIn 0.4s;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .record-card {
            background-color: var(--card-background);
            border-radius: 12px;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border-left: 5px solid;
            overflow: hidden;
        }
        .record-card.win { border-left-color: var(--win-color); }
        .record-card.loss { border-left-color: var(--loss-color); }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 15px;
            background-color: #fcfcfc;
            border-bottom: 1px solid var(--border-color);
        }
        .card-header .period { font-weight: 600; font-size: 1em; }
        .card-header .status {
            font-weight: 700;
            font-size: 1.1em;
        }
        .status.win { color: var(--win-color); }
        .status.loss { color: var(--loss-color); }
        .card-body {
            padding: 15px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        .info-item {
            font-size: 0.9em;
        }
        .info-item .label {
            color: var(--text-secondary);
            display: block;
            font-size: 0.85em;
            margin-bottom: 2px;
        }
        .info-item .value {
            font-weight: 500;
        }
        .no-records {
            text-align: center;
            padding: 50px 20px;
            background-color: var(--card-background);
            border-radius: 12px;
            color: var(--text-secondary);
        }
        
 /* --- Modal/Popup Styles --- */
.modal-overlay {
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    z-index: 2000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 15px;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}
.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}
.modal-content {
    background: white;
    border-radius: 15px;
    width: 100%;
    max-width: 500px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.2);
    transform: scale(0.9);
    transition: transform 0.3s ease;
}
.modal-overlay.active .modal-content {
    transform: scale(1);
}
.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 20px;
    border-bottom: 1px solid var(--border-color);
}
.modal-header h3 {
    margin: 0;
    font-size: 1.2em;
}
.modal-close-btn {
    background: none;
    border: none;
    font-size: 2em;
    cursor: pointer;
    color: #999;
    line-height: 1;
}
.modal-body {
    padding: 20px;
    line-height: 1.6;
}
.modal-body ul {
    padding-left: 20px;
}
.modal-body li {
    margin-bottom: 10px;
}

        
    </style>
</head>
<body>

    <header class="fixed-header">
        <div class="top-bar">
            <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
            <h1 class="title">My Game Records</h1>
            
            <button id="help-btn" class="help-btn" onclick=""><i class="fas fa-question-circle"></i></button>
        </div>
        <div class="game-tabs-container">
            <?php foreach ($game_data as $game_key => $records): ?>
                <button class="game-tab <?php echo ($game_key == $active_tab) ? 'active' : ''; ?>" data-tab="<?php echo $game_key; ?>">
                    <?php echo ucfirst(str_replace('-', ' ', $game_key)); ?>
                </button>
            <?php endforeach; ?>
        </div>
    </header>

    <main class="container">
        <?php foreach ($game_data as $game_key => $records): ?>
            <div id="<?php echo $game_key; ?>" class="tab-content <?php echo ($game_key == $active_tab) ? 'active' : ''; ?>">
                <?php if (!empty($records)): ?>
                    <?php foreach ($records as $record):
                        $status_value = floatval($record['status']);
                    $is_win = $status_value > 0;

                        $status_class = $is_win ? 'win' : 'loss';
                    ?>
                        <div class="record-card <?php echo $status_class; ?>">
                            <div class="card-header">
                                <span class="period">Period: <?php echo htmlspecialchars($record['period_id']); ?></span>
                                <span class="status <?php echo $status_class; ?>">
<?php
    $formatted_status = number_format(abs($status_value), 2);
    echo ($is_win ? '+ ' : '- ') . '₹' . $formatted_status;
?>

                                </span>
                            </div>
                            <div class="card-body">
                                <div class="info-item">
                                    <span class="label">Bet Type</span>
                                    <span class="value"><?php echo htmlspecialchars(ucfirst($record['bet_type'])); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="label">Bet Value</span>
                                    <span class="value"><?php echo htmlspecialchars($record['bet_value']); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="label">Amount</span>
                                    <span class="value">₹<?php echo number_format($record['amount'], 2); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="label">Date & Time</span>
                                    <span class="value"><?php echo date('d M Y, h:i A', strtotime($record['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-records">
                        <i class="fas fa-folder-open fa-2x" style="margin-bottom: 15px;"></i>
                        <p>No records found for this game.</p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </main>

<!-- Help Modal/Popup -->
<div class="modal-overlay" id="help-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>About This Page</h3>
            <button class="modal-close-btn" id="modal-close">&times;</button>
        </div>
        <div class="modal-body">
            <p>This page shows a complete record of all the games you have played.</p>
            <ul>
                <li>You can switch between different games like Fast-Parity and Parity by clicking the buttons at the top.</li>
                <li>Each record card displays details of your bet, including the Period ID, amount, and the result (Win or Loss).</li>
                <li>Cards with a green border indicate a 'Win', and cards with a red border indicate a 'Loss'.</li>
            </ul>
            <p>This helps you analyze your gaming history and track your performance.</p>
        </div>
    </div>
</div>


    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const tabButtons = document.querySelectorAll('.game-tab');
        const tabContents = document.querySelectorAll('.tab-content');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                // सभी बटन और कंटेंट से 'active' क्लास हटाएँ
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));

                // क्लिक किए गए बटन और संबंधित कंटेंट पर 'active' क्लास जोड़ें
                button.classList.add('active');
                document.getElementById(button.dataset.tab).classList.add('active');
            });
        });
    });
    
    // --- Modal/Popup Logic ---
document.addEventListener('DOMContentLoaded', function() {
    // --- टैब वाला कोड ---
    const tabButtons = document.querySelectorAll('.game-tab');
    // ... (यह कोड जैसा है वैसा ही रहेगा)

    // --- Modal/Popup Logic (अब यह अंदर है) ---
    const helpBtn = document.getElementById('help-btn');
    const helpModal = document.getElementById('help-modal');
    const modalCloseBtn = document.getElementById('modal-close');

    helpBtn.addEventListener('click', () => {
        helpModal.classList.add('active');
    });

    modalCloseBtn.addEventListener('click', () => {
        helpModal.classList.remove('active');
    });

    helpModal.addEventListener('click', (e) => {
        if (e.target === helpModal) {
            helpModal.classList.remove('active');
        }
    });
});

    
    </script>

</body>
</html>

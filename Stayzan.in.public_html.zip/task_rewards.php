<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Rewards</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --bg-primary: #f8fafc;
            --bg-secondary: #ffffff;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --accent-primary: #3b82f6;
            --accent-success: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
            --border-color: #e2e8f0;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --border-radius: 12px;
            --transition: all 0.2s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            line-height: 1.5;
        }

        /* Header */
        .header {
            background-color: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-btn {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1.1rem;
            cursor: pointer;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .header-btn:hover {
            background-color: var(--bg-primary);
            color: var(--text-primary);
        }

        .header-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        /* Main Content */
        .main-content {
            padding: 1.5rem;
            max-width: 500px;
            margin: 0 auto;
        }

        /* Task List */
        .task-list {
            display: grid;
            gap: 1rem;
        }

        .task-item {
            background-color: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: var(--transition);
        }

        .task-item:hover {
            box-shadow: var(--shadow-md);
            border-color: var(--accent-primary);
        }

        .task-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background-color: var(--accent-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: white;
            flex-shrink: 0;
        }

        .task-info {
            flex: 1;
        }

        .task-title {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
            color: var(--text-primary);
        }

        .task-description {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        .task-requirement {
            font-size: 0.75rem;
            color: var(--accent-danger);
            margin-top: 0.25rem;
        }

        .task-reward {
            text-align: right;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 0.5rem;
        }

        .reward-amount {
            font-size: 1rem;
            font-weight: 700;
            color: var(--accent-warning);
        }

        .claim-btn {
            background-color: var(--accent-primary);
            border: none;
            border-radius: 8px;
            padding: 0.5rem 1rem;
            color: white;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            font-size: 0.875rem;
            min-width: 80px;
        }

        .claim-btn:hover {
            background-color: #2563eb;
            transform: translateY(-1px);
        }

        .claim-btn.completed {
            background-color: var(--accent-success);
            cursor: not-allowed;
        }

        .claim-btn.completed:hover {
            background-color: var(--accent-success);
            transform: none;
        }

        .claim-btn.disabled {
            background-color: var(--text-secondary);
            cursor: not-allowed;
            opacity: 0.6;
        }

        .claim-btn.disabled:hover {
            background-color: var(--text-secondary);
            transform: none;
        }

        .task-item.completed {
            opacity: 0.7;
            background-color: #f8fafc;
        }

        .task-item.completed .task-title,
        .task-item.completed .task-description {
            text-decoration: line-through;
        }

        .task-item.disabled {
            opacity: 0.6;
        }

        /* Loading Animation */
        .loading-spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Help Popup */
        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
        }

        .popup-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .popup-content {
            background: var(--bg-secondary);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            max-width: 400px;
            width: 90%;
            box-shadow: var(--shadow-lg);
            transform: scale(0.9);
            transition: var(--transition);
        }

        .popup-overlay.active .popup-content {
            transform: scale(1);
        }

        .popup-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .popup-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .popup-close {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1.5rem;
            cursor: pointer;
            transition: var(--transition);
        }

        .popup-close:hover {
            color: var(--text-primary);
        }

        .help-item {
            margin-bottom: 1rem;
            padding: 1rem;
            background-color: var(--bg-primary);
            border-radius: 8px;
        }

        .help-item h4 {
            color: var(--accent-primary);
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
            font-weight: 600;
        }

        .help-item p {
            color: var(--text-secondary);
            font-size: 0.875rem;
            line-height: 1.5;
        }

        /* Status Messages */
        .status-message {
            position: fixed;
            top: 80px;
            left: 50%;
            transform: translateX(-50%);
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            z-index: 1001;
            box-shadow: var(--shadow-lg);
            animation: slideDown 0.3s ease-out;
        }

        .status-message.success {
            background-color: var(--accent-success);
            color: white;
        }

        .status-message.loading {
            background-color: var(--accent-primary);
            color: white;
        }

        .status-message.error {
            background-color: var(--accent-danger);
            color: white;
        }

        @keyframes slideDown {
            from { transform: translateX(-50%) translateY(-20px); opacity: 0; }
            to { transform: translateX(-50%) translateY(0); opacity: 1; }
        }

        /* Confetti Canvas */
        #confetti-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 999;
        }

        /* Responsive */
        @media (max-width: 480px) {
            .main-content {
                padding: 1rem;
            }
            
            .task-item {
                padding: 0.875rem;
            }
            
            .header {
                padding: 0.875rem 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <button class="header-btn" id="backBtn" aria-label="Go back">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h1 class="header-title">Task Rewards</h1>
        <button class="header-btn" id="helpBtn" aria-label="Help">
            <i class="fas fa-question-circle"></i>
        </button>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Task List -->
        <div class="task-list" id="taskList">
            <!-- Tasks will be loaded dynamically -->
        </div>
    </main>

    <!-- Help Popup -->
    <div class="popup-overlay" id="helpPopup">
        <div class="popup-content">
            <div class="popup-header">
                <h3 class="popup-title">Help & Information</h3>
                <button class="popup-close" id="closePopup">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="help-item">
                <h4><i class="fas fa-coins"></i> How do Task Rewards work?</h4>
                <p>Complete tasks to earn instant rewards. Money is added directly to your account.</p>
            </div>
            
            <div class="help-item">
                <h4><i class="fas fa-gift"></i> When do I get rewards?</h4>
                <p>Rewards are credited immediately upon task completion. No waiting required.</p>
            </div>
            
            <div class="help-item">
                <h4><i class="fas fa-server"></i> How is data updated?</h4>
                <p>All task information comes from our servers. Only available tasks are shown to you.</p>
            </div>
            
            <div class="help-item">
                <h4><i class="fas fa-question"></i> More questions?</h4>
                <p>Contact our support team if you have any other questions or concerns.</p>
            </div>
        </div>
    </div>

    <!-- Confetti Canvas -->
    <canvas id="confetti-canvas"></canvas>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
    
<script>
        
  const BACKEND_API = {
    getUserTasks: async () => {
        const res = await fetch('get_user_tasks');
        const data = await res.json();
        return {
            userId: data.userId ?? null,
            tasks: data.tasks
        };
    },

    claimReward: async (taskId) => {
        const formData = new FormData();
        formData.append('task_id', taskId);

        const res = await fetch("claim_reward", {
            method: "POST",
            body: formData
        });

        const data = await res.json();

        if (!data.success && data.status !== 'success') {
            throw new Error(data.message || 'Failed to claim');
        }

        return {
            success: true,
            message: data.message,
            taskId: taskId
        };
    }
};

        document.addEventListener('DOMContentLoaded', async () => {
            // Elements
            const backBtn = document.getElementById('backBtn');
            const helpBtn = document.getElementById('helpBtn');
            const helpPopup = document.getElementById('helpPopup');
            const closePopup = document.getElementById('closePopup');
            const taskList = document.getElementById('taskList');
            const confettiCanvas = document.getElementById('confetti-canvas');
            
            // Initialize confetti
            const myConfetti = confetti.create(confettiCanvas, {
                resize: true,
                useWorker: true
            });

            // Load tasks from backend
            await loadTasks();

            // Back button functionality
            backBtn.addEventListener('click', () => {
                if (window.history.length > 1) {
                    window.history.back();
                } else {
                    window.location.href = '/';
                }
            });

            // Help popup functionality
            helpBtn.addEventListener('click', () => {
                helpPopup.classList.add('active');
                document.body.style.overflow = 'hidden';
            });

            closePopup.addEventListener('click', closeHelpPopup);
            helpPopup.addEventListener('click', (e) => {
                if (e.target === helpPopup) {
                    closeHelpPopup();
                }
            });

            function closeHelpPopup() {
                helpPopup.classList.remove('active');
                document.body.style.overflow = 'auto';
            }

            // Load tasks from backend
            async function loadTasks() {
                showStatusMessage('Loading data...', 'loading');
                
                try {
                    const data = await BACKEND_API.getUserTasks();
                    renderTasks(data.tasks);
                    
                    // NO confetti effect for auto-completed tasks on page load
                    // Only show loading completion message
                    setTimeout(() => {
                        hideStatusMessage();
                    }, 500);
                    
                } catch (error) {
                    console.error('Error loading tasks:', error);
                    showStatusMessage('Error loading data', 'error');
                }
            }

            // Render tasks in UI
            function renderTasks(tasks) {
                taskList.innerHTML = '';
                
                tasks.forEach(task => {
                    const taskElement = createTaskElement(task);
                    taskList.appendChild(taskElement);
                });
            }

            // Create task element
            function createTaskElement(task) {
                const taskDiv = document.createElement('div');
                taskDiv.className = `task-item ${task.status}`;
                taskDiv.dataset.taskId = task.id;

                let buttonContent = '';
                let buttonClass = 'claim-btn';
                
                switch (task.status) {
                    case 'completed':
                        buttonContent = '<i class="fas fa-check"></i> Claimed';
                        buttonClass += ' completed';
                        break;
                    case 'available':
                        buttonContent = 'Claim';
                        break;
                    case 'locked':
                        buttonContent = 'Locked';
                        buttonClass += ' disabled';
                        break;
                }

                taskDiv.innerHTML = `
                    <div class="task-icon">
                        <i class="fas ${task.icon}"></i>
                    </div>
                    <div class="task-info">
                        <div class="task-title">${task.title}</div>
                        <div class="task-description">${task.description}</div>
                        ${task.requirement ? `<div class="task-requirement">${task.requirement}</div>` : ''}
                    </div>
                    <div class="task-reward">
                        <span class="reward-amount">+ ₹${task.reward}</span>
                        <button class="${buttonClass}" ${task.status !== 'available' ? 'disabled' : ''}>${buttonContent}</button>
                    </div>
                `;

                // Add click event for available tasks
                if (task.status === 'available') {
                    const button = taskDiv.querySelector('.claim-btn');
                    button.addEventListener('click', () => claimReward(task.id, task.reward, button));
                }

                return taskDiv;
            }

            // Claim reward function
            async function claimReward(taskId, reward, button) {
                // Show loading state
                button.innerHTML = '<span class="loading-spinner"></span>';
                button.disabled = true;

                try {
                    const result = await BACKEND_API.claimReward(taskId);
                    
                    if (result.success) {
                        // Update UI
                        button.innerHTML = '<i class="fas fa-check"></i> Claimed';
                        button.classList.add('completed');
                        
                        const taskItem = button.closest('.task-item');
                        taskItem.classList.add('completed');
                        
                        // Show effects ONLY for manually claimed rewards
                        showConfetti();
                        showStatusMessage(`+₹${reward} claimed successfully!`, 'success');
                        
                        // Reload tasks to get updated data
                        setTimeout(() => {
                            loadTasks();
                        }, 2000);
                    }
                } catch (error) {
                    console.error('Error claiming reward:', error);
                    showStatusMessage('Error claiming reward', 'error');
                    
                    // Reset button
                    button.innerHTML = 'Claim';
                    button.disabled = false;
                }
            }

            // Show status message
            function showStatusMessage(message, type = 'success') {
                // Remove existing messages
                const existingMessages = document.querySelectorAll('.status-message');
                existingMessages.forEach(msg => msg.remove());
                
                const messageDiv = document.createElement('div');
                messageDiv.className = `status-message ${type}`;
                messageDiv.innerHTML = message;
                
                document.body.appendChild(messageDiv);
                
                // Auto-remove message after 3 seconds
                setTimeout(() => {
                    hideStatusMessage();
                }, 1000);
            }

            // Hide status message
            function hideStatusMessage() {
                const messages = document.querySelectorAll('.status-message');
                messages.forEach(msg => {
                    msg.style.animation = 'slideDown 0.2s ease-out reverse';
                    setTimeout(() => {
                        if (msg.parentNode) {
                            msg.parentNode.removeChild(msg);
                        }
                    }, 300);
                });
            }

            // Show confetti effect (only for manually claimed rewards)
            function showConfetti() {
                const duration = 2 * 1000;
                const animationEnd = Date.now() + duration;
                const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 999 };

                function randomInRange(min, max) {
                    return Math.random() * (max - min) + min;
                }

                const interval = setInterval(function() {
                    const timeLeft = animationEnd - Date.now();

                    if (timeLeft <= 0) {
                        return clearInterval(interval);
                    }

                    const particleCount = 30 * (timeLeft / duration);
                    
                    myConfetti({
                        ...defaults,
                        particleCount,
                        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
                        colors: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']
                    });
                    
                    myConfetti({
                        ...defaults,
                        particleCount,
                        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
                        colors: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']
                    });
                }, 250);
            }

            // Keyboard shortcuts
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    closeHelpPopup();
                }
                if (e.key === 'h' || e.key === 'H') {
                    helpBtn.click();
                }
            });
        });
        
  function checkAndUpdateTasks() {
    fetch("fetch_total_bets")
        .then(res => res.json())
        .then(data => {
         
         if (data.status === "success") {
          document.getElementById('totalBets').textContent = data.total_bets;
            }

        })
        .catch(err => {
            console.error("❌ Error in task check:", err);
        });
}

// ✅ Page load par call karo
document.addEventListener('DOMContentLoaded', () => {
    checkAndUpdateTasks(); // Pehli baar turant
    setInterval(checkAndUpdateTasks, 3000); // Har 5 second baad
});     

    </script>
</body>
</html>
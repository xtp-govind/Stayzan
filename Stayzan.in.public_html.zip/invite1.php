<?php
session_start();
if (!isset($_SESSION['unique_id'])) {
    header("Location: login");
    exit();
}
$unique_id = $_SESSION['unique_id'];
$invite_link = "https://stayzan.in/login?ref=" . $unique_id;
?>

<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invite Friends</title>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* General Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
            padding-bottom: 80px;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 100%;
            padding: 20px;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            text-align: center;
            border-bottom-left-radius: 25px;
            border-bottom-right-radius: 25px;
            box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%) translateY(-100%) rotate(0deg); }
            50% { transform: translateX(0%) translateY(0%) rotate(180deg); }
        }

        .header h1 {
            font-size: 1.8em;
            margin-bottom: 8px;
            position: relative;
            z-index: 1;
        }

        .header p {
            font-size: 0.9em;
            opacity: 0.9;
            position: relative;
            z-index: 1;
        }

        /* Your Invitation Record Section */
        .invitation-record-section {
            background: white;
            padding: 25px;
            margin-top: 20px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            text-align: center;
            border: 1px solid rgba(102, 126, 234, 0.1);
        }

        .section-title {
            font-size: 1.3em;
            font-weight: 700;
            text-align: center;
            margin-bottom: 25px;
            color: #333;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 2px;
        }

        .invitation-record-section .label {
            font-size: 1em;
            font-weight: 600;
            margin-bottom: 15px;
            color: #555;
        }

        .link-box {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border: 2px dashed #667eea;
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .link-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.2);
        }

        .link-box .invite-code {
            font-size: 1.1em;
            font-weight: bold;
            color: #667eea;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .copy-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 18px;
            font-size: 0.9em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .copy-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }
        
        .copy-btn .fa-check {
            display: none;
        }

        /* Share Buttons */
        .share-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .share-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex: 1;
            padding: 15px;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            font-weight: 600;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .share-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .share-btn:hover::before {
            left: 100%;
        }
        
        .share-btn i {
            font-size: 1.2em;
        }

        .whatsapp-btn {
            background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
            box-shadow: 0 6px 20px rgba(37, 211, 102, 0.3);
        }

        .telegram-btn {
            background: linear-gradient(135deg, #0088cc 0%, #005f99 100%);
            box-shadow: 0 6px 20px rgba(0, 136, 204, 0.3);
        }
        
        .share-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        /* Your Referral Network Section */
        .referral-network-section {
            background: white;
            padding: 25px;
            margin-top: 20px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            border: 1px solid rgba(102, 126, 234, 0.1);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            text-align: center;
        }

        .stat-item {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 20px 15px;
            border-radius: 15px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            border: 2px solid transparent;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .stat-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .stat-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.2);
            border-color: rgba(102, 126, 234, 0.3);
        }

        .stat-item .icon {
            font-size: 2em;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-item .value {
            font-size: 1.6em;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 6px;
            animation: countUp 1s ease-out;
        }

        @keyframes countUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stat-item .label {
            font-size: 0.9em;
            color: #666;
            font-weight: 500;
        }

        /* Popup Overlay */
        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 2000;
            display: none;
            align-items: flex-end;
            justify-content: center;
        }

        .popup-overlay.show {
            display: flex;
        }

        .popup-content {
            background: white;
            width: 100%;
            height: 75%; /* 3/4 screen size */
            border-top-left-radius: 25px;
            border-top-right-radius: 25px;
            box-shadow: 0 -10px 40px rgba(0,0,0,0.2);
            display: flex;
            flex-direction: column;
            transform: translateY(100%);
            transition: transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        .popup-overlay.show .popup-content {
            transform: translateY(0);
        }

        .popup-header {
            padding: 20px 25px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border-top-left-radius: 25px;
            border-top-right-radius: 25px;
        }

        .popup-title {
            font-size: 1.3em;
            font-weight: 700;
            color: #333;
        }

        .popup-close-btn {
            background: #f1f3f4;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 1.3em;
            cursor: pointer;
            color: #888;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .popup-close-btn:hover {
            background: #e9ecef;
            color: #333;
            transform: rotate(90deg);
        }

        .popup-body {
            flex-grow: 1;
            overflow-y: auto;
            padding: 25px;
        }

        /* Commission Items in Popup */
        .commission-item {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            border-left: 4px solid #667eea;
            transition: all 0.3s ease;
        }

        .commission-item:hover {
            transform: translateX(5px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
        }

        .commission-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .commission-user {
            font-weight: bold;
            color: #333;
            font-size: 1em;
            flex: 1;
        }

        .commission-level {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.8em;
            font-weight: 600;
            margin-left: 10px;
        }

        .commission-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .commission-amount-info {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9em;
            color: #555;
        }

        .commission-percentage {
            font-weight: 600;
            color: #667eea;
        }

        .commission-amount {
            font-weight: bold;
            color: #28a745;
            font-size: 1.1em;
        }

        .commission-date {
            font-size: 0.8em;
            color: #999;
            text-align: right;
            margin-top: 6px;
        }

        /* Referral Items in Popup */
        .referral-item {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            border-left: 4px solid #28a745;
            transition: all 0.3s ease;
        }

        .referral-item:hover {
            transform: translateX(5px);
            box-shadow: 0 8px 25px rgba(40, 167, 69, 0.15);
        }

        .referral-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .referral-user {
            font-weight: bold;
            color: #333;
            font-size: 1em;
            flex: 1;
        }

        .referral-status {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.8em;
            font-weight: 600;
            margin-left: 10px;
        }

        .referral-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .referral-info {
            font-size: 0.9em;
            color: #555;
        }

        .referral-date {
            font-size: 0.8em;
            color: #999;
            text-align: right;
            margin-top: 6px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }

        .empty-state i {
            font-size: 3em;
            margin-bottom: 15px;
            color: #ddd;
        }

        .empty-state h3 {
            font-size: 1.2em;
            margin-bottom: 8px;
            color: #666;
        }

        .empty-state p {
            font-size: 0.9em;
        }

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e9ecef;
            padding: 10px 0;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: #666;
            transition: all 0.3s ease;
            padding: 8px 12px;
            border-radius: 12px;
        }

        .nav-item.active {
            color: #667eea;
            background: rgba(102, 126, 234, 0.1);
        }

        .nav-item i {
            font-size: 1.2em;
            margin-bottom: 4px;
        }

        .nav-item span {
            font-size: 0.7em;
            font-weight: 500;
        }

        /* Responsive Design */
        @media (max-width: 480px) {
            .container {
                padding: 15px;
            }
            
            .stats-grid {
                gap: 10px;
            }
            
            .stat-item {
                padding: 15px 10px;
            }
            
            .stat-item .value {
                font-size: 1.4em;
            }
            
            .popup-body {
                padding: 20px;
            }
            
            .commission-item, .referral-item {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1><i class="fas fa-users"></i> दोस्तों को आमंत्रित करें</h1>
            <p>अपने दोस्तों को आमंत्रित करें और कमीशन कमाएं</p>
        </div>

        <!-- Your Invitation Record Section -->
        <div class="invitation-record-section">
            <div class="section-title">आपका आमंत्रण रिकॉर्ड</div>
            <div class="label">अपना आमंत्रण लिंक साझा करें</div>
            <div class="link-box">
                <span class="invite-code" id="inviteLink"><?php echo $invite_link; ?></span>
                <button class="copy-btn" onclick="copyInviteLink()">
                    <i class="fas fa-copy"></i>
                    <i class="fas fa-check"></i>
                    कॉपी करें
                </button>
            </div>
            <div class="share-buttons">
                <button class="share-btn whatsapp-btn" onclick="shareOnWhatsApp()">
                    <i class="fab fa-whatsapp"></i>
                    WhatsApp
                </button>
                <button class="share-btn telegram-btn" onclick="shareOnTelegram()">
                    <i class="fab fa-telegram"></i>
                    Telegram
                </button>
            </div>
        </div>

        <!-- Your Referral Network Section -->
        <div class="referral-network-section">
            <div class="section-title">आपका रेफरल नेटवर्क</div>
            <div class="stats-grid">
                <div class="stat-item" onclick="showReferralPopup()">
                    <div class="icon">
                        <i class="fas fa-user-friends"></i>
                    </div>
                    <div class="value" id="totalInvites">25</div>
                    <div class="label">कुल आमंत्रण</div>
                </div>
                <div class="stat-item" onclick="showCommissionPopup()">
                    <div class="icon">
                        <i class="fas fa-coins"></i>
                    </div>
                    <div class="value" id="totalEarnings">₹1,250</div>
                    <div class="label">कुल कमाई</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Referral Users Popup -->
    <div class="popup-overlay" id="referralPopup">
        <div class="popup-content">
            <div class="popup-header">
                <h3 class="popup-title">आपके रेफरल यूजर्स</h3>
                <button class="popup-close-btn" onclick="closePopup('referralPopup')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="popup-body">
                <!-- यहाँ backend से referral users की data आएगी -->
                <div class="referral-item">
                    <div class="referral-header">
                        <span class="referral-user">राहुल शर्मा</span>
                        <span class="referral-status">सक्रिय</span>
                    </div>
                    <div class="referral-details">
                        <div class="referral-info">Level 1 • ₹500 खर्च</div>
                    </div>
                    <div class="referral-date">15 जनवरी 2024 को जुड़े</div>
                </div>

                <div class="referral-item">
                    <div class="referral-header">
                        <span class="referral-user">प्रिया गुप्ता</span>
                        <span class="referral-status">सक्रिय</span>
                    </div>
                    <div class="referral-details">
                        <div class="referral-info">Level 1 • ₹300 खर्च</div>
                    </div>
                    <div class="referral-date">12 जनवरी 2024 को जुड़े</div>
                </div>

                <div class="referral-item">
                    <div class="referral-header">
                        <span class="referral-user">अमित कुमार</span>
                        <span class="referral-status">सक्रिय</span>
                    </div>
                    <div class="referral-details">
                        <div class="referral-info">Level 2 • ₹750 खर्च</div>
                    </div>
                    <div class="referral-date">10 जनवरी 2024 को जुड़े</div>
                </div>

                <div class="referral-item">
                    <div class="referral-header">
                        <span class="referral-user">सुनीता देवी</span>
                        <span class="referral-status">सक्रिय</span>
                    </div>
                    <div class="referral-details">
                        <div class="referral-info">Level 1 • ₹200 खर्च</div>
                    </div>
                    <div class="referral-date">8 जनवरी 2024 को जुड़े</div>
                </div>

                <div class="referral-item">
                    <div class="referral-header">
                        <span class="referral-user">विकास सिंह</span>
                        <span class="referral-status">सक्रिय</span>
                    </div>
                    <div class="referral-details">
                        <div class="referral-info">Level 3 • ₹400 खर्च</div>
                    </div>
                    <div class="referral-date">5 जनवरी 2024 को जुड़े</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Commission Records Popup -->
    <div class="popup-overlay" id="commissionPopup">
        <div class="popup-content">
            <div class="popup-header">
                <h3 class="popup-title">कमीशन रिकॉर्ड</h3>
                <button class="popup-close-btn" onclick="closePopup('commissionPopup')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="popup-body">
                <!-- यहाँ backend से commission records की data आएगी -->
                <div class="commission-item">
                    <div class="commission-header">
                        <span class="commission-user">राहुल शर्मा से</span>
                        <span class="commission-level">Level 1</span>
                    </div>
                    <div class="commission-details">
                        <div class="commission-amount-info">
                            <span class="commission-percentage">10%</span>
                            <span>कमीशन • ₹500 की खरीदारी पर</span>
                        </div>
                        <span class="commission-amount">₹50</span>
                    </div>
                    <div class="commission-date">15 जनवरी 2024</div>
                </div>

                <div class="commission-item">
                    <div class="commission-header">
                        <span class="commission-user">प्रिया गुप्ता से</span>
                        <span class="commission-level">Level 1</span>
                    </div>
                    <div class="commission-details">
                        <div class="commission-amount-info">
                            <span class="commission-percentage">10%</span>
                            <span>कमीशन • ₹300 की खरीदारी पर</span>
                        </div>
                        <span class="commission-amount">₹30</span>
                    </div>
                    <div class="commission-date">12 जनवरी 2024</div>
                </div>

                <div class="commission-item">
                    <div class="commission-header">
                        <span class="commission-user">अमित कुमार से</span>
                        <span class="commission-level">Level 2</span>
                    </div>
                    <div class="commission-details">
                        <div class="commission-amount-info">
                            <span class="commission-percentage">5%</span>
                            <span>कमीशन • ₹750 की खरीदारी पर</span>
                        </div>
                        <span class="commission-amount">₹37.50</span>
                    </div>
                    <div class="commission-date">10 जनवरी 2024</div>
                </div>

                <div class="commission-item">
                    <div class="commission-header">
                        <span class="commission-user">सुनीता देवी से</span>
                        <span class="commission-level">Level 1</span>
                    </div>
                    <div class="commission-details">
                        <div class="commission-amount-info">
                            <span class="commission-percentage">10%</span>
                            <span>कमीशन • ₹200 की खरीदारी पर</span>
                        </div>
                        <span class="commission-amount">₹20</span>
                    </div>
                    <div class="commission-date">8 जनवरी 2024</div>
                </div>

                <div class="commission-item">
                    <div class="commission-header">
                        <span class="commission-user">विकास सिंह से</span>
                        <span class="commission-level">Level 3</span>
                    </div>
                    <div class="commission-details">
                        <div class="commission-amount-info">
                            <span class="commission-percentage">3%</span>
                            <span>कमीशन • ₹400 की खरीदारी पर</span>
                        </div>
                        <span class="commission-amount">₹12</span>
                    </div>
                    <div class="commission-date">5 जनवरी 2024</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <div class="nav-items">
            <a href="#" class="nav-item">
                <i class="fas fa-home"></i>
                <span>होम</span>
            </a>
            <a href="#" class="nav-item active">
                <i class="fas fa-users"></i>
                <span>आमंत्रित करें</span>
            </a>
            <a href="#" class="nav-item">
                <i class="fas fa-wallet"></i>
                <span>वॉलेट</span>
            </a>
            <a href="#" class="nav-item">
                <i class="fas fa-user"></i>
                <span>प्रोफाइल</span>
            </a>
        </div>
    </div>

    <script>
        // Copy invite link function
        function copyInviteLink() {
            const inviteLink = document.getElementById('inviteLink').textContent;
            navigator.clipboard.writeText(inviteLink).then(function() {
                const copyBtn = document.querySelector('.copy-btn');
                const copyIcon = copyBtn.querySelector('.fa-copy');
                const checkIcon = copyBtn.querySelector('.fa-check');
                
                copyIcon.style.display = 'none';
                checkIcon.style.display = 'inline';
                copyBtn.innerHTML = '<i class="fas fa-check"></i> कॉपी हो गया!';
                
                setTimeout(function() {
                    copyIcon.style.display = 'inline';
                    checkIcon.style.display = 'none';
                    copyBtn.innerHTML = '<i class="fas fa-copy"></i> कॉपी करें';
                }, 2000);
            });
        }

        // Share on WhatsApp
        function shareOnWhatsApp() {
            const inviteLink = document.getElementById('inviteLink').textContent;
            const message = `मेरे साथ StayZan पर जुड़ें और बेहतरीन डील्स पाएं! ${inviteLink}`;
            const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
        }

        // Share on Telegram
        function shareOnTelegram() {
            const inviteLink = document.getElementById('inviteLink').textContent;
            const message = `मेरे साथ StayZan पर जुड़ें और बेहतरीन डील्स पाएं! ${inviteLink}`;
            const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent(message)}`;
            window.open(telegramUrl, '_blank');
        }

        // Show referral users popup
        function showReferralPopup() {
            const popup = document.getElementById('referralPopup');
            popup.classList.add('show');
            document.body.style.overflow = 'hidden';
        }

        // Show commission records popup
        function showCommissionPopup() {
            const popup = document.getElementById('commissionPopup');
            popup.classList.add('show');
            document.body.style.overflow = 'hidden';
        }

        // Close popup
        function closePopup(popupId) {
            const popup = document.getElementById(popupId);
            popup.classList.remove('show');
            document.body.style.overflow = 'auto';
        }

        // Close popup when clicking on overlay
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('popup-overlay')) {
                e.target.classList.remove('show');
                document.body.style.overflow = 'auto';
            }
        });

        // Prevent body scroll when popup is open
        document.addEventListener('DOMContentLoaded', function() {
            const popups = document.querySelectorAll('.popup-overlay');
            popups.forEach(popup => {
                popup.addEventListener('scroll', function(e) {
                    e.stopPropagation();
                });
            });
        });
    </script>
</body>
</html>
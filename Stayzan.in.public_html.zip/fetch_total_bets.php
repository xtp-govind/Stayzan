<?php
session_start();
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Check session
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

$unique_id = $_SESSION['unique_id'];

// ✅ DB Connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// ✅ Check DB connection
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    exit;
}

$tables = ['fastparity_bets', 'parity_bets', 'sapre_bets'];
$total_bets = 0;
$bets_count = [];

foreach ($tables as $table) {
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM $table WHERE unique_id = ?");
    $stmt->bind_param("s", $unique_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $count = (int)$row['total'];

    if ($count > 0) {
        $bets_count[$table] = $count;
        $total_bets += $count;
    }

    $stmt->close();
}

// ✅ Task Update Logic
function updateTaskIfLocked($conn, $unique_id, $task_id) {
    $check = $conn->prepare("SELECT status FROM user_tasks WHERE user_id = ? AND task_id = ?");
    $check->bind_param("ss", $unique_id, $task_id);
    $check->execute();
    $res = $check->get_result();
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if ($row['status'] === 'locked') {
            $update = $conn->prepare("UPDATE user_tasks SET status = 'available' WHERE user_id = ? AND task_id = ?");
            $update->bind_param("ss", $unique_id, $task_id);
            $update->execute();
            $update->close();
        }
    }
    $check->close();
}

// ✅ Conditions for bet10 and bet100 tasks
if ($total_bets >= 10) {
    updateTaskIfLocked($conn, $unique_id, 'bet10');
}
if ($total_bets >= 100) {
    updateTaskIfLocked($conn, $unique_id, 'bet100');
}
if ($total_bets >= 500) {
    updateTaskIfLocked($conn, $unique_id, 'bet500');
}
if ($total_bets >= 1000) {
    updateTaskIfLocked($conn, $unique_id, 'bet1000');
}

// ✅ Final response
if (empty($bets_count)) {
    echo json_encode([
        'status' => 'empty',
        'message' => 'No bets found in any table.',
        'unique_id' => $unique_id
    ]);
} else {
    echo json_encode([
        'status' => 'success',
        'unique_id' => $unique_id,
        'total_bets' => $total_bets,
        'bets_count' => $bets_count
    ]);
}

$conn->close();
exit;
?>
<?php
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

$mobile = $_POST['mobile'];
$otp = $_POST['otp'];

$stmt = $conn->prepare("SELECT * FROM mobile_otp WHERE mobile=? AND otp=? AND created_at > (NOW() - INTERVAL 10 MINUTE)");
$stmt->bind_param("ss", $mobile, $otp);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows > 0) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid or expired OTP"]);
}
?>
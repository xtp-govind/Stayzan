<?php  
// Secret defined in Razorpay Dashboard  
$webhook_secret = "Govind@2003#";  

// Step 1: Receive raw POST payload
$payload = file_get_contents("php://input");

// Logging raw payload for debugging
file_put_contents("webhook_govind.txt", "---- Webhook Received at " . date("Y-m-d H:i:s") . " ----" . PHP_EOL, FILE_APPEND);
file_put_contents("webhook_govind.txt", "RAW Payload: " . $payload . PHP_EOL, FILE_APPEND);

// Step 2: Retrieve header signature
$headers = getallheaders();
$razorpay_signature = $headers['X-Razorpay-Signature'] ?? '';
file_put_contents("webhook_govind.txt", "Received Signature: " . $razorpay_signature . PHP_EOL, FILE_APPEND);

// Step 3: Generate expected signature
$expected_signature = hash_hmac('sha256', $payload, $webhook_secret);
file_put_contents("webhook_govind.txt", "Expected Signature: " . $expected_signature . PHP_EOL, FILE_APPEND);

// Step 4: Verify signature
if (!hash_equals($expected_signature, $razorpay_signature)) {
    file_put_contents("webhook_govind.txt", "❌ Signature mismatch! Webhook might be tampered." . PHP_EOL . PHP_EOL, FILE_APPEND);
    http_response_code(403);
    exit("Invalid Signature");
}

// Step 5: Decode JSON payload
$event = json_decode($payload, true);
$event_type = $event['event'] ?? 'unknown';

$payment_entity = $event['payload']['payment']['entity'] ?? [];
$payment_id = $payment_entity['id'] ?? '';
$order_id = $payment_entity['order_id'] ?? '';
$amount = $payment_entity['amount'] ?? 0;
$amount_rupees = $amount / 100;
$status = $payment_entity['status'] ?? '';
$email = $payment_entity['email'] ?? '';
$contact = $payment_entity['contact'] ?? '';
$notes = $payment_entity['notes'] ?? [];
$unique_id = $notes['unique_id'] ?? ''; // Pass this when creating order

file_put_contents("webhook_govind.txt", "✅ Event: $event_type | ₹$amount_rupees | UID: $unique_id" . PHP_EOL, FILE_APPEND);

// Step 6: Connect to Database
$conn = new mysqli("localhost", "u976552851_hellogovind", "Govind@00#", "u976552851_hellogovind");
if ($conn->connect_error) {
    http_response_code(500);
    file_put_contents("webhook_govind.txt", "❌ Database connection failed!" . PHP_EOL . PHP_EOL, FILE_APPEND);
    exit("DB Error");
}

// Step 7: Handle Success
if ($event_type === "payment.captured" && $status === "captured" && $unique_id !== '') {
    $stmt = $conn->prepare("INSERT INTO transactions (unique_id, order_id, payment_id, amount, status) VALUES (?, ?, ?, ?, 'success')");
    $stmt->bind_param("sssd", $unique_id, $order_id, $payment_id, $amount_rupees);
    $stmt->execute();
    $stmt->close();

    $stmt2 = $conn->prepare("UPDATE users SET balance = balance + ? WHERE unique_id = ?");
    $stmt2->bind_param("ds", $amount_rupees, $unique_id);
    $stmt2->execute();
    $stmt2->close();

    file_put_contents("webhook_govind.txt", "✅ Wallet Updated: ₹$amount_rupees added to $unique_id" . PHP_EOL, FILE_APPEND);
}

// Step 8: Handle Failures
if ($event_type === "payment.failed") {
    file_put_contents("webhook_govind.txt", "❌ Payment Failed for Order ID: $order_id" . PHP_EOL, FILE_APPEND);
}

if ($event_type === "refund.processed") {
    file_put_contents("webhook_govind.txt", "🔁 Refund Processed for Payment ID: $payment_id" . PHP_EOL, FILE_APPEND);
}

$conn->close();
file_put_contents("webhook_govind.txt", "✅ Webhook processed and DB closed." . PHP_EOL . PHP_EOL, FILE_APPEND);

http_response_code(200);
echo "✅ Webhook processed";
?>
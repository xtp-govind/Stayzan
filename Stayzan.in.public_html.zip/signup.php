<?php

header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
ob_start(); // Start output buffering

// Database connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    ob_end_flush(); exit;
}

// Function to generate unique ID
function generateUniqueId() {
    $letters = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 2);
    $numbers = substr(str_shuffle("0123456789"), 0, 4);
    return $letters . $numbers;
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $mobile = trim($_POST['mobile']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $referral = isset($_POST['referral']) ? trim($_POST['referral']) : null;

    // Check if mobile already exists
    $check_mobile_stmt = $conn->prepare("SELECT * FROM users WHERE mobile = ?");
    $check_mobile_stmt->bind_param("s", $mobile);
    $check_mobile_stmt->execute();
    $mobile_result = $check_mobile_stmt->get_result();
    if ($mobile_result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'field' => 'mobile', 'message' => 'Mobile number already exists, please login.']);
        $check_mobile_stmt->close();
        ob_end_flush(); exit;
    }
    $check_mobile_stmt->close();

    // Check if email already exists
    $check_email_stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $check_email_stmt->bind_param("s", $email);
    $check_email_stmt->execute();
    $email_result = $check_email_stmt->get_result();
    if ($email_result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'field' => 'email', 'message' => 'Email is already registered, please login.']);
        $check_email_stmt->close();
        ob_end_flush(); exit;
    }
    $check_email_stmt->close();

    // Validate referral code
    $valid_referral = null;
    $level_1 = $level_2 = $level_3 = $level_4 = $level_5 = null;
    if (!empty($referral)) {
        $check_referral_stmt = $conn->prepare("SELECT unique_id FROM users WHERE unique_id = ?");
        $check_referral_stmt->bind_param("s", $referral);
        $check_referral_stmt->execute();
        $referral_result = $check_referral_stmt->get_result();
        if ($referral_result->num_rows > 0) {
            $valid_referral = $referral;
            $level_1 = $referral;

            // Fetch referral chain
            $chain_stmt = $conn->prepare("SELECT level_1, level_2, level_3, level_4 FROM referral_users WHERE unique_id = ?");
            $chain_stmt->bind_param("s", $referral);
            $chain_stmt->execute();
            $chain_result = $chain_stmt->get_result();
            if ($chain_result->num_rows > 0) {
                $chain_data = $chain_result->fetch_assoc();
                $level_2 = $chain_data['level_1'] ?? null;
                $level_3 = $chain_data['level_2'] ?? null;
                $level_4 = $chain_data['level_3'] ?? null;
                $level_5 = $chain_data['level_4'] ?? null;
            }
            $chain_stmt->close();
        }
        $check_referral_stmt->close();
    }

    // Generate Unique ID
    $unique_id = generateUniqueId();

    // Insert user
    $stmt = $conn->prepare("INSERT INTO users (name, email, mobile, password, unique_id, referred_by) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $email, $mobile, $password, $unique_id, $valid_referral);

    if ($stmt->execute()) {
        $_SESSION['unique_id'] = $unique_id;
        $_SESSION['logged_in'] = true;
        $_SESSION['signup_success'] = true;
        $_SESSION['name'] = $name;

        // Referral user chain
        $referral_stmt = $conn->prepare("INSERT INTO referral_users (unique_id, level_1, level_2, level_3, level_4, level_5) VALUES (?, ?, ?, ?, ?, ?)");
        $referral_stmt->bind_param("ssssss", $unique_id, $level_1, $level_2, $level_3, $level_4, $level_5);
        $referral_stmt->execute();
        $referral_stmt->close();

        // Rewards table
        $reward_stmt = $conn->prepare("INSERT INTO referral_rewards (unique_id, referral_balance, wallet_balance, first_refer) VALUES (?, 0.00, 0.00, 'no')");
        $reward_stmt->bind_param("s", $unique_id);
        $reward_stmt->execute();
        $reward_stmt->close();
        
// ✅ Check and update inviter's invite task status
if (!empty($valid_referral)) {
    $check_invite_task = $conn->prepare("SELECT status FROM user_tasks WHERE user_id = ? AND task_id = 'invite'");
    $check_invite_task->bind_param("s", $valid_referral);
    $check_invite_task->execute();
    $invite_result = $check_invite_task->get_result();
    
    if ($invite_result && $invite_result->num_rows > 0) {
        $invite_row = $invite_result->fetch_assoc();
        if ($invite_row['status'] === 'locked') {
            // Update to 'available'
            $update_invite_task = $conn->prepare("UPDATE user_tasks SET status = 'available' WHERE user_id = ? AND task_id = 'invite'");
            $update_invite_task->bind_param("s", $valid_referral);
            $update_invite_task->execute();
            $update_invite_task->close();
        }
    }
    $check_invite_task->close();
}
        
        // Step 1: Get all task IDs from task_master table
        $task_query = $conn->query("SELECT id FROM task_master");
             if ($task_query && $task_query->num_rows > 0) {
                $task_stmt = $conn->prepare("INSERT  INTO user_tasks (user_id, task_id, status) VALUES (?, ?, ?)");

          while ($row = $task_query->fetch_assoc()) {
        $task_id = $row['id'];

        // ✅ Signup task completed, others locked
        $status = ($task_id === 'signup') ? 'completed' : 'locked';

        $task_stmt->bind_param("sss", $unique_id, $task_id, $status);
        $task_stmt->execute();
    }
    $task_stmt->close();
}

        echo json_encode(['status' => 'success', 'message' => 'Signup completed successfully!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
    ob_end_flush();
    exit;
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    $conn->close();
    ob_end_flush();
    exit;
}
?>
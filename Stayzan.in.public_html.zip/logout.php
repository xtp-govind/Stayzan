<?php
session_start();
session_unset();      // sabhi session variables ko unset karta hai
session_destroy();    // session destroy karta hai

// Optional: Cookie bhi clear karna ho to
// setcookie("PHPSESSID", "", time() - 3600, "/");

header("Location: login.php"); // login page pe redirect
exit();
?>
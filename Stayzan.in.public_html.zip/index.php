<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Page</title>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* CSS Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0 0 80px 0; /* Only bottom padding for navigation */
            background: #f0f2f5; /* Lighter background for better contrast */
            min-height: 100vh;
            color: #333;
        }

        .container {
            width: 100%;
            max-width: 100%;
            margin: 0;
            background: white;
            min-height: calc(100vh - 80px);
        }

        /* --- MODIFIED HEADER SECTION --- */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            flex-wrap: wrap; /* Allows items to wrap on smaller screens */
            gap: 15px;
        }

        .balance-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .balance-info .label {
            font-size: 0.8em;
            margin-bottom: 2px;
            opacity: 0.9;
            font-weight: 300;
        }

        .balance-info .amount {
            font-size: 1.8em;
            font-weight: 700;
        }
        
        .balance-info .user-id {
            font-size: 0.75em;
            opacity: 0.8;
            margin-top: 2px;
        }

        .reload-icon {
            cursor: pointer;
            font-size: 1.2em;
            padding: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.15);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .reload-icon:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(180deg);
        }

        .reload-icon.spinning {
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .actions-section {
            display: flex;
            gap: 10px;
        }

        .actions-section button {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border: none;
            border-radius: 25px;
            font-size: 0.9em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: white;
        }

        .recharge-btn {
            background: linear-gradient(135deg, #28a745 0%, #218838 100%);
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
        }

        .withdraw-btn {
            background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%);
            box-shadow: 0 4px 15px rgba(255, 193, 7, 0.3);
        }

        .actions-section button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.2);
        }
        /* --- END OF MODIFIED HEADER SECTION --- */


        /* Rewards Section */
        .rewards-section {
            display: flex;
            justify-content: space-around;
            padding: 20px;
            gap: 15px;
            background: #f8f9fa;
        }

        .reward-button {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            padding: 20px;
            border-radius: 15px;
            background: white;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            flex: 1;
            border: 2px solid transparent;
        }

        .reward-button:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border-color: #667eea;
        }

        .reward-button .icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 10px;
            font-size: 1.8em;
            color: white;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .task-reward .icon {
            background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);
        }

        .check-in .icon {
            background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%);
        }

        .reward-button .text {
            font-size: 0.9em;
            font-weight: 600;
            color: #333;
        }

        /* Ad Slider Section */
        .ad-slider-section {
            padding: 20px;
            background: white;
        }

        .slider-container {
            position: relative;
            width: 100%;
            height: 150px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .slider-wrapper {
            display: flex;
            width: 500%;
            height: 100%;
            transition: transform 0.5s ease-in-out;
        }

        .slide {
            width: 20%;
            height: 100%;
            position: relative;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2em;
            font-weight: bold;
        }

        .slide:nth-child(1) {
            background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
        }

        .slide:nth-child(2) {
            background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
        }

        .slide:nth-child(3) {
            background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
        }

        .slide:nth-child(4) {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .slide:nth-child(5) {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .slide-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            z-index: 2;
        }

        .dots-container {
            display: flex;
            justify-content: center;
            margin-top: 15px;
            gap: 8px;
        }

        .dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #ddd;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .dot.active {
            background: #667eea;
            transform: scale(1.2);
        }

        .dot:hover {
            background: #999;
        }

        /* Games Section */
        .games-section {
            padding: 20px;
            background: #f8f9fa;
        }

        .section-title {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 15px;
            color: #333;
            text-align: center;
        }

        .games-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .game-button {
            background: white;
            border: none;
            border-radius: 15px;
            padding: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            border: 2px solid transparent;
        }

        .game-button:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border-color: #667eea;
        }

        .game-button img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
            
        }

/* Coming Soon style */
.coming-soon {
    position: relative;
    cursor: not-allowed; /* Click disable feel */
    overflow: hidden;
}

.coming-soon::after {
    content: "Coming Soon";
    position: absolute;
    bottom: 60px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.7);
    color: #fff;
    font-size: 14px;
    padding: 3px 8px;
    border-radius: 6px;
    pointer-events: none;
}

/* Blur effect on image */
.coming-soon img {
    filter: grayscale(80%) blur(1px);
    opacity: 0.8;
}

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e9ecef;
            padding: 10px 0;
            z-index: 1000;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 100%;
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #666;
            min-width: 60px;
        }

        .nav-item:hover {
            background: #f8f9fa;
            color: #667eea;
            transform: translateY(-2px);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .nav-item i {
            font-size: 1.3em;
            margin-bottom: 4px;
        }

        .nav-item .nav-text {
            font-size: 0.75em;
            font-weight: 600;
        }

        /* Success message */
        .success-message {
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 12px 18px;
            border-radius: 10px;
            transform: translateX(120%);
            transition: transform 0.4s ease-in-out;
            z-index: 1000;
            font-size: 0.9em;
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
        }

        .success-message.show {
            transform: translateX(0);
        }

        /* Loading state */
        .loading {
            opacity: 0.6;
            pointer-events: none;
        }

        /* Responsive */
        @media (max-width: 480px) {
            .header {
                flex-direction: column;
                align-items: stretch; /* Stretch items to full width */
            }
            
            .actions-section {
                justify-content: space-between; /* Distribute buttons evenly */
            }
            
            .actions-section button {
                flex-grow: 1; /* Allow buttons to grow */
                justify-content: center;
            }

            .rewards-section, .ad-slider-section, .games-section {
                padding: 15px;
            }

            .slider-container {
                height: 120px;
            }
        }
        
/* --- START: CLEAN & MODERN POPUP STYLES --- */
/* Overlay */
.popup-overlay {
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0, 0, 0, 0.55);
    z-index: 2000;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0; visibility: hidden;
    transition: opacity 0.3s ease, visibility 0.3s ease;
}
.popup-overlay.show {
    opacity: 1;
    visibility: visible;
}

/* Popup Content */
.popup-content {
    position: relative;
    background: #fff;
    width: 90%;
    max-width: 360px;
    text-align: center;
    border-radius: 18px;
    padding: 28px 22px;
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
    transform: scale(0.92);
    opacity: 0;
    transition: transform 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275), opacity 0.3s ease;
}
.popup-overlay.show .popup-content {
    transform: scale(1);
    opacity: 1;
}

/* Close Button */
.popup-close-btn {
    position: absolute;
    top: 14px; right: 14px;
    width: 32px; height: 32px;
    background: #f4f4f4;
    border-radius: 50%;
    display: flex; justify-content: center; align-items: center;
    font-size: 1.2em;
    color: #777;
    cursor: pointer;
    transition: background-color 0.2s, color 0.2s, transform 0.2s;
}
.popup-close-btn:hover {
    background-color: #e2e2e2;
    color: #222;
    transform: scale(1.1);
}

/* Title + Subtitle */
.popup-title {
    font-size: 1.7em;
    font-weight: 700;
    margin-bottom: 6px;
    color: #2c3e50;
}
.popup-subtitle {
    font-size: 0.9em;
    color: #666;
    margin-bottom: 18px;
}

/* Text */
.popup-text {
    font-size: 1em;
    color: #444;
    margin-bottom: 15px;
    line-height: 1.45;
}

/* Buttons */
.popup-link {
    display: flex; align-items: center; justify-content: center;
    gap: 10px;
    background: #3498db;
    color: #fff;
    padding: 13px 18px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 600;
    font-size: 1em;
    margin-top: 10px;
    transition: all 0.25s ease;
    box-shadow: 0 4px 15px rgba(52, 152, 219, 0.25);
}
.popup-link:last-of-type {
    background: #2ecc71;
    box-shadow: 0 4px 15px rgba(46, 204, 113, 0.25);
}
.popup-link:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 22px rgba(0,0,0,0.15);
}
.popup-link i {
    font-size: 1.15em;
}

.highlight {
    background: linear-gradient(45deg, #27ae60, #2ecc71);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 700;
}

    </style>
</head>
<body>
    
    
    <!-- START: POPUP HTML --><div id="infoPopup" class="popup-overlay">
  <div class="popup-content">
    <span class="popup-close-btn" onclick="closePopup()">&times;</span>
    
    <h2 class="popup-title">Important Update</h2>
    <p class="popup-subtitle">Stay connected with us for daily rewards & predictions</p>
    
<p class="popup-text">
  Join our <b>Lifafa Telegram Group</b> and earn up to 
  <span class="highlight">₹20 per day</span>.
</p>
    <a href="https://t.me/stayzann" target="_blank" class="popup-link">
      <i class="fab fa-telegram-plane"></i> Join Lifafa Group
    </a>

    <p class="popup-text">Get accurate and official updates in our prediction group.</p>
    <a href="https://t.me/its_stayzan_official" target="_blank" class="popup-link">
      <i class="fab fa-telegram-plane"></i> Join Prediction Group
    </a>
  </div>
</div>

<!-- END: POPUP HTML -->


    <div class="container">
        <!-- Header Section -->
        <div class="header">
            <div class="balance-section">
                <div class="balance-info">
                    <div class="label">Balance</div>
                    <div class="amount">₹<span id="balance">0.00</span></div>
                    <div class="user-id">ID: <span id="unique_id">XYZ</span></div>
                </div>
                <div class="reload-icon" onclick="refreshBalance()" title="Refresh Balance">
                    <i class="fas fa-sync-alt"></i>
                </div>
            </div>
            <div class="actions-section">
                <button class="recharge-btn" onclick="handleRecharge()">
                    <i class="fas fa-plus"></i> Recharge
                </button>
                <button class="withdraw-btn" onclick="handleWithdraw()">
                    <i class="fas fa-minus"></i> Withdraw
                </button>
            </div>
        </div>

        <!-- Rewards Section -->
        <div class="rewards-section">
            <div class="reward-button task-reward"  onclick='location.href ="task_rewards"'>
                <div class="icon">
                    <i class="fas fa-gift"></i>
                </div>
                <div class="text">Task reward</div>
            </div>
            <div class="reward-button check-in" onclick='location.href ="check_in_daily.php"'>
                <div class="icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div class="text">Check in</div>
            </div>
        </div>

        <!-- Ad Slider Section -->
        <div class="ad-slider-section">
            <div class="slider-container">
                <div class="slider-wrapper" id="sliderWrapper">
                    <div class="slide">
                        <div class="slide-content">
                            <h3>🎉 Welcome Bonus!</h3>
                            <p>Get ₹50 on first deposit</p>
                        </div>
                    </div>
                    <div class="slide">
                        <div class="slide-content">
                            <h3>🎮 Play & Win</h3>
                            <p>Daily tournaments available</p>
                        </div>
                    </div>
                    <div class="slide">
                        <div class="slide-content">
                            <h3>💰 Cashback Offer</h3>
                            <p>Up to 20% cashback daily</p>
                        </div>
                    </div>
                    <div class="slide">
                        <div class="slide-content">
                            <h3>🏆 VIP Program</h3>
                            <p>Exclusive rewards for VIP</p>
                        </div>
                    </div>
                    <div class="slide">
                        <div class="slide-content">
                            <h3>🎁 Refer & Earn</h3>
                            <p>₹500 for each successfull referral</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dots-container">
                <span class="dot active" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
                <span class="dot" onclick="currentSlide(4)"></span>
                <span class="dot" onclick="currentSlide(5)"></span>
            </div>
        </div>

        <!-- Games Section -->
       <div class="games-section">
    <div class="section-title">🎮 Popular Games</div>
    <div class="games-grid">
        <button class="game-button" onclick="openGame('fast-parity')">
            <img src="/logo/fast-parity.webp" alt="Fast-Parity Game">
        </button>
        <button class="game-button" onclick="openGame('parity_game')">
            <img src="/logo/parity.webp" alt="Parity Game">
        </button>
       <button class="game-button" onclick="openGame('mine_sweeper')">
            <img src="/logo/mine.webp" alt="Mine sweeper Game">
        </button>

        <!-- Sapre Game (Coming Soon) -->
        <div class="game-button coming-soon">
            <img src="/logo/spare.webp" alt="Sapre Game">
        </div>

        <!-- Aviator Game (Coming Soon) -->
        <div class="game-button coming-soon">
            <img src="/logo/aviator.webp" alt="Dice Game">
        </div>
    </div>
</div>
    </div>

    <!-- Bottom Navigation Bar -->
    <div class="bottom-nav">
        <div class="nav-container">
            <div class="nav-item active" onclick="navigateTo('home')">
                <i class="fas fa-home"></i>
                <div class="nav-text">Home</div>
            </div>
            <div class="nav-item" onclick="navigateTo('invite')">
                <i class="fas fa-users"></i>
                <div class="nav-text">Invite</div>
            </div>
            <div class="nav-item" onclick="navigateTo('recharge')">
                <i class="fas fa-credit-card"></i>
                <div class="nav-text">Recharge</div>
            </div>
            <div class="nav-item" onclick="navigateTo('profile')">
                <i class="fas fa-user"></i>
                <div class="nav-text">My</div>
            </div>
        </div>
    </div>

    <!-- Success Message -->
    <div id="successMessage" class="success-message">
        Balance updated successfully!
    </div>

    <script>
        
     
     // --- START: POPUP JAVASCRIPT ---
const popup = document.getElementById('infoPopup');

// पॉपअप दिखाने का फंक्शन
function showPopup() {
    popup.classList.add('show');
}

// पॉपअप छिपाने का फंक्शन
function closePopup() {
    popup.classList.remove('show');
}

// जब पेज लोड हो, तो पॉपअप दिखाएं
document.addEventListener('DOMContentLoaded', () => {
    // थोड़ी देर बाद पॉपअप दिखाएं ताकि पेज पहले लोड हो जाए
    setTimeout(showPopup, 500); 
});

// जब पॉपअप के बाहर (overlay पर) क्लिक हो, तो उसे बंद करें
popup.addEventListener('click', (event) => {
    // यह सुनिश्चित करें कि क्लिक overlay पर हुआ है, content पर नहीं
    if (event.target === popup) {
        closePopup();
    }
});
// --- END: POPUP JAVASCRIPT ---

        
        // JavaScript Functions

        let currentSlideIndex = 0;
        const totalSlides = 5;

        // Page load पर user data load करें
        document.addEventListener("DOMContentLoaded", function() {
            loadUserData();
            startAutoSlider();
        });

// एक ग्लोबल वैरिएबल यह ट्रैक करने के लिए कि क्या डेटा पहले से लोड हो रहा है
let isFetching = false;


function loadUserData() {
    if (isFetching) {
        console.log("Already fetching data. Please wait.");
        return;
    }

    isFetching = true;

    const balanceElement = document.getElementById('balance');
    const userIdElement = document.getElementById('unique_id');
    const reloadIcon = document.querySelector('.reload-icon i');

    if (!balanceElement || !userIdElement || !reloadIcon) {
        console.error("Error: Required HTML elements not found.");
        isFetching = false; // स्थिति को रीसेट करें
        return;
    }

    // 3. आइकन को घुमाना शुरू करें
    reloadIcon.classList.add('fa-spin');

    // 4. दो प्रॉमिस बनाएं: एक डेटा लाने के लिए, दूसरा 1 सेकंड के टाइमर के लिए
    const fetchDataPromise = fetch('fetch_login_user.php').then(response => {
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = 'login.php';
            }
            throw new Error(`Network response was not ok. Status: ${response.status}`);
        }
        return response.json();
    });

    const timerPromise = new Promise(resolve => setTimeout(resolve, 1000)); // 1000ms = 1 सेकंड

    Promise.all([fetchDataPromise, timerPromise])
        .then(([data]) => { // परिणाम में केवल डेटा प्रॉमिस का डेटा लें
            if (data && data.status === 'success') {
                balanceElement.innerText = data.data.balance;
                userIdElement.innerText = data.data.unique_id;
            } else {
                console.error('Error from server:', data.message || 'Unknown server error');
                balanceElement.innerText = 'Error';
                userIdElement.innerText = 'N/A';
            }
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
            balanceElement.innerText = 'Error';
            userIdElement.innerText = 'N/A';
        })
        .finally(() => {
            // 6. सब कुछ खत्म होने के बाद, आइकन को घुमाना बंद करें और स्थिति को रीसेट करें
            reloadIcon.classList.remove('fa-spin');
            isFetching = false;
        });
}

// refreshBalance फंक्शन को बदलने की आवश्यकता नहीं है, यह वैसे ही काम करेगा
function refreshBalance() {
    loadUserData();
    setTimeout(() => {
        showSuccessMessage("Balance updated successfully!");
    }, 1000); // इसे थोड़ा बढ़ा दें ताकि यह स्पिन खत्म होने के बाद दिखे
}

// showSuccessMessage फंक्शन को भी बदलने की आवश्यकता नहीं है
function showSuccessMessage(text = "Operation successful!") {
    const message = document.getElementById('successMessage');
    message.textContent = text;
    message.classList.add('show');
    setTimeout(() => {
        message.classList.remove('show');
    }, 1000);
}



        // Slider Functions
        function currentSlide(n) {
            showSlide(currentSlideIndex = n - 1);
        }

        function showSlide(n) {
            const slider = document.getElementById('sliderWrapper');
            const dots = document.querySelectorAll('.dot');
            
            if (n >= totalSlides) currentSlideIndex = 0;
            if (n < 0) currentSlideIndex = totalSlides - 1;
            
            slider.style.transform = `translateX(-${currentSlideIndex * 20}%)`;
            
            // Update dots
            dots.forEach(dot => dot.classList.remove('active'));
            dots[currentSlideIndex].classList.add('active');
        }

        function nextSlide() {
            currentSlideIndex++;
            showSlide(currentSlideIndex);
        }

        function startAutoSlider() {
            setInterval(nextSlide, 4000); // Change slide every 4 seconds
        }

        // Bottom navigation function
        function navigateTo(page) {
            // Active state update
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
            event.currentTarget.classList.add('active');
            
            // Page redirection
            switch(page) {
                case 'home':
                    window.location.href = 'index.php';
                    break;
                case 'invite':
                    window.location.href = 'invite.php';
                    break;
                case 'recharge':
                    window.location.href = 'recharge.php';
                    break;
                case 'profile':
                    window.location.href = 'profile.php';
                    break;
            }
        }

        // Other button functions
        function handleRecharge() {
            window.location.href = 'recharge.php';
        }

        function handleWithdraw() {
            window.location.href = 'withdrawal.php';
        }

        function handleTaskReward() {
            window.location.href = 'task_rewards.php';
        }

        function handleCheckIn() {
            window.location.href = 'daily_checkin.php';
        }

        function openGame(gameName) {
            window.location.href = '/' + gameName + '.php';
        }

        // Touch events for mobile slider
        let startX = 0;
        let endX = 0;

        document.querySelector('.slider-container').addEventListener('touchstart', function(e) {
            startX = e.touches[0].clientX;
        });

        document.querySelector('.slider-container').addEventListener('touchend', function(e) {
            endX = e.changedTouches[0].clientX;
            handleSwipe();
        });

        function handleSwipe() {
            const threshold = 50;
            const diff = startX - endX;
            
            if (Math.abs(diff) > threshold) {
                if (diff > 0) {
                    // Swipe left - next slide
                    currentSlideIndex++;
                } else {
                    // Swipe right - previous slide
                    currentSlideIndex--;
                }
                showSlide(currentSlideIndex);
            }
        }
    </script>

</body>
</html>

<?php

ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);

// --- कॉन्फ़िगरेशन ---
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$botToken = "8115363929:AAG1nYXBZCmxYm3jrFE5Np2Om5JU4MRcMy0";

// --- डेटाबेस कनेक्शन ---
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    die("Database connection failed.");
}

// --- टेलीग्राम से इनपुट पढ़ें ---
$content = file_get_contents("php://input");
if (!$content) {
    exit();
}
$update = json_decode($content, true);

// --- संदेश या कॉलबैक क्वेरी को प्रोसेस करें ---
if (isset($update["message"])) {
    $message = $update["message"];
    $chatId = $message["chat"]["id"];
    $text = trim($message["text"] ?? "");
    $username = $message["from"]["username"] ?? "Unknown";
    handleMessage($conn, $chatId, $text, $username);
} elseif (isset($update["callback_query"])) {
    $callbackQuery = $update["callback_query"];
    $chatId = $callbackQuery["message"]["chat"]["id"];
    $data = $callbackQuery["data"];
    $username = $callbackQuery["from"]["username"] ?? "Unknown";
    handleCallback($conn, $chatId, $data, $username, $callbackQuery["id"]);
}

exit();

// --- मुख्य संदेश हैंडलर ---
function handleMessage($conn, $chatId, $text, $username) {
    sendTyping($chatId);

    if (in_array(strtolower($text), ["/start", "hi", "hello"])) {
        handleStart($conn, $chatId);
        return;
    }

    $state = getUserState($conn, $chatId);
    if (!$state) {
        sendMessage($chatId, "शुरू करने के लिए कृपया /start टाइप करें।");
        return;
    }

    switch ($state["step"]) {
        case "waiting_unique_id":
            handleUniqueId($conn, $chatId, $text);
            break;
        case "waiting_problem_detail":
            handleProblemDetail($conn, $chatId, $text, $username, $state);
            break;
        case "waiting_my_complaints_unique_id":
            handleMyComplaintsUniqueId($conn, $chatId, $text);
            break;
        default:
            sendMessage($chatId, "कृपया दिए गए विकल्पों में से चुनें या /start टाइप करके पुनः आरंभ करें।");
            break;
    }
}

// --- कॉलबैक (बटन क्लिक) हैंडलर ---
function handleCallback($conn, $chatId, $data, $username, $callbackQueryId) {
    sendTyping($chatId);
    
    // FAQ Handling
    if ($data === "showFAQ") {
        $faqText = "🧠 *अक्सर पूछे जाने वाले सवाल (FAQ):*\n\n"
                 . "1️⃣ *Withdrawal कब आता है?*\nसभी Withdrawal 24 घंटे में प्रोसेस होते हैं।\n\n"
                 . "2️⃣ *Recharge किया लेकिन Coin नहीं मिले?*\nयदि पैसा कट गया है और कॉइन नहीं आए हैं, तो कृपया Ticket बनाएं।\n\n"
                 . "3️⃣ *Password भूल गए?*\nLogin पेज पर 'Forgot Password' का उपयोग करें।\n\n"
                 . "4️⃣ *Account बंद हो गया?*\nTicket बनाकर Support से संपर्क करें।\n\n"
                 . "5️⃣ *Balance गलत दिख रहा है?*\nTransaction History जांचें या Ticket बनाएं।\n\n"
                 . "और जानकारी के लिए /start करके Ticket बनाएं।";

        sendMessage($chatId, $faqText);
        answerCallbackQuery($callbackQueryId);
        return;
    }

    $state = getUserState($conn, $chatId);
    if ($state && $state["step"] === "waiting_issue_type") {
        if ($data === 'MyComplaints') {
            handleMyComplaintsStart($conn, $chatId);
        } else {
            handleIssueChoice($conn, $chatId, $data);
        }
    }
    answerCallbackQuery($callbackQueryId);
}

// --- चरण 1: /start कमांड ---
function handleStart($conn, $chatId) {
    sendTyping($chatId);

    $msg = "नमस्ते 👋\nकृपया अपनी समस्या का प्रकार चुनें:";
    $keyboard = [
        "inline_keyboard" => [
            [["text" => "1️⃣ Withdrawal", "callback_data" => "Withdrawal"], ["text" => "2️⃣ Recharge", "callback_data" => "Recharge"]],
            [["text" => "3️⃣ Password", "callback_data" => "Password"], ["text" => "4️⃣ Account", "callback_data" => "Account"]],
            [["text" => "5️⃣ UPI", "callback_data" => "UPI"], ["text" => "6️⃣ Balance", "callback_data" => "Balance"]],
            [["text" => "7️⃣ Other", "callback_data" => "Other"]],
            [["text" => "📄 My Complaints", "callback_data" => "MyComplaints"]],
            [["text" => "❓ FAQ", "callback_data" => "showFAQ"]]
        ]
    ];
    setUserState($conn, $chatId, "waiting_issue_type");
    sendMessage($chatId, $msg, json_encode($keyboard));
}

// --- चरण 2: समस्या का प्रकार चुनना ---
function handleIssueChoice($conn, $chatId, $issueType) {
    sendTyping($chatId);

    setUserState($conn, $chatId, "waiting_unique_id", ["issue_type" => $issueType]);
    $msg = "🔍 आपने चुना: *$issueType*\n\nअब कृपया अपनी Unique ID भेजें (उदाहरण: SV1234)";
    sendMessage($chatId, $msg);
}

// --- चरण 3: Unique ID प्राप्त करना ---
function handleUniqueId($conn, $chatId, $text) {
    sendTyping($chatId);

    if (!preg_match("/^[A-Z]{2}\d{4,6}$/i", $text)) {
        sendMessage($chatId, "❗अमान्य प्रारूप।\nकृपया एक सही Unique ID भेजें (उदाहरण: SV1234)।");
        return;
    }
    $unique_id = strtoupper($text);

    $stmt = $conn->prepare("SELECT unique_id, name FROM users WHERE unique_id = ?");
    $stmt->bind_param("s", $unique_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        sendMessage($chatId, "❗यह Unique ID (*$unique_id*) हमारे रिकॉर्ड में नहीं मिली। कृपया सही ID भेजें।");
        return;
    }
    $user_data = $result->fetch_assoc();
    $user_name = $user_data['name'] ?? 'User';

    $state_data = getUserState($conn, $chatId);
    $state_data['unique_id'] = $unique_id;
    $state_data['user_name'] = $user_name;
    setUserState($conn, $chatId, "waiting_problem_detail", $state_data);

    $msg = "✅ आपकी Unique ID सत्यापित हो गई है!\n\nHello $user_name,\nअब कृपया अपनी समस्या विस्तार से लिखें।\n(उदाहरण: ₹100 का रिचार्ज किया लेकिन कॉइन नहीं मिले)";
    sendMessage($chatId, $msg);
}

// --- चरण 4: समस्या का विवरण और टिकट बनाना ---
function handleProblemDetail($conn, $chatId, $text, $username, $state) {
    sendTyping($chatId);

    $issueType = $state["issue_type"];
    $uniqueId = $state["unique_id"];
    $userNameFromState = $state["user_name"] ?? $username;
    $ticketId = "TKT" . rand(10000, 99999);

    $stmt = $conn->prepare("INSERT INTO complaints (user_id, username, unique_id, issue_type, message, ticket_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $chatId, $userNameFromState, $uniqueId, $issueType, $text, $ticketId);
    $stmt->execute();

    deleteUserState($conn, $chatId);

    $autoReplies = [
        "Withdrawal" => "सभी withdrawal 24 घंटे के अंदर process हो जाते हैं...",
        "Recharge"   => "यदि आपका पैसा कट गया है और कॉइन नहीं आए हैं...",
        "Password"   => "आप लॉगिन पेज पर 'Forgot Password' विकल्प का उपयोग करें...",
        "Account"    => "यदि आपका अकाउंट ब्लॉक/सस्पेंड हो गया है...",
        "UPI"        => "कृपया सुनिश्चित करें कि आपकी UPI ID सही है...",
        "Balance"    => "कृपया अपने ट्रांजैक्शन हिस्ट्री को फिर से जांचें...",
        "Other"      => "आपकी समस्या दर्ज कर ली गई है, हमारी टीम जल्द ही..."
    ];
    $autoReply = $autoReplies[$issueType] ?? "हमारी टीम आपकी समस्या की जांच करेगी।";

    $finalMsg = "✅ *आपकी शिकायत सफलतापूर्वक दर्ज की गई है!*\n\n"
              . "🆔 *Ticket ID:* `$ticketId`\n"
              . "🔖 *समस्या का प्रकार:* $issueType\n\n"
              . "📌 $autoReply\n\n"
              . "इस Ticket ID को भविष्य के संदर्भ के लिए सहेज कर रखें।";
    sendMessage($chatId, $finalMsg);
}

// --- 'My Complaints' ---
function handleMyComplaintsStart($conn, $chatId) {
    sendTyping($chatId);

    setUserState($conn, $chatId, 'waiting_my_complaints_unique_id');
    sendMessage($chatId, "कृपया अपनी Unique ID भेजें ताकि हम आपकी पिछली शिकायतें ढूंढ सकें।");
}

function handleMyComplaintsUniqueId($conn, $chatId, $text) {
    sendTyping($chatId);

    if (!preg_match("/^[A-Z]{2}\d{4,6}$/i", $text)) {
        sendMessage($chatId, "❗अमान्य प्रारूप।\nकृपया एक सही Unique ID भेजें (उदाहरण: SV1234)।");
        return;
    }
    $unique_id = strtoupper($text);

    $stmt = $conn->prepare("SELECT unique_id FROM users WHERE unique_id = ?");
    $stmt->bind_param("s", $unique_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        sendMessage($chatId, "❗यह Unique ID (*$unique_id*) हमारे रिकॉर्ड में नहीं मिली। कृपया सही ID भेजें।");
        return;
    }

    $stmt = $conn->prepare("SELECT issue_type, message, ticket_id, status, status_text FROM complaints WHERE unique_id = ? ORDER BY created_at DESC");
    $stmt->bind_param("s", $unique_id);
    $stmt->execute();
    $complaintsResult = $stmt->get_result();

    if ($complaintsResult->num_rows > 0) {
        $responseMsg = "✅ आपकी पिछली शिकायतें ($unique_id):\n\n";
        while ($row = $complaintsResult->fetch_assoc()) {
            $responseMsg .= "----------------------------------------\n";
            $responseMsg .= "🆔 *Ticket ID:* `{$row['ticket_id']}`\n";
            $responseMsg .= "🔖 *समस्या का प्रकार:* {$row['issue_type']}\n";
            $responseMsg .= "📝 *विवरण:* {$row['message']}\n";
            $responseMsg .= "📊 *स्थिति:* " . ($row['status'] ?? 'N/A') . "\n";
            $responseMsg .= "💬 *स्थिति विवरण:* " . ($row['status_text'] ?? 'N/A') . "\n";
        }
        sendMessage($chatId, $responseMsg);
    } else {
        sendMessage($chatId, "इस Unique ID ($unique_id) के लिए कोई शिकायत नहीं मिली।");
    }

    deleteUserState($conn, $chatId);
}

// --- Typing Animation Function ---
function sendTyping($chatId) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendChatAction";
    $post = [
        "chat_id" => $chatId,
        "action" => "typing"
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}


// --- सहायक फ़ंक्शंस ---

function getUserState($conn, $chatId) {
    $stmt = $conn->prepare("SELECT step, issue_type, unique_id, user_name FROM user_state WHERE chat_id = ?");
    $stmt->bind_param("i", $chatId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function setUserState($conn, $chatId, $step, $data = []) {
    $issueType = $data["issue_type"] ?? null;
    $uniqueId = $data["unique_id"] ?? null;
    $userName = $data["user_name"] ?? null; // नया फील्ड

    $state = getUserState($conn, $chatId);
    if ($state) {
        // यदि पहले से कोई state है तो उसे अपडेट करें
        $currentIssueType = $state["issue_type"];
        $currentUniqueId = $state["unique_id"];
        $currentUserName = $state["user_name"];
        
        $newIssueType = $issueType ?? $currentIssueType;
        $newUniqueId = $uniqueId ?? $currentUniqueId;
        $newUserName = $userName ?? $currentUserName; // नया फील्ड

        $stmt = $conn->prepare("UPDATE user_state SET step = ?, issue_type = ?, unique_id = ?, user_name = ? WHERE chat_id = ?");
        $stmt->bind_param("ssssi", $step, $newIssueType, $newUniqueId, $newUserName, $chatId);
    } else {
        // नया state डालें
        $stmt = $conn->prepare("INSERT INTO user_state (chat_id, step, issue_type, unique_id, user_name) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $chatId, $step, $issueType, $uniqueId, $userName);
    }
    $stmt->execute();
}

function deleteUserState($conn, $chatId) {
    $stmt = $conn->prepare("DELETE FROM user_state WHERE chat_id = ?");
    $stmt->bind_param("i", $chatId);
    $stmt->execute();
}

function sendMessage($chatId, $text, $replyMarkup = null) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $post = [
        "chat_id" => $chatId,
        "text" => $text,
        "parse_mode" => "Markdown"
    ];
    if ($replyMarkup) {
        $post["reply_markup"] = $replyMarkup;
    }
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

function answerCallbackQuery($callbackQueryId) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/answerCallbackQuery";
    $post = ["callback_query_id" => $callbackQueryId];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

?>

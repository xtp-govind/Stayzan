<?php
$servername = "localhost";
$username = "u976552851_party"; // Same as DB name in Hostinger
$password = "Govind@00#";       // Your provided password
$database = "u976552851_party";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
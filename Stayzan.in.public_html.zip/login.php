<?php
session_start();

if (isset($_GET['ref'])) {
    $_SESSION['referrer_code'] = $_GET['ref'];
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Login - India's #1 Gaming Platform</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* --- Reset & Base Styles --- */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            padding: 20px;
            color: #333;
            overflow-x: hidden;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        /* --- Backgrounds --- */
        body.login-active { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        body.signup-active { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        body.forgot-active { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    /* --- Logo Section --- */
.logo-section {
    text-align: center;
    margin-bottom: 50px;
    padding-top: 30px;
}

/* अपडेट किया गया लोगो टेक्स्ट स्टाइल */
.logo-text {
    font-family: 'Times New Roman', Times, serif;
    font-size: 70px !important;
    font-weight: bold;
    text-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* सफ़ेद टेक्स्ट पर शैडो बेहतर दिखेगा */
}

.logo-text .logo-s {
    color: #28a745; /* हरा */
}

.logo-text .logo-tay {
    color: #ffffff; /* सफ़ेद */
}

.logo-text .logo-za {
    color: #dc3545; /* लाल */
}

.logo-text .logo-n {
    color: #ffffff; /* सफ़ेद */
}

/* फ्लोटिंग एनिमेशन (यह पहले से आपके कोड में है) */
@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
}

        /* --- Form Container --- */
        .form-container {
            max-width: 100%;
            width: 100%;
            padding: 0 20px;
            display: none;
            animation: fadeInUp 0.8s ease-out;
        }

        .form-container.active {
            display: block;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* --- Form Titles --- */
        .form-title {
            text-align: center;
            font-size: 2.5em;
            font-weight: 700;
            margin-bottom: 10px;
            color: rgba(255, 255, 255, 0.95);
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        .form-subtitle {
            text-align: center;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 40px;
            font-size: 1.1em;
            font-weight: 400;
        }

        /* --- Input Groups --- */
        .input-group {
            position: relative;
            margin-bottom: 25px;
            width: 100%;
        }

        .input-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
            font-size: 1.2em;
            z-index: 2;
            transition: color 0.3s ease;
        }

        .form-input {
            width: 100%;
            padding: 18px 25px 18px 60px;
            border: 2px solid rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            font-size: 1.1em;
            font-family: 'Poppins', sans-serif;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            color: white;
            transition: all 0.3s ease;
            outline: none;
        }

        .form-input::placeholder { color: rgba(255, 255, 255, 0.7); }
        .form-input:focus {
            border-color: rgba(255, 255, 255, 0.6);
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
        }
        .form-input:focus + .input-icon { color: white; }

        .password-field { padding-right: 60px; }

        .toggle-password {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
            cursor: pointer;
            font-size: 1.2em;
            transition: color 0.3s ease;
            z-index: 2;
        }
        .toggle-password:hover { color: white; }

        /* --- Buttons --- */
        .btn-primary {
            width: 100%;
            padding: 18px;
            border: none;
            border-radius: 15px;
            font-size: 1.2em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            margin-top: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .login-active .btn-primary { background: linear-gradient(135deg, #ffffff, #f8f9fa); color: #667eea; box-shadow: 0 8px 25px rgba(255, 255, 255, 0.3); }
        .login-active .btn-primary:hover { transform: translateY(-3px); box-shadow: 0 12px 35px rgba(255, 255, 255, 0.4); }
        .signup-active .btn-primary { background: linear-gradient(135deg, #ffffff, #fff5f5); color: #f5576c; box-shadow: 0 8px 25px rgba(255, 255, 255, 0.3); }
        .signup-active .btn-primary:hover { transform: translateY(-3px); box-shadow: 0 12px 35px rgba(255, 255, 255, 0.4); }
        .forgot-active .btn-primary { background: linear-gradient(135deg, #ffffff, #f0f9ff); color: #4facfe; box-shadow: 0 8px 25px rgba(255, 255, 255, 0.3); }
        .forgot-active .btn-primary:hover { transform: translateY(-3px); box-shadow: 0 12px 35px rgba(255, 255, 255, 0.4); }
        .btn-primary:disabled { background: rgba(255, 255, 255, 0.3); cursor: not-allowed; transform: none; }

        /* --- Links --- */
        .forgot-link {
            display: block;
            text-align: right;
            margin: -15px 0 25px 0;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            font-size: 1em;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .forgot-link:hover { color: white; text-shadow: 0 0 10px rgba(255, 255, 255, 0.5); }

        .toggle-text {
            text-align: center;
            margin-top: 35px;
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.1em;
        }
        .toggle-link {
            color: white;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.3);
        }
        .toggle-link:hover { text-shadow: 0 0 15px rgba(255, 255, 255, 0.8); }

        /* --- Terms & Conditions --- */
        .terms-group {
            display: flex;
            align-items: flex-start;
            text-align: left;
            margin: 25px 0;
            font-size: 1em;
            color: rgba(255, 255, 255, 0.8);
        }
        .terms-group input[type="checkbox"] {
            margin-right: 15px;
            margin-top: 3px;
            width: 20px;
            height: 20px;
            accent-color: white;
            flex-shrink: 0;
        }
        .terms-group a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            text-shadow: 0 0 5px rgba(255, 255, 255, 0.3);
        }

        /* --- Loading Spinner --- */
        .btn-primary .spinner {
            display: none;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 24px;
            height: 24px;
            border: 3px solid rgba(0, 0, 0, 0.1);
            border-top-color: currentColor;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        .btn-primary.processing .button-text { visibility: hidden; }
        .btn-primary.processing .spinner { display: block; }
        @keyframes spin { to { transform: translate(-50%, -50%) rotate(360deg); } }

        /* --- Overlay & Modal --- */
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        .overlay.active { opacity: 1; visibility: visible; }
        .modal {
            background: white;
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            width: 90%;
            max-width: 450px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }
        .overlay.active .modal { transform: scale(1); }
        .modal h3 {
            margin-bottom: 25px;
            color: #2d3748;
            font-size: 1.4em;
            font-weight: 600;
        }
        .modal .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            margin-top: 20px;
        }

        /* --- Responsive Design --- */
        @media (max-width: 768px) {
            body { padding: 15px; }
            .logo-section { margin-bottom: 40px; padding-top: 20px; }
            .logo-text { font-size: 50px; } /* Adjust logo size for smaller screens */
            .form-title { font-size: 2em; }
            .form-input { padding: 16px 20px 16px 55px; font-size: 1em; }
            .input-icon { left: 18px; font-size: 1.1em; }
            .toggle-password { right: 18px; font-size: 1.1em; }
        }

        @media (max-width: 480px) {
            .form-container { padding: 0 15px; }
            .logo-text { font-size: 40px; } /* Adjust logo size for mobile */
            .form-title { font-size: 1.8em; }
            .form-subtitle { font-size: 1em; }
        }
        
        /* --- ब्राउज़र ऑटोफिल स्टाइल को ठीक करने के लिए --- */
input:-webkit-autofill,
input:-webkit-autofill:hover, 
input:-webkit-autofill:focus, 
input:-webkit-autofill:active {
    -webkit-text-fill-color: white !important; /* टेक्स्ट का रंग सफ़ेद करें */
    -webkit-box-shadow: 0 0 0px 1000px rgba(255, 255, 255, 0.1) inset !important; /* बैकग्राउंड को ट्रांसपेरेंट जैसा बनाएं */
    transition: background-color 5000s ease-in-out 0s; /* बैकग्राउंड बदलने वाले एनिमेशन को बहुत लंबा कर दें */
    backdrop-filter: blur(10px); /* ब्लर इफ़ेक्ट वापस लगाएं */
    font-family: 'Poppins', sans-serif; /* फॉन्ट को भी ठीक करें */
    font-size: 1.1em; /* फॉन्ट साइज को भी ठीक करें */
}





    </style>
</head>
<body class="login-active">
    <!-- Logo Section -->
<div class="logo-section">
    <h1 class="logo-text">
        <span class="logo-s">S</span><span class="logo-tay">tay</span><span class="logo-za">Za</span><span class="logo-n">n</span>
    </h1>
</div>


    <!-- Login Form -->
    <div id="loginForm" class="form-container active">
        <h1 class="form-title">Welcome Back!</h1>
        <p class="form-subtitle">Sign in to continue your gaming journey</p>
        
        <form id="loginFormAjax">
            <div class="input-group">
                <i class="fas fa-phone input-icon"></i>
                <input type="tel" id="loginMobile" name="mobile" class="form-input" placeholder="Mobile Number" required>
            </div>
            <div class="input-group">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" id="loginPassword" name="password" class="form-input password-field" placeholder="Password" required>
                <i class="fas fa-eye-slash toggle-password" onclick="togglePassword('loginPassword')"></i>
            </div>
            <a href="#" class="forgot-link" onclick="showForgetForm(event)">Forgot Password?</a>
            <button type="submit" class="btn-primary">
                <span class="button-text">Sign In</span>
                <span class="spinner"></span>
            </button>
        </form>
        <p class="toggle-text">Don't have an account? <a class="toggle-link" onclick="showSignupForm()">Create Account</a></p>
    </div>

   <div id="signupForm" class="form-container">
        <h1 class="form-title">Join the Game!</h1>
        <p class="form-subtitle">Create your account and start winning</p>
        
        <form id="signupFormInternal">
            <!-- मौजूदा इनपुट फ़ील्ड्स -->
            <div class="input-group">
                <i class="fas fa-user input-icon"></i>
                <input type="text" id="name" name="name" class="form-input" placeholder="Full Name" required>
            </div>
            <div class="input-group">
                <i class="fas fa-envelope input-icon"></i>
                <input type="email" id="email" name="email" class="form-input" placeholder="Email Address" required>
            </div>
            <div class="input-group">
                <i class="fas fa-phone input-icon"></i>
                <input type="tel" id="signupMobile" name="mobile" class="form-input" placeholder="10-Digit Mobile Number" pattern="\d{10}" required>
            </div>
            <div class="input-group">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" id="signupPassword" name="password" class="form-input password-field" placeholder="Create Password" required>
                <i class="fas fa-eye-slash toggle-password" onclick="togglePassword('signupPassword')"></i>
            </div>

           <!-- बाकी का फॉर्म -->
            <div class="input-group">
                <i class="fas fa-gift input-icon"></i>
                <input type="text" id="referralCode" name="referral" class="form-input" placeholder="Referral Code (Optional)">
            </div>
            <div class="terms-group">
                <input type="checkbox" id="consent" name="consent" required>
                <label for="consent">I agree to the <a href="/terms_and_condition" target="_blank">Terms</a> & <a href="/privacy_policy" target="_blank">Privacy Policy</a>.</label>
            </div>
            <button type="submit" class="btn-primary">
                <span class="button-text">Create Account</span>
                <span class="spinner"></span>
            </button>
        </form>
        <p class="toggle-text">Already have an account? <a class="toggle-link" onclick="showLoginForm()">Sign In</a></p>
    </div>

    <!-- Forgot Password Form -->
    <div id="forgetPasswordForm" class="form-container">
        <h1 class="form-title">Reset Password</h1>
        <p class="form-subtitle">Enter your details to reset your password</p>
        
        <form id="forgetPasswordAjax">
            <div class="input-group">
                <i class="fas fa-envelope input-icon"></i>
                <input type="email" id="forgetEmail" name="email" class="form-input" placeholder="Registered Email" required>
            </div>
            <div class="input-group">
                <i class="fas fa-phone input-icon"></i>
                <input type="tel" id="forgetMobile" name="mobile" class="form-input" placeholder="Registered Mobile" required>
            </div>
            <div class="input-group">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" id="newPassword" name="password" class="form-input password-field" placeholder="New Password" required>
                <i class="fas fa-eye-slash toggle-password" onclick="togglePassword('newPassword')"></i>
            </div>
            <button type="submit" class="btn-primary">
                <span class="button-text">Reset Password</span>
                <span class="spinner"></span>
            </button>
        </form>
        <p class="toggle-text">Remembered your password? <a class="toggle-link" onclick="showLoginForm()">Sign In</a></p>
    </div>

    <!-- Overlay for Messages -->
    <div id="overlay" class="overlay">
        <div class="modal">
            <h3 id="modalMessage"></h3>
            <button class="btn-primary" onclick="closeOverlay()">Close</button>
        </div>
    </div>

    <script>
        window.onload = function () {
            const urlParams = new URLSearchParams(window.location.search);
            const ref = urlParams.get('ref');
            const referralInput = document.getElementById("referralCode");

            if (ref && referralInput) {
                referralInput.value = ref;
                referralInput.readOnly = true; // ✅ Disable editing (but still sends in form)
                referralInput.style.backgroundColor = "#f0f0f0"; // Optional: show it's readonly
            }
        };

        // सभी फॉर्म कंटेनरों को प्राप्त करें
        const loginForm = document.getElementById('loginForm');
        const signupForm = document.getElementById('signupForm');
        const forgetPasswordForm = document.getElementById('forgetPasswordForm');

        // पासवर्ड दृश्यता टॉगल करें
        function togglePassword(Id) {
            const passwordInput = document.getElementById(Id);
            const toggleIcon = passwordInput.nextElementSibling;
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            }
        }
      
        // फॉरगेट पासवर्ड फॉर्म दिखाएं
        function showForgetForm(e) {
            e.preventDefault();
            loginForm.classList.remove('active');
            signupForm.classList.remove('active');
            forgetPasswordForm.classList.add('active');
            document.body.className = 'forgot-active';
        }

        // लॉगिन फॉर्म दिखाएं
        function showLoginForm() {
            forgetPasswordForm.classList.remove('active');
            signupForm.classList.remove('active');
            loginForm.classList.add('active');
            document.body.className = 'login-active';
        }

        // साइनअप फॉर्म दिखाएं
        function showSignupForm() {
            loginForm.classList.remove('active');
            forgetPasswordForm.classList.remove('active');
            signupForm.classList.add('active');
            document.body.className = 'signup-active';
        }

    // साइनअप फॉर्म सबमिशन को हैंडल करें
    function submitSignupForm(event) {
        event.preventDefault();

        const submitButton = document.querySelector('#signupFormInternal button[type="submit"]');
        
        if (submitButton.classList.contains('processing')) {
            return;
        }

        submitButton.disabled = true;
        submitButton.classList.add('processing');

        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const mobile = document.getElementById("signupMobile").value;
        const password = document.getElementById("signupPassword").value;
        const referral = document.getElementById("referralCode").value;

        if (!name || !email || !mobile || !password) {
            showOverlay("Please fill in all fields.", "error");
            submitButton.disabled = false;
            submitButton.classList.remove('processing');
            return;
        }

        const userData = `name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&mobile=${encodeURIComponent(mobile)}&password=${encodeURIComponent(password)}&referral=${encodeURIComponent(referral)}`;

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "signup", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                submitButton.disabled = false;
                submitButton.classList.remove('processing');
                if (xhr.status == 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.status === "success") {
                            window.location.href = "index.php?signup_success=true";
                        } else {
                            showOverlay(response.message, "error");
                        }
                    } catch (e) {
                        const errorDetails = "Error: Invalid response from server.\n\nServer Response:\n" + xhr.responseText;
                        showOverlay(errorDetails, "error");
                    }
                } else {
                    showOverlay("Error: Unable to process the request. Status: " + xhr.status, "error");
                }
            }
        };
        xhr.send(userData);
    }

    document.getElementById("signupFormInternal").addEventListener("submit", submitSignupForm);

        // संदेश के साथ ओवरले दिखाएं
        function showOverlay(message, type) {
            const overlay = document.getElementById("overlay");
            const modalMessage = document.getElementById("modalMessage");
            modalMessage.textContent = message;
            modalMessage.style.color = type === "success" ? "green" : "black";
            overlay.classList.add("active");
        }

        // ओवरले बंद करें
        function closeOverlay() {
            document.getElementById("overlay").classList.remove("active");
        }

        // लॉगिन फॉर्म सबमिशन को हैंडल करें
        document.getElementById("loginFormAjax").addEventListener("submit", function(event) {
            event.preventDefault();
            const mobile = document.getElementById("loginMobile").value;
            const password = document.getElementById("loginPassword").value;
            if (!mobile || !password) {
                showOverlay("Please fill in all fields.");
                return;
            }
            const loginData = `mobile=${encodeURIComponent(mobile)}&password=${encodeURIComponent(password)}`;
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "login2", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    if (xhr.responseText.trim() === "Success") {
                        window.location.href = "index";
                    } else {
                          showOverlay(xhr.responseText);
                    }
                }
            };
            xhr.send(loginData);
        });
   
        // फॉरगेट पासवर्ड को हैंडल करें
        document.getElementById("forgetPasswordAjax").addEventListener("submit", function(e) {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);
            fetch("forget_password", { method: "POST", body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showOverlay("✅ Password updated successfully!");
                    fetch("security_notification", { method: "POST", body: formData })
                    .finally(() => {
                        window.location.href = "login";
                    });
                } else {
                    showOverlay("❌ " + (data.error || "Failed to update password."));
                }
            })
            .catch(err => {
                console.error("💥 Server error:", err);
                showOverlay("Something went wrong. Try again later.");
            });
        });
    
        // राइट-क्लिक और टेक्स्ट सिलेक्शन को डिसेबल करें
        document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
        document.addEventListener('selectstart', function (e) { e.preventDefault(); });    

        // बैक बटन से आने पर पेज को रीलोड करें
        if (performance.navigation.type == 2) {
            location.reload();
        }
        
    
        
    </script>
</body>
</html>

<?php
header('Content-Type: application/json');
session_start();

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}


$unique_id = $_SESSION['unique_id'] ?? null;
if (!$unique_id) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit;
}

$sql = "
    SELECT tm.id, tm.title, tm.description, tm.reward, tm.icon,
           ut.status, ut.completed_at
    FROM task_master tm
    LEFT JOIN user_tasks ut ON tm.id = ut.task_id AND ut.user_id = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $unique_id);
$stmt->execute();
$res = $stmt->get_result();

$tasks = [];
while ($row = $res->fetch_assoc()) {
    $tasks[] = [
        "id" => $row["id"],
        "title" => $row["title"],
        "description" => $row["description"],
        "reward" => (int)$row["reward"],
        "icon" => $row["icon"],
        "status" => $row["status"] ?? 'locked',
        "completedAt" => $row["completed_at"]
    ];
}

echo json_encode(["status" => "success", "tasks" => $tasks]);
?>
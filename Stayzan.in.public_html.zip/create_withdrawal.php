<?php
session_start();
header('Content-Type: application/json');

// ✅ DB Connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "step" => "db", "message" => "Database connection failed"]);
    exit();
}

// ✅ Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "step" => "method", "message" => "Only POST requests are allowed"]);
    exit();
}

// ✅ Session Check
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["status" => "error", "step" => "session", "message" => "User not logged in"]);
    exit();
}
$unique_id = $_SESSION['unique_id'];

// ✅ Parse JSON body
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);
if (!$data) {
    echo json_encode(["status" => "error", "step" => "json_decode", "message" => "Invalid JSON body", "debug" => [["step" => "raw_input", "data" => $raw]]]);
    exit();
}

// ✅ Extract and Validate Inputs
$amount = isset($data['amount']) ? floatval($data['amount']) : 0;
$account_raw = isset($data['account']) ? $data['account'] : '';

if ($amount < 530) {
    echo json_encode(["status" => "error", "step" => "amount_check", "message" => "Minimum withdrawal amount is ₹530"]);
    exit();
}
if (empty($account_raw)) {
    echo json_encode(["status" => "error", "step" => "account_check", "message" => "Account is required"]);
    exit();
}

// ✅ Detect Method
if (strpos($account_raw, 'upi-') === 0) {
    $method = 'UPI';
    $account = str_replace('upi-', '', $account_raw);
} elseif (strpos($account_raw, 'bank-') === 0) {
    $method = 'Bank';
    $account = str_replace('bank-', '', $account_raw);
} else {
    echo json_encode(["status" => "error", "step" => "account_type", "message" => "Invalid account format"]);
    exit();
}

$txn_check = $conn->prepare("SELECT id FROM transactions WHERE unique_id = ? AND amount >= 500 AND status = 'success' LIMIT 1");
$txn_check->bind_param("s", $unique_id);
$txn_check->execute();
$txn_result = $txn_check->get_result();

if ($txn_result->num_rows === 0) {
    echo json_encode(["status" => "error", "step" => "transaction_check", "message" => "You must have at least one successful Recharge of ₹500+ before withdrawal"]);
    exit();
}

// ✅ Balance Check
$balance_result = $conn->query("SELECT balance FROM users WHERE unique_id = '$unique_id'");
if ($balance_result && $balance_row = $balance_result->fetch_assoc()) {
    $current_balance = floatval($balance_row['balance']);
    if ($amount > $current_balance) {
        echo json_encode(["status" => "error", "step" => "balance_check", "message" => "Insufficient balance"]);
        exit();
    }
} else {
    echo json_encode(["status" => "error", "step" => "fetch_balance", "message" => "Unable to fetch balance"]);
    exit();
}

// ✅ Insert Withdrawal Request
$stmt = $conn->prepare("INSERT INTO withdrawals (unique_id, method, amount, account, status) VALUES (?, ?, ?, ?, 'pending')");
$stmt->bind_param("ssds", $unique_id, $method, $amount, $account);
if ($stmt->execute()) {
    // ✅ Update User Balance
    $new_balance = $current_balance - $amount;
    $update_stmt = $conn->prepare("UPDATE users SET balance = ? WHERE unique_id = ?");
    $update_stmt->bind_param("ds", $new_balance, $unique_id);
    $update_stmt->execute();
    $update_stmt->close();

    echo json_encode(["status" => "success", "message" => "Withdrawal request submitted"]);
} else {
    echo json_encode(["status" => "error", "step" => "insert", "message" => "Database error"]);
}

$stmt->close();
$conn->close();
?>
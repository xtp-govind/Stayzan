<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit();
}

$unique_id = $_SESSION['unique_id'];

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// ✅ Fetch balance from users table
$user_balance = 0;
$sql1 = "SELECT balance FROM users WHERE unique_id = ?";
$stmt1 = $conn->prepare($sql1);
$stmt1->bind_param("s", $unique_id);
$stmt1->execute();
$result1 = $stmt1->get_result();
if ($result1->num_rows > 0) {
    $row = $result1->fetch_assoc();
    $user_balance = $row['balance'];
}

// ✅ Fetch wallet_balance from referral_rewards table
$referral_wallet = 0;
$sql2 = "SELECT wallet_balance FROM referral_rewards WHERE unique_id = ?";
$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("s", $unique_id);
$stmt2->execute();
$result2 = $stmt2->get_result();
if ($result2->num_rows > 0) {
    $row = $result2->fetch_assoc();
    $referral_wallet = $row['wallet_balance'];
}

// ✅ Output JSON
echo json_encode([
    "status" => "success",
    "balance" => number_format((float)$user_balance, 2, '.', ''),
    "wallet_balance" => number_format((float)$referral_wallet, 2, '.', '')
]);

$conn->close();
?>
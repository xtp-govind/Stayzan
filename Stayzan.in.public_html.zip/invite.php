<?php
session_start();
// Redirect to login if not authenticated
if (!isset($_SESSION['unique_id'])) {
    header("Location: login.php"); // It's good practice to use .php extension
    exit();
}
$unique_id = $_SESSION['unique_id'];
// Construct the invitation link
$invite_link = "https://stayzan.in/login?ref=" . htmlspecialchars($unique_id, ENT_QUOTES, 'UTF-8');
?>

<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invite Friends & Earn</title>
    <!-- Font Awesome CDN for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* General Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            color: #333;
            padding-bottom: 80px; /* Space for bottom nav */
        }

        .container {
            width: 100%;
            max-width: 100%;
            padding: 20px;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            text-align: center;
            border-bottom-left-radius: 25px;
            border-bottom-right-radius: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .header h1 {
            font-size: 1.8em;
            margin-bottom: 5px;
        }

        .header p {
            font-size: 0.9em;
            opacity: 0.9;
        }

        /* Common Card Style */
        .card {
            background: white;
            padding: 25px;
            margin-top: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }

        /* Invitation Link Section */
        .invite-link-section .label {
            font-size: 1em;
            font-weight: 600;
            margin-bottom: 15px;
            color: #555;
            text-align: center;
        }

        .link-box {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #f8f9fa;
            border: 2px dashed #ddd;
            border-radius: 10px;
            padding: 12px 15px;
            margin-bottom: 20px;
        }

        .link-box .invite-code {
            font-size: 1.1em;
            font-weight: bold;
            color: #667eea;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .copy-btn {
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 10px 15px;
            font-size: 0.9em;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .copy-btn:hover {
            background: #5a67d8;
        }
        
        .copy-btn .fa-check {
            display: none;
        }

        /* Share Buttons */
        .share-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .share-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            font-weight: 600;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .share-btn i {
            font-size: 1.2em;
        }

        .whatsapp-btn {
            background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
            box-shadow: 0 4px 15px rgba(37, 211, 102, 0.3);
        }

        .telegram-btn {
            background: linear-gradient(135deg, #0088cc 0%, #005f99 100%);
            box-shadow: 0 4px 15px rgba(0, 136, 204, 0.3);
        }
        
        .share-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.2);
        }

        /* Invitation Stats Section */
        .stats-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            text-align: center;
        }

        .stat-item {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .stat-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        .stat-item .value {
            font-size: 1.6em;
            font-weight: bold;
            color: #667eea;
        }

        .stat-item .label {
            font-size: 0.9em;
            color: #666;
            margin-top: 5px;
        }

        /* Rules Section */
        .rules-title {
            font-size: 1.2em;
            font-weight: 700;
            margin-bottom: 15px;
            text-align: center;
        }

        .rules-list {
            list-style: none;
            padding-left: 0;
        }

        .rules-list li {
            display: flex;
            align-items: flex-start;
            margin-bottom: 12px;
            font-size: 0.9em;
            color: #555;
        }

        .rules-list i {
            color: #28a745;
            margin-right: 10px;
            margin-top: 4px;
        }

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e9ecef;
            padding: 10px 0;
            z-index: 1000;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #666;
            min-width: 60px;
        }

        .nav-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .nav-item i {
            font-size: 1.3em;
            margin-bottom: 4px;
        }

        .nav-item .nav-text {
            font-size: 0.75em;
            font-weight: 600;
        }
        
        /* Bottom Sheet Modal */
        .bottom-sheet {
            position: fixed;
            left: 0;
            right: 0;
            bottom: -100%;
            background: white;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.15);
            z-index: 9999;
            transition: bottom 0.4s ease-in-out;
            max-height: 75%;
            overflow-y: auto;
        }

        .bottom-sheet.open {
            bottom: 0;
        }

        .sheet-content {
            padding: 20px;
        }

        .sheet-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: bold;
            font-size: 1.1em;
            margin-bottom: 15px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }

        .close-btn {
            cursor: pointer;
            font-size: 1.2em;
            color: #555;
        }

        .sheet-body {
            font-size: 0.95em;
            color: #444;
        }
        
.card2 {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    margin: 15px 20px 0px 20px;
}

        
    </style>
</head>
<body>

    <div class="header">
        <h1>Invite Friends & Earn Rewards</h1>
        <p>Share your link and get rewarded for every new user.</p>
    </div>


<div class="card2 referral-balance-section">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
            <div style="font-size: 11px; color: #555;">Total Referral Amount</div>
            <div style="font-size: 20px; font-weight: bold; color: #000; margin-top: 2px; margin-left: 1px;">₹<span id="referralBalance">0.00</span></div>
        </div>
        <button onclick="window.location.href='withdrawalrafer.php'" style="padding: 8px 14px; background-color: #4CAF50; color: white; border: none; border-radius: 6px; font-weight: bold;">
            Withdrawal
        </button>
    </div>
</div>


    <div class="container">
        <!-- Invitation Link Section -->
        <div class="card invite-link-section">
            <div class="label">Your Invitation Link</div>
            <div class="link-box">
                <span class="invite-code" id="inviteCode"><?php echo $invite_link; ?></span>
                <button class="copy-btn" onclick="copyLink()">
                    <i class="fas fa-copy"></i>
                    <i class="fas fa-check"></i>
                </button>
            </div>
            <div class="share-buttons">
                <button class="share-btn whatsapp-btn" onclick="shareOnWhatsApp()">
                    <i class="fab fa-whatsapp"></i> WhatsApp
                </button>
                <button class="share-btn telegram-btn" onclick="shareOnTelegram()">
                    <i class="fab fa-telegram-plane"></i> Telegram
                </button>
            </div>
        </div>

        <!-- Invitation Stats Section -->
        <div class="card">
            <div class="stats-grid">
                <div class="stat-item" onclick="showReferralLevels()">
                    <div class="value" id="totalInvites">--</div>
                    <div class="label">Total Invites</div>
                </div>
                <div class="stat-item" onclick="showReferralCommission()">
                    <div class="value">₹<span id="totalEarnings">--</span></div>
                    <div class="label">Total Commission</div>
                </div>
            </div>
        </div>
        
        <!-- Rules Section -->
        <div class="card rules-section">
            <h2 class="rules-title">Invitation Rules</h2>
            <ul class="rules-list">
                <li><i class="fas fa-check-circle"></i>You will get ₹10 when your friend registers using your link.</li>
                <li><i class="fas fa-check-circle"></i>You will receive a 30% commission on your friend's first recharge.</li>
                <li><i class="fas fa-check-circle"></i>Rewards will be credited to your account balance automatically.</li>
                <li><i class="fas fa-check-circle"></i>Creating multiple fake accounts can lead to a ban.</li>
            </ul>
        </div>
    </div>

    <!-- Bottom Navigation Bar -->
    <div class="bottom-nav">
        <div class="nav-container">
            <a href="index.php" class="nav-item">
                <i class="fas fa-home"></i>
                <div class="nav-text">Home</div>
            </a>
            <a href="invite.php" class="nav-item active">
                <i class="fas fa-users"></i>
                <div class="nav-text">Invite</div>
            </a>
            <a href="recharge.php" class="nav-item">
                <i class="fas fa-credit-card"></i>
                <div class="nav-text">Recharge</div>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="fas fa-user"></i>
                <div class="nav-text">My</div>
            </a>
        </div>
    </div>

    <!-- Bottom Sheet Modal -->
    <div id="bottomSheet" class="bottom-sheet">
        <div class="sheet-content">
            <div class="sheet-header">
                <span id="sheetTitle">Details</span>
                <i class="fas fa-times close-btn" onclick="closeBottomSheet()"></i>
            </div>
            <div class="sheet-body" id="sheetBody">
                <!-- Dynamic content will be loaded here -->
            </div>
        </div>
    </div>

    <script>
        

function loadReferralBalance() {
    fetch('fetch_referral_balance.php')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('referralBalance').innerText = `${parseFloat(data.referral_balance).toFixed(2)}`;
            } else {
                document.getElementById('referralBalance').innerText = '₹0.00';
            }
        })
        .catch(() => {
            document.getElementById('referralBalance').innerText = '₹0.00';
        });
}

 
// Get the invitation link from the PHP code
        const inviteLink = document.getElementById('inviteCode').innerText;
        
// Function to fetch and update stats from the server
function updateStats() {
    fetch("fetch_referral_chain.php") // 👈 backend file ka actual naam yahan likho
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                document.getElementById("totalInvites").innerText = data.total_invites;
                document.getElementById("totalEarnings").innerText = data.total_commission;
            } else {
                console.error("Error from server:", data.message);
            }
        })
        .catch(error => {
            console.error("Fetch error:", error);
        });
}

        // Copy link function
        function copyLink() {
            navigator.clipboard.writeText(inviteLink).then(() => {
                const copyBtn = document.querySelector('.copy-btn');
                const copyIcon = copyBtn.querySelector('.fa-copy');
                const checkIcon = copyBtn.querySelector('.fa-check');
                
                copyIcon.style.display = 'none';
                checkIcon.style.display = 'inline-block';
                
                setTimeout(() => {
                    copyIcon.style.display = 'inline-block';
                    checkIcon.style.display = 'none';
                }, 2000); // Revert back after 2 seconds
            }).catch(err => {
                console.error('Failed to copy: ', err);
                alert('Failed to copy link.');
            });
        }

        // Share functions
        const shareText = `Join me on this awesome platform and earn rewards! Use my link to sign up: ${inviteLink}`;

        function shareOnWhatsApp() {
            const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
            window.open(whatsappUrl, '_blank');
        }

        function shareOnTelegram() {
            const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent(shareText)}`;
            window.open(telegramUrl, '_blank');
        }
        
        // --- Bottom Sheet Functions ---
function showReferralLevels() {
    fetch('fetch_referral_chain.php')
        .then(res => res.json())
        .then(data => {
            const container = document.createElement('div');

            if (data.status !== 'success') {
                container.innerHTML = '<p style="text-align:center; color:red;">Failed to load referral levels.</p>';
            } else {
                const allUsers = [];

                // Flatten all levels into a single array with level info
                for (let i = 1; i <= 5; i++) {
                    const users = data.referrals[`level_${i}`] || [];
                    users.forEach(uid => {
                        allUsers.push({ id: uid, level: i });
                    });
                }

                if (allUsers.length === 0) {
                    container.innerHTML = '<p style="text-align:center; color:#777;">No referrals found.</p>';
                } else {
                    allUsers.forEach(user => {
                        const row = document.createElement('div');
                        row.style.display = 'flex';
                        row.style.justifyContent = 'space-between';
                        row.style.padding = '8px 10px';
                        row.style.borderBottom = '1px solid #eee';
                        row.style.fontSize = '14px';

                        row.innerHTML = `
                            <span style="font-weight: 500;">${user.id}</span>
                            <span style="color: #555;">Level ${user.level}</span>
                        `;

                        container.appendChild(row);
                    });
                }
            }

            openBottomSheet('Your Referral Users', container);
        })
        .catch(err => {
            const error = document.createElement('p');
            error.style.color = 'red';
            error.innerText = 'Error loading data.';
            openBottomSheet('Your Referral Users', error);
        });
}
function showReferralCommission() {
    fetch('fetch_referral_commission.php')
        .then(res => res.json())
        .then(data => {
            const container = document.createElement('div');
            if (data.status !== 'success' || data.commissions.length === 0) {
                container.innerHTML = '<p style="text-align:center; color:#888;">No commission earned yet.</p>';
            } else {
                data.commissions.forEach(item => {
                    const div = document.createElement('div');
                    div.style.background = '#f8f9fa';
                    div.style.padding = '10px';
                    div.style.marginBottom = '10px';
                    div.style.borderRadius = '10px';
                    div.innerHTML = `
                        <div style="display: flex; justify-content: space-between; font-weight: bold;">
                            <span>From: ${item.from_user}</span>
                            <span>Level ${item.level}</span>
                        </div>
                        <div style="margin-top: 5px; font-size: 0.9em; color: #555;">
                            Bet: ₹${item.bet_amount} | Commission: ₹${item.commission} (${item.percent}%)
                        </div>
                        <div style="font-size: 0.8em; color: #999; margin-top: 3px;">${item.date}</div>
                    `;
                    container.appendChild(div);
                });
            }
            openBottomSheet('Your Referral Commissions', container);
        })
        .catch(err => {
            const error = document.createElement('p');
            error.style.color = 'red';
            error.innerText = 'Error loading commission.';
            openBottomSheet('Your Referral Commissions', error);
        });
}
        

        // Open Bottom Sheet
        function openBottomSheet(title, contentHtml) {
            document.getElementById('sheetTitle').innerText = title;
            const body = document.getElementById('sheetBody');
            body.innerHTML = ''; // Clear previous content
            body.appendChild(contentHtml);
            document.getElementById('bottomSheet').classList.add('open');
        }

        // Close Bottom Sheet
        function closeBottomSheet() {
            document.getElementById('bottomSheet').classList.remove('open');
        }
        
        // Load initial data when the page is ready
        document.addEventListener('DOMContentLoaded', () => {
            updateStats();
            loadReferralBalance();
        });
    </script>

</body>
</html>

<?php

include 'config.php';
header('Content-Type: application/json');

// Get user ID from GET param
if (!isset($_GET['id'])) {
  http_response_code(400);
  echo json_encode(["error" => "Missing user ID"]);
  exit();
}

$userId = $_GET['id'];

// Prepare and execute query
$stmt = $conn->prepare("SELECT money FROM users WHERE unique_id = ?");
$stmt->bind_param("s", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  echo json_encode(["money" => (int)$row['money']]);
} else {
  echo json_encode(["money" => 0]);
}

$stmt->close();
$conn->close();
?>
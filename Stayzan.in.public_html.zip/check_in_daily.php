<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classic Daily Rewards with Confetti</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- कंफ़ेटी लाइब्रेरी -->
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.2/dist/confetti.browser.min.js"></script>

    <style>
        :root {
            --bg-color: #f4f7f9;
            --card-bg: #ffffff;
            --primary-color: #007bff;
            --success-color: #28a745;
            --gold-color: #ffc107;
            --text-dark: #212529;
            --text-light: #6c757d;
            --border-color: #dee2e6;
            --shadow-color: rgba(0, 0, 0, 0.05);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-color);
            color: var(--text-dark);
        }

        .top-bar {
            position: fixed; top: 0; left: 0; right: 0; max-width: 450px; margin: 0 auto;
            display: flex; justify-content: space-between; align-items: center; padding: 15px;
            background: rgba(255, 255, 255, 0.7); backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px); z-index: 1000; transition: box-shadow 0.3s ease;
        }
        .top-bar.scrolled { box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-bottom: 1px solid var(--border-color); }
        .top-bar .title { font-size: 18px; font-weight: 600; }
        .top-bar .icon-btn {
            background: transparent; border: none; cursor: pointer; font-size: 18px; color: var(--text-dark);
            width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center;
            justify-content: center; transition: background-color 0.2s ease, transform 0.2s ease;
        }
        .top-bar .icon-btn:hover { background-color: #e9e9eb; transform: scale(1.1); }
    
        .main-content {
            max-width: 400px;
            margin: 0 auto;
            padding: 80px 20px 20px;
        }

        .progress-wrapper {
            margin-bottom: 30px;
        }

        .progress-labels {
            display: flex;
            justify-content: space-between;
            font-size: 0.8rem;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text-light);
        }

        .progress-bar-bg {
            width: 100%;
            height: 8px;
            background-color: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-bar-fg {
            width: 0%;
            height: 100%;
            background-color: var(--primary-color);
            border-radius: 4px;
            transition: width 0.5s ease-in-out;
        }

        .rewards-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }

        .day-card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 15px 10px;
            text-align: center;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            cursor: pointer;
            position: relative;
            box-shadow: 0 4px 15px var(--shadow-color);
        }
        
        .day-label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-light);
            margin-bottom: 5px;
        }

        .reward-amount {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--text-dark);
        }
        
        .day-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
        }

        .day-card.locked {
            background-color: #f8f9fa;
            opacity: 0.6;
            cursor: not-allowed;
            pointer-events: none;
        }

        .day-card.claimable {
            border-color: var(--primary-color);
            background-color: #e7f3ff;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(0, 123, 255, 0); }
            100% { box-shadow: 0 0 0 0 rgba(0, 123, 255, 0); }
        }
        
        .day-card.claimed {
            background-color: #e9ecef;
            border-color: var(--border-color);
            cursor: default;
        }
        .day-card.claimed .day-label,
        .day-card.claimed .reward-amount {
            color: #adb5bd;
            text-decoration: line-through;
        }
        .day-card.claimed::after {
            content: '\f00c';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 2rem;
            color: var(--success-color);
            opacity: 0.5;
        }

        .lucky-day {
            grid-column: span 3;
            margin-top: 10px;
            padding: 20px;
            border: 1px dashed var(--border-color);
        }
        .lucky-day.claimable {
            border-color: var(--gold-color);
            border-style: solid;
            background-color: #fff8e1;
        }
        .lucky-day .reward-amount {
            font-size: 1.5rem;
        }
        .lucky-day .fa-gift {
            color: var(--gold-color);
            margin-right: 8px;
        }
        
        .help-section { 
            margin-bottom: 20px; 
        }
        .help-section:last-child {
            margin-bottom: 0;
        }
        .help-section h4 { 
            font-size: 16px; 
            font-weight: 600; 
            margin-bottom: 8px; 
            display: flex; 
            align-items: center; 
            gap: 8px; 
            color: var(--primary-color); 
        }
        .help-section p { 
            font-size: 14px; 
            line-height: 1.6; 
            color: var(--text-light);
        }
        .help-section ul { 
            list-style-position: inside; 
            padding-left: 5px; 
            color: var(--text-light);
        }
        .help-section li { 
            margin-bottom: 5px; 
        }
        .help-contact-btn {
            width: 100%; 
            padding: 12px; 
            background-color: var(--primary-color); 
            color: white;
            border: none; 
            border-radius: 12px; 
            font-weight: 600; 
            cursor: pointer;
            text-align: center; 
            text-decoration: none; 
            display: block; 
            margin-top: 15px;
            transition: background-color 0.3s ease;
        }
        .help-contact-btn:hover {
            background-color: #0056b3;
        }

        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.5); z-index: 2000;
            display: flex; justify-content: center; align-items: center;
            opacity: 0; visibility: hidden; transition: opacity 0.3s ease, visibility 0.3s ease;
        }
        .modal-overlay.open { opacity: 1; visibility: visible; }
        .modal-content {
            background: var(--card-bg);
            border-radius: 24px; padding: 25px;
            width: 90%; max-width: 400px;
            transform: scale(0.95); transition: transform 0.3s ease;
        }
        .modal-overlay.open .modal-content { transform: scale(1); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        
        .close-btn {
            background: transparent;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--text-light);
            padding: 5px;
            line-height: 1;
        }
        .close-btn:hover {
            color: var(--text-dark);
        }

        .status-message {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 20px;
            font-size: 14px;
            color: #856404;
        }
    </style>
</head>
<body>
    <audio id="claimSound" src="https://assets.codepen.io/29642/pop.mp3" preload="auto"></audio>
    <audio id="luckySound" src="https://assets.codepen.io/29642/success.mp3" preload="auto"></audio>

    <header class="top-bar" id="top-bar">
        <button class="icon-btn" onclick="window.history.back()" aria-label="Go Back"><i class="fas fa-arrow-left"></i></button>
        <h1 class="title">Daily Rewards</h1>
        <button class="icon-btn" id="open-help-modal-btn" aria-label="Help"><i class="fas fa-question"></i></button>
    </header>

    <main class="main-content">
        <div id="status-message" class="status-message" style="display: none;"></div>
        
        <div class="progress-wrapper">
            <div class="progress-labels">
                <span>Progress</span>
                <span id="progressText">0 / 7 Days</span>
            </div>
            <div class="progress-bar-bg">
                <div class="progress-bar-fg" id="progressBar"></div>
            </div>
        </div>

        <div class="rewards-grid">
            <div class="day-card locked" data-day="1"><div class="day-label">Day 1</div><div class="reward-amount">₹2</div></div>
            <div class="day-card locked" data-day="2"><div class="day-label">Day 2</div><div class="reward-amount">₹3</div></div>
            <div class="day-card locked" data-day="3"><div class="day-label">Day 3</div><div class="reward-amount">₹4</div></div>
            <div class="day-card locked" data-day="4"><div class="day-label">Day 4</div><div class="reward-amount">₹5</div></div>
            <div class="day-card locked" data-day="5"><div class="day-label">Day 5</div><div class="reward-amount">₹6</div></div>
            <div class="day-card locked" data-day="6"><div class="day-label">Day 6</div><div class="reward-amount">₹7</div></div>
            <div class="day-card lucky-day locked" data-day="7">
                <div class="day-label">Day 7 - Lucky Reward</div>
                <div class="reward-amount"><i class="fas fa-gift"></i> Special Bonus</div>
            </div>
        </div>
    </main>

<!-- Help Modal -->
<div class="modal-overlay" id="help-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>सहायता केंद्र (Help Center)</h3>
            <button class="close-btn" id="close-help-modal-btn">&times;</button>
        </div>

        <div class="help-section">
            <h4><i class="fas fa-gavel"></i> रिवॉर्ड्स के नियम</h4>
            <ul>
                <li>हर दिन सिर्फ अगला दिन ही क्लेम कर सकते हैं।</li>
                <li>लगातार 7 दिन पूरे करने पर स्पेशल बोनस मिलता है।</li>
                <li>3 दिन तक चेक-इन नहीं करने पर Day 1 से रीसेट हो जाएगा।</li>
                <li>Day 7 के बाद फिर से Day 1 से शुरू होता है।</li>
            </ul>
        </div>

        <div class="help-section">
            <h4><i class="fas fa-question-circle"></i> आम सवाल (FAQ)</h4>
            <p><strong>प्रश्न: मेरा प्रोग्रेस रीसेट क्यों हुआ?</strong><br>
            उत्तर: अगर आप 3 दिन तक चेक-इन नहीं करते, तो सिस्टम Day 1 से रीसेट हो जाता है।</p>
            <p><strong>प्रश्न: क्लेम किया पैसा कहाँ दिखेगा?</strong><br>
            उत्तर: यह पैसा आपके मेन वॉलेट बैलेंस में तुरंत जुड़ जाता है।</p>
        </div>

        <div class="help-section">
            <h4><i class="fas fa-headset"></i> मदद चाहिए?</h4>
            <p>
                अगर आपको कोई और समस्या है या आपका पैसा वॉलेट में नहीं जुड़ा है, तो हमसे संपर्क करें।
            </p>
            <a href="https://t.me/stayzan_bot" class="help-contact-btn">
                <i class="fab fa-telegram-plane"></i> Telegram पर संपर्क करें
            </a>
        </div>
    </div>
</div>

<script>
// ✅ Help Modal Logic
const helpModal = document.getElementById('help-modal');
const openHelpModalBtn = document.getElementById('open-help-modal-btn');
const closeHelpModalBtn = document.getElementById('close-help-modal-btn');

const openHelpModal = () => helpModal.classList.add('open');
const closeHelpModal = () => helpModal.classList.remove('open');

openHelpModalBtn.addEventListener('click', openHelpModal);
closeHelpModalBtn.addEventListener('click', closeHelpModal);

helpModal.addEventListener('click', (e) => {
    if (e.target === helpModal) {
        closeHelpModal();
    }
});

// ✅ Confetti Function
function triggerConfetti() {
    confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const claimSound = document.getElementById('claimSound');
    const luckySound = document.getElementById('luckySound');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const statusMessage = document.getElementById('status-message');

    let userStatus = {
        current_day: 1,
        streak_count: 0,
        today_claimed: false,
        days_since_last_checkin: 0
    };

    function showStatusMessage(message, type = 'info') {
        statusMessage.textContent = message;
        statusMessage.style.display = 'block';
        statusMessage.className = 'status-message';
        
        if (type === 'error') {
            statusMessage.style.background = '#f8d7da';
            statusMessage.style.borderColor = '#f5c6cb';
            statusMessage.style.color = '#721c24';
        } else if (type === 'success') {
            statusMessage.style.background = '#d4edda';
            statusMessage.style.borderColor = '#c3e6cb';
            statusMessage.style.color = '#155724';
        }
        
        setTimeout(() => {
            statusMessage.style.display = 'none';
        }, 5000);
    }

    // =================================================================================
    // ✅ बदला हुआ UPDATEUI फ़ंक्शन
    // यह फ़ंक्शन अब हर स्थिति को सही ढंग से संभालेगा।
    // =================================================================================
    function updateUI() {
        const currentDayToClaim = userStatus.current_day;
        const hasUserClaimedToday = userStatus.today_claimed;

        console.log('UI अपडेट हो रहा है:', { currentDayToClaim, hasUserClaimedToday });

        // --- 1. प्रोग्रेस बार को अपडेट करें ---
        let completedDays = currentDayToClaim - 1;
        if (currentDayToClaim === 1 && hasUserClaimedToday) {
            // विशेष मामला: Day 7 अभी-अभी क्लेम हुआ है।
            completedDays = 7;
        }
        
        completedDays = Math.max(0, Math.min(completedDays, 7));
        const percentage = (completedDays / 7) * 100;
        progressBar.style.width = `${percentage}%`;
        progressText.textContent = `${completedDays} / 7 दिन`;

        // --- 2. सभी रिवॉर्ड कार्ड्स को अपडेट करें ---
        document.querySelectorAll('.day-card').forEach(card => {
            const day = parseInt(card.dataset.day, 10);
            card.classList.remove('claimed', 'claimable', 'locked');

            if (day < currentDayToClaim) {
                card.classList.add('claimed');
            } else if (day === currentDayToClaim) {
                if (hasUserClaimedToday) {
                    card.classList.add('locked');
                } else {
                    card.classList.add('claimable');
                }
            } else {
                card.classList.add('locked');
            }
        });

        // --- 3. विशेष स्थिति को संभालें (जब चक्र पूरा हो) ---
        if (currentDayToClaim === 1 && hasUserClaimedToday) {
            document.querySelectorAll('.day-card').forEach(card => {
                card.classList.add('claimed');
                card.classList.remove('claimable', 'locked');
            });
        }
    }

    function fetchCheckinStatus() {
        fetch('checkin_history.php')
            .then(res => {
                if (!res.ok) {
                    throw new Error('Network response was not ok');
                }
                return res.json();
            })
            .then(data => {
                console.log("सर्वर से मिला डेटा:", data);
                
                if (data.error) {
                    showStatusMessage('Error: ' + data.error, 'error');
                    return;
                }
                
                userStatus = {
                    current_day: data.current_day || 1,
                    streak_count: data.streak_count || 0,
                    today_claimed: data.today_claimed || false,
                    days_since_last_checkin: data.days_since_last_checkin || 0
                };
                
                updateUI();
            })
            .catch(error => {
                console.error('चेक-इन स्थिति प्राप्त करने में त्रुटि:', error);
                showStatusMessage('सर्वर से कनेक्ट नहीं हो पा रहा। कृपया बाद में कोशिश करें।', 'error');
            });
    }

    // =================================================================================
    // ✅ बदला हुआ CLAIMTODAY फ़ंक्शन
    // यह अब मैन्युअल रूप से स्थिति अपडेट करने के बजाय सर्वर से नवीनतम डेटा प्राप्त करता है।
    // =================================================================================
    function claimToday(day) {
        const card = document.querySelector(`.day-card[data-day='${day}']`);
        if (!card || card.style.pointerEvents === 'none') {
            return;
        }
        card.style.pointerEvents = 'none'; // डबल-क्लिक से बचने के लिए

        fetch('checkin_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `day=${day}`
        })
        .then(res => res.json())
        .then(data => {
            console.log("क्लेम की प्रतिक्रिया:", data);
            
            if (data.success) {
                triggerConfetti();
                
                if (day === 7) {
                    luckySound.play();
                    showStatusMessage(`बधाई हो! आपको ₹${data.reward} का स्पेशल बोनस मिला!`, 'success');
                } else {
                    claimSound.play();
                    showStatusMessage(`बधाई हो! आपको ₹${data.reward} मिले!`, 'success');
                }
                
                // सबसे महत्वपूर्ण बदलाव: UI को अपडेट करने के लिए सर्वर से नवीनतम स्थिति फिर से प्राप्त करें।
                // यह सुनिश्चित करता है कि UI हमेशा डेटाबेस के साथ सिंक में रहे।
                fetchCheckinStatus();
                
            } else {
                showStatusMessage(data.message || 'कुछ गलत हुआ है।', 'error');
                card.style.pointerEvents = 'auto'; // विफल होने पर कार्ड को फिर से सक्षम करें
            }
        })
        .catch(error => {
            console.error('इनाम का दावा करने में त्रुटि:', error);
            showStatusMessage('सर्वर से कनेक्ट नहीं हो पा रहा। कृपया बाद में कोशिश करें।', 'error');
            card.style.pointerEvents = 'auto'; // विफल होने पर कार्ड को फिर से सक्षम करें
        });
    }

    // दिन के कार्ड पर क्लिक इवेंट लिस्नर जोड़ें
    document.querySelectorAll('.day-card').forEach(card => {
        card.addEventListener('click', () => {
            // केवल 'claimable' कार्ड पर क्लिक करने की अनुमति दें
            if (card.classList.contains('claimable')) {
                const day = parseInt(card.dataset.day);
                claimToday(day);
            }
        });
    });

    // प्रारंभिक लोड
    fetchCheckinStatus();
    
    // हर 30 सेकंड में स्थिति ताज़ा करें (वैकल्पिक)
    // setInterval(fetchCheckinStatus, 30000);
});
</script>
</body>
</html>

<?php
session_start();

if (isset($_GET['ref'])) {
    $_SESSION['referrer_code'] = $_GET['ref'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Leevora - Login & Signup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* --- नया और बेहतर CSS --- */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .main-container {
            background: #ffffff;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            width: 100%;
            max-width: 400px;
        }
        .form-container {
            padding: 35px 30px;
            display: none; /* डिफ़ॉल्ट रूप से सभी फॉर्म छिपे हुए हैं */
        }
        .form-container.active {
            display: block; /* केवल सक्रिय फॉर्म दिखाई देगा */
        }
        .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            gap: 10px;
        }
        .logo-container img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        .logo-container h2 {
            font-size: 2em;
            margin: 0;
            color: #333;
            font-weight: 600;
        }
        h1 {
            text-align: center;
            margin-bottom: 10px;
            color: #333;
            font-size: 1.8em;
            font-weight: 600;
        }
        p.subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 25px;
        }
        .input-group {
            position: relative;
            margin-bottom: 20px;
        }
        .input-group .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
            font-size: 1.1em;
        }
        .input-group .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
            cursor: pointer;
            font-size: 1.1em;
        }
        .form-input {
            width: 100%;
            padding: 12px 15px 12px 50px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1em;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
            background: #f9f9f9;
            color: #333;
        }
        .form-input.password-field { padding-right: 50px; }
        .form-input:focus {
            outline: none;
            border-color: #6e8efb;
            background: white;
            box-shadow: 0 0 0 3px rgba(110, 142, 251, 0.2);
        }
        .btn-primary {
            width: 100%;
            padding: 13px;
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 25px 0;
            color: #999;
            font-size: 0.9em;
        }
        .divider::before, .divider::after {
            content: ''; flex: 1; border-bottom: 1px solid #ddd;
        }
        .divider:not(:empty)::before { margin-right: .5em; }
        .divider:not(:empty)::after { margin-left: .5em; }
        .toggle-text {
            text-align: center;
            margin-top: 25px;
            color: #666;
            font-size: 0.95em;
        }
        .toggle-link {
            color: #6e8efb;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
        }
        .terms-group {
            display: flex;
            align-items: flex-start;
            margin-top: 15px;
            margin-bottom: 20px;
        }
        .terms-group input[type="checkbox"] {
            margin-top: 3px; margin-right: 10px; flex-shrink: 0;
            width: 16px; height: 16px; accent-color: #6e8efb;
        }
        .terms-group label { font-size: 0.9em; color: #555; line-height: 1.4; }
        .terms-group label a { color: #6e8efb; text-decoration: none; font-weight: 500; }
        .overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            display: flex; justify-content: center; align-items: center;
            z-index: 1000; visibility: hidden; opacity: 0;
            transition: visibility 0s, opacity 0.3s;
        }
        .overlay.active { visibility: visible; opacity: 1; }
        .modal {
            background-color: white; padding: 25px; border-radius: 10px;
            text-align: center; width: 90%; max-width: 350px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
   <div class="main-container">
        <!-- Login Form -->
        <div id="loginForm" class="form-container active">
            <div class="logo-container">
                <img src="https://leevora.com/logo/logo.png" alt="Logo">
                <h2>PlaceBet</h2>
            </div>
            <h1>Welcome Back!</h1>
            <p class="subtitle">Login to continue</p>
            
            <form id="loginFormAjax" action="login2" method="POST">
                <div class="input-group">
                    <i class="fas fa-phone input-icon"></i>
                    <input type="text" id="loginMobile" name="mobile" class="form-input" placeholder="Mobile Number" required>
                </div>
                <div class="input-group">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" id="loginPassword" name="password" class="form-input password-field" placeholder="Password" required>
                    <i class="fas fa-eye toggle-password" onclick="togglePassword('loginPassword')"></i>
                </div>
                <a href="#" class="toggle-link" style="float: right; margin-top: -10px; font-size: 0.9em;">Forgot password?</a>
                <button class="btn-primary" type="submit">Sign In</button>
            </form>
            <div class="toggle-text">Don't have an account? <a class="toggle-link" onclick="showSignupForm()">Sign Up</a></div>
        </div>

        <!-- Signup Form -->
        <div id="signupForm" class="form-container">
            <div class="logo-container">
                <img src="https://leevora.com/logo/logo.png" alt="Logo">
                <h2>PlaceBET</h2>
            </div>
            <h1>Create Account</h1>
            <p class="subtitle">Enter your details to get started</p>
            
            <form id="signupFormInternal" onsubmit="submitSignupForm(event)">
                <div class="input-group">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" id="name" name="name" class="form-input" placeholder="Full Name" required>
                </div>
                <div class="input-group">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" id="email" name="email" class="form-input" placeholder="Email Address" required>
                </div>
                <div class="input-group">
                    <i class="fas fa-phone input-icon"></i>
                    <input type="tel" id="signupMobile" name="mobile" class="form-input" pattern="\d{10}" required placeholder="Mobile Number">
                </div>
                <div class="input-group">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" id="signupPassword" name="password" class="form-input password-field" placeholder="Create Password" required>
                    <i class="fas fa-eye toggle-password" onclick="togglePassword('signupPassword')"></i>
                </div>
                <div class="terms-group">
                    <input type="checkbox" id="consent" name="consent" required>
                    <label for="consent">I agree to the <a href="terms_and_condition" target="_blank">Terms</a> and <a href="privacy_policy" target="_blank">Privacy Policy</a>.</label>
                </div>
                <button class="btn-primary" type="submit">Sign Up</button>
            </form>
            <div class="toggle-text">Already have an account? <a class="toggle-link" onclick="showLoginForm()">Login</a></div>
        </div>
        
        <!-- Forget Password Form -->
        <div id="forgetPasswordForm" class="form-container">
            <div class="logo-container">
                <img src="https://leevora.com/logo/logo.png" alt="Logo">
                <h2>PlaceBET </h2>
            </div>
            <h1>Reset Password</h1>
            <p class="subtitle">Enter your details to reset</p>

            <form id="forgetPasswordAjax" action="forget_password" method="POST">
                <div class="input-group">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" id="forgetEmail" name="email" class="form-input" placeholder="Registered Email" required>
                </div>
                <div class="input-group">
                    <i class="fas fa-phone input-icon"></i>
                    <input type="text" id="forgetMobile" name="mobile" class="form-input" placeholder="Registered Mobile" required>
                </div>
                <div class="input-group">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" id="newPassword" name="password" class="form-input password-field" placeholder="New Password" required>
                    <i class="fas fa-eye toggle-password" onclick="togglePassword('newPassword')"></i>
                </div>
                <button class="btn-primary" type="submit">Reset Password</button>
            </form>
            <div class="toggle-text">Remembered your password? <a class="toggle-link" onclick="showLoginForm()">Login</a></div>
        </div>
    </div>

    <!-- Overlay for Message (आपका मौजूदा ओवरले) -->
    <div id="overlay" class="overlay">
        <div class="modal">
            <h3 id="modalMessage"></h3>
            <button class="btn-primary" style="margin-top: 20px;" onclick="closeOverlay()">Close</button>
        </div>
    </div>

    <script>
        // --- आपका मौजूदा JavaScript लॉजिक (बिना किसी बदलाव के) ---

        // सभी फॉर्म कंटेनरों को प्राप्त करें
        const loginForm = document.getElementById('loginForm');
        const signupForm = document.getElementById('signupForm');
        const forgetPasswordForm = document.getElementById('forgetPasswordForm');

        // पासवर्ड दृश्यता टॉगल करें
        function togglePassword(Id) {
            const passwordInput = document.getElementById(Id);
            const toggleIcon = passwordInput.nextElementSibling;
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
      
        // फॉरगेट पासवर्ड फॉर्म दिखाएं
        document.querySelector('a[href="#"]').addEventListener("click", function (e) {
            e.preventDefault();
            loginForm.classList.remove('active');
            signupForm.classList.remove('active');
            forgetPasswordForm.classList.add('active');
        });

        // लॉगिन फॉर्म दिखाएं
        function showLoginForm() {
            forgetPasswordForm.classList.remove('active');
            signupForm.classList.remove('active');
            loginForm.classList.add('active');
        }

        // साइनअप फॉर्म दिखाएं
        function showSignupForm() {
            loginForm.classList.remove('active');
            forgetPasswordForm.classList.remove('active');
            signupForm.classList.add('active');
        }
      
        // साइनअप फॉर्म सबमिशन को हैंडल करें
        function submitSignupForm(event) {
            event.preventDefault();
            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const mobile = document.getElementById("signupMobile").value;
            const password = document.getElementById("signupPassword").value;
            if (!name || !email || !mobile || !password) {
                showOverlay("Please fill in all fields.", "error");
                return;
            }
            const userData = `name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&mobile=${encodeURIComponent(mobile)}&password=${encodeURIComponent(password)}`;
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "signup", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4) {
                    if (xhr.status == 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            if (response.status === "success") {
                                window.location.href = "index?signup_success=true";
                            } else {
                                showOverlay(response.message, "error");
                            }
                        } catch (e) {
                            console.error("Invalid JSON response", xhr.responseText);
                            showOverlay("An unexpected error occurred.", "error");
                        }
                    } else {
                        showOverlay("Error: Unable to process the request.", "error");
                    }
                }
            };
            xhr.send(userData);
        }

        // संदेश के साथ ओवरले दिखाएं
        function showOverlay(message, type) {
            const overlay = document.getElementById("overlay");
            const modalMessage = document.getElementById("modalMessage");
            modalMessage.textContent = message;
            modalMessage.style.color = type === "success" ? "green" : "black";
            overlay.classList.add("active");
        }

        // ओवरले बंद करें
        function closeOverlay() {
            document.getElementById("overlay").classList.remove("active");
        }

        // साइनअप फॉर्म पर सबमिट हैंडलर अटैच करें
        document.getElementById("signupFormInternal").addEventListener("submit", submitSignupForm);  

        // लॉगिन फॉर्म सबमिशन को हैंडल करें
        document.getElementById("loginFormAjax").addEventListener("submit", function(event) {
            event.preventDefault();
            const mobile = document.getElementById("loginMobile").value;
            const password = document.getElementById("loginPassword").value;
            if (!mobile || !password) {
                alert("Please fill in all fields.");
                return;
            }
            const loginData = `mobile=${encodeURIComponent(mobile)}&password=${encodeURIComponent(password)}`;
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "login2", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    if (xhr.responseText === "Success") {
                        window.location.href = "index";
                    } else {
                        alert(xhr.responseText);
                    }
                }
            };
            xhr.send(loginData);
        });
   
        // फॉरगेट पासवर्ड को हैंडल करें
        document.getElementById("forgetPasswordAjax").addEventListener("submit", function(e) {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);
            fetch("forget_password", { method: "POST", body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert("✅ Password updated successfully!");
                    fetch("security_notification", { method: "POST", body: formData })
                    .then(res => res.json())
                    .then(data2 => {
                        console.log("🔒 Security log:", data2.success ? "Success" : data2.error);
                        window.location.href = "index";
                    })
                    .catch(err => {
                        console.warn("⚠️ Security notification error:", err);
                        window.location.href = "login";
                    });
                } else {
                    alert("❌ " + data.error);
                }
            })
            .catch(err => {
                console.error("💥 Server error:", err);
                alert("Something went wrong. Try again later.");
            });
        });
    
        // राइट-क्लिक और टेक्स्ट सिलेक्शन को डिसेबल करें
        document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
        document.addEventListener('selectstart', function (e) { e.preventDefault(); });    

        // बैक बटन से आने पर पेज को रीलोड करें
        if (performance.navigation.type == 2) {
            location.reload();
        }
  </script>
</body>
</html>

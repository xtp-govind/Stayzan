<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>My Wallet</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            color: #333;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            touch-action: manipulation;
        }

        /* Mobile-First Top Bar */
        .top-bar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(15px);
            color: #333;
            padding: 12px 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 18px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            min-height: 40px;
        }

        .top-bar-left {
            display: flex;
            align-items: center;
            font-weight: 600;
        }

        .top-bar-left i {
            margin-right: 15px;
            cursor: pointer;
            color: #555;
            padding: 12px;
            border-radius: 50%;
            transition: all 0.3s ease;
            min-width: 44px;
            min-height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }
        
        .top-bar-left i:hover,
        .top-bar-left i:active {
            background: rgba(102, 126, 234, 0.15);
            color: #667eea;
            transform: scale(1.05);
        }
        
        .help-icon {
            cursor: pointer;
            font-size: 20px;
            color: #555;
            padding: 12px;
            border-radius: 50%;
            transition: all 0.3s ease;
            min-width: 44px;
            min-height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .help-icon:hover,
        .help-icon:active {
            background: rgba(102, 126, 234, 0.15);
            color: #667eea;
            transform: scale(1.05);
        }

        /* Mobile-Optimized Container */
        .container {
            padding: 10px 16px;
            max-width: 100%;
            margin: 0 auto;
        }

        /* Enhanced Mobile Balance Cards */
        .balance-cards-container {
            display: grid;
            grid-template-columns: 1fr;
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .balance-card {
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
            min-height: 100px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .balance-card:active {
            transform: translateY(-4px) scale(0.98);
            box-shadow: 0 12px 40px rgba(0,0,0,0.2);
        }
        
        .wallet-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .gaming-card {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        .balance-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: shimmer 6s infinite linear;
        }
        
        @keyframes shimmer {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .balance-card h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 500;
            opacity: 0.9;
            position: relative;
            z-index: 2;
            margin-bottom: 8px;
        }

        .balance-card .amount {
            font-size: 32px;
            font-weight: 700;
            margin: 5px 0;
            letter-spacing: 1px;
            position: relative;
            z-index: 2;
        }
        
        .balance-card .add-money-btn {
            background: rgba(255, 255, 255, 0.25);
            border: 2px solid rgba(255, 255, 255, 0.4);
            color: white;
            padding: 10px 20px;
            border-radius: 12px;
            font-size: 14px;
            cursor: pointer;
            margin-top: 10px;
            transition: all 0.3s ease;
            position: relative;
            z-index: 2;
            font-weight: 600;
            min-height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            touch-action: manipulation;
        }
        
        .balance-card .add-money-btn:hover,
        .balance-card .add-money-btn:active {
            background: rgba(255, 255, 255, 0.35);
            transform: translateY(-2px) scale(1.02);
            box-shadow: 0 6px 20px rgba(255, 255, 255, 0.3);
        }
        
        /* Mobile-Optimized Transfer Section */
        .transfer-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(15px);
            padding: 24px 20px;
            border-radius: 24px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.12);
            border: 1px solid rgba(255, 255, 255, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .transfer-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }
        
        .transfer-container h3 {
            text-align: center;
            margin-top: 0;
            margin-bottom: 24px;
            font-size: 22px;
            font-weight: 600;
            color: #2c3e50;
            position: relative;
        }
        
        .transfer-container h3::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 2px;
        }
        
        /* Mobile-First Transfer Box */
        .transfer-box {
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-bottom: 24px;
        }

        .account-card {
            padding: 20px;
            border: 2px solid #e0e0e0;
            border-radius: 16px;
            text-align: center;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            min-height: 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            touch-action: manipulation;
        }
        
        .account-card:active {
            border-color: #667eea;
            transform: translateY(-2px) scale(0.98);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.15);
        }
        
        .account-card .label {
            font-size: 12px;
            color: #7f8c8d;
            margin-bottom: 8px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .account-card .balance {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        /* Mobile-Optimized Swap Button */
        #swap-btn {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
            border-radius: 50%;
            width: 56px;
            height: 56px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            color: white;
            transition: all 0.3s ease;
            position: relative;
            align-self: center;
            margin: 5px 0;
            box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
            touch-action: manipulation;
        }
        
        #swap-btn:hover {
            transform: rotate(180deg) scale(1.1);
            box-shadow: 0 6px 24px rgba(102, 126, 234, 0.4);
        }
        
        #swap-btn:active {
            transform: rotate(0deg) scale(1);
            box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
        }
        
        #swap-btn i {
            position: relative;
            z-index: 2;
            transition: transform 0.3s ease;
        }
        
        /* Mobile-Optimized Form */
        .transfer-form {
            margin-top: 0;
        }

        .transfer-form label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 600;
            font-size: 14px;
        }

        .transfer-form input {
            width: 100%;
            padding: 16px 20px;
            margin-bottom: 20px;
            border-radius: 16px;
            border: 2px solid #e0e0e0;
            box-sizing: border-box;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
            min-height: 56px;
            background: white;
            -webkit-appearance: none;
            -moz-appearance: textfield;
        }
        
        .transfer-form input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }
        
        .transfer-form button {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            font-size: 18px;
            border: none;
            cursor: pointer;
            width: 100%;
            padding: 18px;
            border-radius: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            min-height: 56px;
            touch-action: manipulation;
            box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
        }
        
        .transfer-form button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }
        
        .transfer-form button:hover::before,
        .transfer-form button:active::before {
            left: 100%;
        }
        
        .transfer-form button:hover,
        .transfer-form button:active {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
        }

        /* Enhanced Mobile Overlay */
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(8px);
            z-index: 1000;
            display: flex;
            align-items: flex-end;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }

        .overlay.show {
            opacity: 1;
            visibility: visible;
        }

        .overlay-content {
            background: white;
            width: 100%;
            padding: 32px 24px;
            padding-top: 48px;
            border-radius: 24px 24px 0 0;
            box-shadow: 0 -8px 32px rgba(0,0,0,0.2);
            position: relative;
            transform: translateY(100%);
            transition: transform 0.3s ease;
            color: #333;
            max-height: 80vh;
            overflow-y: auto;
        }

        .overlay.show .overlay-content {
            transform: translateY(0);
        }
        
        .close-btn {
            position: absolute;
            top: 16px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 6px;
            background: #ccc;
            border-radius: 3px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .close-btn:hover,
        .close-btn:active {
            background: #999;
            width: 80px;
        }
        
        .overlay-content h3 {
            margin-top: 16px;
            text-align: center;
            font-size: 24px;
            margin-bottom: 24px;
            color: #333;
            position: relative;
        }
        
        .overlay-content h3::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: #667eea;
            border-radius: 2px;
        }
        
        .faq-item {
            margin-bottom: 20px;
            text-align: left;
        }
        
        .faq-question {
            font-weight: 600;
            color: #667eea;
            margin-bottom: 8px;
            font-size: 16px;
        }
        
        .faq-answer {
            color: #555;
            line-height: 1.6;
            font-size: 14px;
            padding-left: 16px;
            border-left: 3px solid #667eea;
        }

        /* Loading State */
        .loading {
            pointer-events: none;
            opacity: 0.7;
        }

        .loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 20px;
            height: 20px;
            margin: -10px 0 0 -10px;
            border: 2px solid #ffffff;
            border-radius: 50%;
            border-top-color: transparent;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Tablet Responsive Design */
        @media (min-width: 768px) {
            .container {
                max-width: 600px;
                padding: 32px 24px;
            }

            .balance-cards-container {
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }

            .transfer-box {
                flex-direction: row;
                align-items: center;
                gap: 20px;
            }

            #swap-btn {
                margin: 0;
            }
        }

        /* Desktop Responsive Design */
        @media (min-width: 1024px) {
            .container {
                max-width: 500px;
                padding: 40px 32px;
            }

            .top-bar-left i:hover,
            .help-icon:hover {
                background: rgba(102, 126, 234, 0.1);
            }

            .balance-card:hover {
                transform: translateY(-6px);
                box-shadow: 0 16px 48px rgba(0,0,0,0.2);
            }

            .account-card:hover {
                border-color: #667eea;
                transform: translateY(-2px);
                box-shadow: 0 8px 24px rgba(102, 126, 234, 0.15);
            }

           #swap-btn:hover {
            transform: rotate(180deg) scale(1.1);
        } {
                transform: rotate(180deg) scale(1.05);
            }

            .transfer-form button:hover {
                transform: translateY(-3px);
                box-shadow: 0 12px 32px rgba(102, 126, 234, 0.4);
            }
        }
        
.notification {
    position: fixed;
    top: 20px; /* टॉप बार से थोड़ी दूरी */
    left: 50%;
    transform: translateX(-50%);
    padding: 14px 24px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.15);
    z-index: 2000; /* यह सुनिश्चित करता है कि यह सबसे ऊपर दिखे */
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 16px;
    font-weight: 600;
    color: white;
    opacity: 0;
    visibility: hidden;
    transform: translate(-50%, -100px); /* शुरुआती पोजीशन, ऊपर की ओर */
    transition: transform 0.4s ease-in-out, opacity 0.4s ease-in-out, visibility 0.4s;
    min-width: 280px;
    max-width: 90%;
    text-align: center;
    justify-content: center;
}

.notification.show {
    opacity: 1;
    visibility: visible;
    transform: translate(-50%, 0); /* फाइनल पोजीशन */
}

/* Success Message Style */
.notification.success {
    background: linear-gradient(135deg, #28a745, #218838);
    border-left: 6px solid #1e7e34;
}

/* Error Message Style */
.notification.error {
    background: linear-gradient(135deg, #dc3545, #c82333);
    border-left: 6px solid #b21f2d;
}

.notification i {
    font-size: 20px;
}

        
    </style>
</head>
<body>
    <!-- Top Bar with Back Button Functionality -->
    <div class="top-bar">
        <div class="top-bar-left">
            <i class="fas fa-arrow-left" onclick="window.history.back()" aria-label="Go back"></i>
            <span>My Wallet</span>
        </div>
        <i class="fas fa-question-circle help-icon" id="helpBtn" aria-label="Help"></i>
    </div>

    <!-- Main Content -->
    <div class="container">
        <!-- Enhanced Balance Cards -->
        <div class="balance-cards-container">
            <div class="balance-card wallet-card">
                <h3>Wallet Balance</h3>
                <p class="amount">₹5,000</p>
            </div>
            <div class="balance-card gaming-card">
                <h3>Gaming Balance</h3>
                <p class="amount">₹3,500</p>
                <button class="add-money-btn" id="addMoneyBtn">
                    <i class="fas fa-plus-circle"></i> Add Money
                </button>
            </div>
        </div>

        <!-- Enhanced Transfer Section -->
        <div class="transfer-container">
            <h3>Transfer Funds</h3>
            <div class="transfer-box">
                <div class="account-card" id="from-card">
                    <div class="label">FROM</div>
                    <div class="balance" id="from-account-name">Wallet Balance</div>
                </div>
                <button id="swap-btn" aria-label="Swap accounts">
                    <i class="fas fa-exchange-alt"></i>
                </button>
                <div class="account-card" id="to-card">
                    <div class="label">TO</div>
                    <div class="balance" id="to-account-name">Gaming Balance</div>
                </div>
            </div>
            <form class="transfer-form" id="transferForm">
                <label for="amount">Amount:</label>
                <input type="number" id="amount" placeholder="₹0.00" required min="1" step="0.01">
                <button type="submit" id="transferBtn">Confirm Transfer</button>
            </form>
        </div>
    </div>

    <!-- Enhanced Help Overlay -->
    <div class="overlay" id="helpOverlay">
        <div class="overlay-content">
            <div class="close-btn" id="closeBtn" aria-label="Close help"></div>
            <h3><i class="fas fa-question-circle"></i> Frequently Asked Questions</h3>
            
            <div class="faq-item">
                <div class="faq-question">Q: Wallet Balance और Gaming Balance में क्या अंतर है?</div>
                <div class="faq-answer">Wallet Balance आपके general transactions के लिए है, जबकि Gaming Balance सिर्फ games और entertainment के लिए उपयोग होता है।</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">Q: क्या मैं दोनों balances के बीच पैसे transfer कर सकता हूँ?</div>
                <div class="faq-answer">हाँ, आप Transfer Funds सेक्शन का उपयोग करके आसानी से पैसे transfer कर सकते हैं।</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">Q: Add Money बटन कैसे काम करता है?</div>
                <div class="faq-answer">Add Money बटन पर क्लिक करके आप अपने Gaming Balance में पैसे जोड़ सकते हैं।</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">Q: क्या transactions secure हैं?</div>
                <div class="faq-answer">हाँ, सभी transactions encrypted और secure हैं। आपकी जानकारी पूरी तरह सुरक्षित है।</div>
            </div>
        </div>
    </div>

    <script>
        // Enhanced Mobile-Friendly JavaScript
        
        // Utility function to show loading state
        function showLoading(element) {
            element.classList.add('loading');
            element.disabled = true;
        }

        function hideLoading(element) {
            element.classList.remove('loading');
            element.disabled = false;
        }

        // Enhanced Overlay Logic
        const helpBtn = document.getElementById('helpBtn');
        const closeBtn = document.getElementById('closeBtn');
        const overlay = document.getElementById('helpOverlay');

        helpBtn.addEventListener('click', () => {
            overlay.classList.add('show');
            document.body.style.overflow = 'hidden'; // Prevent background scroll
        });

        closeBtn.addEventListener('click', () => {
            overlay.classList.remove('show');
            document.body.style.overflow = ''; // Restore scroll
        });

        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.classList.remove('show');
                document.body.style.overflow = '';
            }
        });

        // Enhanced Swap Button Logic
        const swapBtn = document.getElementById('swap-btn');
        const fromAccountName = document.getElementById('from-account-name');
        const toAccountName = document.getElementById('to-account-name');

        swapBtn.addEventListener('click', () => {
            // Add haptic feedback for mobile
            if (navigator.vibrate) {
                navigator.vibrate(50);
            }
            
            // Swap the account names
            const temp = fromAccountName.textContent;
            fromAccountName.textContent = toAccountName.textContent;
            toAccountName.textContent = temp;
        });

        // Add Money Button - Redirect to /recharge.php
        const addMoneyBtn = document.getElementById('addMoneyBtn');
        
        addMoneyBtn.addEventListener('click', () => {
            // Add haptic feedback for mobile
            if (navigator.vibrate) {
                navigator.vibrate(100);
            }
            
            showLoading(addMoneyBtn);
            
            // Redirect to recharge page
            setTimeout(() => {
                window.location.href = '/recharge.php';
            }, 300); // Small delay for better UX
        });

        // Enhanced Transfer Form Logic with Backend Integration
        const transferForm = document.getElementById('transferForm');
        const amountInput = document.getElementById('amount');
        const transferBtn = document.getElementById('transferBtn');

        transferForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const amount = parseFloat(amountInput.value);
            const fromAccount = fromAccountName.textContent;
            const toAccount = toAccountName.textContent;
            
            // Validation
            if (!amount || amount <= 0) {
                  showNotification('Please enter a valid amount', 'error');
              return;
            }

            // Add haptic feedback for mobile
            if (navigator.vibrate) {
                navigator.vibrate([100, 50, 100]);
            }

            showLoading(transferBtn);

            // Prepare data for backend
            const transferData = {
                amount: amount,
                from_account: fromAccount,
                to_account: toAccount
            };

            try {
                // Send data to backend
                const response = await fetch('transfer_balance', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify(transferData)
                });

                const result = await response.json();

                if (response.ok && result.success) {
                    // Success
                 showNotification('Transfer Successful!', 'success'); 
                    amountInput.value = '';
                    
                    // Update balances if provided by backend
                    if (result.updated_balances) {
                        updateBalanceDisplay(result.updated_balances);
                    }
                } else {
                    // Error from backend
                    showNotification(result.message || 'Transfer Failed', 'error');
                }
            } catch (error) {
                // Network or other error
                console.error('Transfer error:', error);
                showNotification('Network error. Please try again.', 'error');
            } finally {
                hideLoading(transferBtn);
            }
        });


        // Enhanced mobile touch handling
        document.addEventListener('touchstart', function() {}, {passive: true});
        
        // Prevent zoom on double tap for form inputs
        let lastTouchEnd = 0;
        document.addEventListener('touchend', function (event) {
            const now = (new Date()).getTime();
            if (now - lastTouchEnd <= 300) {
                event.preventDefault();
            }
            lastTouchEnd = now;
        }, false);

        // Service Worker registration for better mobile performance (optional)
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
                // Register service worker if available
                console.log('Service Worker support detected');
            });
        }
        
    
document.addEventListener('DOMContentLoaded', function () {
    fetchBalances();
});

function fetchBalances() {
    fetch('get_all_balance') // 🔁 Update this path if file name is different
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                // Set Wallet Balance
                const walletBalanceEl = document.querySelector('.wallet-card .amount');
                if (walletBalanceEl) {
                    walletBalanceEl.textContent = '₹' + data.wallet_balance;
                }

                // Set Gaming Balance
                const gamingBalanceEl = document.querySelector('.gaming-card .amount');
                if (gamingBalanceEl) {
                    gamingBalanceEl.textContent = '₹' + data.balance;
                }
            } else {
                console.error('Balance fetch error:', data.message);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
        });
}
   
 // इस फंक्शन को अपने मौजूदा स्क्रिप्ट टैग में कहीं भी जोड़ें
function showNotification(message, type) {
    // पुराने नोटिफिकेशन को हटा दें (अगर कोई है)
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }

    // नया नोटिफिकेशन एलिमेंट बनाएं
    const notification = document.createElement('div');
    notification.className = `notification ${type}`; // type होगा 'success' या 'error'
    
    // आइकन सेट करें
    const iconClass = type === 'success' ? 'fas fa-check-circle' : 'fas fa-times-circle';
    notification.innerHTML = `<i class="${iconClass}"></i><span>${message}</span>`;

    // बॉडी में जोड़ें
    document.body.appendChild(notification);

    // कुछ ही पलों में 'show' क्लास जोड़ें ताकि CSS ट्रांजीशन काम करे
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);

    // 1 सेकंड बाद नोटिफिकेशन को हटा दें
    setTimeout(() => {
        notification.classList.remove('show');
        // ट्रांजीशन खत्म होने के बाद DOM से हटा दें
        notification.addEventListener('transitionend', () => {
            notification.remove();
        });
    }, 2000);
}

    </script>
</body>
</html>
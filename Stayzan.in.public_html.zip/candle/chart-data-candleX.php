<?php
// /api/chart-data.php

// --- हेडर और कनेक्शन (यह सब ठीक है) ---
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header('Content-Type: application/json');

$host = "localhost";
$user = "u976552851_candleY";
$password = "Govind@2003#";
$database = "u976552851_candleY";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    // एक JSON त्रुटि भेजें
    echo json_encode(['success' => false, 'error' => 'Database connection failed.']);
    exit();
}

// --- पैरामीटर (यह भी ठीक है) ---
$asset = isset($_GET['asset']) ? $_GET['asset'] : 'Lee';
$timeframe = isset($_GET['timeframe']) ? (int)$_GET['timeframe'] : 30;
$limit = 500; // हम केवल 500 कैंडल का इतिहास भेजेंगे


$sql = "
    SELECT * FROM (
        SELECT 
            `timestamp` as `time`, 
            `open_price` as `open`, 
            `high_price` as `high`, 
            `low_price` as `low`, 
            `close_price` as `close` 
        FROM `candles` 
        WHERE `asset_name` = ? AND `timeframe` = ? 
        ORDER BY `timestamp` DESC 
        LIMIT ?
    ) sub
    ORDER BY `time` ASC
";

$stmt = $conn->prepare($sql);
// अब तीन पैरामीटर हैं, इसलिए "sii" का उपयोग करें
$stmt->bind_param("sii", $asset, $timeframe, $limit);

// --- बाकी का कोड वैसा ही रहेगा ---
$stmt->execute();
$result = $stmt->get_result();

$candles = [];
while ($row = $result->fetch_assoc()) {
    $row['open'] = (float)$row['open'];
    $row['high'] = (float)$row['high'];
    $row['low'] = (float)$row['low'];
    $row['close'] = (float)$row['close'];
    $candles[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode(['success' => true, 'candles' => $candles]);
?>

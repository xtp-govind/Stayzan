<?php
// फाइल का नाम: ultra_light_engine.php

// इसे 35 सेकंड तक चलने दें, यह काफी है
set_time_limit(29);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$asset_name = 'Lee';
echo "अल्ट्रा-लाइट इंजन शुरू हो रहा है: [$asset_name]...\n";

// --- डेटाबेस कनेक्शन (सिर्फ ट्रेड्स वाला) ---
$tradesHost = "localhost";
$tradesUser = "u976552851_candleY";
$tradesPass = "Govind@2003#";
$tradesDB   = "u976552851_candleY";
$connTrades = new mysqli($tradesHost, $tradesUser, $tradesPass, $tradesDB);

// --- कॉन्फ़िगरेशन ---
$timeframe = 30;

// Helper: लाइव प्राइस अपडेट करने के लिए
function updateLivePrice($conn, $asset, $price) {
    $stmt = $conn->prepare("INSERT INTO live_prices (asset_name, current_price) VALUES (?, ?) ON DUPLICATE KEY UPDATE current_price = ?");
    $stmt->bind_param("sdd", $asset, $price, $price);
    $stmt->execute();
}

// ==================================================================
// मुख्य लॉजिक
// ==================================================================

$candle_timestamp = floor(time() / $timeframe) * $timeframe;

// 1. सही ओपन प्राइस प्राप्त करें
$last_candle_stmt = $connTrades->prepare("SELECT close_price FROM candles WHERE asset_name = ? AND close_price IS NOT NULL ORDER BY timestamp DESC LIMIT 1");
$last_candle_stmt->bind_param("s", $asset_name);
$last_candle_stmt->execute();
$result = $last_candle_stmt->get_result();
$open_price = ($result->fetch_assoc()['close_price']) ?? 100.0;
$open_price = (float)$open_price;

if ($open_price <= 0) {
    $open_price = 100.0;
}

// 2. नई कैंडल बनाएं (सिर्फ ओपन प्राइस के साथ)
$insert_candle_stmt = $connTrades->prepare(
    "INSERT INTO candles (asset_name, timeframe, open_price, timestamp) VALUES (?, ?, ?, ?)"
);
$insert_candle_stmt->bind_param("sidi", $asset_name, $timeframe, $open_price, $candle_timestamp);
$insert_candle_stmt->execute();
$new_candle_id = $connTrades->insert_id;
echo "[$asset_name] नई कैंडल (#$new_candle_id) बनाई गई। ओपन: $open_price\n";

// 3. बेट्स इकट्ठा करें (सिर्फ यह तय करने के लिए कि कीमत किस दिशा में ले जानी है)
$stmt = $connTrades->prepare("SELECT direction, bet_amount FROM trades WHERE asset_name = ? AND status = 'waiting'");
$stmt->bind_param("s", $asset_name);
$stmt->execute();
$waiting_trades_result = $stmt->get_result();

$total_up_bets = 0;
$total_down_bets = 0;
while ($row = $waiting_trades_result->fetch_assoc()) {
    if ($row['direction'] === 'up') {
        $total_up_bets += (float)$row['bet_amount'];
    } else {
        $total_down_bets += (float)$row['bet_amount'];
    }
}
echo "[$asset_name] बेट्स का विश्लेषण: (UP: $total_up_bets, DOWN: $total_down_bets)\n";

// 4. जीतने वाली दिशा तय करें (कंपनी का मुनाफा)
$company_should_win_up = ($total_up_bets <= $total_down_bets);

// ==================================================================
// 30-सेकंड का लाइव प्राइस लूप
// ==================================================================
$live_price = $open_price;
$high_price = $open_price;
$low_price = $open_price;

for ($second = 1; $second <= $timeframe; $second++) {
    $loop_start_time = microtime(true);

    // --- लाइव प्राइस की गणना ---
    $change = 0;
    if ($second <= 10) {
        $change = (rand(-15, 15) / 1000);
    } elseif ($second > 10 && $second < ($timeframe - 2)) {
        if ($total_up_bets > 0 || $total_down_bets > 0) { // अगर कोई बेट है
            if ($company_should_win_up) {
                $change = (rand(5, 20) / 1000);
            } else {
                $change = (rand(-20, -5) / 1000);
            }
        } else {
            $change = (rand(-15, 15) / 1000);
        }
    } else {
        $change = (rand(-10, 10) / 1000);
    }
    
    $live_price = $live_price * (1 + $change);
    $high_price = max($high_price, $live_price);
    $low_price = min($low_price, $live_price);

    updateLivePrice($connTrades, $asset_name, $live_price);
    // echo "[$asset_name] सेकंड $second: लाइव प्राइस = " . round($live_price, 4) . "\n"; // आप चाहें तो इसे बंद कर सकते हैं

    // --- सटीक 1 सेकंड का इंतजार ---
    $loop_end_time = microtime(true);
    $execution_time = $loop_end_time - $loop_start_time;
    $sleep_time = 1 - $execution_time;
    if ($sleep_time > 0) {
        usleep($sleep_time * 1000000);
    }
}

// ==================================================================
// चक्र का अंत: सिर्फ कैंडल को अपडेट करें
// ==================================================================
$final_close_price = $live_price;
echo "[$asset_name] चक्र समाप्त। फाइनल क्लोज प्राइस: $final_close_price\n";

// 5. कैंडल को हाई, लो और क्लोज प्राइस के साथ अपडेट करें
$update_candle_stmt = $connTrades->prepare("UPDATE candles SET high_price = ?, low_price = ?, close_price = ? WHERE id = ?");
$update_candle_stmt->bind_param("dddi", $high_price, $low_price, $final_close_price, $new_candle_id);
$update_candle_stmt->execute();
echo "[$asset_name] कैंडल (#$new_candle_id) अपडेट की गई।\n";

$connTrades->close();
echo "[$asset_name] अल्ट्रा-लाइट इंजन समाप्त।\n";
?>

<?php
// फाइल का नाम: get_live_price.php

// --- आउटपुट को JSON बनाने के लिए हेडर सेट करें ---
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // यह लाइन डेवलपमेंट के लिए जरूरी हो सकती है

// --- डेटाबेस कनेक्शन ---
// ध्यान दें: यहाँ आपको वही कनेक्शन डिटेल्स डालनी हैं जो आपकी इंजन स्क्रिप्ट में हैं
$host = "localhost";
$user = "u976552851_candleY"; // ट्रेड्स वाला यूजर
$pass = "Govind@2003#";      // ट्रेड्स वाला पासवर्ड
$db   = "u976552851_candleY";      // ट्रेड्स वाला डेटाबेस
$conn = new mysqli($host, $user, $pass, $db);

// कनेक्शन जांचें
if ($conn->connect_error) {
    // अगर कनेक्शन फेल होता है तो एरर मैसेज भेजें
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit(); // स्क्रिप्ट को यहीं रोक दें
}

// --- एसेट का नाम प्राप्त करें ---
// हम यह उम्मीद कर रहे हैं कि फ्रंटएंड से asset_name भेजा जाएगा, जैसे: get_live_price.php?asset=Lee
$asset_name = $_GET['asset'] ?? '';

if (empty($asset_name)) {
    // अगर एसेट का नाम नहीं भेजा गया तो एरर दें
    echo json_encode(['success' => false, 'message' => 'Asset name not provided.']);
    exit();
}

// --- डेटाबेस से लाइव प्राइस प्राप्त करें ---
try {
    $stmt = $conn->prepare("SELECT current_price, last_updated FROM live_prices WHERE asset_name = ?");
    $stmt->bind_param("s", $asset_name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // कीमत को फ्लोट में बदलें और 4 डेसीमल तक राउंड करें, जैसा आप चाहते हैं
        $price = round((float)$row['current_price'], 4); 
        
        // सफलता का मैसेज और डेटा भेजें
        echo json_encode([
            'success' => true,
            'asset' => $asset_name,
            'price' => $price,
            'last_updated' => $row['last_updated']
        ]);
    } else {
        // अगर उस एसेट के लिए कोई कीमत नहीं मिली
        echo json_encode(['success' => false, 'message' => 'Price not available for this asset.']);
    }

} catch (Exception $e) {
    // अगर कोई और SQL एरर आती है
    echo json_encode(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
}

// कनेक्शन बंद करें
$conn->close();

?>

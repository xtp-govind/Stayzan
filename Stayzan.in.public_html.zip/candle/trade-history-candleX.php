<?php

// 1. हेडर को JSON के रूप में सेट 
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header('Content-Type: application/json');
session_start();

// ✅ DB connection
$host = "localhost";
$user = "u976552851_candleY";
$password = "Govind@2003#";
$database = "u976552851_candleY";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
// 3. उपयोगकर्ता की पहचान करें (यह सबसे महत्वपूर्ण सुरक्षा जांच है)
if (!isset($_SESSION['unique_id'])) {
    // यदि उपयोगकर्ता लॉग इन नहीं है, तो त्रुटि भेजें
    echo json_encode(['success' => false, 'error' => 'Authentication required.']);
    exit(); // स्क्रिप्ट को तुरंत रोक दें
}
// लॉग-इन उपयोगकर्ता की यूनिक आईडी प्राप्त करें
$user_unique_id = $_SESSION['unique_id'];

// 4. डेटाबेस से डेटा प्राप्त करने की तैयारी करें
$trades = [];
$error = null;

try {
    // SQL क्वेरी: केवल लॉग-इन उपयोगकर्ता के ट्रेड प्राप्त करें
    // सबसे हाल के ट्रेड को सबसे ऊपर दिखाने के लिए `ORDER BY placed_at DESC` का उपयोग करें
    $sql = "SELECT 
                asset_name,
                direction,
                bet_amount,
                entry_price,
                exit_price,
                status,
                result_amount,
                placed_at
            FROM 
                trades 
            WHERE 
                user_unique_id = ? 
            ORDER BY 
                placed_at DESC
            LIMIT 50"; // प्रदर्शन के लिए एक लिमिट जोड़ना एक अच्छा अभ्यास है

    // SQL इंजेक्शन से बचने के लिए तैयार स्टेटमेंट का उपयोग करें
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user_unique_id);

    // 5. क्वेरी निष्पादित करें
    $stmt->execute();
    $result = $stmt->get_result();

    // 6. परिणामों को एक ऐरे में संसाधित करें
    while ($row = $result->fetch_assoc()) {
        // डेटा को फ्रंटएंड के लिए तैयार करें
        $trades[] = [
            // डेटाबेस कॉलम को जावास्क्रिप्ट में अपेक्षित नामों से मैप करें
            'assetName' => $row['asset_name'],
            'direction' => $row['direction'],
            'betAmount' => (float)$row['bet_amount'],
            'entryPrice' => (float)$row['entry_price'],
            'exitPrice' => $row['exit_price'] ? (float)$row['exit_price'] : 0, // यदि NULL है तो 0 सेट करें
            'result' => $row['result_amount'] ? (float)$row['result_amount'] : 0, // यदि NULL है तो 0 सेट करें
            'timeframeLabel' => '30s', // आप इसे trades टेबल में भी स्टोर कर सकते हैं
            'startTime' => date('h:i:s A', strtotime($row['placed_at'])), // समय को प्रारूपित करें
            'endTime' => $row['exit_price'] ? date('h:i:s A', strtotime($row['placed_at']) + 30) : 'N/A' // अनुमानित अंत समय
        ];
    }

    // 7. स्टेटमेंट और कनेक्शन बंद करें
    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    // यदि कोई डेटाबेस त्रुटि होती है
    $error = "An error occurred: " . $e->getMessage();
}

// 8. अंतिम JSON प्रतिक्रिया भेजें
if ($error) {
    echo json_encode(['success' => false, 'error' => $error]);
} else {
    echo json_encode(['success' => true, 'data' => $trades]);
}

?>

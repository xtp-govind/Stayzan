<?php
// /api/place-bet.php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header('Content-Type: application/json');

// ✅ Users DB connection (user details + balance)
$usersHost = "localhost";
$usersUser = "u976552851_hellogovind";
$usersPass = "Govind@00#";
$usersDB   = "u976552851_hellogovind";
$connUsers = new mysqli($usersHost, $usersUser, $usersPass, $usersDB);
if ($connUsers->connect_error) {
    die(json_encode(['success' => false, 'error' => "Users DB connection failed: " . $connUsers->connect_error]));
}

// ✅ Trades DB connection (bets/trades storage)
$tradesHost = "localhost";
$tradesUser = "u976552851_candleY";
$tradesPass = "Govind@2003#";
$tradesDB   = "u976552851_candleY";
$connTrades = new mysqli($tradesHost, $tradesUser, $tradesPass, $tradesDB);
if ($connTrades->connect_error) {
    die(json_encode(['success' => false, 'error' => "Trades DB connection failed: " . $connTrades->connect_error]));
}

// ✅ Check login
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(['success' => false, 'error' => 'Authentication required.']);
    exit();
}
$user_unique_id = $_SESSION['unique_id'];

// ✅ Input
$json_data = file_get_contents('php://input');
$data = json_decode($json_data);

if (!$data || !isset($data->asset) || !isset($data->direction) || !isset($data->amount)) {
    echo json_encode(['success' => false, 'error' => 'Invalid input data.']);
    exit();
}

$asset = $data->asset;
$direction = $data->direction;
$betAmount = (float)$data->amount;

try {
    // --- Step 1: Lock + check balance in Users DB ---
    $connUsers->begin_transaction();

    $stmt = $connUsers->prepare("SELECT `balance` FROM `users` WHERE `unique_id` = ? FOR UPDATE");
    $stmt->bind_param("s", $user_unique_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        throw new Exception("User not found.");
    }

    $currentBalance = (float)$user['balance'];
    if ($currentBalance < $betAmount) {
        throw new Exception("Insufficient balance.");
    }

    // Deduct balance
    $newBalance = $currentBalance - $betAmount;
    $stmt = $connUsers->prepare("UPDATE `users` SET `balance` = ? WHERE `unique_id` = ?");
    $stmt->bind_param("ds", $newBalance, $user_unique_id);
    $stmt->execute();

    // Commit users balance update
    $connUsers->commit();

    // --- Step 2: Get entry price from latest candle of this asset ---
    $stmt = $connTrades->prepare("SELECT close_price 
                                  FROM candles 
                                  WHERE asset_name = ? 
                                  ORDER BY timestamp DESC 
                                  LIMIT 1");
    $stmt->bind_param("s", $asset);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        $entryPrice = (float)$row['close_price'];
    } else {
        // fallback (अगर candles table खाली हो)
        $entryPrice = 100.00;
    }

    // --- Step 3: Insert trade record in Trades DB ---
    $stmt = $connTrades->prepare("INSERT INTO `trades` 
        (user_unique_id, asset_name, direction, bet_amount, entry_price, status) 
        VALUES (?, ?, ?, ?, ?, 'waiting')");
    $stmt->bind_param("sssdd", $user_unique_id, $asset, $direction, $betAmount, $entryPrice);
    $stmt->execute();

    echo json_encode([
        'success'    => true,
        'message'    => 'Bet placed successfully!',
        'newBalance' => $newBalance,
        'entryPrice' => $entryPrice
    ]);

} catch (Exception $e) {
    $connUsers->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

if (isset($stmt) && $stmt) {
    $stmt->close();
}
$connUsers->close();
$connTrades->close();
?>
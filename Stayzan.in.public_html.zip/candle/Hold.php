<?php  
  
// त्रुटियों को स्क्रीन पर दिखाने के लिए, ताकि डीबगिंग आसान हो  
ini_set('display_errors', 1);  
ini_set('display_startup_errors', 1);  
error_reporting(E_ALL);  
  
// MySQLi को सख्त मोड में सेट करें  
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);  
  
echo "यथार्थवादी स्मार्ट Cron Job शुरू हो रहा है...\n";  
  
// --- डेटाबेस कनेक्शन ---  
$tradesHost = "localhost";   
$tradesUser = "u976552851_candleY";   
$tradesPass = "Govind@2003#";   
$tradesDB   = "u976552851_candleY";  
$connTrades = new mysqli($tradesHost, $tradesUser, $tradesPass, $tradesDB);  
  
$usersHost = "localhost";   
$usersUser = "u976552851_hellogovind";   
$usersPass = "Govind@00#";   
$usersDB   = "u976552851_hellogovind";  
$connUsers = new mysqli($usersHost, $usersUser, $usersPass, $usersDB);  
  
// --- कॉन्फ़िगरेशन ---  
$assets_to_process = ['Lee', 'BTB', 'RAa', 'Gol', 'Oxl'];  
$timeframe = 30; // सेकंड  
$payout_ratio = 0.85; // 85% लाभ  
  
// Helper: random decimal generate करना  
function makeRandomDecimal($base) {  
    $digits = rand(6, 8); // 6–8 digit ka random decimal  
    $randDec = mt_rand(10**($digits-1), (10**$digits)-1);  
    return floor($base) . "." . $randDec;  
}  
  
foreach ($assets_to_process as $asset_name) {  
    echo "------------------------------------------\n";  
    echo "एसेट प्रोसेस हो रहा है: $asset_name\n";  
  
    // 1. सभी 'waiting' बेट्स और ओपन प्राइस प्राप्त करें  
    $stmt = $connTrades->prepare("SELECT id, user_unique_id, direction, bet_amount, entry_price FROM trades WHERE asset_name = ? AND status = 'waiting'");  
    $stmt->bind_param("s", $asset_name);  
    $stmt->execute();  
    $waiting_trades_result = $stmt->get_result();  
      
    $waiting_trades = [];  
    $total_up_bets = 0;  
    $total_down_bets = 0;  
    $highest_up_entry = 0;  
    $lowest_down_entry = INF;  
  
    while ($row = $waiting_trades_result->fetch_assoc()) {  
        $row['bet_amount'] = (float)$row['bet_amount'];  
        $row['entry_price'] = (float)$row['entry_price'];  
        $waiting_trades[] = $row;  
          
        if ($row['direction'] === 'up') {  
            $total_up_bets += $row['bet_amount'];  
            $highest_up_entry = max($highest_up_entry, $row['entry_price']);  
        } else {  
            $total_down_bets += $row['bet_amount'];  
            $lowest_down_entry = min($lowest_down_entry, $row['entry_price']);  
        }  
    }  
  
    // पिछली कैंडल का क्लोज प्राइस प्राप्त करें  
    $last_candle_stmt = $connTrades->prepare("SELECT close_price FROM candles WHERE asset_name = ? ORDER BY timestamp DESC LIMIT 1");  
    $last_candle_stmt->bind_param("s", $asset_name);  
    $last_candle_stmt->execute();  
    $open_price = ($last_candle_stmt->get_result()->fetch_assoc()['close_price']) ?? 100.0;  
    $open_price = (float)$open_price;  
  
    // अगर कोई बेट नहीं है तो रैंडम कैंडल बनाओ  
    if (empty($waiting_trades)) {  
        echo "कोई waiting trade नहीं है। एक रैंडम कैंडल बना रहा हूँ...\n";  
          
        $percent_change = (rand(-50, 50) / 10000);    
        $close_price = $open_price * (1 + $percent_change);  
          
        $high_price = max($open_price, $close_price) + (rand(1, 50) / 100.0);  
        $low_base   = min($open_price, $close_price) - (rand(1, 50) / 100.0);  
  
        if ($low_base >= min($open_price, $close_price)) {  
            $low_base = min($open_price, $close_price) - (rand(1, 10) / 100.0);  
        }  
  
        // ✅ random decimal low price  
        $low_price = makeRandomDecimal($low_base);  
  
        $high_price = round($high_price, 2);  
        $close_price = round($close_price, 2);  
  
        $candle_time = floor(time() / $timeframe) * $timeframe;  
          
        $insert_candle_stmt = $connTrades->prepare(  
            "INSERT INTO candles (asset_name, timeframe, open_price, high_price, low_price, close_price, timestamp)   
             VALUES (?, ?, ?, ?, ?, ?, ?)"  
        );  
        $insert_candle_stmt->bind_param("siddsdi", $asset_name, $timeframe, $open_price, $high_price, $low_price, $close_price, $candle_time);  
        $insert_candle_stmt->execute();  
          
        echo "रैंडम कैंडल बनाई गई। ओपन: $open_price, क्लोज: $close_price, हाई: $high_price, लो: $low_price\n";  
        continue;  
    }  
  
    // 2. जीतने वाली दिशा तय करें  
    $make_up_win = ($total_up_bets <= $total_down_bets);  
    echo "कुल UP: $total_up_bets | कुल DOWN: $total_down_bets\n";  
  
    // 3. Random close price  
    $percent_change = (rand(50, 250) / 10000);  
    $random_direction = (rand(0, 1) === 1) ? 1 : -1;  
    $natural_close_price = $open_price * (1 + ($percent_change * $random_direction));  
    $final_close_price = $natural_close_price;  
  
    // 4. Adjustment for winner  
    if ($make_up_win) {  
        if ($final_close_price <= $lowest_down_entry) {  
            $adjustment = $open_price * (rand(10, 50) / 10000);  
            $final_close_price = $lowest_down_entry + $adjustment;  
        }  
    } else {  
        if ($final_close_price >= $highest_up_entry) {  
            $adjustment = $open_price * (rand(10, 50) / 10000);  
            $final_close_price = $highest_up_entry - $adjustment;  
        }  
    }  
      
    $final_close_price = round($final_close_price, 2);  
    echo "ओपन: $open_price | क्लोज: $final_close_price\n";  
  
    // 5. Trades process karo  
    foreach ($waiting_trades as $trade) {  
        $is_win = false;  
        if ($trade['direction'] === 'up' && $final_close_price > $trade['entry_price']) {  
            $is_win = true;  
        } elseif ($trade['direction'] === 'down' && $final_close_price < $trade['entry_price']) {  
            $is_win = true;  
        }  
  
        $new_status = $is_win ? 'win' : 'loss';  
        $result_amount = $is_win ? ($trade['bet_amount'] * $payout_ratio) : -$trade['bet_amount'];  
  
        $connTrades->begin_transaction();  
        try {  
            $update_trade_stmt = $connTrades->prepare("UPDATE trades SET status = ?, result_amount = ?, exit_price = ? WHERE id = ?");  
            $update_trade_stmt->bind_param("sddi", $new_status, $result_amount, $final_close_price, $trade['id']);  
            $update_trade_stmt->execute();  
  
            if ($is_win) {  
                $amount_to_add = $trade['bet_amount'] + ($trade['bet_amount'] * $payout_ratio);  
                $update_balance_stmt = $connUsers->prepare("UPDATE users SET balance = balance + ? WHERE unique_id = ?");  
                $update_balance_stmt->bind_param("ds", $amount_to_add, $trade['user_unique_id']);  
                $update_balance_stmt->execute();  
            }  
            $connTrades->commit();  
        } catch (Exception $e) {  
            $connTrades->rollback();  
            error_log("ट्रेड प्रोसेस Error: #" . $trade['id'] . " - " . $e->getMessage() . "\n", 3, __DIR__."/cron_errors.log");  
        }  
    }  
  
    // 6. ✅ Final candle with strict low + random decimal  
    $high_price = max($open_price, $final_close_price) + (rand(1, 50) / 100.0);  
    $low_base   = min($open_price, $final_close_price) - (rand(1, 50) / 100.0);  
  
    if ($low_base >= min($open_price, $final_close_price)) {  
        $low_base = min($open_price, $final_close_price) - (rand(1, 10) / 100.0);  
    }  
  
    $low_price = makeRandomDecimal($low_base);  
    $high_price = round($high_price, 2);  
  
    $candle_time = floor(time() / $timeframe) * $timeframe;  
      
    $insert_candle_stmt = $connTrades->prepare(  
        "INSERT INTO candles (asset_name, timeframe, open_price, high_price, low_price, close_price, timestamp)   
         VALUES (?, ?, ?, ?, ?, ?, ?)"  
    );  
    $insert_candle_stmt->bind_param("siddsdi", $asset_name, $timeframe, $open_price, $high_price, $low_price, $final_close_price, $candle_time);  
    $insert_candle_stmt->execute();  
  
    echo "नई कैंडल बनाई गई। हाई: $high_price | लो: $low_price\n";  
}  
  
$connTrades->close();  
$connUsers->close();  
echo "यथार्थवादी स्मार्ट Cron Job समाप्त हुआ।\n";  
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lottie Success Test</title>
  <!-- Lottie Player -->
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      padding: 40px;
      background: #f4f4f4;
    }
    #success-animation {
      display: none;
      margin-top: 20px;
    }
    button {
      padding: 10px 20px;
      font-size: 16px;
      border: none;
      background: #4CAF50;
      color: white;
      cursor: pointer;
      border-radius: 8px;
    }
    button:hover {
      background: #45a049;
    }
  </style>
</head>
<body>

  <h1>Test Page</h1>
  <p>Click below to test the success effect 👇</p>
  <button onclick="showSuccessAnimation()">Show Success Effect</button>

  <div id="success-animation">
    <lottie-player 
      src="https://assets9.lottiefiles.com/packages/lf20_jbrw3hcz.json"
      background="transparent"  
      speed="1"  
      style="width: 300px; height: 300px;"  
      autoplay>
    </lottie-player>
    <h2>Payment Successful 🎉</h2>
  </div>

  <script>
    function showSuccessAnimation() {
      const animBox = document.getElementById("success-animation");
      animBox.style.display = "block"; // show animation box
    }
  </script>

</body>
</html>
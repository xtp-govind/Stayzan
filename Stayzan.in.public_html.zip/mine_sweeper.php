<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>माइन स्वीपर गेम</title>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    <style>
/* === नया और आकर्षक CSS कोड === */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

:root {
    --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    --secondary-color: #5E5DF0;
    --background-color: #f0f2f5;
    --box-color: #ffffff;
    --text-color: #333;
    --light-text: #777;
    --start-button-color: #28a745;
    --stop-button-gradient: linear-gradient(135deg, #ff8c00, #fd7e14);
    --win-color: #28a745;
    --loss-color: #dc3545;
    --border-radius: 12px;
    --shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
}

body {
    font-family: 'Poppins', sans-serif;
    background-color: var(--background-color);
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
}

.mobile-frame {
    width: 100%;
    max-width: 450px;
    background-color: var(--background-color);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
}

.game-header {
    background: var(--primary-gradient);
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 1.2em;
    font-weight: 600;
}
.game-header .back-arrow, .game-header .rules {
    cursor: pointer;
    transition: transform 0.2s;
}
.game-header .back-arrow:hover, .game-header .rules:hover {
    transform: scale(1.1);
}

.main-content {
    padding: 20px;
    background: var(--primary-gradient);
    border-bottom-left-radius: 35px;
    border-bottom-right-radius: 35px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

/* === नया टॉप-बार स्टाइल === */
.top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}
.top-bar .icons {
    display: flex;
    gap: 15px;
}
.top-bar .icons i {
    font-size: 20px;
    cursor: pointer;
    color: white;
    opacity: 0.8;
    transition: opacity 0.3s, transform 0.3s;
}
.top-bar .icons i:hover {
    opacity: 1;
    transform: scale(1.1);
}
.wallet {
    display: flex;
    align-items: center;
    background-color: rgba(255, 255, 255, 0.15);
    padding: 8px 15px;
    border-radius: 50px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}
.wallet .coin-icon {
    color: #ffd700;
    margin-right: 10px;
    font-size: 1.2em;
    animation: spin 2s linear infinite;
}
@keyframes spin {
    from { transform: rotateY(0deg); }
    to { transform: rotateY(360deg); }
}
.wallet #wallet-amount {
    font-size: 1.1em;
    font-weight: 600;
    color: white;
}

.grid-selector {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 25px;
}
.grid-selector button {
    background-color: rgba(255, 255, 255, 0.2);
    color: white;
    border: 1px solid rgba(255, 255, 255, 0.5);
    padding: 10px 25px;
    border-radius: 20px;
    cursor: pointer;
    font-size: 1em;
    font-weight: 500;
    transition: all 0.3s;
}
.grid-selector button.active {
    background-color: white;
    color: var(--secondary-color);
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

/* --- ग्रिड एरिया (कोई बदलाव नहीं) --- */
.grid-area {
    position: relative;
    display: grid;
    gap: 10px;
    justify-content: center;
}
.box {
    width: 100%; aspect-ratio: 1 / 1;
    background-color: var(--box-color);
    border-radius: var(--border-radius);
    cursor: pointer;
    transition: all 0.3s;
    display: flex; flex-direction: column;
    justify-content: center; align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
}
.box-icon { font-size: 36px; color: var(--secondary-color); opacity: 0.6; }
.box-text { color: var(--secondary-color); font-weight: 500; margin-top: 5px; }
.box.opened.safe { background-color: #ffc107; }
.box.opened.bomb { background-color: var(--loss-color); }
.box.opened .box-icon, .box.opened .box-text { display: none; }
.box .reward-text { font-size: 1.5em; font-weight: bold; color: #fff; }
.box .bomb-icon { font-size: 2.5em; color: white; }

#start-button {
    position: absolute; top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    width: 100px; height: 100px;
    background-color: var(--start-button-color);
    color: white; border-radius: 50%;
    border: 5px solid rgba(255, 255, 255, 0.7);
    display: flex; justify-content: center; align-items: center;
    font-size: 1.8em; font-weight: bold; cursor: pointer;
    z-index: 10; transition: all 0.3s;
}

/* === नया स्टॉप बटन स्टाइल === */
#stop-button-container {
    padding: 15px 20px;
    background-color: #fff;
    position: sticky;
    bottom: 0;
    box-shadow: 0 -5px 20px rgba(0,0,0,0.08);
    border-top: 1px solid #e9ecef;
}
#stop-button {
    width: 100%;
    padding: 15px;
    background: var(--stop-button-gradient);
    color: white;
    border: none;
    border-radius: var(--border-radius);
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 20px rgba(253, 126, 20, 0.4);
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 15px;
    letter-spacing: 0.5px;
}
#stop-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(253, 126, 20, 0.5);
}
#stop-button .stop-button-text { font-size: 1.1em; font-weight: 500; }
#stop-button .stop-button-winnings { font-size: 1.2em; font-weight: 700; }

.info-section { padding: 25px 20px; text-align: center; background: #fff; }
.info-section h3 { margin-top: 0; font-weight: 400; font-size: 1em; color: var(--light-text); }
#message { font-weight: 600; color: var(--secondary-color); min-height: 24px; font-size: 1.1em; }

/* === नया और बेहतर हिस्ट्री सेक्शन का CSS === */
.history-section {
    background-color: #fff;
    padding: 0;
    border-top: 8px solid var(--background-color);
}

.history-tabs {
    display: flex;
    background-color: #f0f2f5;
    padding: 5px;
    margin: 20px 15px 0 15px;
    border-radius: var(--border-radius);
}

.history-tab {
    flex: 1;
    padding: 12px 10px;
    border: none;
    background-color: transparent;
    color: var(--light-text);
    font-size: 1em;
    font-weight: 600;
    cursor: pointer;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.history-tab.active {
    background-color: #fff;
    color: var(--secondary-color);
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
}

.history-content {
    display: none;
    padding: 15px 15px 25px 15px;
}

.history-content.active {
    display: block;
}

.history-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
    max-height: 400px; /* एक हाइट सेट करें ताकि स्क्रॉल हो सके */
    overflow-y: auto;
    
}

/* स्क्रॉलबार स्टाइलिंग */
.history-list::-webkit-scrollbar {
    display: none;
}

.history-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px;
    background-color: #f8f9fa;
    border-radius: var(--border-radius);
    border-left: 5px solid; /* यह JS से सेट होगा */
    transition: transform 0.2s, box-shadow 0.2s;
}
.history-item:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow);
}

.history-item-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
    text-align: left;
}

.history-item-info .user-id {
    font-size: 0.8em;
    color: var(--light-text);
    font-weight: 500;
}

.history-item-info .grid-size {
    font-size: 1.1em;
    font-weight: 600;
    color: var(--text-color);
}

.history-item-result {
    text-align: right;
}

.history-item-result .winnings {
    font-size: 1.2em;
    font-weight: 700;
}

.history-item-result .bet-amount {
    font-size: 0.85em;
    color: var(--light-text);
}

/* जीत और हार के लिए रंग */
.history-item.win {
    border-left-color: var(--win-color);
}
.history-item.win .winnings {
    color: var(--win-color);
}

.history-item.loss {
    border-left-color: var(--loss-color);
}
.history-item.loss .winnings {
    color: var(--loss-color);
}


.hidden { display: none !important; }

/* --- Popup Styles (कोई बदलाव नहीं) --- */
.popup-backdrop {
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.5); z-index: 9998; display: none;
}
.popup-backdrop.show { display: block; }
.popup-overlay {
    position: fixed; bottom: -100%; left: 0; right: 0;
    background: #fff; border-top-left-radius: 20px; border-top-right-radius: 20px;
    transition: bottom 0.4s ease; z-index: 9999; padding: 25px;
    box-shadow: 0 -5px 25px rgba(0,0,0,0.2); max-height: 80vh; overflow-y: auto;
}
.popup-overlay.show { bottom: 0; }
.popup-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.popup-title { font-size: 20px; font-weight: 600; color: #333; margin: 0; }
.popup-close {
    width: 30px; height: 30px; border-radius: 50%; background: #f8f9fa;
    border: 1px solid #dee2e6; display: flex; align-items: center; justify-content: center;
    cursor: pointer; font-size: 18px; color: #6c757d; transition: all 0.3s ease;
}
.popup-section { margin-bottom: 20px; }
.popup-section > div:first-child { font-weight: 600; margin-bottom: 10px; color: #333; font-size: 16px; }
.money-options {
    display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;
    width: 100%; box-sizing: border-box; margin-bottom: 20px;
}
.money-options button {
    padding: 12px 8px; border: 2px solid #dee2e6; border-radius: 8px;
    background: #f8f9fa; cursor: pointer; font-weight: 600;
    transition: all 0.3s ease; font-size: 14px; width: 100%; box-sizing: border-box;
}
.money-options button.selected {
    background: var(--primary-gradient); color: white;
    border-color: #667eea; box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}
.quantity-controls { display: flex; align-items: center; justify-content: center; gap: 15px; }
.quantity-controls button {
    width: 40px; height: 40px; border: 2px solid #667eea; border-radius: 50%;
    background: #f8f9fa; color: #667eea; font-size: 18px; font-weight: 600;
    cursor: pointer; transition: all 0.3s ease;
}
.quantity-controls span { font-size: 18px; font-weight: 600; min-width: 30px; text-align: center; color: #333; }
.popup-balance {
    text-align: center; margin-bottom: 15px; padding: 12px;
    background: linear-gradient(135deg, #e3f2fd, #f3e5f5); border-radius: 10px;
    font-weight: 600; color: #333; border: 1px solid #e1bee7;
}
.popup-total {
    text-align: center; font-size: 18px; font-weight: 600; margin-bottom: 20px;
    color: #333; padding: 10px; background: #f8f9fa; border-radius: 8px; border: 2px solid #dee2e6;
}
.popup-confirm {
    width: 100%; padding: 15px; background: linear-gradient(135deg, #28a745, #20c997);
    color: white; border: none; border-radius: 10px; font-size: 16px; font-weight: 600;
    cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
}
.popup-confirm:disabled { background: #6c757d; cursor: not-allowed; box-shadow: none; }

/* === Rule Popup का CSS === */
.popup-content {
    padding-top: 10px;
}

.rule-item {
    display: flex;
    align-items: flex-start;
    margin-bottom: 25px;
}

.rule-icon {
    font-size: 24px;
    color: var(--secondary-color);
    margin-right: 20px;
    width: 30px;
    text-align: center;
    margin-top: 5px;
}

.rule-text h4 {
    font-size: 1.1em;
    font-weight: 600;
    color: var(--text-color);
    margin: 0 0 5px 0;
}

.rule-text p {
    font-size: 0.95em;
    color: var(--light-text);
    line-height: 1.6;
    margin: 0;
}

.rule-video-container {
    margin-bottom: 25px; /* वीडियो और नीचे के कंटेंट के बीच स्पेस */
    border-radius: var(--border-radius); /* कोनों को गोल करें */
    overflow: hidden; /* यह सुनिश्चित करता है कि वीडियो कोनों से बाहर न निकले */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); /* हल्की सी परछाई */
    background-color: #e9ecef; /* वीडियो लोड होने तक बैकग्राउंड कलर */
}

.rule-video-container video {
    display: block; /* नीचे किसी भी अतिरिक्त स्पेस को हटाता है */
    width: 100%;
}



    </style>
</head>
<body>

    <div class="mobile-frame">
        <!-- Main Game Content -->
        <header class="game-header">
           <i class="fa-solid fa-arrow-left back-arrow" onclick="window.history.back()"></i>
            <span class="title">Mine Sweeper</span>
            <span class="rules" onclick="openRulePopup()">Rule</span>

        </header>
        <main class="main-content">
            <div class="top-bar">
               <div class="icons">
                 <i id="sound-icon" class ="fa-solid fa-volume-high" onclick="toggleSound()"></i>
                    <i class="fa-regular fa-clock"></i>
                </div>

                <div class="wallet">
                    <i class="fa-solid fa-coins coin-icon"></i>
                    <span id="wallet-amount">10000</span>
                </div>
            </div>
            <div class="grid-selector">
                <button onclick="selectGrid(2)">2x2</button>
                <button onclick="selectGrid(3)" class="active">3x3</button>
                <button onclick="selectGrid(4)">4x4</button>
            </div>
            <div id="game-board" class="grid-area">
                <!-- Game board will be generated by JS -->
            </div>
        </main>
        
    
<div id="stop-button-container" class="hidden">
    <button id="stop-button" onclick="cashout()">
        <span class="stop-button-text">Stop & Collect</span>
        <span class="stop-button-winnings">₹<span id="collect-amount">0</span></span>
    </button>
</div>


        <section class="info-section">
            <h3>To get a bonus, check the boxes where you think there are no mines!</h3>
            <div id="message" style="font-weight: bold; color: var(--primary-color); min-height: 24px;"></div>
        </section>
        
<!-- === नया और बेहतर हिस्ट्री सेक्शन === -->
<section class="history-section">
    <div class="history-tabs">
        <button class="history-tab active" onclick="switchTab(event, 'my-orders')">My History</button>
        <button class="history-tab" onclick="switchTab(event, 'all-orders')">Everyone's History</button>
    </div>

    <div id="my-orders" class="history-content active">
        <div class="history-list" id="my-history-list">
            <!-- मेरी हिस्ट्री यहाँ JS से लोड होगी -->
        </div>
    </div>

    <div id="all-orders" class="history-content">
        <div class="history-list" id="all-history-list">
            <!-- सबकी हिस्ट्री यहाँ JS से लोड होगी -->
        </div>
    </div>
</section>

        <!-- Popup Area -->
        <div class="popup-backdrop" id="popupBackdrop"></div>
        <div class="popup-overlay" id="betPopup">
            <div class="popup-header">
                <div class="popup-title" id="popupTitle">Place Bet (3x3)</div>
                <button class="popup-close" onclick="closePopup()">×</button>
            </div>
            <div class="popup-balance" id="popupBalance">Available Balance: ₹10000</div>
            <div class="popup-section">
                <div>Select Money</div>
                <div class="money-options" id="moneyOptions">
                    <button onclick="selectMoney(10)">₹10</button>
                    <button onclick="selectMoney(50)">₹50</button>
                    <button onclick="selectMoney(100)" class="selected">₹100</button>
                    <button onclick="selectMoney(1000)">₹1000</button>
                    <button onclick="selectMoney(5000)">₹5000</button>
                    <button onclick="selectMoney(10000)">₹10000</button>
                </div>
            </div>
            <div class="popup-section">
                <div>Quantity</div>
                <div class="quantity-controls">
                    <button onclick="changeQuantity(-1)">-</button>
                    <span id="qtyDisplay">1</span>
                    <button onclick="changeQuantity(1)">+</button>
                </div>
            </div>
            <div class="popup-total" id="popupTotal">Total: ₹100</div>
            <button class="popup-confirm" id="confirmBetBtn" onclick="confirmBet()">Confirm</button>
        </div>
    </div>
    
    <!-- Rule Popup (English Version) --><!-- Rule Popup (Updated with Video) -->
<div class="popup-backdrop" id="rulePopupBackdrop"></div>
<div class="popup-overlay" id="rulePopup">
    <div class="popup-header">
        <div class="popup-title">Game Rules</div>
        <button class="popup-close" onclick="closeRulePopup()">×</button>
    </div>
    <div class="popup-content">

        <!-- === वीडियो सेक्शन यहाँ जोड़ें === -->
        <div class="rule-video-container">
            <video width="100%" controls autoplay muted loop playsinline>
                <source src="logo/minevideo.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
        <!-- === वीडियो सेक्शन का अंत === -->

        <div class="rule-item">
            <div class="rule-icon"><i class="fa-solid fa-bullseye"></i></div>
            <div class="rule-text">
                <h4>Objective</h4>
                <p>Open all the safe boxes in the grid while avoiding the hidden bombs.</p>
            </div>
        </div>
        <div class="rule-item">
            <div class="rule-icon"><i class="fa-solid fa-gamepad"></i></div>
            <div class="rule-text">
                <h4>How to Play</h4>
                <p>1. Choose a grid size (2x2, 3x3, 4x4) and place your bet by clicking 'Start'.</p>
                <p>2. Start opening the boxes one by one.</p>
                <p>3. You will win an amount for every safe box you open.</p>
            </div>
        </div>
        <div class="rule-item">
            <div class="rule-icon"><i class="fa-solid fa-bomb"></i></div>
            <div class="rule-text">
                <h4>The Bomb</h4>
                <p>If you click on a box with a bomb, you will immediately lose your bet amount, and the game will end.</p>
            </div>
        </div>
        <div class="rule-item">
            <div class="rule-icon"><i class="fa-solid fa-sack-dollar"></i></div>
            <div class="rule-text">
                <h4>Cash Out</h4>
                <p>You can press the 'Stop & Collect' button at any time to take your winnings. If you open all safe boxes, you win the jackpot!</p>
            </div>
        </div>
    </div>
</div>

    <audio id="bomb-sound" src="logo/bomb.mp3" preload="auto"></audio>
    <audio id="cashout-sound" src="logo/cash.mp3" preload="auto"></audio>
    <audio id="click-sound" src="logo/click.mp3" preload="auto"></audio>

<script>
    
 function toggleSound() {
    // स्टेट को टॉगल करें (अगर true है तो false, अगर false है तो true)
    isSoundOn = !isSoundOn; 
    
    const soundIcon = document.getElementById('sound-icon');
    
    if (isSoundOn) {
        // अगर साउंड चालू है, तो 'volume-high' आइकन दिखाएं
        soundIcon.classList.remove('fa-volume-xmark');
        soundIcon.classList.add('fa-volume-high');
    } else {
        // अगर साउंड बंद है, तो 'volume-xmark' (म्यूट) आइकन दिखाएं
        soundIcon.classList.remove('fa-volume-high');
        soundIcon.classList.add('fa-volume-xmark');
    }
}   
    
function playSound(soundId) {
    // --- यहाँ जांच जोड़ें ---
    // अगर साउंड बंद है, तो कुछ भी न करें और फंक्शन से बाहर निकल जाएं
    if (!isSoundOn) {
        return; 
    }
    
    const sound = document.getElementById(soundId);
    if (sound) {
        sound.currentTime = 0;
        sound.play().catch(error => console.log(`Error playing sound: ${error}`)); // एरर हैंडलिंग जोड़ना अच्छा है
    }
}

    // --- DOM Elements ---
    const walletAmountEl = document.getElementById('wallet-amount');
    const gameBoard = document.getElementById('game-board');
    const messageEl = document.getElementById('message');
    const gridSelectorButtons = document.querySelectorAll('.grid-selector button');
    const stopButtonContainer = document.getElementById('stop-button-container');
    const collectAmountEl = document.getElementById('collect-amount');
    const popupBackdrop = document.getElementById('popupBackdrop');
    const betPopup = document.getElementById('betPopup');
    const popupTitle = document.getElementById('popupTitle');
    const popupBalance = document.getElementById('popupBalance');
    const qtyDisplay = document.getElementById('qtyDisplay');
    const popupTotal = document.getElementById('popupTotal');
    const confirmBetBtn = document.getElementById('confirmBetBtn');
    const moneyOptionsContainer = document.getElementById('moneyOptions');
    const historyTableBody = document.getElementById('history-table-body');
    const rulePopupBackdrop = document.getElementById('rulePopupBackdrop');
    const rulePopup = document.getElementById('rulePopup');
    
    // --- Game State ---
    let wallet = 0; // Initial wallet, will be fetched from server
    let gameActive = false;
    let bombPosition = -1;
    let gridSize = 3;
    let openedBoxes = 0;
    let currentWinnings = 0;
    let betAmount = 0;
    let selectedMoney = 100;
    let quantity = 1;
    let gameOutcome = null;
    let openedBoxIndices = []; 
    let isSoundOn = true;

    const rewards = {
        2: [5, 8, 12],
        3: [2, 4, 6, 8, 10, 10, 10, 10],
        4: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 11, 12],
    };


    async function fetchBalance() {
        try {

            const response = await fetch('fetch_login_user.php'); 
            const data = await response.json();

            if (data.status === 'success') {

                const balanceString = data.data.balance.replace(/,/g, '');
                wallet = parseFloat(balanceString);
                updateWalletUI();
            } else {

                messageEl.textContent = data.message || "बैलेंस लोड करने में विफल।";
            }
        } catch (error) {
            console.error("Error fetching balance:", error);
            messageEl.textContent = "सर्वर से कनेक्ट नहीं हो सका।";
        }
    }


    // 2. सर्वर पर बैलेंस अपडेट करने के लिए फंक्शन
 async function updateBalanceOnServer(amount, reason, winnings = 0) {
    try {
        // अब हम सर्वर पर 'amount', 'reason', और 'winnings' भेजेंगे
        const response = await fetch('add_balance_bomb.php', { // .php एक्सटेंशन जोड़ना अच्छा अभ्यास है
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                amount: amount,
                reason: reason,
                winnings: winnings 
            })
        });

        const data = await response.json();

        if (data.success) {
            wallet = parseFloat(data.new_balance);
            updateWalletUI();
        } else {
            // सर्वर से मिले एरर मैसेज को दिखाएं
            messageEl.textContent = data.message || "Failed to update balance on server.";
        }
    } catch (error) {
        console.error("Error updating balance:", error);
        messageEl.textContent = "Could not connect to the server.";
    }
}

    
    // 3. गेम हिस्ट्री रिकॉर्ड करने के लिए फंक्शन
    async function recordGameHistory(bet, grid, result, winnings) {
        try {
            // महत्वपूर्ण: यहाँ अपनी PHP API का सही URL डालें
            await fetch('mine_history', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    bet_amount: bet,
                    grid_size: grid,
                    result: result, // 'win', 'loss', 'cashout'
                    winnings: winnings
                })
            });
        } catch (error) {
            console.error("Error recording history:", error);
        }
    }

    // --- Game Logic ---
    function updateWalletUI() {
        walletAmountEl.textContent = `₹${wallet.toFixed(2)}`;
        if(popupBalance) popupBalance.textContent = `Available Balance: ₹${wallet.toFixed(2)}`;
    }

function openRulePopup() {
    rulePopupBackdrop.classList.add('show');
    rulePopup.classList.add('show');
}

function closeRulePopup() {
    rulePopupBackdrop.classList.remove('show');
    rulePopup.classList.remove('show');
}

    // इस फंक्शन को पूरी तरह से बदल दें
async function fetchHistory() {
    try {
        const response = await fetch('mine_history_get.php'); // आपकी PHP स्क्रिप्ट
        const result = await response.json();
        const historyList = document.getElementById('my-history-list');

        if (result.status === 'success' && result.data.length > 0) {
            historyList.innerHTML = '';
            result.data.forEach(record => {
                const item = document.createElement('div');
                const resultType = (record.result === 'win' || record.result === 'cashout') ? 'win' : 'loss';
                const winningsSign = (resultType === 'win') ? '+' : '-';
                const finalAmount = (resultType === 'win') ? record.winnings : record.bet_amount;

                item.className = `history-item ${resultType}`;
                
                item.innerHTML = `
                    <div class="history-item-info">
                        <span class="grid-size">Grid: ${record.grid_size}</span>
                        <span class="user-id">ID: ${record.user_id}</span>
                    </div>
                    <div class="history-item-result">
                        <div class="winnings">${winningsSign}₹${parseFloat(finalAmount).toFixed(2)}</div>
                        <div class="bet-amount">Bet: ₹${parseFloat(record.bet_amount).toFixed(2)}</div>
                    </div>
                `;
                historyList.appendChild(item);
            });
        } else {
            historyList.innerHTML = '<p style="text-align:center; color:var(--light-text);">No history found.</p>';
        }
    } catch (error) {
        console.error("Error fetching history:", error);
        const historyList = document.getElementById('my-history-list');
        historyList.innerHTML = '<p style="text-align:center; color:var(--loss-color);">Could not load history.</p>';
    }
}


    function createGrid() {
        gameActive = false;
        stopButtonContainer.classList.add('hidden');
        gameBoard.innerHTML = '';
        
        const totalBoxes = gridSize * gridSize;
        gameBoard.style.gridTemplateColumns = `repeat(${gridSize}, 1fr)`;

        for (let i = 0; i < totalBoxes; i++) {
            const box = document.createElement('div');
            box.classList.add('box');
            box.dataset.index = i;
            box.innerHTML = `<i class="fa-solid fa-person-digging box-icon"></i><span class="box-text">StayZan</span>`;
            box.addEventListener('click', () => handleBoxClick(i));
            gameBoard.appendChild(box);
        }
        
        const startButton = document.createElement('div');
        startButton.id = 'start-button';
        startButton.textContent = 'Start';
        startButton.onclick = openPopup;
        gameBoard.appendChild(startButton);
        
        messageEl.textContent = "खेलने के लिए 'Start' पर क्लिक करें।";
    }

    async function confirmBet() {
        betAmount = selectedMoney * quantity;
        if (betAmount > wallet) {
            messageEl.textContent = "आपके पास पर्याप्त सिक्के नहीं हैं!";
            return;
        }
        closePopup();
        
        await updateBalanceOnServer(-betAmount, 'bet_placed');
        startGame();
    }
    async function startGame() {
    try {
        const response = await fetch('start_game_mine.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                bet_amount: betAmount,
                grid_size: gridSize
            })
        });
        const gameData = await response.json();

        if (gameData.status !== 'success') {
            messageEl.textContent = gameData.message || "Could not start game.";
            
            await updateBalanceOnServer(betAmount, 'game_start_failed'); 
            return;
        }

        gameOutcome = gameData.outcome;
        bombPosition = -1; 
        gameActive = true;
        openedBoxes = 0;
        currentWinnings = 0;
        openedBoxIndices= [];
    
        
        const startButton = document.getElementById('start-button');
        if(startButton) startButton.classList.add('hidden');
        
        messageEl.textContent = "Choose a box. Good luck!";

    } catch (error) {
        console.error("Error starting game:", error);
        messageEl.textContent = "Error connecting to the server.";
       await updateBalanceOnServer(betAmount, 'game_start_failed');
    }
}

    

  async function handleBoxClick(index) {

    if (!gameActive || openedBoxIndices.includes(index)) return;

    openedBoxIndices.push(index);

    try {
        const response = await fetch('get_bomb_position.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                grid_size: gridSize,
                opened_boxes: openedBoxIndices,
                outcome: gameOutcome,
                current_winnings: currentWinnings,
                bet_amount: betAmount
            })
        });

        const data = await response.json();

        if (data.status === 'success') {
            // सर्वर से मिली बम की पोजीशन को अपडेट करें
            bombPosition = data.bomb_position; 
        } else {
            // एरर हैंडलिंग (कोई बदलाव नहीं)
            messageEl.textContent = "Could not verify game. Please restart.";
            gameActive = false;
            return;
        }
    } catch (error) {
        // एरर हैंडलिंग (कोई बदलाव नहीं)
        messageEl.textContent = "Connection error. Please restart.";
        gameActive = false;
        return;
    }

    // --- बाकी का लॉजिक लगभग वैसा ही है ---

    const box = gameBoard.querySelector(`[data-index='${index}']`);
    
    // अब हम openedBoxIndices.add(index) का उपयोग नहीं करेंगे क्योंकि हम push() कर चुके हैं।
    box.classList.add('opened');

    if (index === bombPosition) {
        // खिलाड़ी हार गया
        playSound('bomb-sound');
        box.classList.add('bomb');
        box.innerHTML = '<i class="fa-solid fa-bomb bomb-icon"></i>';
        endGame(false);
    } else {
        // खिलाड़ी सुरक्षित है
        playSound('click-sound');
        openedBoxes++; // यह काउंटर अभी भी उपयोगी है
        const baseReward = rewards[gridSize][openedBoxes - 1] || 0;
        const rewardAmount = Math.ceil(baseReward * (betAmount / 10));
        currentWinnings += rewardAmount;
        
        box.classList.add('safe');
        box.innerHTML = `<span class="reward-text">+${rewardAmount}</span>`;
        
        if (openedBoxes > 0) {
            collectAmountEl.textContent = currentWinnings;
            stopButtonContainer.classList.remove('hidden');
        }
        messageEl.textContent = `आप ₹${currentWinnings} जीत चुके हैं। अगला चुनें।`;

        if (openedBoxes === (gridSize * gridSize - 1)) {
            endGame(true);
        }
    }
}

 async function cashout() {
        if (!gameActive) return;
        playSound('cashout-sound'); 
        gameActive = false;
        
        messageEl.textContent = `बधाई! आपने ₹${currentWinnings} कैश आउट किए।`;
        stopButtonContainer.classList.add('hidden');
        
        await updateBalanceOnServer(currentWinnings, 'cashout_win', currentWinnings);
        await recordGameHistory(betAmount, `${gridSize}x${gridSize}`, 'cashout', currentWinnings);

        revealAll();
        setTimeout(() => {
        createGrid();
        fetchHistory();
      }, 1000);
    
    }

async function endGame(isWin) {
    gameActive = false;
    stopButtonContainer.classList.add('hidden');

    if (isWin) {
        playSound('cashout-sound'); 
        // --- जीतने का लॉजिक (यह सही है) ---
        const totalWin = currentWinnings + betAmount;
        messageEl.textContent = `बधाई! आपने ₹${currentWinnings} जीते!`;
        
        // सर्वर पर बैलेंस और total_won दोनों अपडेट करें
        await updateBalanceOnServer(totalWin, 'full_win', currentWinnings);
        
        // गेम हिस्ट्री रिकॉर्ड करें
        await recordGameHistory(betAmount, `${gridSize}x${gridSize}`, 'win', currentWinnings);

    } else {
        // --- हारने का लॉजिक (यहाँ सुधार किया गया है) ---
        messageEl.textContent = `बॉम्ब! आप ₹${betAmount} हार गए।`;

        // 1. सर्वर पर total_lost को अपडेट करने के लिए API कॉल करें
        try {
            await fetch('mine_record_loss.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ bet_amount: betAmount })
            });
        } catch (error) {
            console.error("Error recording loss:", error);
        }

        // 2. गेम हिस्ट्री रिकॉर्ड करें (यह पहले जैसा ही है)
        await recordGameHistory(betAmount, `${gridSize}x${gridSize}`, 'loss', 0);
    }
    
    // यह कोड दोनों स्थितियों में चलेगा
    revealAll();
    setTimeout(() => {
        createGrid();
        fetchHistory();
    }, 1500);
}

    
    function revealAll() {
        const boxes = gameBoard.querySelectorAll('.box');
        boxes.forEach((box, i) => {
            if (!openedBoxIndices.includes(i)) {
                if (i === bombPosition) {
                    box.classList.add('opened', 'bomb');
                    box.innerHTML = '<i class="fa-solid fa-bomb bomb-icon"></i>';
                }
            }
        });
    }

    function selectGrid(size) {
        if (gameActive) return;
        gridSize = size;
        gridSelectorButtons.forEach(btn => {
            btn.classList.remove('active');
            if (parseInt(btn.textContent.charAt(0)) === size) {
                btn.classList.add('active');
            }
        });
        createGrid();
    }

    function openPopup() {
        popupTitle.textContent = `Place Bet (${gridSize}x${gridSize})`;
        updateWalletUI();
        updateTotal();
        popupBackdrop.classList.add('show');
        betPopup.classList.add('show');
    }

    function closePopup() {
        popupBackdrop.classList.remove('show');
        betPopup.classList.remove('show');
    }

    function selectMoney(amount) {
        selectedMoney = amount;
        document.querySelectorAll('.money-options button').forEach(btn => btn.classList.remove('selected'));
        event.target.classList.add('selected');
        updateTotal();
    }

    function changeQuantity(change) {
        if (quantity + change >= 1) {
            quantity += change;
            qtyDisplay.textContent = quantity;
            updateTotal();
        }
    }

    function updateTotal() {
        const total = selectedMoney * quantity;
        popupTotal.textContent = `Total: ₹${total}`;
        confirmBetBtn.disabled = total > wallet;
    }
    
    // यह नया और अपडेटेड फंक्शन है
function switchTab(event, tabName) {
    // सभी टैब कंटेंट को छिपाएं
    const tabcontent = document.getElementsByClassName("history-content");
    for (let i = 0; i < tabcontent.length; i++) {
        tabcontent[i].classList.remove('active');
    }

    const tablinks = document.getElementsByClassName("history-tab");
    for (let i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove('active');
    }

    document.getElementById(tabName).classList.add('active');
    event.currentTarget.classList.add('active');

    if (tabName === 'all-orders') {
        fetchAllHistory();
        
    }
}



// यह फंक्शन अभी के लिए खाली छोड़ दें या एक मैसेज दिखा
async function fetchAllHistory() {
    const allHistoryList = document.getElementById('all-history-list');
    allHistoryList.innerHTML = '<p style="text-align:center; color:var(--light-text);">Loading history...</p>';

    try {
        // नई PHP स्क्रिप्ट को कॉल करें
        const response = await fetch('fetch_all_players_history.php');
        const result = await response.json();

        if (result.status === 'success' && result.data.length > 0) {
            allHistoryList.innerHTML = ''; // पुरानी लिस्ट को साफ़ करें
            result.data.forEach(record => {
                const item = document.createElement('div');
                const resultType = record.result === 'win' ? 'win' : 'loss';
                const winningsSign = resultType === 'win' ? '+' : '-';
                // अगर जीत है तो winnings दिखाएं, हार है तो bet_amount दिखाएं
                const finalAmount = resultType === 'win' ? record.winnings : record.bet_amount;

                item.className = `history-item ${resultType}`;
                
                item.innerHTML = `
                    <div class="history-item-info">
                        <span class="grid-size">Grid: ${record.grid_size}</span>
                        <span class="user-id">ID: ${record.user_id}</span>
                    </div>
                    <div class="history-item-result">
                        <div class="winnings">${winningsSign}₹${parseFloat(finalAmount).toFixed(2)}</div>
                        <div class="bet-amount">Bet: ₹${parseFloat(record.bet_amount).toFixed(2)}</div>
                    </div>
                `;
                allHistoryList.appendChild(item);
            });
        } else {
            allHistoryList.innerHTML = '<p style="text-align:center; color:var(--light-text);">No history found.</p>';
        }
    } catch (error) {
        console.error("Error fetching all history:", error);
        allHistoryList.innerHTML = '<p style="text-align:center; color:var(--loss-color);">Could not load history.</p>';
    }
}

    // --- Initial Setup ---
    window.onload = async () => {
        await fetchBalance();
        await fetchHistory();
        selectGrid(3);
    };
    </script>

</body>
</html>
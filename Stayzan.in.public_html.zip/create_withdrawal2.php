<?php
session_start();
header('Content-Type: application/json');

// ✅ 1. Database Connection
$host = "localhost";
$user = "u976552851_hellogovind";  // apne credentials
$password = "Govind@00#";         // apne credentials
$database = "u976552851_hellogovind";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit();
}

// ✅ 2. Only Allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit();
}

// ✅ 3. Session Check
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit();
}
$unique_id = $_SESSION['unique_id'];

// ✅ 4. Inputs
$amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
$account_raw = $_POST['account'] ?? "";

// ✅ 5. Validation
if ($amount < 530) {
    echo json_encode(["status" => "error", "message" => "Minimum withdrawal is ₹530"]);
    exit();
}
if (empty($account_raw)) {
    echo json_encode(["status" => "error", "message" => "Please select a withdrawal account"]);
    exit();
}

// ✅ 6. Determine Method (upi- / bank- prefix se)
if (strpos($account_raw, 'upi-') === 0) {
    $method = 'UPI';
    $account = str_replace('upi-', '', $account_raw);
} elseif (strpos($account_raw, 'bank-') === 0) {
    $method = 'Bank';
    $account = str_replace('bank-', '', $account_raw);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid account format"]);
    exit();
}

$txn_check = $conn->prepare("SELECT id FROM transactions WHERE unique_id = ? AND amount >= 500 AND status = 'success' LIMIT 1");
$txn_check->bind_param("s", $unique_id);
$txn_check->execute();
$txn_result = $txn_check->get_result();

if ($txn_result->num_rows === 0) {
    echo json_encode(["status" => "error", "step" => "transaction_check", "message" => "You must have at least one successful Recharge of ₹500+ before withdrawal"]);
    exit();
}


// ✅ 7. Check referral balance
$bal_stmt = $conn->prepare("SELECT referral_balance FROM referral_rewards WHERE unique_id = ? LIMIT 1");
$bal_stmt->bind_param("s", $unique_id);
$bal_stmt->execute();
$result = $bal_stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $current_balance = floatval($row['referral_balance']);
    if ($amount > $current_balance) {
        echo json_encode(["status" => "error", "message" => "Insufficient referral balance"]);
        $bal_stmt->close();
        $conn->close();
        exit();
    }
} else {
    echo json_encode(["status" => "error", "message" => "Referral balance record not found"]);
    $bal_stmt->close();
    $conn->close();
    exit();
}
$bal_stmt->close();

// ✅ 8. Insert withdrawal request
$stmt = $conn->prepare("INSERT INTO rafer_withdrawals (unique_id, method, amount, account, status) VALUES (?, ?, ?, ?, 'pending')");
$stmt->bind_param("ssds", $unique_id, $method, $amount, $account);

if ($stmt->execute()) {
    // ✅ 9. Update referral balance
    $new_balance = $current_balance - $amount;
    $update_stmt = $conn->prepare("UPDATE referral_rewards SET referral_balance = ? WHERE unique_id = ?");
    $update_stmt->bind_param("ds", $new_balance, $unique_id);
    if ($update_stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Withdrawal request submitted successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Request saved but balance not updated. Contact support."]);
    }
    $update_stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Failed to submit withdrawal request"]);
}

$stmt->close();
$conn->close();
?>
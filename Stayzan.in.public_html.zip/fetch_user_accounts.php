<?php
session_start();

// Disable browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Content-Type: application/json");

// Database connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$unique_id = $_SESSION['unique_id'];
$accounts = [];

$result = mysqli_query($conn, "SELECT * FROM user_accounts WHERE unique_id='$unique_id'");
while ($row = mysqli_fetch_assoc($result)) {
    $label = $row['type'] === 'UPI' ? $row['upi_id'] : '****' . substr($row['acc_number'], -4);
    $value = strtolower($row['type']) . '-' . ($row['type'] === 'UPI' ? $row['upi_id'] : $row['acc_number']);
    $accounts[] = [
        'type' => $row['type'],
        'label' => $label,
        'value' => $value
    ];
}
echo json_encode(['accounts' => $accounts]);
?>

<?php
session_start();
header('Content-Type: application/json');

// --- Config ---
$botToken = "8404477667:AAFH_4wVwvyTTqFEHFWPbNparq557Txpgzo";
$chatId = "1733227695";

// --- DB Connection ---
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode(['ok' => false, 'error' => 'Database connection failed.']);
    exit();
}

// --- User session check ---
if (!isset($_SESSION['unique_id']) || empty($_SESSION['unique_id'])) {
    echo json_encode(['ok' => false, 'error' => 'User not logged in']);
    exit();
}
$userUniqueId = $_SESSION['unique_id'];

// --- Input ---
$amount = $_POST['amount'] ?? 0;
if ($amount <= 0) {
    echo json_encode(['ok' => false, 'error' => 'Invalid amount']);
    exit();
}

// --- Custom ID Generators ---
function generateOrderId() {
    return "order_" . strtoupper(bin2hex(random_bytes(4))); 
}

function generatePaymentId() {
    return "pay_" . strtoupper(bin2hex(random_bytes(4))); 
}

$orderId = generateOrderId();
$paymentId = generatePaymentId();

// --- File Upload ---
$fileName = $userUniqueId . '_' . time() . '_' . basename($_FILES['screenshot']['name']);
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}
$uploadFile = $uploadDir . $fileName;

if (move_uploaded_file($_FILES['screenshot']['tmp_name'], $uploadFile)) {
    // ✅ Reprocess image
    $info = getimagesize($uploadFile);
    $validImage = false;

    if ($info !== false) {
        $width = $info[0];
        $height = $info[1];
        $mime = $info['mime'];

        $maxDim = 2000;
        if ($width > $maxDim || $height > $maxDim) {
            $ratio = min($maxDim / $width, $maxDim / $height);
            $newW = (int)($width * $ratio);
            $newH = (int)($height * $ratio);
        } else {
            $newW = $width;
            $newH = $height;
        }

        if ($mime === "image/jpeg") {
            $src = imagecreatefromjpeg($uploadFile);
        } elseif ($mime === "image/png") {
            $src = imagecreatefrompng($uploadFile);
        } else {
            $src = null;
        }

        if ($src) {
            $dst = imagecreatetruecolor($newW, $newH);
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, $width, $height);
            imagejpeg($dst, $uploadFile, 90); 
            imagedestroy($src);
            imagedestroy($dst);
            $validImage = true;
        }
    }

    $photoUrl = 'https://' . $_SERVER['HTTP_HOST'] . '/uploads/' . $fileName;

    // --- Save transaction ---
    $stmt = $conn->prepare("INSERT INTO transactions 
        (unique_id, amount, status, screenshot_url, order_id, payment_id) 
        VALUES (?, ?, 'pending', ?, ?, ?)");
    $stmt->bind_param("sdsss", $userUniqueId, $amount, $photoUrl, $orderId, $paymentId);

    if ($stmt->execute()) {
        $newTransactionId = $conn->insert_id;

        // --- Caption for Telegram ---
        $caption = "नया रिचार्ज अनुरोध:\n\n";
        $caption .= "User ID: " . $userUniqueId . "\n";
        $caption .= "Transaction ID: " . $newTransactionId . "\n";
        $caption .= "Order ID: " . $orderId . "\n";
        $caption .= "Payment ID: " . $paymentId . "\n";
        $caption .= "राशि: ₹" . number_format($amount, 2);

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '✅ सफल (Success)', 'callback_data' => 'success:' . $newTransactionId],
                    ['text' => '❌ विफल (Failed)', 'callback_data' => 'failed:' . $newTransactionId]
                ]
            ]
        ];

        // --- Prepare Telegram request ---
        $postFields = [
            'chat_id' => $chatId,
            'caption' => $caption,
            'reply_markup' => json_encode($keyboard)
        ];

        if ($validImage) {
            $postFields['photo'] = new CURLFile(realpath($uploadFile));
            $telegramApiUrl = "https://api.telegram.org/bot{$botToken}/sendPhoto";
        } else {
            $postFields['text'] = $caption . "\n\nScreenshot: " . $photoUrl;
            unset($postFields['caption']);
            unset($postFields['reply_markup']);
            $telegramApiUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
        }

        // --- Send to Telegram ---
        $ch = curl_init($telegramApiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);

        file_put_contents(__DIR__ . "/telegram_debug.log", 
            "REQUEST: " . print_r($postFields, true) . "\nRESPONSE: " . $response . "\nERROR: " . $err . "\n\n", 
            FILE_APPEND
        );

        echo json_encode(['ok' => true, 'message' => 'Request sent successfully']);
    } else {
        echo json_encode(['ok' => false, 'error' => 'DB error: ' . $stmt->error]);
    }
    $stmt->close();
} else {
    echo json_encode(['ok' => false, 'error' => 'File upload failed']);
}
$conn->close();
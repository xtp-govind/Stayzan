<?php

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Content-Type: application/json");


// हमेशा की तरह, सेशन शुरू करें
session_start();

$servername = "localhost";
$username = "u976552851_hellogovind";
$password = "Govind@00#";
$dbname = "u976552851_hellogovind";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // Production में विस्तृत त्रुटि न दिखाएं
    die("Connection failed. Please try again later.");
}




// आउटपुट के लिए हेडर को JSON के रूप में सेट करें
header('Content-Type: application/json');

// 1. सुरक्षा जांच: क्या उपयोगकर्ता लॉग इन है?
if (!isset($_SESSION['unique_id'])) {
    // अगर user_id सेशन में नहीं है, तो इसका मतलब है कि उपयोगकर्ता लॉग इन नहीं है।
    // एक त्रुटि संदेश के साथ स्क्रिप्ट को रोक दें।
    echo json_encode([
        'status' => 'error',
        'message' => 'Authentication required. Please login.'
    ]);
    http_response_code(401); // 401 Unauthorized HTTP status code
    exit(); // स्क्रिप्ट को आगे बढ़ने से रोकें
}

// 2. सेशन से उपयोगकर्ता की आईडी प्राप्त करें
$userId = $_SESSION['unique_id'];

// 3. डेटाबेस से उपयोगकर्ता का विवरण प्राप्त करें (Prepared Statement का उपयोग करके)
// हम हमेशा डेटाबेस से नवीनतम डेटा प्राप्त करते हैं ताकि जानकारी हमेशा अपडेट रहे।
$stmt = $conn->prepare("SELECT referral_balance FROM referral_rewards WHERE unique_id = ?");

// जांचें कि क्या स्टेटमेंट तैयार करने में कोई त्रुटि हुई है
if ($stmt === false) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database query failed.'
    ]);
    http_response_code(500); // Internal Server Error
    exit();
}

$stmt->bind_param("s", $userId); // 's' का मतलब है कि user_id एक इंटीजर है
$stmt->execute();
$result = $stmt->get_result();

// 4. परिणाम की जांच करें और JSON में जवाब दें
if ($user = $result->fetch_assoc()) {
    // उपयोगकर्ता मिला, विवरण लौटाएं
    echo json_encode([
        'status' => 'success',
        'data' => [
            'balance' => number_format($user['referral_balance'], 2)
        ]
    ]);
} else {
    // ऐसा तब हो सकता है जब सेशन में आईडी हो, लेकिन उपयोगकर्ता डेटाबेस से हटा दिया गया हो
    echo json_encode([
        'status' => 'error',
        'message' => 'User not found.'
    ]);
    http_response_code(404); // Not Found
}

// स्टेटमेंट और कनेक्शन बंद करें
$stmt->close();
$conn->close();

?>

<?php
session_start();
header("Content-Type: application/json");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");

$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

if (!isset($_SESSION["unique_id"])) {
    echo json_encode(["error" => "User not logged in"]);
    exit();
}

$user_id = $_SESSION["unique_id"];

// Balance
$balance_stmt = $conn->prepare("SELECT balance FROM users WHERE unique_id = ?");
$balance_stmt->bind_param("s", $user_id);
$balance_stmt->execute();
$balance_result = $balance_stmt->get_result();
$current_balance = $balance_result->fetch_assoc()["balance"] ?? 0.00;
$balance_stmt->close();

// History
$history_stmt = $conn->prepare("SELECT amount, status, payment_id, updated_at FROM transactions WHERE unique_id = ? ORDER BY id DESC LIMIT 5");
$history_stmt->bind_param("s", $user_id);
$history_stmt->execute();
$history_result = $history_stmt->get_result();

$history = [];
while ($row = $history_result->fetch_assoc()) {
    $history[] = $row;
}
$history_stmt->close();

// Return balance as a float directly, not a formatted string with commas
echo json_encode([
    "balance" => (float)$current_balance, // Cast to float
    "history" => $history
]);

$conn->close();

?>

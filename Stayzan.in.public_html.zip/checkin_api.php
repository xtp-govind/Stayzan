<?php
session_start();

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$unique_id = $_SESSION['unique_id'] ?? null;
$day = (int)($_POST['day'] ?? 0);

if (!$unique_id || !$day || $day < 1 || $day > 7) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$today = date('Y-m-d');

// ✅ Get current user status
$stmt = $conn->prepare("SELECT current_day, last_checkin_date, streak_count FROM user_checkin_status WHERE unique_id = ?");
$stmt->bind_param("s", $unique_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$row = $result->fetch_assoc()) {
    echo json_encode(['success' => false, 'message' => 'User status not found']);
    exit;
}

$current_day = (int)$row['current_day'];
$last_checkin_date = $row['last_checkin_date'];
$streak_count = (int)$row['streak_count'];

// ✅ Validate: Can only claim the current expected day
if ($day !== $current_day) {
    echo json_encode(['success' => false, 'message' => 'Can only claim day ' . $current_day]);
    exit;
}

// ✅ Check if already claimed today
$check_today = $conn->prepare("SELECT id FROM daily_checkins WHERE unique_id = ? AND checkin_date = ?");
$check_today->bind_param("ss", $unique_id, $today);
$check_today->execute();
if ($check_today->get_result()->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Already claimed today']);
    exit;
}

// ✅ Check if claiming consecutive day (not more than 1 day gap)
if ($last_checkin_date) {
    $last_date = new DateTime($last_checkin_date);
    $current_date = new DateTime($today);
    $days_gap = $current_date->diff($last_date)->days;
    
    if ($days_gap > 1) {
        // Reset to day 1 if gap > 1 day
        $current_day = 1;
        $streak_count = 0;
        
        if ($day !== 1) {
            echo json_encode(['success' => false, 'message' => 'Streak broken. Please claim day 1']);
            exit;
        }
    }
}

// ✅ Determine reward based on day
switch ($day) {
    case 1: $reward = 2; break;
    case 2: $reward = 3; break;
    case 3: $reward = 4; break;
    case 4: $reward = 5; break;
    case 5: $reward = 6; break;
    case 6: $reward = 7; break;
    case 7: $reward = rand(10, 30); break;
    default: $reward = 0; break;
}

// ✅ Start transaction
$conn->begin_transaction();

try {
    // Insert today's check-in
    $insert_checkin = $conn->prepare("INSERT INTO daily_checkins (unique_id, day, checkin_date, reward) VALUES (?, ?, ?, ?)");
    $insert_checkin->bind_param("sisi", $unique_id, $day, $today, $reward);
    $insert_checkin->execute();
    
    // Update user balance
    $update_balance = $conn->prepare("UPDATE users SET balance = balance + ? WHERE unique_id = ?");
    $update_balance->bind_param("is", $reward, $unique_id);
    $update_balance->execute();
    
    // Update user check-in status
    $next_day = ($day == 7) ? 1 : $day + 1; // Reset to day 1 after day 7
    $new_streak = ($day == 7) ? $streak_count + 1 : $streak_count; // Increment streak only after completing 7 days
    
    $update_status = $conn->prepare("UPDATE user_checkin_status SET current_day = ?, last_checkin_date = ?, streak_count = ? WHERE unique_id = ?");
    $update_status->bind_param("isis", $next_day, $today, $new_streak, $unique_id);
    $update_status->execute();
    
    // Commit transaction
    $conn->commit();
    
    echo json_encode([
        'success' => true, 
        'reward' => $reward,
        'next_day' => $next_day,
        'streak_count' => $new_streak
    ]);
    
} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
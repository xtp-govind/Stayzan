<?php
// JSON रिस्पॉन्स के लिए हेडर सेट करें
header('Content-Type: application/json');

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// रिस्पॉन्स के लिए एक ऐरे बनाएं
$response = ['success' => false, 'error' => ''];

// जांचें कि क्या यह POST रिक्वेस्ट है और सभी ज़रूरी फ़ील्ड्स मौजूद हैं
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'], $_POST['mobile'], $_POST['password'])) {
    
    // इनपुट को सुरक्षित करें
    $email = $conn->real_escape_string($_POST['email']);
    $mobile = $conn->real_escape_string($_POST['mobile']);
    $new_password = $_POST['password'];

    // जांचें कि कोई भी फ़ील्ड खाली तो नहीं है
    if (empty($email) || empty($mobile) || empty($new_password)) {
        $response['error'] = 'Please fill all the fields.';
        echo json_encode($response);
        exit;
    }

    // पासवर्ड को हैश करें (यह बहुत ज़रूरी है!)
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // --- मुख्य लॉजिक ---

    // 1. पहले ईमेल के आधार पर यूज़र को ढूंढें
    $stmt_email = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt_email->bind_param("s", $email);
    $stmt_email->execute();
    $result_email = $stmt_email->get_result();
    $user_by_email = $result_email->fetch_assoc();
    $stmt_email->close();

    // 2. फिर मोबाइल नंबर के आधार पर यूज़र को ढूंढें
    $stmt_mobile = $conn->prepare("SELECT * FROM users WHERE mobile = ?");
    $stmt_mobile->bind_param("s", $mobile);
    $stmt_mobile->execute();
    $result_mobile = $stmt_mobile->get_result();
    $user_by_mobile = $result_mobile->fetch_assoc();
    $stmt_mobile->close();

    // --- शर्तों की जांच ---

    if ($user_by_email && $user_by_mobile) {
        // दोनों रिकॉर्ड मिले, अब जांचें कि क्या वे एक ही यूज़र के हैं
        if ($user_by_email['id'] === $user_by_mobile['id']) {
            // केस 1: ईमेल और मोबाइल दोनों सही हैं और एक ही यूज़र के हैं
            // पासवर्ड अपडेट करें
            $stmt_update = $conn->prepare("UPDATE users SET password = ? WHERE email = ? AND mobile = ?");
            $stmt_update->bind_param("sss", $hashed_password, $email, $mobile);
            
            if ($stmt_update->execute()) {
                $response['success'] = true;
            } else {
                $response['error'] = 'Failed to update password. Please try again.';
            }
            $stmt_update->close();
        } else {
            // ईमेल और मोबाइल अलग-अलग अकाउंट से जुड़े हैं
            $response['error'] = 'Email and Mobile number do not belong to the same account.';
        }
    } elseif ($user_by_email && !$user_by_mobile) {
        // केस 2: ईमेल सही है, लेकिन मोबाइल नंबर गलत है
        $response['error'] = 'Incorrect Mobile Number for the provided email.';
    } elseif (!$user_by_email && $user_by_mobile) {
        // केस 2: मोबाइल सही है, लेकिन ईमेल गलत है
        $response['error'] = 'Incorrect Email for the provided mobile number.';
    } else {
        // केस 3: ईमेल और मोबाइल दोनों ही गलत हैं
        $response['error'] = 'No account found. Please sign up first.';
    }

} else {
    // अगर रिक्वेस्ट सही नहीं है
    $response['error'] = 'Invalid request method.';
}

// कनेक्शन बंद करें
$conn->close();

// JSON फॉर्मेट में रिस्पॉन्स भेजें
echo json_encode($response);
?>

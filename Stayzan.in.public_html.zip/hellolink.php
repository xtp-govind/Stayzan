<?php
// 1. एक ज़्यादा सुरक्षित और रैंडम सीक्रेट की का उपयोग करें
$secret_key = "K#uT$8&z@!pLqW9*rE$vY2bN"; // महत्वपूर्ण: इसे गुप्त रखें
$today = date("Y-m-d");

// --- फंक्शन: एक्सपायर होने वाला सुरक्षित लिंक बनाने के लिए ---
function create_expiring_link($lifafa_id, $secret_key) {
    $today = date("Y-m-d");
    $timestamp = time(); // वर्तमान समय (सेकंड में)

    // हैश में अब timestamp भी शामिल होगा
    $code = md5($today . $lifafa_id . $timestamp . $secret_key);
    
    // URL में code, lifafa_id, और timestamp (t) तीनों भेजें
    return "https://stayzan.in/lucky_lifafa?code=$code&lifafa_id=$lifafa_id&t=$timestamp";
}

// --- सुबह और शाम के लिफाफे बनाएं ---
$link_1 = create_expiring_link("morning_reward", $secret_key);
$link_2 = create_expiring_link("evening_reward", $secret_key);
$link_3 = create_expiring_link("spacial_reward", $secret_key);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lifafa Link Generator</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root {
            --primary-color: #ffc107;
            --dark-bg: #212529;
            --card-bg: #343a40;
            --text-color: #f8f9fa;
            --border-color: #495057;
            --success-color: #28a745;
        }
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: var(--dark-bg);
            color: var(--text-color);
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }
        .container {
            width: 100%;
            max-width: 600px;
            text-align: center;
        }
        h1 {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 30px;
        }
        .lifafa-card {
            background-color: var(--card-bg);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            border: 1px solid var(--border-color);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            text-align: left;
        }
        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }
        .card-header i {
            font-size: 1.8rem;
            color: var(--primary-color);
            margin-right: 15px;
        }
        .card-header h2 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }
        .link-display {
            background-color: var(--dark-bg);
            padding: 15px;
            border-radius: 8px;
            word-wrap: break-word;
            font-size: 0.9rem;
            margin-bottom: 20px;
            border: 1px solid var(--border-color);
        }
        .link-display a {
            color: var(--primary-color);
            text-decoration: none;
        }
        .link-display a:hover {
            text-decoration: underline;
        }
        .btn-copy {
            display: block;
            width: 100%;
            padding: 12px;
            font-size: 1rem;
            font-weight: 600;
            color: #212529;
            background-color: var(--primary-color);
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
        }
        .btn-copy:hover {
            background-color: #ffca2c;
        }
        .btn-copy:active {
            transform: scale(0.98);
        }
        .btn-copy.copied {
            background-color: var(--success-color);
            color: var(--text-color);
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>🎁 Lifafa Link Generator</h1>

        <!-- Morning Lifafa Card -->
        <div class="lifafa-card">
            <div class="card-header">
                <i class="fas fa-sun"></i>
                <h2>Morning Lifafa</h2>
            </div>
            <div class="link-display">
                <a href="<?= htmlspecialchars($link_1) ?>" target="_blank"><?= htmlspecialchars($link_1) ?></a>
            </div>
            <button class="btn-copy" onclick="copyToClipboard('<?= htmlspecialchars($link_1) ?>', this)">
                <i class="fas fa-copy"></i> Copy Link
            </button>
        </div>

        <!-- Evening Lifafa Card -->
        <div class="lifafa-card">
            <div class="card-header">
                <i class="fas fa-moon"></i>
                <h2>Evening Lifafa</h2>
            </div>
            <div class="link-display">
                <a href="<?= htmlspecialchars($link_2) ?>" target="_blank"><?= htmlspecialchars($link_2) ?></a>
            </div>
            <button class="btn-copy" onclick="copyToClipboard('<?= htmlspecialchars($link_2) ?>', this)">
                <i class="fas fa-copy"></i> Copy Link
            </button>
        </div>

        <!-- spacil Lifafa Card -->
        <div class="lifafa-card">
            <div class="card-header">
                <i class="fas fa-moon"></i>
                <h2>spacil Lifafa</h2>
            </div>
            <div class="link-display">
                <a href="<?= htmlspecialchars($link_3) ?>" target="_blank"><?= htmlspecialchars($link_3) ?></a>
            </div>
            <button class="btn-copy" onclick="copyToClipboard('<?= htmlspecialchars($link_3) ?>', this)">
                <i class="fas fa-copy"></i> Copy Link
            </button>
        </div>
        
    </div>

    <script>
        function copyToClipboard(text, buttonElement) {
            // Create a temporary textarea element to hold the text
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            
            // Select and copy the text
            textarea.select();
            document.execCommand('copy');
            
            // Remove the temporary element
            document.body.removeChild(textarea);

            // Provide user feedback
            const originalText = buttonElement.innerHTML;
            buttonElement.innerHTML = '<i class="fas fa-check"></i> Copied!';
            buttonElement.classList.add('copied');

            // Revert back to original text after 2 seconds
            setTimeout(() => {
                buttonElement.innerHTML = originalText;
                buttonElement.classList.remove('copied');
            }, 2000);
        }
    </script>

</body>
</html>

<?php
header('Content-Type: application/json');
session_start();

// ✅ 1. Database Connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit();
}

// ✅ 2. सुरक्षा और इनपुट
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["status" => "error", "message" => "Authentication required."]);
    exit();
}
$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['grid_size']) || !isset($input['bet_amount'])) {
    echo json_encode(["status" => "error", "message" => "Invalid game data."]);
    exit();
}

$userId = $_SESSION['unique_id'];
$grid_size = intval($input['grid_size']);
$bet_amount = floatval($input['bet_amount']);
$total_boxes = $grid_size * $grid_size;

// ✅ 3. यूज़र का डेटा प्राप्त करें
$query = "SELECT total_won_mine, total_lost_mine, last_game_result_mine FROM users WHERE unique_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$user_data = $stmt->get_result()->fetch_assoc();
$stmt->close();

$profit_cycle = $user_data['total_won_mine'] - $user_data['total_lost_mine'];
$last_game_result = $user_data['last_game_result_mine'];

// ✅ 4. नया और स्मार्ट गेम लॉजिक
$should_win = false; // डिफ़ॉल्ट रूप से हार

// --- नियम 1: हार्ड लिमिट (Hard Limit) ---
// अगर प्रॉफ़िट ₹100 या उससे ज़्यादा है, तो हमेशा हराओ।
if ($profit_cycle >= 100) {
    $should_win = false;
    $decision_reason = "Hard Limit: Profit is ₹100 or more.";
} 
// --- नियम 2: ज़िग-ज़ैग पैटर्न (Zig-Zag Pattern) ---
// अगर खिलाड़ी पिछला गेम जीता था, तो इस बार उसे हराने की संभावना बढ़ा दो।
else if ($last_game_result === 'win') {
    // 80% संभावना है कि वह हारेगा (सिर्फ़ 20% चांस है जीतने का)
    if (rand(1, 100) <= 20) {
        $should_win = true;
        $decision_reason = "Zig-Zag: Won last game, but got lucky to win again.";
    } else {
        $should_win = false;
        $decision_reason = "Zig-Zag: Won last game, so lose this one.";
    }
}
// --- नियम 3: सामान्य RTP (Normal RTP) ---
// अगर ऊपर के कोई नियम लागू नहीं होते (यानी खिलाड़ी पिछला गेम हारा था या नया है)
else {
    $RTP = 90; // खिलाड़ी को जिताने का चांस ज़्यादा रखें ताकि वह ₹100 के लक्ष्य तक पहुँचे
    if (rand(1, 100) <= $RTP) {
        $should_win = true;
        $decision_reason = "Normal RTP: Player is on a losing streak or new.";
    } else {
        $should_win = false;
        $decision_reason = "Normal RTP: Player got unlucky.";
    }
}


// ✅ 6. नया JSON रिस्पॉन्स भेजें
echo json_encode([
    'status' => 'success',
    'outcome' => $should_win ? 'win' : 'loss', // 'win' या 'loss' भेजें
    'debug_info' => [
        'profit_cycle' => $profit_cycle,
        'last_game_result' => $last_game_result,
        'should_win' => $should_win,
        'reason' => $decision_reason
    ]
]);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
    <title>CandleX Trading</title>

    <script src="https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.1/dist/lightweight-charts.standalone.production.js"></script>
    <script src="https://unpkg.com/lightweight-charts-drawing-tools/dist/lightweight-charts-drawing-tools.standalone.production.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        :root {
            --bg-primary: #131722;
            --bg-secondary: #1e222d;
            --text-primary: #d1d4dc;
            --text-secondary: #8a8e97;
            --color-green: #26a69a;
            --color-red: #ef5350;
            --color-yellow: #f0b90b;
        }
        
        body {
            margin: 0;
            padding: 0;
            background: var(--bg-primary);
            color: var(--text-primary);
            font-family: 'Poppins', sans-serif;
        }

        /* --- Top Bar --- */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            background-color: var(--bg-secondary);
        }
        .top-bar .icon { font-size: 24px; cursor: pointer; }
        .top-bar .title { font-size: 18px; font-weight: 600; }

        /* --- Balance and Time Info --- */
        .account-info {
            display: flex;
            justify-content: space-around;
            padding: 5px 15px 5px 15px;
            background: var(--bg-secondary);
            border-top: 1px solid #333;
        }
        .info-item {
            text-align: center;
        }
        .info-item .label {
            font-size: 12px;
            color: var(--text-secondary);
            margin-bottom: 4px;
        }
        .info-item .value {
            font-size: 15px;
            font-weight: 600;
        }
        #total-balance-value {
            color: var(--color-yellow);
        }

        /* --- Chart --- */
        #chart-container {
            width: 100%;
            height: 45vh; /* Chart height */
            position: relative; /* Important for tooltip positioning */
        }
        #chart { width: 100%; height: 100%; }

        /* --- Tooltip Styling --- */
        #tooltip {
            position: absolute;
            display: none;
            padding: 8px;
            background-color: rgba(30, 34, 45, 0.9);
            border: 1px solid var(--text-secondary);
            border-radius: 8px;
            font-size: 12px;
            color: var(--text-primary);
            pointer-events: none; /* So it doesn't interfere with chart events */
            z-index: 1000;
            width: 150px;
        }
        .tooltip-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
        }
        .tooltip-label { color: var(--text-secondary); }
        .tooltip-value { font-weight: 600; }

        /* --- Controls Area --- */
        .controls-area {
            background: var(--bg-secondary);
            padding: 20px 15px;
            margin-top: 10px;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }
        
        .control-label {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 10px;
            text-align: center;
        }

        .bet-amount-control {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 8px;
            margin-bottom: 20px;
        }
        .amount-btn {
            background: var(--bg-secondary);
            border: none;
            color: var(--text-primary);
            font-size: 24px;
            font-weight: 600;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            cursor: pointer;
        }

/* UPDATED: Styles for both span and input */
#bet-amount, #bet-amount-input {
    font-size: 22px;
    font-weight: 700;
    color: var(--color-yellow);
    background: transparent;
    border: none;
    text-align: center;
    outline: none;
    width: 100px; /* इसे थोड़ी चौड़ाई दें ताकि यह छोटा न हो जाए */
    padding: 0; /* अतिरिक्त पैडिंग हटा दें */
    margin: 0; /* अतिरिक्त मार्जिन हटा दें */
    font-family: 'Poppins', sans-serif; /* फॉन्ट को भी समान रखें */
}

/* Hide the input by default */
#bet-amount-input {
    display: none;
}

/* Optional: Hide the number input spinners in Chrome/Safari/Edge */
#bet-amount-input::-webkit-outer-spin-button,
#bet-amount-input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

/* Optional: Hide the number input spinners in Firefox */
#bet-amount-input[type=number] {
    -moz-appearance: textfield;
}

       

        .trade-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .trade-btn {
            padding: 18px;
            font-size: 20px;
            font-weight: 700;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .trade-btn:disabled { opacity: 0.7; cursor: not-allowed; }
        .up { background-color: var(--color-green); color: white; }
        .down { background-color: var(--color-red); color: white; }
        
/* --- Timeframe Bar Styling --- */
.timeframe-bar {
    display: flex;
    justify-content: space-around;
    padding: 8px 15px;
    background-color: var(--bg-primary);
    border-bottom: 1px solid #333;
}
.time-btn {
    background: transparent;
    border: 1px solid var(--text-secondary);
    color: var(--text-secondary);
    font-size: 14px;
    font-weight: 500;
    padding: 5px 15px;
    border-radius: 15px;
    cursor: pointer;
    transition: all 0.2s ease;
}
.time-btn.active {
    background-color: var(--color-yellow);
    color: var(--bg-primary);
    border-color: var(--color-yellow);
    font-weight: 700;
}

/* --- Asset Bar Styling (Timeframe Bar जैसा) --- */
.asset-btn {
    background: transparent;
    border: 1px solid var(--text-secondary);
    color: var(--text-secondary);
    font-size: 14px;
    font-weight: 500;
    padding: 5px 15px;
    border-radius: 15px;
    cursor: pointer;
    transition: all 0.2s ease;
}
.asset-btn.active {
    background-color: var(--color-yellow);
    color: var(--bg-primary);
    border-color: var(--color-yellow);
    font-weight: 700;
}

/* --- Pulsating Area Effect --- */
.pulsating-area {
    position: absolute;
    width: 100%; /* पूरे चार्ट की चौड़ाई लेगा */
    left: 0;
    z-index: 1; /* चार्ट के ऊपर, लेकिन लाइन के पीछे */
    opacity: 0;
    transition: opacity 0.5s ease;
    animation: pulse 1.5s infinite;
}

.pulsating-area.up {
    background: linear-gradient(to top, rgba(38, 166, 154, 0.2), rgba(38, 166, 154, 0));
    border-top: 1px solid rgba(38, 166, 154, 0.5);
}

.pulsating-area.down {
    background: linear-gradient(to bottom, rgba(239, 83, 80, 0.2), rgba(239, 83, 80, 0));
    border-bottom: 1px solid rgba(239, 83, 80, 0.5);
}

/* चमकने का एनिमेशन */
@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.01); }
    100% { transform: scale(1); }
}

/* --- History Button --- */
.history-button-container {
    margin-top: 15px;
    text-align: center;
}
.history-btn {
    background: transparent;
    border: 1px solid var(--text-secondary);
    color: var(--text-secondary);
    padding: 10px 25px;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
}
.history-btn:hover {
    background: var(--text-secondary);
    color: var(--bg-primary);
}
.history-btn i {
    margin-right: 8px;
}

/* === NEW & IMPROVED MODAL & HISTORY STYLING === */

.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 100;
    display: none; /* <<--- FIX 1: Start with display: none */
    justify-content: center;
    align-items: flex-end;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.modal-overlay.show {
    display: flex; /* <<--- FIX 2: Use flex when .show is added */
    opacity: 1;
    pointer-events: auto;
}

.modal-content {
    background: var(--bg-secondary);
    width: 100%;
    max-width: 500px; /* Max width on larger screens */
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
    box-shadow: 0 -5px 25px rgba(0,0,0,0.3);
    display: flex;
    flex-direction: column;
    max-height: 70vh; /* Max height */
    transform: translateY(100%); /* Initially off-screen */
    transition: transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.modal-overlay.show .modal-content {
    transform: translateY(0); /* Slide in */
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    border-bottom: 1px solid var(--bg-primary);
    flex-shrink: 0; /* Header should not shrink */
}
.modal-header h2 { margin: 0; font-size: 18px; }
.close-btn { background: none; border: none; color: var(--text-primary); font-size: 28px; cursor: pointer; }

.modal-body {
    padding: 15px;
    overflow-y: auto;
    background-color: var(--bg-primary);
}
.no-history { text-align: center; color: var(--text-secondary); padding: 20px 0; }

/* --- New History Card --- */
.history-item {
    background: var(--bg-secondary);
    border-radius: 12px;
    margin-bottom: 15px;
    overflow: hidden; /* To contain the top part */
}
.history-item:last-child { margin-bottom: 0; }

.history-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 15px;
    background-color: rgba(0,0,0,0.2);
}

.history-top-left {
    display: flex;
    align-items: center;
    gap: 10px;
}

.history-direction-icon {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    font-size: 16px;
}
.history-direction-icon.up { background-color: var(--color-green); color: white; }
.history-direction-icon.down { background-color: var(--color-red); color: white; }

.history-timeframe {
    font-size: 14px;
    font-weight: 600;
}

.history-result {
    font-size: 18px;
    font-weight: 700;
}
.history-result.win { color: var(--color-green); }
.history-result.loss { color: var(--color-red); }

.history-bottom {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr; /* 3 columns */
    gap: 15px;
    padding: 15px;
}

.detail-item {
    display: flex;
    flex-direction: column;
}
.detail-item .label {
    font-size: 11px;
    color: var(--text-secondary);
    margin-bottom: 3px;
    display: flex;
    align-items: center;
    gap: 4px;
}
.detail-item .value { font-weight: 600; font-size: 13px; }

/* --- New Icon Controls Bar --- */
.controls-area {
    position: relative; /* यह लाइन ज़रूरी है */
}
.icon-controls-bar {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
    padding: 5px;
    background-color: var(--bg-primary);
    border-radius: 12px;
}
.icon-btn {
    background: transparent;
    border: none;
    color: var(--text-secondary);
    font-size: 20px;
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
}
.icon-btn:hover {
    color: var(--text-primary);
    background-color: var(--bg-secondary);
}
.icon-btn.active {
    color: var(--color-yellow);
}
.separator {
    width: 1px;
    height: 20px;
    background-color: #444;
}

/* === यह नया, लेफ्ट-साइड वाला कोड है === */
.indicator-menu {
    position: absolute;
    bottom: calc(100% - 73px); 
    left: 5px; 
    
    background: var(--bg-secondary);
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4);
    z-index: 50;
    width: 270px;
    opacity: 0;
    transform: translateY(10px);
    pointer-events: none;
    transition: opacity 0.2s ease, transform 0.2s ease;
}

.indicator-menu.show {
    opacity: 1;
    transform: translateY(0); /* अपनी जगह पर आएगा */
    pointer-events: auto;
}

/* --- Indicator Item (With Icon) --- */
.indicator-item {
    display: grid;
    /* लेआउट: आइकन (छोटा), नाम (बड़ा), टॉगल (छोटा) */
    grid-template-columns: 30px 1fr auto; 
    align-items: center;
    gap: 10px; /* आइटम्स के बीच गैप */
    padding: 12px 10px;
    font-size: 14px;
    cursor: pointer;
    border-bottom: 1px solid var(--bg-primary);
}
.indicator-item:last-child {
    border-bottom: none;
}
.indicator-item:hover {
    background-color: var(--bg-primary);
}

/* आइकन के लिए स्टाइल */
.indicator-icon {
    font-size: 16px;
    text-align: center;
}


/* --- Toggle Switch for Indicators --- */
.toggle-switch {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 22px;
}
.toggle-switch input { display: none; }
.toggle-switch label {
    position: absolute;
    cursor: pointer;
    top: 0; left: 0; right: 0; bottom: 0;
    background-color: var(--bg-primary);
    border-radius: 22px;
    transition: .4s;
}
.toggle-switch label:before {
    position: absolute;
    content: "";
    height: 16px;
    width: 16px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    border-radius: 50%;
    transition: .4s;
}
.toggle-switch input:checked + label {
    background-color: var(--color-green);
}
.toggle-switch input:checked + label:before {
    transform: translateX(18px);
}

/* पुरानी .main-controls-grid और उससे जुड़ी स्टाइल हटाकर यह नई CSS डालें */

/* === New Split Controls Layout === */
.split-controls-container {
    display: flex; /* फ्लेक्सबॉक्स का उपयोग करें */
    gap: 15px; /* दोनों कॉलम के बीच गैप */
    margin-top: 15px;
    margin-bottom: 20px;
}

.control-column {
    display: flex;
    flex-direction: column;
    gap: 15px;
    width: 50%; /* हर कॉलम को 50% चौड़ाई दें */
}

/* --- बेट अमाउंट कंट्रोल --- */
.bet-amount-control {
    margin-bottom: 0;
    height: 55px; /* हाइट सेट करें */
}

/* --- नया स्प्लिट बटन कंटेनर --- */
.split-button-container {
    display: flex;
    height: 55px; /* हाइट सेट करें */
}

.split-btn {
    background: var(--bg-primary);
    border: 1px solid var(--text-secondary);
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-weight: 600;
}
.split-btn:hover {
    border-color: var(--text-primary);
    color: var(--text-primary);
}

/* स्प्लिट बटन का मुख्य हिस्सा */
.split-btn.main {
    flex-grow: 1; /* यह बची हुई सारी जगह ले लेगा */
    border-radius: 12px 0 0 12px; /* बाएं कोने गोल */
    font-size: 16px;
}
.split-btn.main.active {
    border-color: var(--color-yellow);
    color: var(--color-yellow);
    background: rgba(240, 185, 11, 0.1);
}

/* स्प्लिट बटन का छोटा हिस्सा (सेटिंग्स) */
.split-btn.trigger {
    width: 55px; /* चौड़ाई सेट करें */
    border-left: none; /* बीच की लाइन बनाने के लिए */
    border-radius: 0 12px 12px 0; /* दाएं कोने गोल */
    font-size: 20px;
}

/* --- राइट साइड के ट्रेड बटन --- */
.control-column.right .trade-btn {
    flex-grow: 1; /* यह पूरी उपलब्ध हाइट ले लेंगे */
    font-size: 20px;
    font-weight: 700;
    border: none;
    border-radius: 12px;
}
.trade-btn.up { background-color: var(--color-green); color: white; }
.trade-btn.down { background-color: var(--color-red); color: white; }
.trade-btn:disabled { opacity: 0.7; cursor: not-allowed; }

/* === नया नोटिफिकेशन पैनल स्टाइल === */

.app-message {
    position: fixed;
    top: 15px; /* स्क्रीन के टॉप से थोड़ा नीचे */
    left: 50%;
    transform: translateX(-50%);
    width: auto; /* कंटेंट के हिसाब से चौड़ाई */
    max-width: 90%; /* बहुत ज्यादा चौड़ा न हो */
    padding: 12px 20px;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 600;
    text-align: left;
    box-shadow: 0 5px 15px rgba(0,0,0,0.15);
    z-index: 9999;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideInDown 0.4s ease-out;
    border-left: 5px solid; /* साइड में एक मोटी बॉर्डर */
}

/* विभिन्न प्रकारों के लिए रंग */
.app-message.win {
    background: #e6f4ea;
    color: #2e7d32;
    border-color: #2e7d32;
}

.app-message.loss {
    background: #ffe5e7;
    color: #d32f2f;
    border-color: #d32f2f;
}

.app-message.warning {
    background: #fff4e5;
    color: #ef6c00;
    border-color: #ef6c00;
}

.app-message.info {
    background: #e3f2fd;
    color: #1565c0;
    border-color: #1565c0;
}

/* आइकन के लिए स्टाइल */
.app-message::before {
    font-family: "Font Awesome 6 Free"; /* Font Awesome का उपयोग करें */
    font-weight: 900; /* Solid आइकन के लिए */
    font-size: 18px;
}

.app-message.win::before { content: "\f058"; } /* fa-check-circle */
.app-message.loss::before { content: "\f057"; } /* fa-times-circle */
.app-message.warning::before { content: "\f071"; } /* fa-exclamation-triangle */
.app-message.info::before { content: "\f05a"; } /* fa-info-circle */


/* एनीमेशन */
@keyframes slideInDown {
    from {
        opacity: 0;
        transform: translate(-50%, -20px);
    }
    to {
        opacity: 1;
        transform: translate(-50%, 0);
    }
}


    </style>
</head>
<body>

<div class="top-bar">
    <div class="icon" onclick="alert('Back button clicked!')">
        <i class="fa-solid fa-arrow-left"></i>
    </div>
    <div class="title">CandleX</div>
    <div class="icon" onclick="alert('Help button clicked!')">
        <i class="fa-solid fa-circle-question"></i>
    </div>
</div>

<!-- === बदला हुआ Account Info सेक्शन === -->
<div class="account-info">
    <!-- 1. ग्राफ़ चुनने का बटन (Timeframe जैसा) -->
    <div class="info-item" id="asset-selector-button" style="cursor: pointer;">
        <div class="label">Asset</div>
        <div class="value" id="asset-display">Lee <i class="fa-solid fa-chevron-down" style="font-size: 10px;"></i></div>
    </div>

    <!-- 2. टाइमफ्रेम सेलेक्टर (यह वैसा ही है) -->
    <div class="info-item" id="timeframe-selector" style="cursor: pointer;">
         <div class="label">Timeframe</div>
         <div class="value" id="timeframe-display">30s <i class="fa-solid fa-chevron-down" style="font-size: 10px;"></i></div>
    </div>
    
        <div class="info-item">
            <div class="label">Total Balance</div>
            <div class="value">₹<span id="total-balance-value">10000.00</span></div>
        </div>

</div>

<!-- === नया ASSET SELECTION BAR (Initially Hidden) === -->
<div class="timeframe-bar" id="asset-bar" style="display: none;">
    <button class="asset-btn active" data-asset="Lee">Lee</button>
    <button class="asset-btn" data-asset="BTB">BTB</button>
    <button class="asset-btn" data-asset="RAa">RAa</button>
    <button class="asset-btn" data-asset="Gol">Gol</button>
    <button class="asset-btn" data-asset="Oxl">Oxl</button>
</div>
    
<!-- === TIMEFRAME SELECTION BAR (यह पहले से है) === -->
<div class="timeframe-bar" id="timeframe-bar" style="display: none;">
    <button class="time-btn active" data-time="30" data-label="30s">30s</button>
    <button class="time-btn" data-time="45" data-label="45s">45s</button>
    <button class="time-btn" data-time="60" data-label="1m">1m</button>
    <button class="time-btn" data-time="120" data-label="2m">2m</button>
    <button class="time-btn" data-time="180" data-label="3m">3m</button>
</div>

<div id="chart-container">
    <div id="chart"></div>
    <div id="pulsating-area" class="pulsating-area"></div>
    <div id="tooltip"></div>
</div>




<div class="controls-area">
    
    <div class="icon-controls-bar">
        <button class="icon-btn active" id="candle-chart-btn" title="Candlestick Chart"><i class="fa-solid fa-chart-column"></i></button>
        <button class="icon-btn" id="bar-chart-btn" title="Bar Chart"><i class="fa-solid fa-chart-bar"></i></button>
        <button class="icon-btn" id="line-chart-btn" title="Line Chart"><i class="fa-solid fa-chart-line"></i></button>
        <button class="icon-btn" id="area-chart-btn" title="Area Chart"><i class="fa-solid fa-chart-area"></i></button>
        <div class="separator"></div>
        <button class="icon-btn" id="indicator-btn" title="Indicators"><i class="fa-solid fa-wave-square"></i></button>
    </div>

<div class="split-controls-container">
        
        <!-- लेफ्ट साइड -->
        <div class="control-column left">
            <!-- अमाउंट इनपुट -->
            <div class="bet-amount-control">
                <button class="amount-btn" id="decrease-bet">-</button>
                <span id="bet-amount" style="cursor: pointer;">₹100</span>
                <input type="number" id="bet-amount-input" style="display: none;" />
                <button class="amount-btn" id="increase-bet">+</button>
            </div>
            
            <!-- ऑटो-बेट का स्प्लिट बटन -->
            <div class="split-button-container">
                <button class="split-btn main" id="auto-bet-button">
                    <i class="fa-solid fa-robot"></i> Auto Bet
                </button>
                <button class="split-btn trigger" id="auto-bet-settings-btn" title="Auto Bet Settings">
                    <i class="fa-solid fa-sliders"></i>
                </button>
            </div>
        </div>

        <!-- राइट साइड -->
        <div class="control-column right">
            <!-- Up और Down बटन -->
            <button class="trade-btn up" id="up-button">▲ Up</button>
            <button class="trade-btn down" id="down-button">▼ Down</button>
        </div>

    </div>


<!-- पुराने .indicator-menu को इस नए कोड से पूरी तरह बदल दें -->


    <div class="history-button-container">
        <button class="history-btn" id="history-button">
            <i class="fa-solid fa-clock-rotate-left"></i> History
        </button>
    </div>
    
<!-- पुराने .indicator-menu को इस नए कोड से पूरी तरह बदल दें -->
<div class="indicator-menu" id="indicator-menu">
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #FFC300;"><i class="fa-solid fa-chart-line"></i></span>
        <span>Moving Average (20)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="ma-toggle">
            <label for="ma-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #2980B9;"><i class="fa-solid fa-ellipsis-h"></i></span>
        <span>Bollinger Bands (20, 2)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="bb-toggle">
            <label for="bb-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #95A5A6;"><i class="fa-solid fa-chart-bar"></i></span>
        <span>Volume</span>
        <div class="toggle-switch">
            <input type="checkbox" id="volume-toggle">
            <label for="volume-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #E91E63;"><i class="fa-solid fa-heart-pulse"></i></span>
        <span>RSI (14)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="rsi-toggle">
            <label for="rsi-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #8E44AD;"><i class="fa-solid fa-shuffle"></i></span>
        <span>Stochastic (14, 3, 3)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="stoch-toggle">
            <label for="stoch-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #1ABC9C;"><i class="fa-solid fa-signal"></i></span>
        <span>MACD (12, 26, 9)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="macd-toggle">
            <label for="macd-toggle"></label>
        </div>
    </div>
</div>

</div>  
    
<!-- === HISTORY PANEL (MODAL) === -->
<div class="modal-overlay" id="history-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Trade History</h2>
            <button class="close-btn" id="close-history-btn">&times;</button>
        </div>
        <div class="modal-body" id="history-list">
            <!-- History items will be added here by JavaScript -->
            <p class="no-history">You have no trade history yet.</p>
        </div>
    </div>
</div>

<!-- === AUTO-BET SETTINGS MODAL === -->
<div class="modal-overlay" id="auto-bet-settings-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Auto Bet Settings</h2>
            <button class="close-btn" id="close-auto-bet-settings-btn">&times;</button>
        </div>
        <div class="modal-body">
            <p style="text-align: center; color: var(--text-secondary);">
                Configure your automatic trading strategy here.
                <br>(Functionality coming soon!)
            </p>
            <!-- यहाँ भविष्य में सेटिंग्स के ऑप्शन जोड़े जाएँगे -->
        </div>
    </div>
</div>




<div class="infoX" style="display:none;">
    <div class="label">Next Candle In</div>
    <div class="value" id="candle-timer">30s</div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // DOM Elements का रेफरेंस
        const chartContainer = document.getElementById('chart-container');
        const chartElement = document.getElementById('chart');
        const tooltipElement = document.getElementById('tooltip');
        const candleTimerElement = document.getElementById('candle-timer');
        const historyButton = document.getElementById('history-button');
        const historyModal = document.getElementById('history-modal');
        const closeHistoryBtn = document.getElementById('close-history-btn');
        const historyList = document.getElementById('history-list');
        const betAmountSpan = document.getElementById('bet-amount');
        const betAmountInput = document.getElementById('bet-amount-input');
        const decreaseBetBtn = document.getElementById('decrease-bet');
        const increaseBetBtn = document.getElementById('increase-bet');
        const indicatorBtn = document.getElementById('indicator-btn');
        const indicatorMenu = document.getElementById('indicator-menu');

        // --- Chart Configuration ---
        const chart = LightweightCharts.createChart(chartElement, {
            width: chartElement.clientWidth,
            height: chartElement.clientHeight,
            layout: {
                background: { type: 'solid', color: '#131722' },
                textColor: '#d1d4dc',
            },
            grid: {
                vertLines: { color: '#1e222d' },
                horzLines: { color: '#1e222d' },
            },
            crosshair: {
                mode: LightweightCharts.CrosshairMode.Normal,
            },
            rightPriceScale: {
                borderColor: '#333',
            },
            timeScale: {
                borderColor: '#333',
                timeVisible: true,
                secondsVisible: true,
            },
        });

        const candlestickSeries = chart.addCandlestickSeries({
            upColor: '#26a69a',
            downColor: '#ef5350',
            borderDownColor: '#ef5350',
            borderUpColor: '#26a69a',
            wickDownColor: '#ef5350',
            wickUpColor: '#26a69a',
        });

        // --- Backend Data Fetching and Chart Update Logic ---

        const DATA_FETCH_INTERVAL = 30000; // 30 सेकंड (मिलीसेकंड में)
        let countdownInterval;
        let isInitialDataLoaded = false; // यह ट्रैक करने के लिए कि क्या शुरुआती डेटा लोड हो चुका है

        async function fetchAndUpdateChart() {
            try {
                const response = await fetch('/candle/chart-data-candleX.php');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();

                if (data.success && data.candles && data.candles.length > 0) {
                    const formattedData = data.candles.map(candle => ({
                        time: candle.time,
                        open: parseFloat(candle.open),
                        high: parseFloat(candle.high),
                        low: parseFloat(candle.low),
                        close: parseFloat(candle.close),
                    }));

                    if (!isInitialDataLoaded) {
                        // पहली बार: पूरा डेटा लोड करने के लिए setData() का उपयोग करें
                        candlestickSeries.setData(formattedData);
                        isInitialDataLoaded = true;
                        console.log('Initial chart data loaded with ' + formattedData.length + ' candles.');
                    } else {
                        // बाद के अपडेट: केवल आखिरी कैंडल को अपडेट करने के लिए update() का उपयोग करें
                        const lastCandle = formattedData[formattedData.length - 1];
                        candlestickSeries.update(lastCandle);
                        console.log('Chart updated with the latest candle.');
                    }
                } else {
                    console.warn('Received unsuccessful or empty data from backend:', data);
                    if (!isInitialDataLoaded) {
                        candlestickSeries.setData([]); // अगर पहली बार में ही डेटा नहीं है तो चार्ट खाली करें
                    }
                }
            } catch (error) {
                console.error('Failed to fetch or process candle data:', error);
                showMessage('Could not load chart data.', 'loss');
            }
        }

        // अगली कैंडल के लिए काउंटडाउन टाइमर शुरू करने का फंक्शन
        function startCountdown() {
            let secondsLeft = 30;
            if (countdownInterval) {
                clearInterval(countdownInterval);
            }

            candleTimerElement.textContent = `${secondsLeft}s`;
            countdownInterval = setInterval(() => {
                secondsLeft--;
                candleTimerElement.textContent = `${secondsLeft}s`;
                if (secondsLeft < 0) { // 0 पर रीसेट करें
                    secondsLeft = 29; 
                }
            }, 1000);
        }

        // --- Initial Load and Periodic Fetch ---
        function initializeChart() {
            fetchAndUpdateChart(); // पहली बार डेटा लोड करें
            startCountdown();

            setInterval(() => {
                fetchAndUpdateChart(); // बाद में केवल अपडेट करें
                startCountdown();
            }, DATA_FETCH_INTERVAL);
        }
        
        initializeChart();


        // --- UI Event Listeners ---
        let currentBet = 100;
        const betStep = 50;

        function updateBetAmountDisplay() {
            betAmountSpan.textContent = `₹${currentBet}`;
            betAmountInput.value = currentBet;
        }

        increaseBetBtn.addEventListener('click', () => {
            currentBet += betStep;
            updateBetAmountDisplay();
        });

        decreaseBetBtn.addEventListener('click', () => {
            if (currentBet > betStep) {
                currentBet -= betStep;
                updateBetAmountDisplay();
            }
        });

        betAmountSpan.addEventListener('click', () => {
            betAmountSpan.style.display = 'none';
            betAmountInput.style.display = 'block';
            betAmountInput.focus();
        });

        betAmountInput.addEventListener('blur', () => {
            const newValue = parseInt(betAmountInput.value, 10);
            if (!isNaN(newValue) && newValue > 0) {
                currentBet = newValue;
            }
            updateBetAmountDisplay();
            betAmountInput.style.display = 'none';
            betAmountSpan.style.display = 'block';
        });
        
        betAmountInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                betAmountInput.blur();
            }
        });

        indicatorBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            indicatorMenu.classList.toggle('show');
        });

        document.addEventListener('click', (e) => {
            if (!indicatorMenu.contains(e.target) && !indicatorBtn.contains(e.target)) {
                indicatorMenu.classList.remove('show');
            }
        });

        // --- History Modal Logic ---
        historyButton.addEventListener('click', () => {
            updateHistoryUI();
            historyModal.classList.add('show');
        });

        closeHistoryBtn.addEventListener('click', () => historyModal.classList.remove('show'));
        historyModal.addEventListener('click', (e) => {
            if (e.target === historyModal) historyModal.classList.remove('show');
        });

        async function updateHistoryUI() {
            historyList.innerHTML = '<p class="no-history">Loading history...</p>';
            try {
                const response = await fetch('/candle/trade-history-candleX.php');
                const result = await response.json();

                if (!result.success || result.data.length === 0) {
                    historyList.innerHTML = '<p class="no-history">You have no trade history yet.</p>';
                    return;
                }
                historyList.innerHTML = '';
                result.data.forEach(trade => {
                    const resultClass = trade.result >= 0 ? 'win' : 'loss';
                    const resultSign = trade.result >= 0 ? '+' : '-';
                    const directionIcon = trade.direction === 'up' ? '<i class="fa-solid fa-arrow-trend-up"></i>' : '<i class="fa-solid fa-arrow-trend-down"></i>';
                    const itemHTML = `
                        <div class="history-item">
                            <div class="history-top">
                                <div class="history-top-left">
                                    <div class="history-direction-icon ${trade.direction}">${directionIcon}</div>
                                    <div class="history-timeframe">${trade.timeframeLabel}</div>
                                </div>
                                <div class="history-result ${resultClass}">${resultSign}₹${Math.abs(trade.result).toFixed(2)}</div>
                            </div>
                            <div class="history-bottom">
                                <div class="detail-item"><span class="label"><i class="fa-regular fa-money-bill-1"></i> Bet Amount</span><span class="value">₹${trade.betAmount.toFixed(2)}</span></div>
                                <div class="detail-item"><span class="label"><i class="fa-solid fa-right-to-bracket"></i> Entry Price</span><span class="value">${trade.entryPrice.toFixed(3)}</span></div>
                                <div class="detail-item"><span class="label"><i class="fa-solid fa-right-from-bracket"></i> Closing Value</span><span class="value">${trade.exitPrice.toFixed(3)}</span></div>
                                <div class="detail-item"><span class="label"><i class="fa-regular fa-clock"></i> Opening Time</span><span class="value">${trade.startTime}</span></div>
                                <div class="detail-item"><span class="label"><i class="fa-solid fa-clock"></i> Closing Time</span><span class="value">${trade.endTime}</span></div>
                                <div class="detail-item"><span class="label"><i class="fa-solid fa-tag"></i> Bet Type</span><span class="value">${trade.direction.toUpperCase()}</span></div>
                            </div>
                        </div>`;
                    historyList.innerHTML += itemHTML;
                });
            } catch (error) {
                console.error('Failed to load history:', error);
                historyList.innerHTML = '<p class="no-history">Failed to load history.</p>';
            }
        }

        // --- Notification Message Function ---
        function showMessage(message, type = 'info') {
            const existingMessage = document.querySelector('.app-message');
            if (existingMessage) {
                existingMessage.remove();
            }
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `app-message ${type}`;
            messageDiv.textContent = message;
            document.body.prepend(messageDiv);
            setTimeout(() => {
                messageDiv.remove();
            }, 4000);
        }
        
        // चार्ट को रिसाइज करने का लॉजिक ताकि यह हमेशा सही आकार में रहे
        new ResizeObserver(entries => {
          if (entries.length > 0 && entries[0].contentRect.width > 0) {
            const { width, height } = entries[0].contentRect;
            chart.applyOptions({ width, height });
          }
        }).observe(chartElement);

    }); // DOMContentLoaded का अंत
</script>

    
</body>
</html>

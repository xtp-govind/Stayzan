<?php
// सर्वर को यह बताने के लिए कि हम JSON डेटा भेज रहे हैं
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

/**
 * कस्टम यूजर आईडी बनाने के लिए फंक्शन (जैसे: ZA8524)
 * @return string
 */
function generate_custom_user_id() {
    $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $random_letters = substr(str_shuffle($letters), 0, 2);
    $random_numbers = rand(1000, 9999);
    return $random_letters . $random_numbers;
}

// नकली डेटा बनाने के लिए एक फंक्शन
function create_fake_history() {
    $all_history = [];
    $grid_sizes = ['2x2', '3x3', '4x4'];
    $results = ['win', 'loss'];

    for ($i = 0; $i < 20; $i++) {
        $result = $results[array_rand($results)];

        // --- बेट अमाउंट जेनरेट करने का लॉजिक ---
        // 1. 1 से 200 के बीच एक रैंडम पूर्णांक (integer) चुनें।
        //    (आप 200 को बदलकर अधिकतम बेट की सीमा बदल सकते हैं, जैसे 500 करने पर अधिकतम बेट 5000 हो जाएगा)
        $multiplier = rand(1, 200); 

        // 2. उस पूर्णांक को 10 से गुणा करें।
        //    इससे यह सुनिश्चित होता है कि परिणाम हमेशा 10 का गुणज होगा (जैसे 10, 20, 30, ..., 2000)।
        //    न्यूनतम बेट: 1 * 10 = 10
        //    अधिकतम बेट: 200 * 10 = 2000
        $bet_amount = $multiplier * 10;
        
        $winnings = 0;

        if ($result === 'win') {
            $winnings = $bet_amount * (rand(15, 30) / 10); // 1.5x से 5x तक जीत
        }
$record = [
    'user_id'    => generate_custom_user_id(),
    'grid_size'  => $grid_sizes[array_rand($grid_sizes)],
    'bet_amount' => $bet_amount,   // <-- yahan number_format mat use karo
    'result'     => $result,
    'winnings'   => round($winnings, 2) // float rakho 2 decimal tak
];
        

        $all_history[] = $record;
    }

    return $all_history;
}

// नकली डेटा जेनरेट करें
$fake_data = create_fake_history();

// JSON फॉर्मेट में सफलता का संदेश और डेटा भेजें
echo json_encode([
    'status' => 'success',
    'data'   => $fake_data
]);

?>

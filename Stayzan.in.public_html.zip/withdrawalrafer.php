<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Withdrawal Page</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary-color: #6D28D9; --secondary-color: #4F46E5; --success-color: #10B981; --processing-color: #3B82F6; 
          --rejected-color: #EF4444;
      --warning-color: #F59E0B; --danger-color: #EF4444; --light-bg: #F3F4F6;
      --white-color: #ffffff; --dark-text: #111827; --light-text: #6B7280;
      --border-color: #E5E7EB; --card-bg: #ffffff;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
      font-family: 'Poppins', sans-serif; background-color: var(--light-bg);
      color: var(--dark-text); -webkit-font-smoothing: antialiased;
    }
    .container { max-width: 450px; margin: 0 auto; padding: 80px 15px 40px 15px; }
    
    .top-bar {
        position: fixed; top: 0; left: 0; right: 0; max-width: 450px; margin: 0 auto;
        display: flex; justify-content: space-between; align-items: center; padding: 15px;
        background: rgba(255, 255, 255, 0.7); backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px); z-index: 1000; transition: box-shadow 0.3s ease;
    }
    .top-bar.scrolled { box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-bottom: 1px solid var(--border-color); }
    .top-bar .title { font-size: 18px; font-weight: 600; }
    .top-bar .icon-btn {
        background: transparent; border: none; cursor: pointer; font-size: 18px; color: var(--dark-text);
        width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center;
        justify-content: center; transition: background-color 0.2s ease, transform 0.2s ease;
    }
    .top-bar .icon-btn:hover { background-color: #e9e9eb; transform: scale(1.1); }
    
    .card {
        background: var(--card-bg); border-radius: 24px; padding: 25px; margin-bottom: 25px;
        border: 1px solid var(--border-color); box-shadow: 0 8px 25px rgba(0, 0, 0, 0.05);
        animation: slideUp 0.5s ease-out forwards; opacity: 0;
    }
    .card:nth-child(1) { animation-delay: 0.1s; }
    .card:nth-child(2) { animation-delay: 0.2s; }
    .card:nth-child(3) { animation-delay: 0.3s; }
    @keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

    .balance-title { font-size: 16px; color: var(--light-text); margin-bottom: 8px; font-weight: 500; }
    .balance-amount { font-size: 40px; font-weight: 700; color: var(--dark-text); }

    .form-group { margin-bottom: 20px; }
    .label-group { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .label-group label { font-size: 14px; font-weight: 500; color: var(--light-text); }
    .add-account-btn {
        background: transparent; border: none; color: var(--primary-color); font-weight: 600;
        font-size: 13px; cursor: pointer; display: flex; align-items: center; gap: 5px;
        padding: 5px; border-radius: 8px; transition: background-color 0.2s ease;
    }
    .add-account-btn:hover { background-color: #f3f4f6; }
    .add-account-btn:disabled { opacity: 0.6; cursor: not-allowed; }
    .input-wrapper { position: relative; }
    .form-group input, .form-group select {
        width: 100%; padding: 15px 20px 15px 50px; border-radius: 12px; border: 1px solid var(--border-color);
        background-color: #F9FAFB; font-size: 16px; font-family: 'Poppins', sans-serif;
        transition: all 0.3s ease; -webkit-appearance: none;
    }
    .form-group input:focus, .form-group select:focus {
        border-color: var(--primary-color); background-color: var(--white-color);
        outline: none; box-shadow: 0 0 0 3px rgba(109, 40, 217, 0.2);
    }
    .input-wrapper .input-icon {
        position: absolute; left: 18px; top: 50%; transform: translateY(-50%);
        color: var(--light-text); transition: color 0.3s ease;
    }
    .form-group input:focus ~ .input-icon, .form-group select:focus ~ .input-icon { color: var(--primary-color); }

    .withdraw-btn {
        width: 100%; padding: 16px; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        border: none; border-radius: 12px; color: white; font-weight: 600; font-size: 16px;
        cursor: pointer; transition: all 0.3s ease; display: flex; justify-content: center;
        align-items: center; gap: 10px; box-shadow: 0 8px 20px rgba(79, 70, 229, 0.25);
    }
    .withdraw-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(79, 70, 229, 0.35); }

    /* --- ✅ History UI (Updated) --- */
    .history-title { font-weight: 600; font-size: 20px; margin-bottom: 20px; }
    .history-item {
        display: flex; align-items: center; padding: 15px 0;
        border-bottom: 1px solid var(--border-color);
    }
    .history-item:last-child { border-bottom: none; }
    .history-icon {
        width: 45px; height: 45px; border-radius: 50%; display: flex;
        align-items: center; justify-content: center; margin-right: 15px;
    }
    .history-icon.completed { background-color: #D1FAE5; color: #065F46; }
    .history-icon.pending { background-color: #FEF3C7; color: #92400E; }
    .history-icon.processing { background-color: #93C5FD; color: #6D28D9; }
    .history-icon.rejected { background-color: #FECACA; color: #B91C1C;
        }
    .history-details { flex-grow: 1; }
    .history-details .top-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
    .history-details .type { font-weight: 600; font-size: 16px; }
    .history-details .amount { font-weight: 600; font-size: 16px; }
    .history-details .bottom-row { display: flex; justify-content: space-between; align-items: center; font-size: 13px; color: var(--light-text); }
    .history-details .date { display: flex; align-items: center; gap: 5px; }
    .history-details .status { font-weight: 500; text-transform: capitalize; }
    .status.completed { color: var(--success-color); }
    .status.pending { color: var(--warning-color); }
    .status.processing { color: var(--processing-color); }
    .status.rejected { color: var(--rejected-color); }   

    /* --- ✅ Error/Success Message (New) --- */
    #message-container {
        position: fixed; top: 70px; left: 50%; transform: translateX(-50%);
        z-index: 3000; display: flex; flex-direction: column; align-items: center; gap: 10px;
        width: 90%; max-width: 420px;
    }
    .message {
        width: 100%; padding: 15px 20px; border-radius: 12px;
        color: var(--white-color); font-weight: 500;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        display: flex; align-items: center; gap: 10px;
        opacity: 0; transform: translateY(-20px);
        animation: slideInMessage 0.5s forwards, fadeOutMessage 0.5s 4.5s forwards;
    }
    .message.success { background: var(--success-color); }
    .message.warning { background: var(--warning-color); }
    .message.error { background: var(--danger-color); }
    @keyframes slideInMessage { to { opacity: 1; transform: translateY(0); } }
    @keyframes fadeOutMessage { from { opacity: 1; } to { opacity: 0; transform: translateY(-20px); } }

    /* --- Add Account Modal --- */
    .modal-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.5); z-index: 2000;
        display: flex; justify-content: center; align-items: center;
        opacity: 0; visibility: hidden; transition: opacity 0.3s ease, visibility 0.3s ease;
    }
    .modal-overlay.open { opacity: 1; visibility: visible; }
    .modal-content {
        background: var(--white-color); border-radius: 24px; padding: 25px;
        width: 90%; max-width: 400px;
        transform: scale(0.95); transition: transform 0.3s ease;
    }
    .modal-overlay.open .modal-content { transform: scale(1); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { font-size: 18px; font-weight: 600; }
    .modal-header .close-btn {
        background: #f3f4f6; border: none; width: 30px; height: 30px;
        border-radius: 50%; cursor: pointer; font-size: 16px;
    }
    .tab-buttons { display: flex; gap: 10px; border-bottom: 1px solid var(--border-color); margin-bottom: 20px; }
    .tab-btn {
        padding: 10px 15px; border: none; background: transparent; cursor: pointer;
        font-size: 14px; font-weight: 600; color: var(--light-text); position: relative;
    }
    .tab-btn.active { color: var(--primary-color); }
    .tab-btn.active::after {
        content: ''; position: absolute; bottom: -1px; left: 0; right: 0;
        height: 2px; background-color: var(--primary-color);
    }
    .tab-content { display: none; }
    .tab-content.active { display: block; animation: fadeIn 0.5s; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .action-buttons { display: flex; gap: 10px; margin-top: 10px; }
    .action-buttons button {
        flex-grow: 1; padding: 12px; border-radius: 10px; font-weight: 600;
        cursor: pointer; transition: all 0.2s ease;
    }
    .btn-primary { background-color: var(--primary-color); color: white; border: 1px solid var(--primary-color); }
    .btn-secondary { background-color: transparent; color: var(--dark-text); border: 1px solid var(--border-color); }
    
 /* --- ✅ हेल्प मॉडल के लिए नया CSS --- */
.help-section { 
    margin-bottom: 20px; 
}
.help-section:last-child {
    margin-bottom: 0;
}
.help-section h4 { 
    font-size: 16px; 
    font-weight: 600; 
    margin-bottom: 8px; 
    display: flex; 
    align-items: center; 
    gap: 8px; 
    color: var(--primary-color); 
}
.help-section p { 
    font-size: 14px; 
    line-height: 1.6; 
    color: var(--light-text); 
}
.help-section ul { 
    list-style-position: inside; 
    padding-left: 5px; 
    color: var(--light-text);
}
.help-section li { 
    margin-bottom: 5px; 
}
.help-contact-btn {
    width: 100%; 
    padding: 12px; 
    background-color: var(--primary-color); 
    color: white;
    border: none; 
    border-radius: 12px; 
    font-weight: 600; 
    cursor: pointer;
    text-align: center; 
    text-decoration: none; 
    display: block; 
    margin-top: 15px;
    transition: background-color 0.3s ease;
}
.help-contact-btn:hover {
    background-color: var(--secondary-color);
}

  </style>
</head>
<body>

  <header class="top-bar" id="top-bar">
    <button class="icon-btn" onclick="window.history.back()" aria-label="Go Back"><i class="fas fa-arrow-left"></i></button>
        <h1 class="title">Withdrawal</h1>
        <div style="width: 38px;"></div>
        <button class="icon-btn" id="open-help-modal-btn" aria-label="Help"><i class="fas fa-question"></i></button>
  </header>

  <main class="container">
    <section class="card balance-box">
      <h2 class="balance-title">Total Referral Balance</h2>
      <p class="balance-amount">loading...</p>
    </section>

    <section class="card withdraw-box">
      <div class="form-group">
        <div class="label-group">
            <label for="accountSelect">Select Account</label>
            <button class="add-account-btn" id="open-modal-btn">
                <i class="fas fa-plus"></i> Add New
            </button>
        </div>
        <div class="input-wrapper">
            <select id="accountSelect">
              <option value="upi-user@bank">UPI - user@bank</option>
              <option value="bank-1234">Bank - ****1234</option>
            </select>
            <i class="fas fa-university input-icon"></i>
        </div>
      </div>
      
      <div class="form-group">
        <label for="amount">Enter Amount</label>
        <div class="input-wrapper">
            <input type="number" id="amount" placeholder="0.00" />
            <i class="fas fa-rupee-sign input-icon"></i>
        </div>
      </div>
      <button class="withdraw-btn" onclick="handleWithdraw()">
        <i class="fas fa-paper-plane"></i> Withdraw Now
      </button>
    </section>
    
    <section class="card history-box">
      <h2 class="history-title">Withdrawal History</h2>
      <div id="history-list">
          <p>Loading history...</p>
      </div>
    </section>
  </main>

  <!-- ✅ Message Container (New) -->
  <div id="message-container"></div>

  <!-- Add Account Modal -->
  <div class="modal-overlay" id="add-account-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Add New Account</h3>
            <button class="close-btn" id="close-modal-btn">&times;</button>
        </div>
        <form method="POST" action="add_user_account">
            <input type="hidden" name="type" id="accountType" value="UPI">
            <div class="tab-buttons">
                <button type="button" class="tab-btn active" data-tab="upi">UPI</button>
                <button type="button" class="tab-btn" data-tab="bank">Bank Account</button>
            </div>
            <div id="upi-tab" class="tab-content active">
                <div class="form-group">
                    <label for="upiId">UPI ID</label>
                    <input type="text" name="upi_id" id="upiId" placeholder="yourname@bank">
                </div>
            </div>
            <div id="bank-tab" class="tab-content">
                <div class="form-group">
                    <label for="accHolder">Account Holder Name</label>
                    <input type="text" name="acc_holder" id="accHolder" placeholder="e.g. John Doe">
                </div>
                <div class="form-group">
                    <label for="accNumber">Account Number</label>
                    <input type="number" name="acc_number" id="accNumber" placeholder="Enter account number">
                </div>
                <div class="form-group">
                    <label for="ifsc">IFSC Code</label>
                    <input type="text" name="ifsc" id="ifsc" placeholder="Enter IFSC code">
                </div>
            </div>
            <div class="action-buttons">
                <button type="button" class="btn-secondary" id="cancel-add">Cancel</button>
                <button type="submit" class="btn-primary">Save Account</button>
            </div>
        </form>
    </div>
  </div>

<!-- ✅ यह नया हेल्प मॉडल है -->
<div class="modal-overlay" id="help-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Help & Support</h3>
            <button class="close-btn" id="close-help-modal-btn">&times;</button>
        </div>
        <div class="help-section">
            <h4><i class="fas fa-wallet"></i> Withdrawal कैसे लगाएं?</h4>
            <p>
                पैसे निकालने के लिए, नीचे दिए गए स्टेप्स फॉलो करें:
                <ul>
                    <li>सबसे पहले अपना बैंक अकाउंट या UPI चुनें।</li>
                    <li>जितना अमाउंट निकालना है, वह दर्ज करें (न्यूनतम ₹100)।</li>
                    <li>"Withdraw Now" बटन पर क्लिक करें।</li>
                </ul>
            </p>
        </div>
        <div class="help-section">
            <h4><i class="fas fa-hourglass-half"></i> पैसे कब तक आएंगे?</h4>
            <p>
                आमतौर पर, विथड्रॉवल रिक्वेस्ट 24 घंटे के अंदर प्रोसेस हो जाती है। हालांकि, बैंक की प्रक्रिया के कारण इसमें 48 घंटे तक लग सकते हैं।
            </p>
        </div>
        <div class="help-section">
            <h4><i class="fas fa-headset"></i> सहायता चाहिए?</h4>
            <p>
                अगर आपको कोई समस्या आ रही है या आपका विथड्रॉवल 48 घंटे में नहीं आया है, तो आप हमसे संपर्क कर सकते हैं।
            </p>
            <a href="https://t.me/stayzan_bot" class="help-contact-btn">
                <i class="fab fa-telegram-plane"></i> Telegram Support
            </a>
        </div>
    </div>
</div>


  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>


     
     // --- ✅ हेल्प मॉडल का लॉजिक ---
const helpModal = document.getElementById('help-modal');
const openHelpModalBtn = document.getElementById('open-help-modal-btn');
const closeHelpModalBtn = document.getElementById('close-help-modal-btn');

const openHelpModal = () => helpModal.classList.add('open');
const closeHelpModal = () => helpModal.classList.remove('open');

openHelpModalBtn.addEventListener('click', openHelpModal);
closeHelpModalBtn.addEventListener('click', closeHelpModal);

// मॉडल के बाहर क्लिक करने पर बंद करें
helpModal.addEventListener('click', (e) => {
    if (e.target === helpModal) {
        closeHelpModal();
    }
});

      
    // --- ✅ New Message Function ---
    function showMessage(message, type = 'success') {
        const container = document.getElementById('message-container');
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${type}`;
        
        let iconClass = 'fa-check-circle';
        if (type === 'warning') iconClass = 'fa-exclamation-triangle';
        if (type === 'error') iconClass = 'fa-exclamation-circle';

        msgDiv.innerHTML = `<i class="fas ${iconClass}"></i> ${message}`;
        container.appendChild(msgDiv);

        setTimeout(() => {
            msgDiv.remove();
        }, 2000); // Message disappears after 2 seconds
    }

    // --- Modal Logic ---
    const modal = document.getElementById('add-account-modal');
    const openModalBtn = document.getElementById('open-modal-btn');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const cancelBtn = document.getElementById('cancel-add');
    const openModal = () => modal.classList.add('open');
    const closeModal = () => modal.classList.remove('open');
    openModalBtn.addEventListener('click', openModal);
    closeModalBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // --- Tab Switching Logic ---
    let currentTab = 'upi';
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const accountTypeInput = document.getElementById('accountType');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            currentTab = button.dataset.tab;
            accountTypeInput.value = currentTab === 'upi' ? 'UPI' : 'BANK';
            tabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            tabContents.forEach(content => content.classList.remove('active'));
            document.getElementById(`${currentTab}-tab`).classList.add('active');
        });
    });

    // --- Other Functions ---
    const topBar = document.getElementById('top-bar');
    window.addEventListener('scroll', () => {
        topBar.classList.toggle('scrolled', window.scrollY > 10);
    });

    // --- ✅ handleWithdraw (Updated) ---
    // --- ✅ handleWithdraw (FormData Version) ---
async function handleWithdraw() {
    const amountInput = document.getElementById('amount');
    const accountSelect = document.getElementById('accountSelect');
    const amountValue = amountInput.value.trim();
    const selectedAccount = accountSelect.value.trim();

    if (!selectedAccount) {
        showMessage('Please select an account to withdraw.', 'warning');
        return;
    }
    if (!amountValue || isNaN(amountValue) || parseFloat(amountValue) < 530) {
        showMessage('Minimum withdrawal amount is ₹530.', 'warning');
        return;
    }

    // 🔹 FormData bana lo
    const formData = new FormData();
    formData.append("amount", parseFloat(amountValue));
    formData.append("account", selectedAccount);

    try {
        const response = await fetch("/create_withdrawal2.php", {
            method: "POST",
            body: formData   // 👈 ab JSON.stringify ki zarurat nahi
        });

        const data = await response.json();

        if (data.status === 'success') {
            showMessage('Withdrawal request submitted successfully!', 'success');
            amountInput.value = ''; // Clear input field
            fetchBalance();
            fetchHistory(); // Refresh history
        } else {
            showMessage(data.message || 'An unknown error occurred.', 'error');
        }
    } catch (error) {
        console.error('Withdrawal Error:', error);
        showMessage('Could not connect to the server. Please try again.', 'error');
    }
}
    
    let currentBalance = 0;
    async function fetchBalance() {  
        try {  
            const res = await fetch('fetch_login_user_raferamount.php');  
            const response = await res.json();  
            if (response.status === 'success' && response.data) {  
                const balanceString = response.data.balance.replace(/,/g, '');
                const balance = parseFloat(balanceString); 
                document.querySelector('.balance-amount').textContent = `₹${balance.toFixed(2)}`;  
                currentBalance = balance; 
            } else {  
                showMessage('Failed to fetch balance.', 'error');
            }  
        } catch (err) {  
            console.error('Error fetching balance:', err);  
            showMessage('Unable to load balance.', 'error');
        }  
    }

async function fetchAccounts() {
    const accountSelect = document.getElementById('accountSelect');
    const openModalBtn = document.getElementById('open-modal-btn');
    const warningText = document.getElementById('account-limit-warning');

    try {
        const res = await fetch('fetch_user_accounts.php');
        const data = await res.json();
        
        accountSelect.innerHTML = ''; 

        let totalAccounts = 0;

        if (data.accounts && data.accounts.length > 0) {
            data.accounts.forEach(acc => {
                const option = new Option(`${acc.type} - ${acc.label}`, acc.value);
                accountSelect.add(option);
            });
            totalAccounts = data.accounts.length; 
        } else {

            const option = new Option('No accounts found', '');
            option.disabled = true; 
            accountSelect.add(option);
        }

        if (totalAccounts >= 5) {
            openModalBtn.disabled = true; // बटन को डिसेबल करें
            openModalBtn.style.cursor = 'not-allowed'; // कर्सर बदलें
        } else {
            openModalBtn.disabled = false; // बटन को इनेबल करें
            openModalBtn.style.cursor = 'pointer'; // कर्सर वापस बदलें
        }

    } catch (err) {
        console.error('Error fetching accounts:', err);
        const option = new Option('Error loading accounts', '');

        accountSelect.add(option);
        
        openModalBtn.disabled = true;
    
    }
}

    // --- ✅ fetchHistory (Updated) ---
    async function fetchHistory() {
        const historyListDiv = document.getElementById('history-list');
        try {
            const response = await fetch('fetch_withdrawal_rafer_history.php'); 
            const data = await response.json();

            if (data.history) {
                historyListDiv.innerHTML = ''; 

                if (data.history.length === 0) {
                    historyListDiv.innerHTML = '<p style="text-align: center; color: var(--light-text);">No withdrawal history found.</p>';
                    return;
                }

                data.history.forEach(item => {
                    const amountFormatted = parseFloat(item.amount).toFixed(2);
                    const statusClass = item.status.toLowerCase();
                    let icon;
if (statusClass === 'completed') {
    icon = 'fa-check';
} 
else if (statusClass === 'pending') {
    icon = 'fa-hourglass-half';
    
}
else if (statusClass === 'rejected') {
    icon = 'fas fa-times'; 
}
else if (statusClass === 'processing') {
    icon = 'fa-circle-notch fa-spin'; // ya koi aur upar wale options se
}
                    const historyItemHTML = `
                        <div class="history-item">
                            <div class="history-icon ${statusClass}">
                                <i class="fas ${icon}"></i>
                            </div>
                            <div class="history-details">
                                <div class="top-row">
                                    <span class="type">Withdrawal</span>
                                    <span class="amount">₹${amountFormatted}</span>
                                </div>
                                <div class="bottom-row">
                                    <span class="date"><i class="far fa-calendar-alt"></i> ${item.date}</span>
                                    <span class="status ${statusClass}">${item.status}</span>
                                </div>
                            </div>
                        </div>
                    `;
                    historyListDiv.innerHTML += historyItemHTML;
                });
            } else {
                historyListDiv.innerHTML = `<p>Error: Could not load history.</p>`;
            }
        } catch (error) {
            console.error('Error fetching history:', error);
            historyListDiv.innerHTML = '<p>An error occurred while fetching history.</p>';
        }
    }

    // Fetch data on page load
    window.addEventListener('DOMContentLoaded', () => {
        fetchBalance();
        fetchAccounts();
        fetchHistory(); 
    });
  </script>
</body>
</html>

<?php
// db_connect.php

$servername = "localhost";
$username = "u976552851_hellogovind";
$password = "Govind@00#";
$dbname = "u976552851_hellogovind";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // Production में विस्तृत त्रुटि न दिखाएं
    die("Connection failed. Please try again later.");
}

// Set charset
mysqli_set_charset($conn, "utf8mb4");
?>

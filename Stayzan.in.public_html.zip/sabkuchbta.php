<?php
// First DB (mine_bet)
$conn1 = new mysqli("localhost", "u976552851_party", "Govind@00#", "u976552851_party");
if ($conn1->connect_error) die("Conn1 failed: " . $conn1->connect_error);

$mine = $conn1->query("
    SELECT user_id AS user, played_at AS time, bet_amount AS bet, 
           (winnings - bet_amount) AS profit_loss, 
           result AS game_result, 'Mine' AS game_type 
    FROM mine_bet 
    WHERE user_id='UI1482'
");

// Mine Totals (separate summary)
$mine_totals = $conn1->query("
    SELECT 
        SUM(bet_amount) AS total_bet,
        SUM(CASE WHEN winnings > bet_amount THEN (winnings - bet_amount) ELSE 0 END) AS total_profit,
        SUM(CASE WHEN winnings < bet_amount THEN (bet_amount - winnings) ELSE 0 END) AS total_loss
    FROM mine_bet
    WHERE user_id='UI1482'
")->fetch_assoc();


// Second DB (fastparity_bets)
$conn2 = new mysqli("localhost", "u976552851_hellogovind", "Govind@00#", "u976552851_hellogovind");
if ($conn2->connect_error) die("Conn2 failed: " . $conn2->connect_error);

$fast = $conn2->query("
    SELECT unique_id AS user, created_at AS time, amount AS bet, 
           CAST(status AS DECIMAL(10,2)) AS profit_loss, 
           result_text AS game_result, 'FastParity' AS game_type 
    FROM fastparity_bets 
    WHERE unique_id='UI1482'
");

// Parity bets (same DB)
$part = $conn2->query("
    SELECT unique_id AS user, created_at AS time, amount AS bet, 
           CAST(status AS DECIMAL(10,2)) AS profit_loss, 
           result_text AS game_result, 'Parity' AS game_type 
    FROM parity_bets 
    WHERE unique_id='UI1482'
");


// Merge all results
$data = [];
while($row = $mine->fetch_assoc()) $data[] = $row;
while($row = $fast->fetch_assoc()) $data[] = $row;
while($row = $part->fetch_assoc()) $data[] = $row;

// Sort by time
usort($data, function($a, $b) {
    return strtotime($a['time']) - strtotime($b['time']);
});

// Starting balance
$balance = 10;
?>
<!DOCTYPE html>
<html>
<head>
  <title>User Timeline</title>
  <style>
    body { font-family: Arial, sans-serif; margin:20px; }
    table { width:100%; border-collapse: collapse; margin-bottom:20px; }
    th,td { border:1px solid #ccc; padding:8px; text-align:center; }
    th { background:#333; color:#fff; }
    .win {color:green; font-weight:bold;}
    .loss {color:red; font-weight:bold;}
    .cashout {color:orange; font-weight:bold;}
    h2,h3 { margin-top:30px; }
  </style>
</head>
<body>
<h2>User Game Analysis (UI1482)</h2>

<!-- Timeline Table -->
<table>
  <tr>
    <th>Time</th><th>Game Type</th><th>Bet</th><th>Profit/Loss</th><th>Result</th><th>Balance</th>
  </tr>
<?php
foreach($data as $row) {
    $balance += $row['profit_loss'];
    $class = ($row['game_result']=="win")?"win":(($row['game_result']=="loss")?"loss":"cashout");
    echo "<tr>
      <td>{$row['time']}</td>
      <td>{$row['game_type']}</td>
      <td>₹{$row['bet']}</td>
      <td>{$row['profit_loss']}</td>
      <td class='$class'>{$row['game_result']}</td>
      <td>₹{$balance}</td>
    </tr>";
}
?>
</table>

<!-- Mine Bet Summary -->
<h3>Mine Bet Summary</h3>
<table>
  <tr>
    <th>Total Bet</th>
    <th>Total Profit</th>
    <th>Total Loss</th>
  </tr>
  <tr>
    <td>₹<?php echo $mine_totals['total_bet'] ?? 0; ?></td>
    <td style="color:green;">₹<?php echo $mine_totals['total_profit'] ?? 0; ?></td>
    <td style="color:red;">₹<?php echo $mine_totals['total_loss'] ?? 0; ?></td>
  </tr>
</table>

</body>
</html>
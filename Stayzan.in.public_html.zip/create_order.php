<?php
session_start();
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

// DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    $errorMsg = 'DB Connection Failed';
    file_put_contents('errors.txt', $errorMsg . PHP_EOL, FILE_APPEND);
    die(json_encode(['error' => $errorMsg]));
}

// Razorpay Credentials
$key_id = "rzp_live_AAPAIOOECx1xqK";
$key_secret = "39wKAQCaq3RayCEMjZQGx6Og";

// User validation
if (!isset($_SESSION['unique_id'])) {
    $errorMsg = 'User not logged in.';
    http_response_code(401);
    file_put_contents('errors.txt', $errorMsg . PHP_EOL, FILE_APPEND);
    echo json_encode(['error' => $errorMsg]);
    exit;
}
$unique_id = $_SESSION['unique_id'];

// Get input
$postData = json_decode(file_get_contents('php://input'), true);
$amount = $postData['amount'] ?? null;

if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
    $errorMsg = 'Invalid amount';
    http_response_code(400);
    file_put_contents('errors.txt', $errorMsg . PHP_EOL, FILE_APPEND);
    echo json_encode(['error' => $errorMsg]);
    exit;
}

// Prepare order data
$amount_in_paise = $amount * 100;
$receipt_id = 'rcpt_' . time() . '_' . $unique_id;

$orderData = [
    'amount' => $amount_in_paise,
    'currency' => 'INR',
    'receipt' => $receipt_id,
    'payment_capture' => 1,
    'notes' => ['unique_id' => $unique_id]
];

// CURL Request to Razorpay
$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, "$key_id:$key_secret");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($orderData));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Log Razorpay raw response in root
file_put_contents('razorpay_response_log.txt', date("Y-m-d H:i:s") . ' | ' . $response . PHP_EOL, FILE_APPEND);

curl_close($ch);

if ($http_status == 200 || $http_status == 201) {
    $data = json_decode($response, true);
    $razorpayOrderId = $data['id'];

    $output = [
        'status' => 'success',
        'id' => $razorpayOrderId,
        'amount' => $amount_in_paise,
        'currency' => 'INR',
        'key' => $key_id,
        'unique_id' => $unique_id
    ];

    // Log final response to client in root
    file_put_contents('response_to_client.txt', date("Y-m-d H:i:s") . ' | ' . json_encode($output, JSON_PRETTY_PRINT) . PHP_EOL, FILE_APPEND);

    echo json_encode($output);
    exit;
} else {
    // Log errors if order creation failed in root
    file_put_contents('razorpay_response_error.txt', date("Y-m-d H:i:s") . ' | ' . $response . PHP_EOL, FILE_APPEND);
    echo json_encode(['error' => 'Order creation failed', 'details' => $response]);
    exit;
}
?>
<?php
// ✅ Input: $unique_id (session ya signup ke baad generate hua user ID)
// ✅ DB connection

$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);


$unique_id = $_SESSION['unique_id'] ?? null;

if (!$unique_id) {
    exit("Missing unique ID");
}

$conn = new mysqli("localhost", "DB_USER", "DB_PASS", "DB_NAME");
if ($conn->connect_error) exit("DB error");

// Check if already assigned
$check = $conn->prepare("SELECT COUNT(*) as cnt FROM user_tasks WHERE user_id = ?");
$check->bind_param("s", $unique_id);
$check->execute();
$res = $check->get_result()->fetch_assoc();

if ($res['cnt'] > 0) {
    exit("Tasks already assigned.");
}

// Get all tasks from task_master
$tasks = $conn->query("SELECT id FROM task_master");

$stmt = $conn->prepare("INSERT INTO user_tasks (user_id, task_id, status) VALUES (?, ?, ?)");
while ($row = $tasks->fetch_assoc()) {
    $status = ($row['id'] === 'signup') ? 'completed' : 'locked'; // Signup auto complete
    $stmt->bind_param("sss", $unique_id, $row['id'], $status);
    $stmt->execute();
}
echo "Tasks assigned!";
?>
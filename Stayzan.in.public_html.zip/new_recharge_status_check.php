<?php
session_start();
header('Content-Type: application/json');

// --- DB config ---
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    echo json_encode(["error" => "DB connection failed"]);
    exit();
}

if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["error" => "User not logged in"]);
    exit();
}

$userUniqueId = $_SESSION['unique_id'];

// --- Get latest transaction ---
$sql = "SELECT id, status FROM transactions WHERE unique_id = ? ORDER BY id DESC LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $userUniqueId);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row) {
    echo json_encode([
        "id" => $row['id'],
        "status" => $row['status']
    ]);
} else {
    echo json_encode(["status" => "none"]);
}

$stmt->close();
$conn->close();
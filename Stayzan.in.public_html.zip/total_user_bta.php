<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>उपयोगकर्ता प्रबंधन | User Management</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">

    <style>
        :root{--primary-color:#6a5acd;--background-color:#f0f2f5;--card-background:#fff;--text-color:#555;--heading-color:#1d2129;--border-color:#e9ecef;--success-color:#20c997;--danger-color:#dc3545;--warning-color:#ffc107;--shadow:0 6px 20px rgba(0,0,0,.07)}body{font-family:'Poppins',sans-serif;background-color:var(--background-color);color:var(--text-color);margin:0;padding:15px}.container{max-width:1400px;margin:auto}.header{display:flex;flex-direction:column;gap:15px;margin-bottom:25px;background:var(--card-background);padding:20px;border-radius:12px;box-shadow:var(--shadow)}h1{font-size:24px;color:var(--heading-color);margin:0;text-align:center}.controls{display:flex;flex-direction:column;gap:15px}.search-wrapper{position:relative;width:100%}#search-input{width:100%;padding:12px 15px 12px 40px;border:1px solid var(--border-color);border-radius:8px;font-size:15px;box-sizing:border-box}#search-input:focus{outline:none;border-color:var(--primary-color)}.search-wrapper .material-icons-outlined{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#999}.btn{border:none;border-radius:8px;cursor:pointer;transition:all .3s;display:inline-flex;align-items:center;justify-content:center;font-weight:500;text-decoration:none}.btn:hover{transform:translateY(-2px)}.btn-primary{background-color:var(--primary-color);color:#fff;padding:12px;font-size:16px}.btn-primary .material-icons-outlined{margin-right:8px}#user-grid{display:grid;grid-template-columns:1fr;gap:20px}.user-card{background:var(--card-background);border-radius:12px;box-shadow:var(--shadow);padding:20px;display:flex;flex-direction:column;position:relative;transition:transform .3s,box-shadow .3s,opacity .3s}.user-card:hover{transform:translateY(-5px);box-shadow:0 10px 25px rgba(0,0,0,.1)}.user-card.blocked-card{opacity:.6}.card-header{display:flex;align-items:center;gap:15px;border-bottom:1px solid var(--border-color);padding-bottom:15px;margin-bottom:15px}.profile-icon{width:50px;height:50px;border-radius:50%;background-color:var(--primary-color);color:#fff;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:600}.user-info h3{margin:0;font-size:18px;color:var(--heading-color)}.user-info p{margin:0;font-size:14px;color:var(--primary-color);font-weight:500}.card-body{display:flex;flex-direction:column;gap:12px}.info-item{display:flex;align-items:center;gap:10px;font-size:14px}.info-item .material-icons-outlined{font-size:20px;color:#888}.card-footer{margin-top:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}.status{padding:4px 12px;border-radius:16px;font-size:12px;font-weight:500;color:#fff;display:inline-block}.status.active{background-color:var(--success-color)}.status.blocked{background-color:var(--danger-color)}.action-buttons{display:flex;gap:8px}.btn-icon{background:0 0;padding:6px}.btn-icon .material-icons-outlined{font-size:22px}.btn-edit .material-icons-outlined{color:var(--warning-color)}.btn-delete .material-icons-outlined{color:var(--danger-color)}.btn-block{padding:6px 10px;font-size:14px}.btn-block.block{background-color:var(--danger-color);color:#fff}.btn-block.unblock{background-color:var(--success-color);color:#fff}.message-container{text-align:center;padding:40px 20px;color:#777}.modal{display:none;position:fixed;z-index:1000;left:0;top:0;width:100%;height:100%;background-color:rgba(0,0,0,.5);justify-content:center;align-items:center}.modal-content{background-color:#fff;padding:25px;border-radius:12px;width:90%;max-width:500px;position:relative;animation:slide-down .4s ease-out;box-shadow:0 10px 30px rgba(0,0,0,.1)}@keyframes slide-down{from{transform:translateY(-30px);opacity:0}to{transform:translateY(0);opacity:1}}.close-btn{position:absolute;top:10px;right:15px;font-size:30px;font-weight:700;cursor:pointer;color:#aaa}#modal-title{margin-top:0;margin-bottom:25px;color:var(--heading-color);font-size:22px}#user-form .form-group{margin-bottom:20px}#user-form label{display:block;margin-bottom:8px;font-weight:500;color:#555}#user-form input{width:100%;padding:12px;border:1px solid var(--border-color);border-radius:8px;box-sizing:border-box;font-size:15px}#user-form input:focus{outline:none;border-color:var(--primary-color)}#user-form .btn{width:100%;padding:14px;font-size:16px;font-weight:600;background-color:var(--success-color);color:#fff}#toast-container{position:fixed;top:20px;right:20px;z-index:2000}.toast{background-color:#333;color:#fff;padding:15px 20px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.15);margin-bottom:10px;opacity:0;transform:translateX(100%);animation:slide-in .5s forwards}.toast.success{background-color:var(--success-color)}.toast.error{background-color:var(--danger-color)}@keyframes slide-in{to{opacity:1;transform:translateX(0)}}@media (min-width:600px){.header{flex-direction:row;justify-content:space-between;align-items:center}.controls{flex-direction:row;width:auto}.search-wrapper{width:280px}h1{text-align:left}#user-grid{grid-template-columns:repeat(2,1fr)}}@media (min-width:992px){#user-grid{grid-template-columns:repeat(3,1fr)}}@media (min-width:1400px){#user-grid{grid-template-columns:repeat(4,1fr)}}
    </style>
</head>
<body>

    <div id="toast-container"></div>

    <div class="container">
        <div class="header">
            <h1>उपयोगकर्ता प्रबंधन</h1>
            <div class="controls">
                <div class="search-wrapper">
                    <span class="material-icons-outlined">search</span>
                    <input type="text" id="search-input" placeholder="नाम, ईमेल या ID से खोजें...">
                </div>
                <button id="add-user-btn" class="btn btn-primary">
                    <span class="material-icons-outlined">add</span>
                    नया उपयोगकर्ता
                </button>
            </div>
        </div>

        <div id="user-grid"></div>
        <div id="message-container" class="message-container" style="display: none;"></div>

        <div id="user-modal" class="modal">
            <div class="modal-content">
                <span class="close-btn">&times;</span>
                <h2 id="modal-title">नए उपयोगकर्ता जोड़ें</h2>
                <form id="user-form">
                    <input type="hidden" id="user-id">
                    <div class="form-group"><label for="name">पूरा नाम:</label><input type="text" id="name" required></div>
                    <div class="form-group"><label for="email">ईमेल:</label><input type="email" id="email" required></div>
                    <div class="form-group"><label for="mobile">मोबाइल नंबर:</label><input type="text" id="mobile" required></div>
                    <div class="form-group"><label for="balance">बैलेंस:</label><input type="number" id="balance" step="0.01" required></div>
                    <div class="form-group"><label for="password">पासवर्ड:</label><input type="password" id="password"></div>
                    <button type="submit" class="btn">सेव करें</button>
                </form>
            </div>
        </div>
    </div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // ... (बाकी सभी वैरिएबल और फंक्शन वैसे ही रहेंगे) ...
    const userGrid = document.getElementById('user-grid');
    const messageContainer = document.getElementById('message-container');
    const searchInput = document.getElementById('search-input');
    const modal = document.getElementById('user-modal');
    const addUserBtn = document.getElementById('add-user-btn');
    const closeBtn = document.querySelector('.close-btn');
    const userForm = document.getElementById('user-form');
    const modalTitle = document.getElementById('modal-title');
    
    const apiUrl = 'total_user_update.php';
    let allUsers = [];

    const showToast = (message, type = 'success') => {
        const toastContainer = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        toastContainer.appendChild(toast);
        setTimeout(() => { toast.remove(); }, 3000);
    };

    const showMessage = (text) => {
        userGrid.style.display = 'none';
        messageContainer.style.display = 'block';
        messageContainer.innerHTML = text;
    };

    const showGrid = () => {
        userGrid.style.display = 'grid';
        messageContainer.style.display = 'none';
    };

    const renderCards = (users) => {
        userGrid.innerHTML = '';
        if (!users || users.length === 0) {
            showMessage('कोई उपयोगकर्ता नहीं मिला।');
            return;
        }
        showGrid();
        users.forEach(user => {
            const card = createUserCard(user);
            userGrid.appendChild(card);
        });
    };

    const loadUsers = async () => {
        showMessage('लोड हो रहा है...');
        try {
            const response = await fetch(apiUrl);
            if (!response.ok) {
                throw new Error(`नेटवर्क रिस्पॉन्स ठीक नहीं था (स्टेटस: ${response.status})`);
            }
            const result = await response.json();
            if (result.status === 'error') {
                throw new Error(result.message);
            }
            allUsers = result.data;
            renderCards(allUsers);
        } catch (error) {
            console.error('डेटा लोड करने में विफल:', error);
            showMessage(`त्रुटि: ${error.message}. कृपया बाद में पुन: प्रयास करें।`);
        }
    };

    // ✅✅✅ यहाँ अपडेटेड फंक्शन है ✅✅✅
    const createUserCard = (user) => {
        const card = document.createElement('div');
        const isBlocked = user && user.blocked == 1;
        const userName = user && user.name ? user.name : 'N/A';
        const uniqueId = user && user.unique_id ? user.unique_id : 'N/A';
        const userEmail = user && user.email ? user.email : 'N/A';
        const userMobile = user && user.mobile ? user.mobile : 'N/A';
        const userBalance = user && user.balance ? parseFloat(user.balance).toFixed(2) : '0.00';

        card.className = `user-card ${isBlocked ? 'blocked-card' : ''}`;
        
        const statusClass = isBlocked ? 'blocked' : 'active';
        const statusText = isBlocked ? 'Blocked' : 'Active';
        const blockButtonClass = isBlocked ? 'unblock' : 'block';
        const blockButtonText = isBlocked ? 'Unblock' : 'Block';
        const nameInitial = userName.charAt(0).toUpperCase();

        card.innerHTML = `
            <div class="card-header">
                <div class="profile-icon">${nameInitial}</div>
                <div class="user-info">
                    <h3>${userName}</h3>
                    <p>${uniqueId}</p>
                </div>
            </div>
            <div class="card-body">
                <div class="info-item"><span class="material-icons-outlined">email</span><span>${userEmail}</span></div>
                <div class="info-item"><span class="material-icons-outlined">phone_iphone</span><span>${userMobile}</span></div>
                <div class="info-item"><span class="material-icons-outlined">account_balance_wallet</span><span>₹${userBalance}</span></div>
            </div>
            <div class="card-footer">
                <span class="status ${statusClass}">${statusText}</span>
                <div class="action-buttons">
                    <button class="btn btn-block ${blockButtonClass}" data-id="${uniqueId}" data-name="${userName}">${blockButtonText}</button>
                    <button class="btn btn-icon btn-edit" title="एडिट"><span class="material-icons-outlined">edit</span></button>
                    <button class="btn btn-icon btn-delete" data-id="${uniqueId}" data-name="${userName}" title="डिलीट"><span class="material-icons-outlined">delete</span></button>
                </div>
            </div>
        `;

        card.querySelector('.btn-edit').addEventListener('click', () => {
            openModal('उपयोगकर्ता को एडिट करें', user);
        });

        card.querySelector('.btn-delete').addEventListener('click', (event) => {
            const id = event.currentTarget.dataset.id;
            const name = event.currentTarget.dataset.name;
            deleteUser(id, name);
        });

        card.querySelector('.btn-block').addEventListener('click', (event) => {
            const id = event.currentTarget.dataset.id;
            const name = event.currentTarget.dataset.name;
            toggleBlock(id, name, isBlocked);
        });
        
        return card;
    };

    // ... (बाकी सभी फंक्शन toggleBlock, searchInput, openModal, etc. वैसे ही रहेंगे) ...
    const toggleBlock = async (unique_id, name, isCurrentlyBlocked) => {
        const action = isCurrentlyBlocked ? 'अनब्लॉक' : 'ब्लॉक';
        if (!confirm(`क्या आप वाकई ${name} को ${action} करना चाहते हैं?`)) return;
        try {
            const response = await fetch(apiUrl, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ unique_id: unique_id, status: isCurrentlyBlocked ? 0 : 1 })
            });
            const result = await response.json();
            if (result.status === 'error') throw new Error(result.message);
            showToast(result.message, 'success');
            loadUsers();
        } catch (error) {
            showToast(`स्टेटस अपडेट करने में विफल: ${error.message}`, 'error');
        }
    };
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const filteredUsers = allUsers.filter(user => 
            (user.name && user.name.toLowerCase().includes(searchTerm)) ||
            (user.email && user.email.toLowerCase().includes(searchTerm)) ||
            (user.unique_id && user.unique_id.toLowerCase().includes(searchTerm))
        );
        renderCards(filteredUsers);
    });
    const openModal = (title = 'नए उपयोगकर्ता जोड़ें', user = null) => {
        modalTitle.textContent = title;
        userForm.reset();
        document.getElementById('user-id').value = '';
        document.getElementById('password').placeholder = "नया पासवर्ड डालें (आवश्यक)";
        document.getElementById('password').required = true;
        if (user) {
            document.getElementById('user-id').value = user.unique_id;
            document.getElementById('name').value = user.name;
            document.getElementById('email').value = user.email;
            document.getElementById('mobile').value = user.mobile;
            document.getElementById('balance').value = user.balance;
            document.getElementById('password').placeholder = "पासवर्ड बदलने के लिए यहाँ टाइप करें";
            document.getElementById('password').required = false;
        }
        modal.style.display = 'flex';
    };
    const closeModal = () => { modal.style.display = 'none'; };
    addUserBtn.addEventListener('click', () => openModal());
    closeBtn.addEventListener('click', closeModal);
    window.addEventListener('click', (event) => { if (event.target === modal) closeModal(); });
    userForm.addEventListener('submit', async function (event) {
        event.preventDefault();
        const id = document.getElementById('user-id').value;
        const userData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            mobile: document.getElementById('mobile').value,
            balance: parseFloat(document.getElementById('balance').value).toFixed(2),
            password: document.getElementById('password').value
        };
        if (id) { userData.unique_id = id; }
        try {
            const response = await fetch(apiUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(userData) });
            const result = await response.json();
            if (result.status === 'error') throw new Error(result.message);
            showToast(result.message, 'success');
            closeModal();
            loadUsers();
        } catch (error) {
            showToast(`उपयोगकर्ता को सहेजने में विफल: ${error.message}`, 'error');
        }
    });
    const deleteUser = async (id, name) => {
        if (!confirm(`क्या आप वाकई ${name} (${id}) को हमेशा के लिए हटाना चाहते हैं?`)) return;
        try {
            const response = await fetch(`${apiUrl}?unique_id=${id}`, { method: 'DELETE' });
            const result = await response.json();
            if (result.status === 'error') throw new Error(result.message);
            showToast(result.message, 'success');
            loadUsers();
        } catch (error) {
            showToast(`उपयोगकर्ता को हटाने में विफल: ${error.message}`, 'error');
        }
    };

    loadUsers();
});
</script>

</body>
</html>

<?php
include 'config.php';
header('Content-Type: application/json');

$number = rand(0, 9);
$color = ($number % 2 === 0) ? 'Red' : 'Gray';

$stmt = $conn->prepare("INSERT INTO results (number, color) VALUES (?, ?)");
$stmt->bind_param("is", $number, $color);
$stmt->execute();

echo json_encode(["number" => $number, "color" => $color]);
?>
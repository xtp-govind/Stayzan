<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recharge</title>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Razorpay Checkout Script -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
            margin: 0;
            padding-bottom: 80px;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 100%;
            padding: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
        }

        /* Header Styles */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px 20px;
            text-align: center;
            border-bottom-left-radius: 30px;
            border-bottom-right-radius: 30px;
            box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: rotate(0deg); }
            50% { transform: rotate(180deg); }
        }

        .header h1 {
            font-size: 2em;
            margin: 0;
            position: relative;
            z-index: 1;
            font-weight: 700;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }

        /* Balance Card Styles */
        .balance-card {
            text-align: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            position: relative;
            overflow: hidden;
        }

        .balance-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.05)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            opacity: 0.3;
        }

        .balance-card .label {
            font-size: 1.1em;
            color: rgba(255,255,255,0.9);
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
            font-weight: 500;
        }

        .balance-card .amount {
            font-size: 3em;
            font-weight: 800;
            color: white;
            position: relative;
            z-index: 1;
            text-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }

        /* Form Styles */
        .form-title {
            font-size: 1.4em;
            font-weight: 700;
            margin-bottom: 25px;
            text-align: center;
            color: #333;
            position: relative;
        }

        .form-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 3px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 2px;
        }

        .input-group {
            position: relative;
            margin-bottom: 25px;
        }

        .input-group .icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.4em;
            color: #667eea;
            z-index: 2;
        }

        .amount-input {
            width: 100%;
            padding: 20px 20px 20px 60px;
            border: 2px solid #e0e0e0;
            border-radius: 15px;
            font-size: 1.6em;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s ease;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(10px);
        }

        .amount-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 20px rgba(102, 126, 234, 0.3);
            transform: translateY(-2px);
        }

        /* Quick Amount Buttons */
        .quick-amounts {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .quick-amount-btn {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border: 2px solid #dee2e6;
            border-radius: 12px;
            padding: 15px 10px;
            font-size: 1em;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .quick-amount-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: left 0.5s;
        }

        .quick-amount-btn:hover::before {
            left: 100%;
        }

        .quick-amount-btn:hover, .quick-amount-btn.selected {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: #667eea;
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        /* Recharge Button */
        .recharge-btn {
            width: 100%;
            padding: 18px;
            border: none;
            border-radius: 15px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            font-size: 1.2em;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(40, 167, 69, 0.4);
            position: relative;
            overflow: hidden;
        }

        .recharge-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s;
        }

        .recharge-btn:hover::before {
            left: 100%;
        }

        .recharge-btn:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 35px rgba(40, 167, 69, 0.5);
        }

        .recharge-btn:active {
            transform: translateY(-2px);
        }

/* --- ✅ नया इंटरैक्टिव अकॉर्डियन लेआउट CSS --- */
.recharge-history {
    background-color: #f7f8fc;
    border-radius: 24px;
    padding: 20px;
    margin-top: 20px;
}

.history-title {
    font-size: 1.5em;
    font-weight: 700;
    margin-bottom: 20px;
    color: #1d2a4d;
    display: flex;
    align-items: center;
    gap: 12px;
}

.history-title i {
    color: #667eea;
}

#historyList {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 15px; /* हर आइटम के बीच गैप */
}

.accordion-item {
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
    overflow: hidden; /* एनिमेशन के लिए ज़रूरी */
    transition: box-shadow 0.3s ease;
}

.accordion-item.active {
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
}

.accordion-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 18px;
    cursor: pointer;
}

.header-left, .header-right {
    display: flex;
    align-items: center;
    gap: 12px;
}

.header-icon {
    font-size: 1.4em;
}
.header-icon.status-success { color: #28a745; }
.header-icon.status-pending { color: #ffc107; }
.header-icon.status-failed { color: #dc3545; }

.header-amount {
    font-size: 1.2em;
    font-weight: 600;
    color: #1d2a4d;
}

.header-date {
    font-size: 0.9em;
    color: #5a6a85;
}

.expand-icon {
    font-size: 0.9em;
    color: #8492a6;
    transition: transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.accordion-content {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.content-inner {
    padding: 0 20px 20px 20px;
    border-top: 1px solid #f0f2f5;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.9em;
}
.detail-row strong {
    color: #5a6a85;
}
.detail-row span {
    color: #1d2a4d;
    font-weight: 500;
    display: flex;
    align-items: center;
}

.copy-btn {
    background: none; border: none; color: #667eea;
    cursor: pointer; font-size: 1em; margin-left: 8px;
}

.detail-status.status-success { color: #28a745; }
.detail-status.status-pending { color: #ffc107; }
.detail-status.status-failed { color: #dc3545; }

.complaint-wrapper {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px dashed #e0e0e0;
}
.complaint-btn {
    width: 100%;
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
    border-radius: 10px;
    padding: 10px;
    font-size: 0.9em;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}
.complaint-btn:hover {
    background-color: #f1b0b7;
}

.no-history {
    text-align: center; padding: 40px 20px; color: #95a5a6;
}
.no-history i {
    display: block; font-size: 3em; margin-bottom: 15px; color: #bdc3c7;
}




        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e9ecef;
            padding: 10px 0;
            z-index: 1000;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 100%;
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #666;
            min-width: 60px;
        }

        .nav-item:hover {
            background: #f8f9fa;
            color: #667eea;
            transform: translateY(-2px);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .nav-item i {
            font-size: 1.3em;
            margin-bottom: 4px;
        }

        .nav-item .nav-text {
            font-size: 0.75em;
            font-weight: 600;
        }

    
        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .card {
                padding: 20px;
                margin-bottom: 15px;
            }
            
            .balance-card .amount {
                font-size: 2.5em;
            }
            
            .quick-amounts {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }
            
            .history-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .right-actions {
                flex-direction: row;
                align-items: center;
                width: 100%;
                justify-content: space-between;
            }
        }

        @media (max-width: 480px) {
            .header h1 {
                font-size: 1.6em;
            }
            
            .balance-card .amount {
                font-size: 2.2em;
            }
            
            .amount-input {
                font-size: 1.4em;
                padding: 18px 18px 18px 55px;
            }
            
            .quick-amounts {
                grid-template-columns: 1fr 1fr;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Recharge Account</h1>
    </div>

    <div class="container">
        <div class="card balance-card">
            <div class="label">Current Balance</div>
            <div class="amount">₹<span id="currentBalance">0.00</span></div>
        </div>

        <div class="card recharge-form">
            <h2 class="form-title">Enter Recharge Amount</h2>
            <div class="input-group">
                <span class="icon">₹</span>
                <input type="number" id="amountInput" class="amount-input" placeholder="0.00" min="350">
            </div>
            <div class="quick-amounts">
                <button class="quick-amount-btn" onclick="setAmount(500)">₹500</button>
                <button class="quick-amount-btn" onclick="setAmount(700)">₹700</button>
                <button class="quick-amount-btn" onclick="setAmount(1000)">₹1000</button>
                <button class="quick-amount-btn" onclick="setAmount(2000)">₹2000</button>
            </div>
            <button class="recharge-btn" onclick="initiatePayment()">
                <span id="rechargeText">Recharge Now</span>
            </button>
        </div>

        <div class="card recharge-history">
           <h3 class="history-title"><i class="fas fa-history"></i> Payment History</h3>
            <ul id="historyList">
                <!-- History items will be dynamically loaded here -->
            </ul>
        </div>
    </div>


<div class="bottom-nav">  
    <div class="nav-container">  
        <a href="index.php" class="nav-item"><i class="fas fa-home"></i><div class="nav-text">Home</div></a>  
        <a href="invite.php" class="nav-item"><i class="fas fa-users"></i><div class="nav-text">Invite</div></a>  
        <a href="recharge.php" class="nav-item active"><i class="fas fa-credit-card"></i><div class="nav-text">Recharge</div></a>  
        <a href="profile.php" class="nav-item"><i class="fas fa-user"></i><div class="nav-text">My</div></a>  
    </div>  
</div>  

    <script>
        // Global variables
        let currentBalance = 0;
        let isLoading = false;

        // Set amount function with improved error handling
        function setAmount(amount, event = null) {
    if (isLoading) return;
    
    const amountInput = document.getElementById('amountInput');
    amountInput.value = amount;

    // Remove 'selected' class from all quick amount buttons
    document.querySelectorAll('.quick-amount-btn').forEach(btn => {
        btn.classList.remove('selected');
    });

    // Add 'selected' class to clicked button
    if (event && event.target) {
        event.target.classList.add('selected');
    }

    // Add visual feedback
    amountInput.focus();
    amountInput.style.transform = 'scale(1.02)';
    setTimeout(() => {
        amountInput.style.transform = 'scale(1)';
    }, 200);
}
        // Improved payment initiation with better error handling
        async function initiatePayment() {
            if (isLoading) return;
            
            const amount = document.getElementById('amountInput').value;
            const rechargeBtn = document.querySelector('.recharge-btn');
            const rechargeText = document.getElementById('rechargeText');
            
            // Validation
            if (!amount || isNaN(amount) ) {
                showAlert('Please enter a valid amount.', 'error');
                return;
            }
            
            if (amount < 500) {
                showAlert('Minimum recharge amount is ₹500.', 'error');
                return;
            }
            
            if (amount > 100000) {
                showAlert('Maximum recharge amount is ₹100,000.', 'error');
                return;
            }
            
            // Set loading state
            isLoading = true;
            rechargeText.innerHTML = '<span class="loading"></span> Processing...';
            rechargeBtn.disabled = true;
            
            try {
                const response = await fetch('create_order', {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({ amount: parseFloat(amount) })
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                
                const orderData = await response.json();
                
                if (!orderData || !orderData.id) {
                    throw new Error(orderData.error || 'Order creation failed');
                }
                
                // Initialize Razorpay
                const options = {
                    key: "rzp_live_AAPAIOOECx1xqK", // Replace with your actual key
                    amount: orderData.amount,
                    currency: "INR",
                    name: "StayZan",
                    description: "Recharge Transaction in Stayzan",
                    order_id: orderData.id,
                    handler: function (response) {
                  waitForRechargeSuccess(currentBalance);
                    },
                    
                    prefill: {
                        name: "User" 
                    },
                    theme: { 
                        color: "#667eea",
                        backdrop_color: "rgba(0,0,0,0.5)"
                    },
                    modal: {
                        ondismiss: function() {
                            resetRechargeButton();
                        }
                    }
                };
                
                const rzp = new Razorpay(options);
                
                rzp.on('payment.failed', function (response) {
                    console.error('Payment failed:', response.error);
                    showAlert(`Payment Failed: ${response.error.description}`, 'error');
                    resetRechargeButton();
                });
                
                rzp.open();
                
            } catch (error) {
                console.error("Payment initiation error:", error);
                showAlert("Connection error. Please try again.", 'error');
                resetRechargeButton();
            }
        }


    
        // Reset recharge button state
        function resetRechargeButton() {
            isLoading = false;
            const rechargeBtn = document.querySelector('.recharge-btn');
            const rechargeText = document.getElementById('rechargeText');
            rechargeText.textContent = 'Recharge Now';
            rechargeBtn.disabled = false;
        }


        // Improved data loading with better error handling
        async function loadRechargeData() {
            try {
                const response = await fetch("recharge_history.php", {
                    method: 'GET',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                
                if (data.error) {
                    throw new Error(data.error);
                }
                
                // Update balance
                currentBalance = parseFloat(data.balance) || 0;
                document.getElementById("currentBalance").textContent = currentBalance.toFixed(2);
                
                // Update history
                updateHistoryDisplay(data.history || []);
                
            } catch (error) {
                console.error("Data loading failed:", error);
                
                // Show sample data if server request fails
                const sampleData = [
                    { amount: 200, updated_at: '2025-07-28 14:45:00', status: 'success' },
                    { amount: 500, updated_at: '2025-07-27 09:10:00', status: 'pending' },
                    { amount: 100, updated_at: '2025-07-25 17:30:00', status: 'failed' }
                ];
                updateHistoryDisplay(sampleData);
                
                showAlert("Could not load data from server. Showing sample data.", 'warning');
            }
        }

// ✅ इस पूरे फंक्शन को नए वाले से बदलें
function updateHistoryDisplay(historyData) {
    const historyList = document.getElementById("historyList");
    historyList.innerHTML = "";
    
    if (!historyData || historyData.length === 0) {
        historyList.innerHTML = '<li class="no-history"><i class="fas fa-folder-open"></i>No transactions yet.</li>';
        return;
    }
    
    historyData.forEach((item, index) => {
        const li = document.createElement("li");
        li.className = "accordion-item";
        
        const status = item.status.toLowerCase();
        const statusClass = `status-${status}`;
        
        let iconClass = 'fa-check-circle'; // Success
        if (status === 'pending') iconClass = 'fa-hourglass-half';
        else if (status === 'failed') iconClass = 'fa-times-circle';

        const date = new Date(item.updated_at);
        const formattedDate = date.toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
        
        const transactionId = item.id || `TXN${Date.now()}${index}`;

        const complaintButtonHTML = (status === 'pending' || status === 'failed') 
            ? `<button class="complaint-btn" onclick="fileComplaint('${transactionId}')"><i class="fas fa-exclamation-triangle"></i> Report Issue</button>` 
            : '';

        li.innerHTML = `
            <div class="accordion-header" onclick="toggleAccordion(this)">
                <div class="header-left">
                    <i class="fas ${iconClass} header-icon ${statusClass}"></i>
                    <span class="header-amount">₹${parseFloat(item.amount).toFixed(2)}</span>
                </div>
                <div class="header-right">
                    <span class="header-date">${formattedDate}</span>
                    <i class="fas fa-chevron-down expand-icon"></i>
                </div>
            </div>
            <div class="accordion-content">
                <div class="content-inner">
                    <div class="detail-row">
                        <strong>Transaction ID:</strong>
                        <span>
                            ${transactionId}
                            <button class="copy-btn" title="Copy ID" onclick="copyToClipboard('${transactionId}')"><i class="far fa-copy"></i></button>
                        </span>
                    </div>
                    <div class="detail-row">
                        <strong>Status:</strong>
                        <span class="detail-status ${statusClass}">${item.status}</span>
                    </div>
                    ${complaintButtonHTML ? `<div class="complaint-wrapper">${complaintButtonHTML}</div>` : ''}
                </div>
            </div>
        `;
        
        historyList.appendChild(li);
    });
}


// ✅ यह नया फंक्शन स्क्रिप्ट में कहीं भी जोड़ें
function toggleAccordion(element) {
    const item = element.parentElement;
    const content = element.nextElementSibling;
    const icon = element.querySelector('.expand-icon');

    if (item.classList.contains('active')) {
        item.classList.remove('active');
        icon.style.transform = 'rotate(0deg)';
        content.style.maxHeight = null;
    } else {
        // Optional: Close other active accordions
        document.querySelectorAll('.accordion-item.active').forEach(activeItem => {
            activeItem.classList.remove('active');
            activeItem.querySelector('.expand-icon').style.transform = 'rotate(0deg)';
            activeItem.querySelector('.accordion-content').style.maxHeight = null;
        });

        item.classList.add('active');
        icon.style.transform = 'rotate(180deg)';
        content.style.maxHeight = content.scrollHeight + "px";
    }
}

function fileComplaint(transactionId) {
    showAlert(`Filing complaint for Transaction ID: ${transactionId}`, 'info');

}

// ✅ यह नया हेल्पर फंक्शन जोड़ें
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showAlert('Transaction ID copied!', 'success');
    }).catch(err => {
        showAlert('Failed to copy ID.', 'error');
    });
}
        // Get localized status text
        function getStatusText(status) {
            const statusMap = {
                'success': 'Success',
                'pending': 'Pending',
                'failed': 'Failed'
            };
            return statusMap[status.toLowerCase()] || status;
        }

        // File complaint function
        function fileComplaint(transactionId) {
            showAlert(`Filing complaint for Transaction ID ${transactionId}...`, 'info');
            // Add your complaint filing logic here
        }

        // Improved alert system
        function showAlert(message, type = 'info') {
            // Remove existing alerts
            const existingAlert = document.querySelector('.custom-alert');
            if (existingAlert) {
                existingAlert.remove();
            }
            
            const alert = document.createElement('div');
            alert.className = `custom-alert alert-${type}`;
            alert.innerHTML = `
                <div class="alert-content">
                    <span class="alert-icon">${getAlertIcon(type)}</span>
                    <span class="alert-message">${message}</span>
                    <button class="alert-close" onclick="this.parentElement.parentElement.remove()">×</button>
                </div>
            `;
            
            // Add alert styles
            alert.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 10000;
                background: white;
                border-radius: 10px;
                box-shadow: 0 8px 32px rgba(0,0,0,0.2);
                padding: 15px 20px;
                max-width: 90%;
                animation: slideDown 0.3s ease;
            `;
            
            document.body.appendChild(alert);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (alert.parentElement) {
                    alert.remove();
                }
            }, 5000);
        }

        // Get alert icon based on type
        function getAlertIcon(type) {
            const icons = {
                'success': '✅',
                'error': '❌',
                'warning': '⚠️',
                'info': 'ℹ️'
            };
            return icons[type] || 'ℹ️';
        }

        // Add CSS for alerts
        const alertStyles = document.createElement('style');
        alertStyles.textContent = `
            @keyframes slideDown {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }
            
            .custom-alert .alert-content {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .alert-close {
                background: none;
                border: none;
                font-size: 20px;
                cursor: pointer;
                color: #666;
                margin-left: auto;
            }
            
            .alert-success { border-left: 4px solid #28a745; }
            .alert-error { border-left: 4px solid #dc3545; }
            .alert-warning { border-left: 4px solid #ffc107; }
            .alert-info { border-left: 4px solid #17a2b8; }
        `;
        document.head.appendChild(alertStyles);

        // Initialize on page load
        window.addEventListener('load', function() {
            loadRechargeData();
            
// Add input validation  
        const amountInput = document.getElementById('amountInput');  
        amountInput.addEventListener('input', function() {  
            const value = parseFloat(this.value);  
            if (value > 100000) {  
                this.value = 100000;  
                showAlert('Maximum recharge amount is ₹100,000.', 'warning');  
            }  
        });


            
            // Add keyboard support for quick amounts
            document.addEventListener('keydown', function(e) {
                if (e.key >= '1' && e.key <= '4' && e.ctrlKey) {
                    const amounts = [350, 500, 1000, 2000];
                    const index = parseInt(e.key) - 1;
                    if (amounts[index]) {
                        setAmount(amounts[index]);
                    }
                }
            });
        });

        // Add service worker for offline support (optional)
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
                // Register service worker if available
            });
        }
    </script>
</body>
</html>
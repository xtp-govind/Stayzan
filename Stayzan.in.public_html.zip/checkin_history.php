<?php
session_start();

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$unique_id = $_SESSION['unique_id'] ?? null;
if (!$unique_id) {
    echo json_encode(['error' => 'User not logged in']);
    exit;
}

// ✅ Get user's check-in status
$stmt = $conn->prepare("SELECT current_day, last_checkin_date, streak_count FROM user_checkin_status WHERE unique_id = ?");
$stmt->bind_param("s", $unique_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $current_day = (int)$row['current_day'];
    $last_checkin_date = $row['last_checkin_date'];
    $streak_count = (int)$row['streak_count'];
    
    // ✅ Check if user missed 3+ days (reset logic)
    $today = date('Y-m-d');
    $days_since_last_checkin = 0;
    
    if ($last_checkin_date) {
        $last_date = new DateTime($last_checkin_date);
        $current_date = new DateTime($today);
        $days_since_last_checkin = $current_date->diff($last_date)->days;
    }
    
    // ✅ Reset if 3+ days missed
    if ($days_since_last_checkin >= 3) {
        $current_day = 1;
        $streak_count = 0;
        
        // Update database
        $update_stmt = $conn->prepare("UPDATE user_checkin_status SET current_day = 1, streak_count = 0 WHERE unique_id = ?");
        $update_stmt->bind_param("s", $unique_id);
        $update_stmt->execute();
    }
    
    // ✅ Check if today is already claimed
    $today_claimed = false;
    $check_today = $conn->prepare("SELECT id FROM daily_checkins WHERE unique_id = ? AND checkin_date = ?");
    $check_today->bind_param("ss", $unique_id, $today);
    $check_today->execute();
    if ($check_today->get_result()->num_rows > 0) {
        $today_claimed = true;
    }
    
    echo json_encode([
        'current_day' => $current_day,
        'streak_count' => $streak_count,
        'today_claimed' => $today_claimed,
        'days_since_last_checkin' => $days_since_last_checkin,
        'last_checkin_date' => $last_checkin_date
    ]);
    
} else {
    // ✅ First time user - initialize
    $insert_stmt = $conn->prepare("INSERT INTO user_checkin_status (unique_id, current_day, streak_count, last_checkin_date) VALUES (?, 1, 0, NULL)");
    $insert_stmt->bind_param("s", $unique_id);
    $insert_stmt->execute();
    
    echo json_encode([
        'current_day' => 1,
        'streak_count' => 0,
        'today_claimed' => false,
        'days_since_last_checkin' => 0,
        'last_checkin_date' => null
    ]);
}
?>
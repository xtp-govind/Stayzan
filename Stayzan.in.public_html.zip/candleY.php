<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
    <title>CandleX Trading</title>

    <script src="https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.1/dist/lightweight-charts.standalone.production.js"></script>
    <script src="https://unpkg.com/lightweight-charts-drawing-tools/dist/lightweight-charts-drawing-tools.standalone.production.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        :root {
            --bg-primary: #131722;
            --bg-secondary: #1e222d;
            --text-primary: #d1d4dc;
            --text-secondary: #8a8e97;
            --color-green: #26a69a;
            --color-red: #ef5350;
            --color-yellow: #f0b90b;
        }
        
        body {
            margin: 0;
            padding: 0;
            background: var(--bg-primary);
            color: var(--text-primary);
            font-family: 'Poppins', sans-serif;
        }

        /* --- Top Bar --- */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            background-color: var(--bg-secondary);
        }
        .top-bar .icon { font-size: 24px; cursor: pointer; }
        .top-bar .title { font-size: 18px; font-weight: 600; }

        /* --- Balance and Time Info --- */
        .account-info {
            display: flex;
            justify-content: space-around;
            padding: 5px 15px 5px 15px;
            background: var(--bg-secondary);
            border-top: 1px solid #333;
        }
        .info-item {
            text-align: center;
        }
        .info-item .label {
            font-size: 12px;
            color: var(--text-secondary);
            margin-bottom: 4px;
        }
        .info-item .value {
            font-size: 15px;
            font-weight: 600;
        }
        #total-balance-value {
            color: var(--color-yellow);
        }

        /* --- Chart --- */
        #chart-container {
            width: 100%;
            height: 45vh; /* Chart height */
            position: relative; /* Important for tooltip positioning */
        }
        #chart { width: 100%; height: 100%; }

        /* --- Tooltip Styling --- */
        #tooltip {
            position: absolute;
            display: none;
            padding: 8px;
            background-color: rgba(30, 34, 45, 0.9);
            border: 1px solid var(--text-secondary);
            border-radius: 8px;
            font-size: 12px;
            color: var(--text-primary);
            pointer-events: none; /* So it doesn't interfere with chart events */
            z-index: 1000;
            width: 150px;
        }
        .tooltip-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
        }
        .tooltip-label { color: var(--text-secondary); }
        .tooltip-value { font-weight: 600; }

        /* --- Controls Area --- */
        .controls-area {
            background: var(--bg-secondary);
            padding: 20px 15px;
            margin-top: 10px;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }
        
        .control-label {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 10px;
            text-align: center;
        }

        .bet-amount-control {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 8px;
            margin-bottom: 20px;
        }
        .amount-btn {
            background: var(--bg-secondary);
            border: none;
            color: var(--text-primary);
            font-size: 24px;
            font-weight: 600;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            cursor: pointer;
        }

/* UPDATED: Styles for both span and input */
#bet-amount, #bet-amount-input {
    font-size: 22px;
    font-weight: 700;
    color: var(--color-yellow);
    background: transparent;
    border: none;
    text-align: center;
    outline: none;
    width: 100px; /* इसे थोड़ी चौड़ाई दें ताकि यह छोटा न हो जाए */
    padding: 0; /* अतिरिक्त पैडिंग हटा दें */
    margin: 0; /* अतिरिक्त मार्जिन हटा दें */
    font-family: 'Poppins', sans-serif; /* फॉन्ट को भी समान रखें */
}

/* Hide the input by default */
#bet-amount-input {
    display: none;
}

/* Optional: Hide the number input spinners in Chrome/Safari/Edge */
#bet-amount-input::-webkit-outer-spin-button,
#bet-amount-input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

/* Optional: Hide the number input spinners in Firefox */
#bet-amount-input[type=number] {
    -moz-appearance: textfield;
}

       

        .trade-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .trade-btn {
            padding: 18px;
            font-size: 20px;
            font-weight: 700;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .trade-btn:disabled { opacity: 0.7; cursor: not-allowed; }
        .up { background-color: var(--color-green); color: white; }
        .down { background-color: var(--color-red); color: white; }
        
/* --- Timeframe Bar Styling --- */
.timeframe-bar {
    display: flex;
    justify-content: space-around;
    padding: 8px 15px;
    background-color: var(--bg-primary);
    border-bottom: 1px solid #333;
}
.time-btn {
    background: transparent;
    border: 1px solid var(--text-secondary);
    color: var(--text-secondary);
    font-size: 14px;
    font-weight: 500;
    padding: 5px 15px;
    border-radius: 15px;
    cursor: pointer;
    transition: all 0.2s ease;
}
.time-btn.active {
    background-color: var(--color-yellow);
    color: var(--bg-primary);
    border-color: var(--color-yellow);
    font-weight: 700;
}

/* --- Asset Bar Styling (Timeframe Bar जैसा) --- */
.asset-btn {
    background: transparent;
    border: 1px solid var(--text-secondary);
    color: var(--text-secondary);
    font-size: 14px;
    font-weight: 500;
    padding: 5px 15px;
    border-radius: 15px;
    cursor: pointer;
    transition: all 0.2s ease;
}
.asset-btn.active {
    background-color: var(--color-yellow);
    color: var(--bg-primary);
    border-color: var(--color-yellow);
    font-weight: 700;
}

/* --- Pulsating Area Effect --- */
.pulsating-area {
    position: absolute;
    width: 100%; /* पूरे चार्ट की चौड़ाई लेगा */
    left: 0;
    z-index: 1; /* चार्ट के ऊपर, लेकिन लाइन के पीछे */
    opacity: 0;
    transition: opacity 0.5s ease;
    animation: pulse 1.5s infinite;
}

.pulsating-area.up {
    background: linear-gradient(to top, rgba(38, 166, 154, 0.2), rgba(38, 166, 154, 0));
    border-top: 1px solid rgba(38, 166, 154, 0.5);
}

.pulsating-area.down {
    background: linear-gradient(to bottom, rgba(239, 83, 80, 0.2), rgba(239, 83, 80, 0));
    border-bottom: 1px solid rgba(239, 83, 80, 0.5);
}

/* चमकने का एनिमेशन */
@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.01); }
    100% { transform: scale(1); }
}

/* --- History Button --- */
.history-button-container {
    margin-top: 15px;
    text-align: center;
}
.history-btn {
    background: transparent;
    border: 1px solid var(--text-secondary);
    color: var(--text-secondary);
    padding: 10px 25px;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
}
.history-btn:hover {
    background: var(--text-secondary);
    color: var(--bg-primary);
}
.history-btn i {
    margin-right: 8px;
}

/* === NEW & IMPROVED MODAL & HISTORY STYLING === */

.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 100;
    display: none; /* <<--- FIX 1: Start with display: none */
    justify-content: center;
    align-items: flex-end;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.modal-overlay.show {
    display: flex; /* <<--- FIX 2: Use flex when .show is added */
    opacity: 1;
    pointer-events: auto;
}

.modal-content {
    background: var(--bg-secondary);
    width: 100%;
    max-width: 500px; /* Max width on larger screens */
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
    box-shadow: 0 -5px 25px rgba(0,0,0,0.3);
    display: flex;
    flex-direction: column;
    max-height: 70vh; /* Max height */
    transform: translateY(100%); /* Initially off-screen */
    transition: transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.modal-overlay.show .modal-content {
    transform: translateY(0); /* Slide in */
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    border-bottom: 1px solid var(--bg-primary);
    flex-shrink: 0; /* Header should not shrink */
}
.modal-header h2 { margin: 0; font-size: 18px; }
.close-btn { background: none; border: none; color: var(--text-primary); font-size: 28px; cursor: pointer; }

.modal-body {
    padding: 15px;
    overflow-y: auto;
    background-color: var(--bg-primary);
}
.no-history { text-align: center; color: var(--text-secondary); padding: 20px 0; }

/* --- New History Card --- */
.history-item {
    background: var(--bg-secondary);
    border-radius: 12px;
    margin-bottom: 15px;
    overflow: hidden; /* To contain the top part */
}
.history-item:last-child { margin-bottom: 0; }

.history-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 15px;
    background-color: rgba(0,0,0,0.2);
}

.history-top-left {
    display: flex;
    align-items: center;
    gap: 10px;
}

.history-direction-icon {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    font-size: 16px;
}
.history-direction-icon.up { background-color: var(--color-green); color: white; }
.history-direction-icon.down { background-color: var(--color-red); color: white; }

.history-timeframe {
    font-size: 14px;
    font-weight: 600;
}

.history-result {
    font-size: 18px;
    font-weight: 700;
}
.history-result.win { color: var(--color-green); }
.history-result.loss { color: var(--color-red); }

.history-bottom {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr; /* 3 columns */
    gap: 15px;
    padding: 15px;
}

.detail-item {
    display: flex;
    flex-direction: column;
}
.detail-item .label {
    font-size: 11px;
    color: var(--text-secondary);
    margin-bottom: 3px;
    display: flex;
    align-items: center;
    gap: 4px;
}
.detail-item .value { font-weight: 600; font-size: 13px; }

/* --- New Icon Controls Bar --- */
.controls-area {
    position: relative; /* यह लाइन ज़रूरी है */
}
.icon-controls-bar {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
    padding: 5px;
    background-color: var(--bg-primary);
    border-radius: 12px;
}
.icon-btn {
    background: transparent;
    border: none;
    color: var(--text-secondary);
    font-size: 20px;
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
}
.icon-btn:hover {
    color: var(--text-primary);
    background-color: var(--bg-secondary);
}
.icon-btn.active {
    color: var(--color-yellow);
}
.separator {
    width: 1px;
    height: 20px;
    background-color: #444;
}

/* === यह नया, लेफ्ट-साइड वाला कोड है === */
.indicator-menu {
    position: absolute;
    bottom: calc(100% - 73px); 
    left: 5px; 
    
    background: var(--bg-secondary);
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4);
    z-index: 50;
    width: 270px;
    opacity: 0;
    transform: translateY(10px);
    pointer-events: none;
    transition: opacity 0.2s ease, transform 0.2s ease;
}

.indicator-menu.show {
    opacity: 1;
    transform: translateY(0); /* अपनी जगह पर आएगा */
    pointer-events: auto;
}

/* --- Indicator Item (With Icon) --- */
.indicator-item {
    display: grid;
    /* लेआउट: आइकन (छोटा), नाम (बड़ा), टॉगल (छोटा) */
    grid-template-columns: 30px 1fr auto; 
    align-items: center;
    gap: 10px; /* आइटम्स के बीच गैप */
    padding: 12px 10px;
    font-size: 14px;
    cursor: pointer;
    border-bottom: 1px solid var(--bg-primary);
}
.indicator-item:last-child {
    border-bottom: none;
}
.indicator-item:hover {
    background-color: var(--bg-primary);
}

/* आइकन के लिए स्टाइल */
.indicator-icon {
    font-size: 16px;
    text-align: center;
}


/* --- Toggle Switch for Indicators --- */
.toggle-switch {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 22px;
}
.toggle-switch input { display: none; }
.toggle-switch label {
    position: absolute;
    cursor: pointer;
    top: 0; left: 0; right: 0; bottom: 0;
    background-color: var(--bg-primary);
    border-radius: 22px;
    transition: .4s;
}
.toggle-switch label:before {
    position: absolute;
    content: "";
    height: 16px;
    width: 16px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    border-radius: 50%;
    transition: .4s;
}
.toggle-switch input:checked + label {
    background-color: var(--color-green);
}
.toggle-switch input:checked + label:before {
    transform: translateX(18px);
}

/* पुरानी .main-controls-grid और उससे जुड़ी स्टाइल हटाकर यह नई CSS डालें */

/* === New Split Controls Layout === */
.split-controls-container {
    display: flex; /* फ्लेक्सबॉक्स का उपयोग करें */
    gap: 15px; /* दोनों कॉलम के बीच गैप */
    margin-top: 15px;
    margin-bottom: 20px;
}

.control-column {
    display: flex;
    flex-direction: column;
    gap: 15px;
    width: 50%; /* हर कॉलम को 50% चौड़ाई दें */
}

/* --- बेट अमाउंट कंट्रोल --- */
.bet-amount-control {
    margin-bottom: 0;
    height: 55px; /* हाइट सेट करें */
}

/* --- नया स्प्लिट बटन कंटेनर --- */
.split-button-container {
    display: flex;
    height: 55px; /* हाइट सेट करें */
}

.split-btn {
    background: var(--bg-primary);
    border: 1px solid var(--text-secondary);
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-weight: 600;
}
.split-btn:hover {
    border-color: var(--text-primary);
    color: var(--text-primary);
}

/* स्प्लिट बटन का मुख्य हिस्सा */
.split-btn.main {
    flex-grow: 1; /* यह बची हुई सारी जगह ले लेगा */
    border-radius: 12px 0 0 12px; /* बाएं कोने गोल */
    font-size: 16px;
}
.split-btn.main.active {
    border-color: var(--color-yellow);
    color: var(--color-yellow);
    background: rgba(240, 185, 11, 0.1);
}

/* स्प्लिट बटन का छोटा हिस्सा (सेटिंग्स) */
.split-btn.trigger {
    width: 55px; /* चौड़ाई सेट करें */
    border-left: none; /* बीच की लाइन बनाने के लिए */
    border-radius: 0 12px 12px 0; /* दाएं कोने गोल */
    font-size: 20px;
}

/* --- राइट साइड के ट्रेड बटन --- */
.control-column.right .trade-btn {
    flex-grow: 1; /* यह पूरी उपलब्ध हाइट ले लेंगे */
    font-size: 20px;
    font-weight: 700;
    border: none;
    border-radius: 12px;
}
.trade-btn.up { background-color: var(--color-green); color: white; }
.trade-btn.down { background-color: var(--color-red); color: white; }
.trade-btn:disabled { opacity: 0.7; cursor: not-allowed; }

/* === नया नोटिफिकेशन पैनल स्टाइल === */

.app-message {
    position: fixed;
    top: 15px; /* स्क्रीन के टॉप से थोड़ा नीचे */
    left: 50%;
    transform: translateX(-50%);
    width: auto; /* कंटेंट के हिसाब से चौड़ाई */
    max-width: 90%; /* बहुत ज्यादा चौड़ा न हो */
    padding: 12px 20px;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 600;
    text-align: left;
    box-shadow: 0 5px 15px rgba(0,0,0,0.15);
    z-index: 9999;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideInDown 0.4s ease-out;
    border-left: 5px solid; /* साइड में एक मोटी बॉर्डर */
}

/* विभिन्न प्रकारों के लिए रंग */
.app-message.win {
    background: #e6f4ea;
    color: #2e7d32;
    border-color: #2e7d32;
}

.app-message.loss {
    background: #ffe5e7;
    color: #d32f2f;
    border-color: #d32f2f;
}

.app-message.warning {
    background: #fff4e5;
    color: #ef6c00;
    border-color: #ef6c00;
}

.app-message.info {
    background: #e3f2fd;
    color: #1565c0;
    border-color: #1565c0;
}

/* आइकन के लिए स्टाइल */
.app-message::before {
    font-family: "Font Awesome 6 Free"; /* Font Awesome का उपयोग करें */
    font-weight: 900; /* Solid आइकन के लिए */
    font-size: 18px;
}

.app-message.win::before { content: "\f058"; } /* fa-check-circle */
.app-message.loss::before { content: "\f057"; } /* fa-times-circle */
.app-message.warning::before { content: "\f071"; } /* fa-exclamation-triangle */
.app-message.info::before { content: "\f05a"; } /* fa-info-circle */


/* एनीमेशन */
@keyframes slideInDown {
    from {
        opacity: 0;
        transform: translate(-50%, -20px);
    }
    to {
        opacity: 1;
        transform: translate(-50%, 0);
    }
}


    </style>
</head>
<body>

<div class="top-bar">
    <div class="icon" onclick="alert('Back button clicked!')">
        <i class="fa-solid fa-arrow-left"></i>
    </div>
    <div class="title">CandleX</div>
    <div class="icon" onclick="alert('Help button clicked!')">
        <i class="fa-solid fa-circle-question"></i>
    </div>
</div>

<!-- === बदला हुआ Account Info सेक्शन === -->
<div class="account-info">
    <!-- 1. ग्राफ़ चुनने का बटन (Timeframe जैसा) -->
    <div class="info-item" id="asset-selector-button" style="cursor: pointer;">
        <div class="label">Asset</div>
        <div class="value" id="asset-display">Lee <i class="fa-solid fa-chevron-down" style="font-size: 10px;"></i></div>
    </div>

    <!-- 2. टाइमफ्रेम सेलेक्टर (यह वैसा ही है) -->
    <div class="info-item" id="timeframe-selector" style="cursor: pointer;">
         <div class="label">Timeframe</div>
         <div class="value" id="timeframe-display">30s <i class="fa-solid fa-chevron-down" style="font-size: 10px;"></i></div>
    </div>
    
        <div class="info-item">
            <div class="label">Total Balance</div>
            <div class="value">₹<span id="total-balance-value">10000.00</span></div>
        </div>

</div>

<!-- === नया ASSET SELECTION BAR (Initially Hidden) === -->
<div class="timeframe-bar" id="asset-bar" style="display: none;">
    <button class="asset-btn active" data-asset="Lee">Lee</button>
    <button class="asset-btn" data-asset="BTB">BTB</button>
    <button class="asset-btn" data-asset="RAa">RAa</button>
    <button class="asset-btn" data-asset="Gol">Gol</button>
    <button class="asset-btn" data-asset="Oxl">Oxl</button>
</div>
    
<!-- === TIMEFRAME SELECTION BAR (यह पहले से है) === -->
<div class="timeframe-bar" id="timeframe-bar" style="display: none;">
    <button class="time-btn active" data-time="30" data-label="30s">30s</button>
    <button class="time-btn" data-time="45" data-label="45s">45s</button>
    <button class="time-btn" data-time="60" data-label="1m">1m</button>
    <button class="time-btn" data-time="120" data-label="2m">2m</button>
    <button class="time-btn" data-time="180" data-label="3m">3m</button>
</div>

<div id="chart-container">
    <div id="chart"></div>
    <div id="pulsating-area" class="pulsating-area"></div>
    <div id="tooltip"></div>
</div>




<div class="controls-area">
    
    <div class="icon-controls-bar">
        <button class="icon-btn active" id="candle-chart-btn" title="Candlestick Chart"><i class="fa-solid fa-chart-column"></i></button>
        <button class="icon-btn" id="bar-chart-btn" title="Bar Chart"><i class="fa-solid fa-chart-bar"></i></button>
        <button class="icon-btn" id="line-chart-btn" title="Line Chart"><i class="fa-solid fa-chart-line"></i></button>
        <button class="icon-btn" id="area-chart-btn" title="Area Chart"><i class="fa-solid fa-chart-area"></i></button>
        <div class="separator"></div>
        <button class="icon-btn" id="indicator-btn" title="Indicators"><i class="fa-solid fa-wave-square"></i></button>
    </div>

<div class="split-controls-container">
        
        <!-- लेफ्ट साइड -->
        <div class="control-column left">
            <!-- अमाउंट इनपुट -->
            <div class="bet-amount-control">
                <button class="amount-btn" id="decrease-bet">-</button>
                <span id="bet-amount" style="cursor: pointer;">₹100</span>
                <input type="number" id="bet-amount-input" style="display: none;" />
                <button class="amount-btn" id="increase-bet">+</button>
            </div>
            
            <!-- ऑटो-बेट का स्प्लिट बटन -->
            <div class="split-button-container">
                <button class="split-btn main" id="auto-bet-button">
                    <i class="fa-solid fa-robot"></i> Auto Bet
                </button>
                <button class="split-btn trigger" id="auto-bet-settings-btn" title="Auto Bet Settings">
                    <i class="fa-solid fa-sliders"></i>
                </button>
            </div>
        </div>

        <!-- राइट साइड -->
        <div class="control-column right">
            <!-- Up और Down बटन -->
            <button class="trade-btn up" id="up-button">▲ Up</button>
            <button class="trade-btn down" id="down-button">▼ Down</button>
        </div>

    </div>


<!-- पुराने .indicator-menu को इस नए कोड से पूरी तरह बदल दें -->


    <div class="history-button-container">
        <button class="history-btn" id="history-button">
            <i class="fa-solid fa-clock-rotate-left"></i> History
        </button>
    </div>
    
<!-- पुराने .indicator-menu को इस नए कोड से पूरी तरह बदल दें -->
<div class="indicator-menu" id="indicator-menu">
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #FFC300;"><i class="fa-solid fa-chart-line"></i></span>
        <span>Moving Average (20)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="ma-toggle">
            <label for="ma-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #2980B9;"><i class="fa-solid fa-ellipsis-h"></i></span>
        <span>Bollinger Bands (20, 2)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="bb-toggle">
            <label for="bb-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #95A5A6;"><i class="fa-solid fa-chart-bar"></i></span>
        <span>Volume</span>
        <div class="toggle-switch">
            <input type="checkbox" id="volume-toggle">
            <label for="volume-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #E91E63;"><i class="fa-solid fa-heart-pulse"></i></span>
        <span>RSI (14)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="rsi-toggle">
            <label for="rsi-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #8E44AD;"><i class="fa-solid fa-shuffle"></i></span>
        <span>Stochastic (14, 3, 3)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="stoch-toggle">
            <label for="stoch-toggle"></label>
        </div>
    </div>
    <div class="indicator-item">
        <!-- नया आइकन -->
        <span class="indicator-icon" style="color: #1ABC9C;"><i class="fa-solid fa-signal"></i></span>
        <span>MACD (12, 26, 9)</span>
        <div class="toggle-switch">
            <input type="checkbox" id="macd-toggle">
            <label for="macd-toggle"></label>
        </div>
    </div>
</div>

</div>  
    
<!-- === HISTORY PANEL (MODAL) === -->
<div class="modal-overlay" id="history-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Trade History</h2>
            <button class="close-btn" id="close-history-btn">&times;</button>
        </div>
        <div class="modal-body" id="history-list">
            <!-- History items will be added here by JavaScript -->
            <p class="no-history">You have no trade history yet.</p>
        </div>
    </div>
</div>

<!-- === AUTO-BET SETTINGS MODAL === -->
<div class="modal-overlay" id="auto-bet-settings-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Auto Bet Settings</h2>
            <button class="close-btn" id="close-auto-bet-settings-btn">&times;</button>
        </div>
        <div class="modal-body">
            <p style="text-align: center; color: var(--text-secondary);">
                Configure your automatic trading strategy here.
                <br>(Functionality coming soon!)
            </p>
            <!-- यहाँ भविष्य में सेटिंग्स के ऑप्शन जोड़े जाएँगे -->
        </div>
    </div>
</div>




<div class="infoX" style="display:none;">
    <div class="label">Next Candle In</div>
    <div class="value" id="candle-timer">30s</div>
</div>

<script>

// --- Chart Setup ---

const maToggle = document.getElementById('ma-toggle');  
const bbToggle = document.getElementById('bb-toggle');  
const volumeToggle = document.getElementById('volume-toggle');  
const rsiToggle = document.getElementById('rsi-toggle');  
const stochToggle = document.getElementById('stoch-toggle');  
const macdToggle = document.getElementById('macd-toggle');  
  
// --- Indicator Series ---  
let maSeries = null;  
let bbUpperSeries = null, bbMiddleSeries = null, bbLowerSeries = null;  
let volumeSeries = null;  
let rsiSeries = null;  
let stochKSeries = null, stochDSeries = null;  
let macdLineSeries = null, macdSignalSeries = null, macdHistSeries = null;  
  

        const candleChartBtn = document.getElementById('candle-chart-btn');
        const barChartBtn = document.getElementById('bar-chart-btn');
        const areaChartBtn = document.getElementById('area-chart-btn');
        const lineChartBtn = document.getElementById('line-chart-btn');
        const indicatorBtn = document.getElementById('indicator-btn');
        const indicatorMenu = document.getElementById('indicator-menu');
        const pulsatingArea = document.getElementById('pulsating-area');
        const chartElement = document.getElementById('chart');
        const historyButton = document.getElementById('history-button');
        const historyModal = document.getElementById('history-modal');
        const closeHistoryBtn = document.getElementById('close-history-btn');
        const historyList = document.getElementById('history-list');
        const autoBetSettingsBtn = document.getElementById('auto-bet-settings-btn');
        const autoBetSettingsModal = document.getElementById('auto-bet-settings-modal');
        const closeAutoBetSettingsBtn = document.getElementById('close-auto-bet-settings-btn');
        
        const chart = LightweightCharts.createChart(chartElement, {
            layout: { background: { type: 'solid', color: 'transparent' }, textColor: '#d1d4dc' },
            grid: { vertLines: { color: 'rgba(255,255,255,0.1)' }, horzLines: { color: 'rgba(255,255,255,0.1)' } },
            timeScale: { timeVisible: true, secondsVisible: false, borderColor: '#485158' },
            rightPriceScale: { borderColor: '#485158' },
            crosshair: {
                horzLine: { labelVisible: false },
                vertLine: { labelVisible: false },
            },
            handleScroll: true,
            handleScale: true,
        });
        
        const timeframeSelector = document.getElementById('timeframe-selector');
        const timeframeBar = document.getElementById('timeframe-bar');
        const timeframeDisplay = document.getElementById('timeframe-display');
        const timeButtons = document.querySelectorAll('.time-btn');
        const assetSelectorButton = document.getElementById('asset-selector-button');
        const assetBar = document.getElementById('asset-bar');
        const assetDisplay = document.getElementById('asset-display');
        const assetButtons = document.querySelectorAll('.asset-btn');
        const candleTimerElement = document.getElementById('candle-timer');
        
        let activeSeries = chart.addCandlestickSeries({
            upColor: '#26a69a', downColor: '#ef5350', borderVisible: false,
            wickUpColor: '#26a69a', wickDownColor: '#ef5350',
        });
        let currentChartType = 'candle';
        
// --- 3. Initialize All Indicator Series ---
// --- MA Series (On Main Chart) --- 

maSeries = chart.addLineSeries({ color: 'rgba(255, 165, 0, 0.8)', lineWidth: 1, visible: false });  
  
// --- Bollinger Bands Series (On Main Chart) ---  
const bbLineStyle = { color: 'rgba(41, 98, 255, 0.6)', lineWidth: 1, visible: false };  
bbUpperSeries = chart.addLineSeries(bbLineStyle);  
bbMiddleSeries = chart.addLineSeries(bbLineStyle);  
bbLowerSeries = chart.addLineSeries(bbLineStyle);  
  
// --- Volume Series (Panel 1) ---  
volumeSeries = chart.addHistogramSeries({ priceScaleId: 'volume', visible: false });  
chart.priceScale('volume').applyOptions({ scaleMargins: { top: 0.85, bottom: 0 }, visible: false });  
  
// --- RSI Series (Panel 2) ---  
rsiSeries = chart.addLineSeries({ priceScaleId: 'rsi', color: '#e84393', lineWidth: 2, visible: false });  
chart.priceScale('rsi').applyOptions({ scaleMargins: { top: 0.8, bottom: 0 }, visible: false });  
  
// --- Stochastic Series (Panel 3) ---  
stochKSeries = chart.addLineSeries({ priceScaleId: 'stoch', color: '#2962FF', lineWidth: 1, visible: false });  
stochDSeries = chart.addLineSeries({ priceScaleId: 'stoch', color: '#E91E63', lineWidth: 1, visible: false });  
chart.priceScale('stoch').applyOptions({ scaleMargins: { top: 0.8, bottom: 0 }, visible: false });  
  
// --- MACD Series (Panel 4) ---  
macdHistSeries = chart.addHistogramSeries({ priceScaleId: 'macd', visible: false });  
macdLineSeries = chart.addLineSeries({ priceScaleId: 'macd', color: '#2962FF', lineWidth: 2, visible: false });  
macdSignalSeries = chart.addLineSeries({ priceScaleId: 'macd', color: '#E91E63', lineWidth: 2, visible: false });  
chart.priceScale('macd').applyOptions({ scaleMargins: { top: 0.8, bottom: 0 }, visible: false });  
  

        new ResizeObserver(entries => {
            if (entries.length > 0 && entries[0].contentRect.width > 0) {
                chart.applyOptions({ width: entries[0].contentRect.width });
            }
        }).observe(chartElement);

// --- Game State and Settings ---

let assets = {
    "Lee": { masterTime: 0, masterPrice: 150, masterPriceHistory: [] },
    "BTB": { masterTime: 0, masterPrice: 2500, masterPriceHistory: [] },
    "RAa": { masterTime: 0, masterPrice: 1800, masterPriceHistory: [] },
    "Gol": { masterTime: 0, masterPrice: 1950, masterPriceHistory: [] },
    "Oxl": { masterTime: 0, masterPrice: 80, masterPriceHistory: [] }
};

// 2. वर्तमान में कौनसा ग्राफ़ चुना गया है
let currentAssetKey = "Lee"; 

// 3. बाकी सेटिंग्स
let gameSettings = { timeframe: 30 }; // Default timeframe 30s
let tradeHistory = [];
let gameLoop = null;
let currentCandleData = null;
let countdownPriceLine = null;
let historicalCandles = []; 

// 1. MASTER PRICE ENGINE (हर सेकंड चलता है)

function masterPriceUpdate() {
    for (const key in assets) {
        const asset = assets[key];
        asset.masterTime++;
        const volatility = 0.0005;
        asset.masterPrice *= 1 + (Math.random() - 0.5) * volatility * 2;
        asset.masterPriceHistory.push({ time: asset.masterTime, price: asset.masterPrice });
        if (asset.masterPriceHistory.length > 7200) asset.masterPriceHistory.shift();
    }
    
    candleBuilder();
    updateTimer();
    
    if (isTradeActive && activeTradeLine) {
        updatePulsatingArea(activeTradeLine, activeTradeDirection);
    }
}

// 2. CANDLE BUILDER (मास्टर डेटा से कैंडल बनाता है)
let isCandleFinalized = false;
function candleBuilder() {
    const asset = assets[currentAssetKey];
    const tf = gameSettings.timeframe;

    if (isCandleFinalized) {
        isCandleFinalized = false;
        return;
    }

    if (currentCandleData) {
        currentCandleData.high = Math.max(currentCandleData.high, asset.masterPrice);
        currentCandleData.low = Math.min(currentCandleData.low, asset.masterPrice);
        currentCandleData.close = asset.masterPrice;
    }

    const updateChart = () => {
        if (!currentCandleData) return;
        
        switch (currentChartType) {
            case 'line':
            case 'area':
                activeSeries.update({ time: currentCandleData.time, value: currentCandleData.close });
                break;
            case 'candle':
            case 'bar':
            default:
                activeSeries.update(currentCandleData);
                break;
        }
    };

    if ((asset.masterTime + 1) % tf === 0) {
        updateChart();
        
        isCandleFinalized = true;
        const nextOpenPrice = currentCandleData ? currentCandleData.close : asset.masterPrice;
        currentCandleData = {
            time: asset.masterTime + 1,
            open: nextOpenPrice, high: nextOpenPrice, low: nextOpenPrice, close: nextOpenPrice,
        };
    } else {
        updateChart();
    }
    
    updateAllIndicators();
}



// 3. TIMER UI UPDATER (FINAL VERSION FOR IMAGE MATCH)

function updateTimer() {
    const asset = assets[currentAssetKey]; // <<-- वर्तमान ग्राफ़ का डेटा लें
    const secondsUntilNextCandle = gameSettings.timeframe - (asset.masterTime % gameSettings.timeframe);
    candleTimerElement.textContent = secondsUntilNextCandle + 's';

    if (countdownPriceLine) {
        activeSeries.removePriceLine(countdownPriceLine);
    }
    if (secondsUntilNextCandle < 1) return;

    const formattedTime = `00:${secondsUntilNextCandle.toString().padStart(2, '0')}`;
    countdownPriceLine = activeSeries.createPriceLine({
        price: asset.masterPrice,
        color: 'transparent',
        lineWidth: 0,
        lineStyle: LightweightCharts.LineStyle.Solid,
        axisLabelVisible: true,
        title: formattedTime,
        axisLabelColor: '#2A2E39',
        axisLabelTextColor: '#E0E3EA',
    });
}

// 8. --- NEW FUNCTION: To show live profit/loss area ---
function updatePulsatingArea(tradeLine, direction) {
    if (!isTradeActive) {
        pulsatingArea.style.opacity = '0';
        return;
    }

    const entryPrice = tradeLine.options().price;
    const currentPrice = assets[currentAssetKey].masterPrice; // <<--- यहाँ masterPrice की जगह asset.masterPrice करें
    const priceCoordinate = activeSeries.priceToCoordinate(currentPrice);
    const entryCoordinate = activeSeries.priceToCoordinate(entryPrice);


    let isWinning = (direction === 'up' && currentPrice > entryPrice) || (direction === 'down' && currentPrice < entryPrice);

    if (isWinning) {
        if (direction === 'up') {
            pulsatingArea.className = 'pulsating-area up';
            pulsatingArea.style.top = priceCoordinate + 'px';
            pulsatingArea.style.height = (entryCoordinate - priceCoordinate) + 'px';
        } else { // direction is 'down'
            pulsatingArea.className = 'pulsating-area down';
            pulsatingArea.style.top = entryCoordinate + 'px';
            pulsatingArea.style.height = (priceCoordinate - entryCoordinate) + 'px';
        }
        pulsatingArea.style.opacity = '1';
    } else {
        // अगर हार रहे हैं, तो एरिया छिपा दें
        pulsatingArea.style.opacity = '0';
    }
}

// 4. GENERATE HISTORY (चुने गए टाइम-फ्रेम के लिए पुरानी कैंडलबनाता है)

function generateHistory(timeframe) {  
    const asset = assets[currentAssetKey];  
    if (countdownPriceLine && chart) {  
        try {  
  
            const activeSeries = candleSeries || lineSeries;  
            if (activeSeries) activeSeries.removePriceLine(countdownPriceLine);  
        } catch (e) {  
        }  
    }  
    historicalCandles = [];
    let tempCandle = null;
    for (const tick of asset.masterPriceHistory) {
        const candleTime = Math.floor(tick.time / timeframe) * timeframe;
        if (!tempCandle || tempCandle.time !== candleTime) {
            if (tempCandle) historicalCandles.push(tempCandle);
            tempCandle = {
                time: candleTime, open: tick.price, high: tick.price,
                low: tick.price, close: tick.price,
            };
        }
        tempCandle.high = Math.max(tempCandle.high, tick.price);
        tempCandle.low = Math.min(tempCandle.low, tick.price);
        tempCandle.close = tick.price;
    }
    if (tempCandle) historicalCandles.push(tempCandle);
    
  switch (currentChartType) {
    case 'line':
    case 'area':
        const lineData = historicalCandles.map(c => ({ time: c.time, value: c.close }));
        activeSeries.setData(lineData);
        break;
    case 'candle':
    case 'bar':
    default:
        activeSeries.setData(historicalCandles);
        break;
}

    updateAllIndicators();
    currentCandleData = historicalCandles.length ? historicalCandles[historicalCandles.length - 1] : null;
    const totalCandles = historicalCandles.length;
    if (totalCandles === 0) return;
    const candlesIn10Minutes = (10 * 60) / timeframe;
    const candlesToShow = Math.max(30, candlesIn10Minutes);
    const startIndex = Math.max(0, totalCandles - candlesToShow);
    chart.timeScale().setVisibleLogicalRange({
        from: startIndex,
        to: totalCandles,
    });
}

        // --- Betting and Balance Logic ---
        const balanceElement = document.getElementById('total-balance-value');
        const betAmountElement = document.getElementById('bet-amount');
        const betAmountInput = document.getElementById('bet-amount-input');
        const decreaseBetBtn = document.getElementById('decrease-bet');
        const increaseBetBtn = document.getElementById('increase-bet');
        const upButton = document.getElementById('up-button');
        const downButton = document.getElementById('down-button');

        const toastElement = document.getElementById('toast');

        let totalBalance = 10000.00;
        let currentBet = 100;
        const betStep = 50;
        let isTradeActive = false;

        function updateUI() {
            balanceElement.textContent = totalBalance.toFixed(2);
            betAmountElement.textContent = '₹' + currentBet.toFixed(0);
        }

        increaseBetBtn.addEventListener('click', () => {
            if (isTradeActive) return;
            currentBet += betStep;
            updateUI();
        });

        decreaseBetBtn.addEventListener('click', () => {
            if (isTradeActive) return;
            if (currentBet - betStep >= 50) {
                currentBet -= betStep;
                updateUI();
            }
        });

        upButton.addEventListener('click', () => placeBet('up'));
        downButton.addEventListener('click', () => placeBet('down'));

betAmountElement.addEventListener('click', () => {
    if (isTradeActive) return; 
    betAmountElement.style.display = 'none';
    betAmountInput.style.display = 'block';
    betAmountInput.value = currentBet;
    betAmountInput.focus();
    
    chart.applyOptions({
        handleScroll: false,
        handleScale: false,
    });
    
});

betAmountInput.addEventListener('blur', () => {
    let newBet = parseInt(betAmountInput.value, 10);

    if (!isNaN(newBet) && newBet >= 50) {
        currentBet = newBet;
    }
    
    updateUI();
    betAmountInput.style.display = 'none';
    betAmountElement.style.display = 'block';
    
    chart.applyOptions({
        handleScroll: true,
        handleScale: true,
    });
    
});

betAmountInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        betAmountInput.blur();
    }
});

    
        
// === Timeframe और Asset सेलेक्टर के लिए सही Event Listeners ===

assetSelectorButton.addEventListener('click', () => {
    timeframeBar.style.display = 'none';
    const isVisible = assetBar.style.display === 'flex';
    assetBar.style.display = isVisible ? 'none' : 'flex';
});

timeframeSelector.addEventListener('click', () => {
    assetBar.style.display = 'none';
    const isVisible = timeframeBar.style.display === 'flex';
    timeframeBar.style.display = isVisible ? 'none' : 'flex';
});

timeButtons.forEach(button => {
    button.addEventListener('click', () => {
        timeButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        const newTimeframe = parseInt(button.dataset.time);
        const newLabel = button.dataset.label;
        gameSettings.timeframe = newTimeframe;
        
        timeframeDisplay.innerHTML = `${newLabel} <i class="fa-solid fa-chevron-down" style="font-size: 10px;"></i>`;
        
        generateHistory(newTimeframe);
        timeframeBar.style.display = 'none';
    });
});

assetButtons.forEach(button => {
    button.addEventListener('click', () => {
        assetButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        const newAssetKey = button.dataset.asset;
        currentAssetKey = newAssetKey;
        
        assetDisplay.innerHTML = `${newAssetKey} <i class="fa-solid fa-chevron-down" style="font-size: 10px;"></i>`;
        
        generateHistory(gameSettings.timeframe);
        
        assetBar.style.display = 'none';
    });
});


// === NEW Event Listeners for Modal with Animation ===
historyButton.addEventListener('click', () => {
    updateHistoryUI();
    historyModal.classList.add('show');
    document.body.style.overflow = 'hidden'; // Lock background scroll
});

function closeHistoryModal() {
    historyModal.classList.remove('show');
    document.body.style.overflow = 'auto'; // Unlock background scroll
}

closeHistoryBtn.addEventListener('click', closeHistoryModal);

historyModal.addEventListener('click', (e) => {
    if (e.target === historyModal) {
        closeHistoryModal();
    }
});

// === Auto-Bet Settings Modal Logic ===
autoBetSettingsBtn.addEventListener('click', () => {
    autoBetSettingsModal.classList.add('show');
});

function closeAutoBetSettingsModal() {
    autoBetSettingsModal.classList.remove('show');
}

closeAutoBetSettingsBtn.addEventListener('click', closeAutoBetSettingsModal);

autoBetSettingsModal.addEventListener('click', (e) => {
    if (e.target === autoBetSettingsModal) {
        closeAutoBetSettingsModal();
    }
});


// === placeBet का नया और फाइनल वर्ज़न ===
let activeTradeLine = null;
let activeTradeDirection = '';
// let countdownPriceLine = null; ok 

function placeBet(direction) {
    const asset = assets[currentAssetKey]; // <<--- वर्तमान एसेट का डेटा लें
    const secondsIntoCandle = asset.masterTime % gameSettings.timeframe; // <<--- asset.masterTime का उपयोग करें

    if (isTradeActive || secondsIntoCandle >= gameSettings.timeframe - 10) {
        showMessage('Betting is closed for this candle', 'warning');
        return;
    }
    if (totalBalance < currentBet) {
        showMessage('Not enough balance!', 'warning');
        return;
    }

    isTradeActive = true;
    setButtonsState(true);
    totalBalance -= currentBet;
    updateUI();
    
    const entryPrice = asset.masterPrice; // <<--- asset.masterPrice का उपयोग करें
    const betAmount = currentBet;
    const timeRemainingInCandle = (gameSettings.timeframe - secondsIntoCandle) * 1000;

    activeTradeDirection = direction;
    
        activeTradeLine = activeSeries.createPriceLine({
        price: entryPrice,
        color: '#ffffff',
        lineWidth: 2,
        lineStyle: LightweightCharts.LineStyle.Dashed,
        axisLabelVisible: false,
    });

    setTimeout(() => {
        pulsatingArea.style.opacity = '0';
        isTradeActive = false;

        const exitPrice = currentCandleData.close;
        let won = (direction === 'up' && exitPrice > entryPrice) || (direction === 'down' && exitPrice < entryPrice);
        
        const lineToRemove = activeTradeLine;
        activeTradeLine = null;

        let tradeResult;

        if (won) {
            const profit = betAmount * 0.85;
            totalBalance += betAmount + profit;
            tradeResult = profit;
            showMessage(`You won ₹${profit.toFixed(2)}!`, 'win');
            lineToRemove.applyOptions({ color: 'var(--color-green)' });
        } else {
            tradeResult = -betAmount;
            showMessage(`You lost ₹${betAmount}`, 'loss');
            lineToRemove.applyOptions({ color: 'var(--color-red)' });
        }

        const candleStartTime = asset.masterTime - secondsIntoCandle; // <<--- asset.masterTime का उपयोग करें
        tradeHistory.push({
            direction: direction,
            betAmount: betAmount,
            timeframeLabel: document.querySelector('.time-btn.active').dataset.label,
            entryPrice: entryPrice,
            exitPrice: exitPrice,
            result: tradeResult,
            startTime: new Date(candleStartTime * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            endTime: new Date(asset.masterTime * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) // <<--- asset.masterTime का उपयोग करें
        });

        updateUI();

        setTimeout(() => {
            activeSeries.removePriceLine(lineToRemove);
            setButtonsState(false);
        }, 100);

    }, timeRemainingInCandle);
}



        
        function setButtonsState(disabled) {
            upButton.disabled = disabled;
            downButton.disabled = disabled;
        }
        
// notificationPanel starting 

// === नया और अंतिम नोटिफिकेशन सिस्टम (Fast-Parity जैसा) ===
function showMessage(message, type = 'info') {
    // 1. एक नया div एलिमेंट बनाएं
    const messageDiv = document.createElement('div');
    
    // 2. उसे क्लास और संदेश दें
    messageDiv.className = `app-message ${type}`;
    messageDiv.textContent = message;
    
    // 3. उसे body में सबसे ऊपर जोड़ें ताकि वह z-index में सबसे ऊपर रहे
    document.body.prepend(messageDiv);
    
    // 4. 3 सेकंड बाद उसे हटा दें
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}


// --- Initial Load ---
        
function initializeGame() {
    const initialTime = Math.floor(Date.now() / 1000) - 7200;
    for (const key in assets) {
        const asset = assets[key];
        let price = asset.masterPrice; // हर ग्राफ़ की शुरुआती कीमत
        for (let i = 0; i < 7200; i++) {
            price *= 1 + (Math.random() - 0.5) * 0.0005 * 2;
            asset.masterPriceHistory.push({ time: initialTime + i, price: price });
        }
        asset.masterTime = initialTime + 7199;
    }
    generateHistory(gameSettings.timeframe);
    gameLoop = setInterval(masterPriceUpdate, 1000);
    updateUI();
}
        
        // --- Tooltip Logic ---
        const tooltip = document.getElementById('tooltip');
        const chartContainer = document.getElementById('chart-container');

// पुराने chart.subscribeCrosshairMove को इस अंतिम और सबसे बेहतर कोड से बदलें

chart.subscribeCrosshairMove(param => {
    // अगर कोई डेटा नहीं है या ऐतिहासिक डेटा खाली है, तो टूलटिप छिपा दें
    if (!param.time || param.point === undefined || historicalCandles.length === 0) {
        tooltip.style.display = 'none';
        return;
    }

    // ऐतिहासिक डेटा में से सही कैंडल को ढूँढें
    const candleData = historicalCandles.find(c => c.time === param.time);

    // अगर कैंडल नहीं मिलती है, तो बाहर निकल जाएँ
    if (!candleData) {
        tooltip.style.display = 'none';
        return;
    }

    tooltip.style.display = 'block';
    
    const color = candleData.close >= candleData.open ? 'var(--color-green)' : 'var(--color-red)';
    
    tooltip.innerHTML = `
        <div class="tooltip-row">
            <span class="tooltip-label">Open</span>
            <span class="tooltip-value">${candleData.open.toFixed(2)}</span>
        </div>
        <div class="tooltip-row">
            <span class="tooltip-label">High</span>
            <span class="tooltip-value">${candleData.high.toFixed(2)}</span>
        </div>
        <div class="tooltip-row">
            <span class="tooltip-label">Low</span>
            <span class="tooltip-value">${candleData.low.toFixed(2)}</span>
        </div>
        <div class="tooltip-row">
            <span class="tooltip-label">Close</span>
            <span class="tooltip-value" style="color: ${color}">${candleData.close.toFixed(2)}</span>
        </div>
        <div class="tooltip-row">
            <span class="tooltip-label">Time</span>
            <span class="tooltip-value">${new Date(candleData.time * 1000).toLocaleTimeString()}</span>
        </div>
    `;

    const chartWidth = chartContainer.clientWidth;
    const tooltipWidth = tooltip.offsetWidth;
    let left = param.point.x + 20;
    if (left + tooltipWidth > chartWidth) {
        left = param.point.x - tooltipWidth - 20;
    }
    let top = param.point.y + 20;
    if (top + tooltip.offsetHeight > chartContainer.clientHeight) {
        top = param.point.y - tooltip.offsetHeight - 20;
    }
    tooltip.style.left = left + 'px';
    tooltip.style.top = top + 'px';
});


        
        
// === FINAL & DETAILED History UI Function ===
function updateHistoryUI() {
    historyList.innerHTML = '';

    if (tradeHistory.length === 0) {
        historyList.innerHTML = '<p class="no-history">You have no trade history yet.</p>';
        return;
    }

    tradeHistory.slice().reverse().forEach(trade => {
        const resultClass = trade.result >= 0 ? 'win' : 'loss';
        const resultSign = trade.result >= 0 ? '+' : '-';
        const directionIcon = trade.direction === 'up' 
            ? '<i class="fa-solid fa-arrow-trend-up"></i>' 
            : '<i class="fa-solid fa-arrow-trend-down"></i>';

        const itemHTML = `
            <div class="history-item">
                <div class="history-top">
                    <div class="history-top-left">
                        <div class="history-direction-icon ${trade.direction}">${directionIcon}</div>
                        <div class="history-timeframe">${trade.timeframeLabel}</div>
                    </div>
                    <div class="history-result ${resultClass}">
                        ${resultSign}₹${Math.abs(trade.result).toFixed(2)}
                    </div>
                </div>
                <div class="history-bottom">
                    <div class="detail-item">
                        <span class="label"><i class="fa-regular fa-money-bill-1"></i> Bet Amount</span>
                        <span class="value">₹${trade.betAmount.toFixed(2)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label"><i class="fa-solid fa-right-to-bracket"></i> Entry Price</span>
                        <span class="value">${trade.entryPrice.toFixed(3)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label"><i class="fa-solid fa-right-from-bracket"></i> Closing Value</span>
                        <span class="value">${trade.exitPrice.toFixed(3)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label"><i class="fa-regular fa-clock"></i> Opening Time</span>
                        <span class="value">${trade.startTime}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label"><i class="fa-solid fa-clock"></i> Closing Time</span>
                        <span class="value">${trade.endTime}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label"><i class="fa-solid fa-tag"></i> Bet Type</span>
                        <span class="value">${trade.direction.toUpperCase()}</span>
                    </div>
                </div>
            </div>
        `;
        historyList.innerHTML += itemHTML;
    });
}


// === FINAL & EXPANDED Chart Type Event Listeners ===

function switchChartType(newType) {
    // अगर पहले से ही वही टाइप है, तो कुछ न करें
    if (currentChartType === newType) return;

    // पुरानी सीरीज़ हटाएँ
    chart.removeSeries(activeSeries);

    // नई सीरीज़ बनाएँ
    switch (newType) {
        case 'candle':
            activeSeries = chart.addCandlestickSeries({
                upColor: '#26a69a', downColor: '#ef5350', borderVisible: false,
                wickUpColor: '#26a69a', wickDownColor: '#ef5350',
            });
            break;
        case 'bar':
            activeSeries = chart.addBarSeries({
                upColor: '#26a69a', downColor: '#ef5350',
            });
            break;
        case 'line':
            activeSeries = chart.addLineSeries({ color: '#26a69a', lineWidth: 2 });
            break;
        case 'area':
            activeSeries = chart.addAreaSeries({
                lineColor: '#26a69a', topColor: 'rgba(38, 166, 154, 0.5)', bottomColor: 'rgba(38, 166, 154, 0.1)',
            });
            break;
    }
        
    currentChartType = newType;
    if (isTradeActive && activeTradeLine) {
        const oldOptions = activeTradeLine.options();
        activeTradeLine = activeSeries.createPriceLine(oldOptions);
    }
    
    [candleChartBtn, barChartBtn, lineChartBtn, areaChartBtn].forEach(btn => btn.classList.remove('active'));
        
    document.getElementById(`${newType}-chart-btn`).classList.add('active');

    // चार्ट डेटा फिर से लोड करें
    generateHistory(gameSettings.timeframe);
}

candleChartBtn.addEventListener('click', () => switchChartType('candle'));
barChartBtn.addEventListener('click', () => switchChartType('bar'));
lineChartBtn.addEventListener('click', () => switchChartType('line'));
areaChartBtn.addEventListener('click', () => switchChartType('area'));

// chart click evie t khatam yha per 

// पुराने indicatorBtn के Event Listener को इससे बदलें
indicatorBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    indicatorMenu.classList.toggle('show');
});
document.body.addEventListener('click', () => {
    indicatorMenu.classList.remove('show');
});
indicatorMenu.addEventListener('click', (e) => {
    e.stopPropagation();
});
// event lisner off of indentor

// === FINAL Indicator Event Listeners & Updater ===

function updateAllIndicators() {  
    if (maToggle.checked) calculateAndDrawMA();  
    if (bbToggle.checked) calculateAndDrawBB();  
    if (volumeToggle.checked) calculateAndDrawVolume();  
    if (rsiToggle.checked) calculateAndDrawRSI();  
    if (stochToggle.checked) calculateAndDrawStoch();  
    if (macdToggle.checked) calculateAndDrawMACD();  
}  
  
maToggle.addEventListener('change', () => { maSeries.applyOptions({ visible: maToggle.checked }); updateAllIndicators(); });  
bbToggle.addEventListener('change', () => {  
    const isEnabled = bbToggle.checked;  
    bbUpperSeries.applyOptions({ visible: isEnabled });  
    bbMiddleSeries.applyOptions({ visible: isEnabled });  
    bbLowerSeries.applyOptions({ visible: isEnabled });  
    updateAllIndicators();  
});  
volumeToggle.addEventListener('change', () => {  
    const isEnabled = volumeToggle.checked;  
    volumeSeries.applyOptions({ visible: isEnabled });  
    chart.priceScale('volume').applyOptions({ visible: isEnabled });  
    updateAllIndicators();  
});  
rsiToggle.addEventListener('change', () => {  
    const isEnabled = rsiToggle.checked;  
    rsiSeries.applyOptions({ visible: isEnabled });  
    chart.priceScale('rsi').applyOptions({ visible: isEnabled });  
    updateAllIndicators();  
});  
stochToggle.addEventListener('change', () => {  
    const isEnabled = stochToggle.checked;  
    stochKSeries.applyOptions({ visible: isEnabled });  
    stochDSeries.applyOptions({ visible: isEnabled });  
    chart.priceScale('stoch').applyOptions({ visible: isEnabled });  
    updateAllIndicators();  
});  
macdToggle.addEventListener('change', () => {  
    const isEnabled = macdToggle.checked;  
    macdHistSeries.applyOptions({ visible: isEnabled });  
    macdLineSeries.applyOptions({ visible: isEnabled });  
    macdSignalSeries.applyOptions({ visible: isEnabled });  
    chart.priceScale('macd').applyOptions({ visible: isEnabled });  
    updateAllIndicators();  
});  
  
// === ALL INDICATOR CALCULATION FUNCTIONS ===  
  
function calculateAndDrawMA() {  
    const data = activeSeries.data(); if (data.length < 20) return;  
    const maData = data.slice(19).map((d, i) => {  
        const sum = data.slice(i, i + 20).reduce((acc, val) => acc + (val.close ?? val.value), 0);  
        return { time: d.time, value: sum / 20 };  
    });  
    maSeries.setData(maData);  
}  
  
function calculateAndDrawBB() {  
    const data = activeSeries.data(); const period = 20, stdDevMul = 2; if (data.length < period) return;  
    const bbData = { upper: [], middle: [], lower: [] };  
    for (let i = period - 1; i < data.length; i++) {  
        const slice = data.slice(i - period + 1, i + 1).map(d => d.close ?? d.value);  
        const sma = slice.reduce((sum, p) => sum + p, 0) / period;  
        const stdDev = Math.sqrt(slice.map(p => Math.pow(p - sma, 2)).reduce((s, v) => s + v, 0) / period);  
        bbData.middle.push({ time: data[i].time, value: sma });  
        bbData.upper.push({ time: data[i].time, value: sma + (stdDev * stdDevMul) });  
        bbData.lower.push({ time: data[i].time, value: sma - (stdDev * stdDevMul) });  
    }  
    bbMiddleSeries.setData(bbData.middle); bbUpperSeries.setData(bbData.upper); bbLowerSeries.setData(bbData.lower);  
}  
  
function calculateAndDrawVolume() {  
    const data = activeSeries.data(); if (data.length === 0) return;  
    const volumeData = data.map(d => {  
        const isUp = (d.close ?? d.value) >= (d.open ?? d.value);  
        return { time: d.time, value: Math.random() * 1000 + 500, color: isUp ? 'rgba(38, 166, 154, 0.5)' : 'rgba(239, 83, 80, 0.5)' };  
    });  
    volumeSeries.setData(volumeData);  
}  
  
function calculateAndDrawRSI() {  
    const data = activeSeries.data(); if (data.length < 15) return;  
    const rsiData = []; let gains = 0, losses = 0;  
    for (let i = 1; i <= 14; i++) { const diff = (data[i].close ?? data[i].value) - (data[i-1].close ?? data[i-1].value); if (diff > 0) gains += diff; else losses -= diff; }  
    let avgGain = gains / 14, avgLoss = losses / 14;  
    for (let i = 14; i < data.length; i++) {  
        if (i > 14) { const diff = (data[i].close ?? data[i].value) - (data[i-1].close ?? data[i-1].value); avgGain = (avgGain * 13 + (diff > 0 ? diff : 0)) / 14; avgLoss = (avgLoss * 13 + (diff < 0 ? -diff : 0)) / 14; }  
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;  
        rsiData.push({ time: data[i].time, value: 100 - (100 / (1 + rs)) });  
    }  
    rsiSeries.setData(rsiData);  
}  
  
function calculateAndDrawStoch() {  
    const data = activeSeries.data(); const kPeriod = 14, dPeriod = 3; if (data.length < kPeriod) return;  
    const stochData = { k: [], d: [] };  
    for (let i = kPeriod - 1; i < data.length; i++) {  
        const slice = data.slice(i - kPeriod + 1, i + 1);  
        const lowestLow = Math.min(...slice.map(d => d.low));  
        const highestHigh = Math.max(...slice.map(d => d.high));  
        const currentClose = data[i].close;  
        const kValue = ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;  
        stochData.k.push({ time: data[i].time, value: kValue });  
    }  
    if (stochData.k.length < dPeriod) return;  
    for (let i = dPeriod - 1; i < stochData.k.length; i++) {  
        const slice = stochData.k.slice(i - dPeriod + 1, i + 1);  
        const dValue = slice.reduce((sum, val) => sum + val.value, 0) / dPeriod;  
        stochData.d.push({ time: slice[slice.length - 1].time, value: dValue });  
    }  
    stochKSeries.setData(stochData.k); stochDSeries.setData(stochData.d);  
}  
  
function calculateAndDrawMACD() {  
    const data = activeSeries.data(); const fast = 12, slow = 26, signal = 9; if (data.length < slow) return;  
    const ema = (source, period) => { let emaValues = []; let multiplier = 2 / (period + 1); emaValues[0] = source[0]; for (let i = 1; i < source.length; i++) { emaValues[i] = (source[i] - emaValues[i-1]) * multiplier + emaValues[i-1]; } return emaValues; };  
    const prices = data.map(d => d.close ?? d.value);  
    const emaFast = ema(prices, fast); const emaSlow = ema(prices, slow);  
    const macdLine = emaFast.map((val, i) => val - emaSlow[i]);  
    const signalLine = ema(macdLine, signal);  
    const histogram = macdLine.map((val, i) => val - signalLine[i]);  
    const macdData = { line: [], signal: [], hist: [] };  
    for (let i = 0; i < data.length; i++) {  
        const time = data[i].time;  
        macdData.line.push({ time, value: macdLine[i] });  
        macdData.signal.push({ time, value: signalLine[i] });  
        macdData.hist.push({ time, value: histogram[i], color: histogram[i] > 0 ? 'rgba(38, 166, 154, 0.5)' : 'rgba(239, 83, 80, 0.5)' });  
    }  
    macdLineSeries.setData(macdData.line); macdSignalSeries.setData(macdData.signal); macdHistSeries.setData(macdData.hist);  
}  
  
  
initializeGame();  
  
    </script>
</body>
</html>

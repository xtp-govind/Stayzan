<?php
session_start();

// 👇 Cache control headers to force browser to revalidate page
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['unique_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page - Improved Menu</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --secondary-gradient: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
            --warning-gradient: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
            --accent-gradient: linear-gradient(135deg, #89f7fe 0%, #66a6ff 100%);
            --success-gradient: linear-gradient(135deg, #5ee7df 0%, #b490ca 100%);
            
            /* --- अन्य manquants वेरिएबल्स जोड़े गए --- */
            --primary-color: #667eea;
            --bg-secondary: #ffffff;
            --bg-tertiary: #f8f9fa;
            --text-muted: #adb5bd;
            --shadow-soft: 0 4px 12px rgba(0, 0, 0, 0.05);
            /* --- अंत --- */

            --background-color: #f4f6f8;
            --card-background: #ffffff;
            --text-primary: #2c3e50;
            --text-secondary: #7f8c8d;
            --shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            --border-radius-lg: 24px;
            --border-radius-md: 18px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            background-color: var(--background-color);
            color: var(--text-primary);
            margin: 0;
            padding-bottom: 80px;
        }

        .app-container {
            width: 100%;
            max-width: 430px;
            margin: 0 auto;
            background-color: var(--background-color);
            min-height: 100vh;
            position: relative;
        }

        .header-section {
            background: var(--primary-gradient);
            height: 110px;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            position: relative;
        }

        .profile-section {
            text-align: center;
            margin-top: -75px;
            position: relative;
            z-index: 10;
            padding: 0 20px;
        }

        .profile-avatar {
            position: relative;
            display: inline-block;
            margin-bottom: 15px;
        }

        .avatar-img {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid white;
            background-color: #e0e0e0;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .edit-icon {
            position: absolute;
            bottom: 10px;
            right: 5px;
            width: 30px;
            height: 30px;
            background-color: #4a90e2;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            border: 2px solid white;
            cursor: pointer;
        }

        .profile-name {
            font-size: 1.8em;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 5px;
        }

        .profile-email {
            font-size: 1.1em;
            color: #c0392b;
            font-weight: 500;
        }
/* Menu Section */
.menu-section {
    background: var(--bg-secondary);
    padding: 15px;
    border-radius: 15px;
    box-shadow: var(--shadow-soft);
    margin: 15px;
}

.menu-title {
    font-size: 18px;
    font-weight: 700;
    margin-bottom: 20px;
    color: var(--text-primary);
}

.menu-grid {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.menu-item {
    display: flex;
    align-items: center;
    padding: 16px;
    background: var(--bg-tertiary);
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.menu-item::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 0;
    height: 100%;
    background: var(--primary-gradient);
    transition: width 0.3s ease;
    opacity: 0.1;
}

.menu-item:hover::before {
    width: 100%;
}

.menu-item:hover {
    transform: translateX(5px);
    background: var(--bg-secondary);
    box-shadow: var(--shadow-soft);
}

.menu-icon {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    position: relative;
    overflow: hidden;
}

.menu-icon::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 1;
    border-radius: 12px;
}

.menu-icon.wallet::before { background: var(--primary-gradient); }
.menu-icon.orders::before { background: var(--secondary-gradient); }
.menu-icon.favorites::before { background: var(--warning-gradient); }
.menu-icon.settings::before { background: var(--accent-gradient); }
.menu-icon.help::before { background: var(--success-gradient); }

.menu-icon i {
    color: white;
    font-size: 18px;
    z-index: 1;
    position: relative;
}

.menu-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.menu-text {
    font-size: 15px;
    font-weight: 600;
    color: var(--text-primary);
}

.menu-subtitle {
    font-size: 12px;
    color: var(--text-secondary);
}

.menu-badge {
    background: var(--primary-color);
    color: white;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    margin-right: 12px;
    box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
}

.menu-arrow {
    color: var(--text-muted);
    font-size: 14px;
    transition: all 0.3s ease;
}

.menu-item:hover .menu-arrow {
    color: var(--primary-color);
    transform: translateX(5px);
}

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e9ecef;
            padding: 10px 0;
            z-index: 1000;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #666;
            min-width: 60px;
        }

        .nav-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .nav-item i {
            font-size: 1.3em;
            margin-bottom: 4px;
        }

        .nav-item .nav-text {
            font-size: 0.75em;
            font-weight: 600;
        }


    </style>
</head>
<body>
    <div class="app-container">
        <div class="header-section"></div>

<!-- Profile Section (HTML IDs for JS to insert) -->
<div class="profile-section">
    <div class="profile-avatar">
        <img id="profileImage" src="" alt="Profile Picture" class="avatar-img"
             onerror="this.onerror=null; this.src='logo/default.png';">
    </div>
    <h2 id="profileName" class="profile-name">Loading...</h2>
    <p id="profileEmail" class="profile-email">Loading...</p>
</div>


            <!-- Menu Section -->
            <div class="menu-section">
                
                <div class="menu-grid">
                    <div class="menu-item" data-action="wallet" onclick="location.href='wallet'">
                        <div class="menu-icon wallet">
                            <i class="fas fa-wallet"></i>
                        </div>
                        <div class="menu-content">
                            <span class="menu-text">Wallet</span>
                            <span class="menu-subtitle">Manage payments</span>
                        </div>
                        <div id="amount" class="menu-badge">₹0.00</div>
                        <i class="fas fa-chevron-right menu-arrow"></i>
                    </div>

                    <div class="menu-item" data-action="orders" onclick="location.href='orders'">
                        <div class="menu-icon orders">
                        <i class="fas fa-receipt"></i>
                        </div>
                        <div class="menu-content">
                            <span class="menu-text">Your Orders</span>
                            <span class="menu-subtitle">Track & manage</span>
                        </div>
                    
                        <i class="fas fa-chevron-right menu-arrow"></i>
                    </div>

                    <div class="menu-item" data-action="favorites">
                        <div class="menu-icon favorites">
                        <i class="fas fa-download"></i>
                        </div>
                        <div class="menu-content">
                            <span class="menu-text">Download</span>
                            <span class="menu-subtitle">Download App</span>
                        </div>
                        <i class="fas fa-chevron-right menu-arrow"></i>
                    </div>

                    <div class="menu-item" data-action="channel">
                        <div class="menu-icon settings">
                        <i class="fab fa-telegram-plane"></i>
                        </div>
                        <div class="menu-content">
                            <span class="menu-text">Follow Us</span>
                            <span class="menu-subtitle">Teligram Channel</span>
                        </div>
                        <i class="fas fa-chevron-right menu-arrow"></i>
                    </div>

                    <div class="menu-item" data-action="help" onclick="location.href='support'" >
                        <div class="menu-icon help">
                            <i class="fas fa-question-circle"></i>
                        </div>
                        <div class="menu-content">
                            <span class="menu-text">Help & Support</span>
                            <span class="menu-subtitle">Get assistance</span>
                        </div>
                        <i class="fas fa-chevron-right menu-arrow"></i>
                    </div>
                </div>
            </div>
            
            <!-- Logout Button -->
<div style="text-align:center; margin: 20px 0;">
    <form method="post" action="logout.php">
        <button type="submit" style="padding: 12px 30px; font-size: 16px; font-weight: 600; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 30px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); cursor: pointer;">
            <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i> Logout
        </button>
    </form>
</div>
            
        </div>

        <!-- Bottom Navigation (Unchanged) -->
        <div class="bottom-nav">
            <div class="nav-container">
                <a href="index.php" class="nav-item">
                    <i class="fas fa-home"></i>
                    <span class="nav-text">Home</span>
                </a>
                <a href="invite.php" class="nav-item">
                    <i class="fas fa-users"></i>
                    <span class="nav-text">Invite</span>
                </a>
                <a href="recharge.php" class="nav-item">
                    <i class="fas fa-credit-card"></i>
                    <span class="nav-text">Recharge</span>
                </a>
                <a href="profile.php" class="nav-item active">
                    <i class="fas fa-user"></i>
                    <span class="nav-text">My</span>
                </a>
            </div>
        </div>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Profile page loaded successfully');
        });
        
document.addEventListener('DOMContentLoaded', function() {
    fetch('fetch_login_user.php')
        .then(res => res.json())
        .then(response => {
            if (response.status === 'success') {
                const user = response.data;

                document.getElementById('profileName').innerText = user.name;
                document.getElementById('profileEmail').innerText = user.email;

                // ✅ Image check: agar empty ho to default set karo
                const imageUrl = user.user_image && user.user_image.trim() !== ''
                    ? user.user_image
                    : 'logo/default.png';

                document.getElementById('profileImage').src = imageUrl;
            } else {
                console.error(response.message);
            }
        })
        .catch(error => console.error('Fetch error:', error));
});

 function fetchBalances() {
    fetch('get_all_balance')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                const walletBalanceEl = document.getElementById('amount');
                if (walletBalanceEl) {
                    walletBalanceEl.textContent = '₹' + data.wallet_balance;
                }
            } else {
                console.error('Balance fetch error:', data.message);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
        });
}
 
 document.addEventListener('DOMContentLoaded', function() {
    fetchBalances(); // ✅ call karna zaruri hai
});


document.querySelector('[data-action="channel"]').addEventListener('click', function() {
    window.location.href = "https://t.me/stayzann"; // yaha apna actual telegram link daalein
});

         
    </script>
</body>
</html>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Database connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];

    // Check if the mobile exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE mobile = ?");
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // 🔒 Check if account is blocked
        if (isset($user['blocked']) && $user['blocked'] == 1) {
            echo "Your account is blocked, please connect with support";
        } 
        // ✅ If not blocked, then check password
        elseif (password_verify($password, $user['password'])) {
            // Start session and store unique ID
            $_SESSION['unique_id'] = $user['unique_id'];
            $_SESSION['name'] = $user['name']; 
            $_SESSION['logged_in'] = true; // Set logged-in flag
            $_SESSION['image'] = $user['user_image'];          

            // Return success response
            echo "Success";
        } else {
            // Incorrect password
            echo "Incorrect password";
        }
    } else {
        // No user found with the provided mobile
        echo "Please signup first";
    }

    // Close the prepared statement and database connection
    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>4 in a Row</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.2/dist/confetti.browser.min.js"></script>

    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea, #764ba2);
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5; 
            margin: 0; 
            padding-top: 60px;
            display: flex; 
            justify-content: center; 
            align-items: flex-start;
            min-height: 100vh; 
            overflow-x: hidden;
            overflow-y: auto;
        }
        .top-bar {
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 60px;
            background: var(--primary-gradient); 
            color: white; 
            display: flex;
            justify-content: space-between; 
            align-items: center; 
            padding: 0 20px;
            box-sizing: border-box; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); 
            z-index: 1000;
        }
        .top-bar h1 {
            margin: 0; 
            font-size: 1.3em; 
            position: absolute;
            left: 50%; 
            transform: translateX(-50%);
            max-width: calc(100% - 120px);
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .top-bar .icon-button { 
            color: white; 
            font-size: 1.5em; 
            text-decoration: none; 
            z-index: 1001;
        }
        .main-content {
            width: 95%; 
            max-width: 450px; 
            margin-top: 20px; 
            background: white;
            border-radius: 20px; 
            padding: 20px; 
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            box-sizing: border-box; 
            position: relative;
            margin-bottom: 20px;
        }
        .game-header {
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            margin-bottom: 15px; 
            min-height: 50px;
        }
        .user-info {
            display: flex; 
            align-items: center; 
            gap: 10px; 
            background-color: #f8f9fa;
            padding: 8px 12px; 
            border-radius: 25px; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .user-image {
            width: 40px; 
            height: 40px; 
            border-radius: 50%; 
            display: flex;
            justify-content: center; 
            align-items: center; 
            overflow: hidden;
            background-size: cover; 
            background-position: center;
        }
        .user-info.player-user .user-image { border: 3px solid #ef4444; }
        .user-info.player-bot .user-image { border: 3px solid #facc15; }
        .user-image i { font-size: 1.4em; color: #6c757d; }
        .user-id { font-size: 0.9em; font-weight: bold; color: #495057; }
        .amount-display {
            display: flex;
            align-items: center;
            gap: 8px;
            background-color: #fff;
            padding: 8px 15px;
            border-radius: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
            font-weight: 600;
            color: #495057;
        }
        .amount-display i {
            color: #28a745;
            font-size: 1.2em;
        }
        .opponent-info-container {
            display: flex;
            justify-content: flex-end;
            margin-top: 15px;
        }
        #winner-message {
            position: absolute; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%);
            font-size: 2em; 
            font-weight: bold; 
            color: white;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.7); 
            z-index: 11;
            display: none; 
            text-align: center; 
            line-height: 1.2;
        }
        .game-board-area { 
            position: relative; 
            overflow: hidden; 
            margin-top: 15px; 
        }
        #game-board {
            display: grid; 
            grid-template-columns: repeat(7, 1fr); 
            background-color: #1e3a8a;
            padding: 10px; 
            border-radius: 15px; 
            gap: 8px;
            box-shadow: inset 0 0 10px rgba(0,0,0,0.5); 
            transition: filter 0.5s ease;
        }
        #game-board.pre-game, #game-board.game-over { 
            filter: blur(5px); 
            pointer-events: none; 
        }
        .cell { 
            background-color: #dbeafe; 
            border-radius: 50%; 
            aspect-ratio: 1 / 1; 
            position: relative; 
            cursor: pointer;
        }
        .cell:hover {
            background-color: #bfdbfe;
        }
        .piece {
            width: 100%; 
            height: 100%; 
            border-radius: 50%; 
            position: absolute;
            left: 0; 
            top: 0; 
            transform: translateY(var(--start-y-pos, -500px));
            animation: drop-in 0.4s ease-out forwards;
        }
        .piece.red { background-color: #ef4444; }
        .piece.yellow { background-color: #facc15; }
        @keyframes drop-in { 
            to { transform: translateY(0); } 
        }
        .piece.win { 
            animation: win-pulse 0.8s infinite alternate; 
        }
        @keyframes win-pulse {
            from { transform: scale(1); box-shadow: 0 0 5px 2px #fff; }
            to { transform: scale(1.15); box-shadow: 0 0 15px 8px #fff; }
        }
        #start-button-overlay {
            position: absolute; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%;
            display: flex; 
            justify-content: center; 
            align-items: center;
            z-index: 12; 
            transition: opacity 0.5s ease, visibility 0.5s;
        }
        #start-button-overlay.hidden { 
            opacity: 0; 
            visibility: hidden; 
        }
        #start-button {
            width: 120px; 
            height: 120px; 
            font-size: 1.5em; 
            font-weight: bold; 
            color: white;
            background: linear-gradient(45deg, #ff512f, #dd2476); 
            border: 6px solid white;
            border-radius: 50%; 
            cursor: pointer; 
            box-shadow: 0 8px 20px rgba(221, 36, 118, 0.4);
        }
        .current-bet-display {
            text-align: center; 
            font-weight: 600; 
            color: #495057;
            background: #e9ecef; 
            padding: 10px; 
            border-radius: 8px;
            margin-top: 15px; 
            display: none;
        }
        .history-buttons { 
            display: flex; 
            justify-content: space-between; 
            margin-top: 15px; 
            gap: 10px; 
        }
        .history-buttons button {
            flex: 1; 
            padding: 15px; 
            font-size: 1em; 
            font-weight: 600; 
            border: none;
            border-radius: 10px; 
            background-color: #e9ecef; 
            color: #495057; 
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .history-buttons button:hover {
            background-color: #dee2e6;
        }
        .popup-backdrop {
            position: fixed; 
            top: 0; 
            left: 0; 
            right: 0; 
            bottom: 0;
            background: rgba(0, 0, 0, 0.5); 
            z-index: 9998; 
            display: none;
        }
        .popup-backdrop.show { display: block; }
        .popup-overlay {
            position: fixed; 
            bottom: -100%; 
            left: 0; 
            right: 0;
            background: #fff; 
            border-top-left-radius: 20px; 
            border-top-right-radius: 20px;
            transition: bottom 0.4s ease; 
            z-index: 9999; 
            padding: 25px;
            box-shadow: 0 -5px 25px rgba(0,0,0,0.2); 
            max-height: 80vh; 
            overflow-y: auto;
        }
        .popup-overlay.show { bottom: 0; }
        .popup-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 20px; 
        }
        .popup-title { 
            font-size: 20px; 
            font-weight: 600; 
            color: #333; 
            margin: 0; 
        }
        .popup-close {
            width: 30px; 
            height: 30px; 
            border-radius: 50%; 
            background: #f8f9fa;
            border: 1px solid #dee2e6; 
            display: flex; 
            align-items: center; 
            justify-content: center;
            cursor: pointer; 
            font-size: 18px; 
            color: #6c757d; 
            transition: all 0.3s ease;
        }
        .popup-close:hover {
            background: #e9ecef;
        }
        .popup-section { margin-bottom: 20px; }
        .popup-section > div:first-child { 
            font-weight: 600; 
            margin-bottom: 10px; 
            color: #333; 
            font-size: 16px; 
        }
        .money-options {
            display: grid; 
            grid-template-columns: repeat(3, 1fr); 
            gap: 10px;
            width: 100%; 
            box-sizing: border-box; 
            margin-bottom: 20px;
        }
        .money-options button {
            padding: 12px 8px; 
            border: 2px solid #dee2e6; 
            border-radius: 8px;
            background: #f8f9fa; 
            cursor: pointer; 
            font-weight: 600;
            transition: all 0.3s ease; 
            font-size: 14px; 
            width: 100%; 
            box-sizing: border-box;
        }
        .money-options button:hover {
            border-color: #667eea;
        }
        .money-options button.selected {
            background: var(--primary-gradient); 
            color: white;
            border-color: #667eea; 
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        .quantity-controls { 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            gap: 15px; 
        }
        .quantity-controls button {
            width: 40px; 
            height: 40px; 
            border: 2px solid #667eea; 
            border-radius: 50%;
            background: #f8f9fa; 
            color: #667eea; 
            font-size: 18px; 
            font-weight: 600;
            cursor: pointer; 
            transition: all 0.3s ease;
        }
        .quantity-controls button:hover {
            background: #667eea;
            color: white;
        }
        .quantity-controls span { 
            font-size: 18px; 
            font-weight: 600; 
            min-width: 30px; 
            text-align: center; 
            color: #333; 
        }
        .popup-balance {
            text-align: center; 
            margin-bottom: 15px; 
            padding: 12px;
            background: linear-gradient(135deg, #e3f2fd, #f3e5f5); 
            border-radius: 10px;
            font-weight: 600; 
            color: #333; 
            border: 1px solid #e1bee7;
        }
        .popup-total {
            text-align: center; 
            font-size: 18px; 
            font-weight: 600; 
            margin-bottom: 20px;
            color: #333; 
            padding: 10px; 
            background: #f8f9fa; 
            border-radius: 8px; 
            border: 2px solid #dee2e6;
        }
        .popup-confirm {
            width: 100%; 
            padding: 15px; 
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white; 
            border: none; 
            border-radius: 10px; 
            font-size: 16px; 
            font-weight: 600;
            cursor: pointer; 
            transition: all 0.3s ease; 
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
        }
        .popup-confirm:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(40, 167, 69, 0.4);
        }
        .popup-confirm:disabled { 
            background: #6c757d; 
            cursor: not-allowed; 
            box-shadow: none; 
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
            text-align: center;
            display: none;
        }
        .popup-content {
            line-height: 1.6;
            color: #495057;
        }
        .popup-content p {
            margin-top: 0;
        }
        .popup-content ul {
            padding-left: 20px;
            margin-bottom: 0;
        }
        .popup-content li {
            margin-bottom: 10px;
        }
        @media (max-width: 480px) {
            .main-content {
                width: 98%;
                padding: 15px;
                margin-top: 10px;
            }
            .top-bar h1 {
                font-size: 1.1em;
            }
            #start-button {
                width: 100px;
                height: 100px;
                font-size: 1.3em;
            }
        }
    </style>
</head>
<body>

    <header class="top-bar">
        <a href="javascript:history.back()" class="icon-button"><i class="fas fa-arrow-left"></i></a>
        <h1>4 in a Row</h1>
        <a href="#" id="howToPlayBtn" class="icon-button"><i class="fas fa-question-circle"></i></a>
    </header>

    <div class="main-content">
        <div class="game-header">
            <div id="user-profile" class="user-info player-user">
                <div class="user-image"><i class="fas fa-user"></i></div>
                <div class="user-id">Loading...</div>
            </div>
            <div class="amount-display">
                  <i class="fas fa-wallet"></i>
                  <span id="amountValue">₹0</span>
            </div>
        </div>

        <div class="game-board-area">
            <h3 id="winner-message"></h3>
            <div id="game-board"></div>
            <div id="start-button-overlay">
                <button id="start-button">START</button>
            </div>
        </div>

        <div class="opponent-info-container">
            <div id="opponent-profile" class="user-info player-bot">
                <div class="user-image"><i class="fas fa-robot"></i></div>
                <div class="user-id">Bot</div>
            </div>
        </div>

        <div class="current-bet-display" id="currentBetDisplay"></div>

        <footer class="history-buttons">
            <button id="my-history"><i class="fas fa-user"></i> My History</button>
            <button id="all-history"><i class="fas fa-globe"></i> All History</button>
        </footer>
    </div>

    <!-- Bet Popup Area -->
    <div class="popup-backdrop" id="popupBackdrop"></div>
    <div class="popup-overlay" id="betPopup">
        <div class="popup-header">
            <div class="popup-title">Place Bet</div>
            <button class="popup-close" onclick="closePopup()">×</button>
        </div>
        <div class="error-message" id="errorMessage"></div>
        <div class="popup-balance" id="popupBalance">Available Balance: ₹0</div>
        <div class="popup-section">
            <div>Select Money</div>
            <div class="money-options" id="moneyOptions">
                <button data-amount="10" onclick="selectMoney(10)">₹10</button>
                <button data-amount="50" onclick="selectMoney(50)">₹50</button>
                <button data-amount="100" onclick="selectMoney(100)" class="selected">₹100</button>
                <button data-amount="1000" onclick="selectMoney(1000)">₹1000</button>
                <button data-amount="5000" onclick="selectMoney(5000)">₹5000</button>
                <button data-amount="10000" onclick="selectMoney(10000)">₹10000</button>
            </div>
        </div>
        <div class="popup-section">
            <div>Quantity</div>
            <div class="quantity-controls">
                <button onclick="changeQuantity(-1)">-</button>
                <span id="qtyDisplay">1</span>
                <button onclick="changeQuantity(1)">+</button>
            </div>
        </div>
        <div class="popup-total" id="popupTotal">Total: ₹100</div>
        <button class="popup-confirm" id="confirmBetBtn" onclick="confirmBet()">Confirm</button>
    </div>
    
    <!-- How to Play Popup -->
    <div class="popup-overlay" id="howToPlayPopup">
        <div class="popup-header">
            <div class="popup-title">How to Play</div>
            <button class="popup-close" onclick="closeHowToPlayPopup()">×</button>
        </div>
        <div class="popup-content">
            <p><strong>Objective:</strong> Be the first player to connect four of your colored pieces in a row.</p>
            <ul>
                <li>The pieces can be connected horizontally, vertically, or diagonally.</li>
                <li>First, place your bet using the "START" button.</li>
                <li>Click on a column to drop your piece. It will fall to the lowest available spot.</li>
                <li>Take turns with the opponent to place your pieces.</li>
                <li>The first to get 4-in-a-row wins the game and doubles their bet!</li>
                <li>If the board is filled and no one has 4-in-a-row, the game is a draw and your bet is returned.</li>
            </ul>
        </div>
    </div>

    <script>
// --- DOM Elements ---
const boardElement = document.getElementById('game-board');
const startButton = document.getElementById('start-button');
const startOverlay = document.getElementById('start-button-overlay');
const winnerMessage = document.getElementById('winner-message');
const userIdElement = document.querySelector('#user-profile .user-id');
const userImageElement = document.querySelector('#user-profile .user-image');
const currentBetDisplay = document.getElementById('currentBetDisplay');
const opponentIdElement = document.querySelector('#opponent-profile .user-id');
const opponentImageElement = document.querySelector('#opponent-profile .user-image');
const amountValueElement = document.getElementById('amountValue');

// --- Popup Elements ---
const popupBackdrop = document.getElementById('popupBackdrop');
const betPopup = document.getElementById('betPopup');
const howToPlayPopup = document.getElementById('howToPlayPopup');
const howToPlayBtn = document.getElementById('howToPlayBtn');
const popupBalanceElem = document.getElementById('popupBalance');
const qtyDisplay = document.getElementById('qtyDisplay');
const popupTotalElem = document.getElementById('popupTotal');
const confirmBetBtn = document.getElementById('confirmBetBtn');
const moneyOptions = document.getElementById('moneyOptions');
const errorMessage = document.getElementById('errorMessage');

// --- Game & Player State ---
const ROWS = 6, COLS = 7;
let board = [], currentPlayer = 'user', gameActive = false;
let playerBalance = 0, currentBet = 0;
let selectedMoney = 100, quantity = 1;

// --- Data Fetching ---
async function fetchUserData() {
    try {
        // यह एक नकली API प्रतिक्रिया है, आप इसे वास्तविक डेटा से बदल सकते हैं
        const fakeApiResponse = {
            userId: 'Player786',
            imageUrl: 'https://via.placeholder.com/40/ef4444/ffffff?text=P',
            balance: 10000
        };
        userIdElement.textContent = fakeApiResponse.userId;
        userImageElement.style.backgroundImage = `url('${fakeApiResponse.imageUrl}')`;
        userImageElement.innerHTML = '';
        playerBalance = fakeApiResponse.balance;
        updateBalanceDisplay();
    } catch (error) {
        console.error("Failed to fetch user data:", error);
        userIdElement.textContent = 'Error';
    }
}

async function fetchOpponentData() {
    try {
        // यह एक नकली API प्रतिक्रिया है
        const fakeApiResponse = {
            userId: 'BotX',
            imageUrl: 'https://via.placeholder.com/40/facc15/000000?text=B',
        };
        opponentIdElement.textContent = fakeApiResponse.userId;
        opponentImageElement.style.backgroundImage = `url('${fakeApiResponse.imageUrl}')`;
        opponentImageElement.innerHTML = '';
    } catch (error) {
        console.error("Failed to fetch opponent data:", error);
        opponentIdElement.textContent = 'Error';
    }
}

// --- UI Update Functions ---
function updateBalanceDisplay() {
    const formattedBalance = `₹${playerBalance.toLocaleString()}`;
    popupBalanceElem.textContent = `Available Balance: ${formattedBalance}`;
    amountValueElement.textContent = formattedBalance;
}

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    setTimeout(() => {
        errorMessage.style.display = 'none';
    }, 3000);
}

// --- Popup Logic ---
function openPopup() {
    closeHowToPlayPopup(); // दूसरे पॉपअप को बंद करें
    initializeBoard();
    updateBetTotal();
    errorMessage.style.display = 'none';
    popupBackdrop.classList.add('show');
    betPopup.classList.add('show');
}

function closePopup() {
    popupBackdrop.classList.remove('show');
    betPopup.classList.remove('show');
}

function openHowToPlayPopup() {
    closePopup(); // दूसरे पॉपअप को बंद करें
    popupBackdrop.classList.add('show');
    howToPlayPopup.classList.add('show');
}

function closeHowToPlayPopup() {
    popupBackdrop.classList.remove('show');
    howToPlayPopup.classList.remove('show');
}

function selectMoney(amount) {
    selectedMoney = amount;
    moneyOptions.querySelectorAll('button').forEach(btn => btn.classList.remove('selected'));
    const selectedBtn = moneyOptions.querySelector(`button[data-amount="${amount}"]`);
    if (selectedBtn) selectedBtn.classList.add('selected');
    updateBetTotal();
}

function changeQuantity(amount) {
    quantity = Math.max(1, quantity + amount);
    qtyDisplay.textContent = quantity;
    updateBetTotal();
}

function updateBetTotal() {
    const totalBet = selectedMoney * quantity;
    popupTotalElem.textContent = `Total: ₹${totalBet.toLocaleString()}`;
    confirmBetBtn.disabled = totalBet > playerBalance;
}

function confirmBet() {
    const totalBet = selectedMoney * quantity;
    if (totalBet > playerBalance) {
        showError("Insufficient balance!");
        return;
    }
    currentBet = totalBet;
    playerBalance -= currentBet;
    updateBalanceDisplay();
    closePopup();
    startGame();
}

// --- Game Logic ---
function initializeBoard() {
    boardElement.innerHTML = '';
    boardElement.className = 'pre-game';
    startOverlay.classList.remove('hidden');
    winnerMessage.style.display = 'none';
    startButton.textContent = "START";
    currentBetDisplay.style.display = 'none';
    
    for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.dataset.row = r; 
            cell.dataset.col = c;
            cell.addEventListener('click', () => handleCellClick(c));
            boardElement.appendChild(cell);
        }
    }
}

function startGame() {
    board = Array.from({ length: ROWS }, () => Array(COLS).fill(null));
    winnerMessage.style.display = 'none';
    gameActive = true;
    currentPlayer = 'user';
    
    fetchOpponentData(); // बॉट की जानकारी लोड करें
    
    document.querySelectorAll('.piece').forEach(p => p.remove());
    
    boardElement.className = '';
    startOverlay.classList.add('hidden');
    
    currentBetDisplay.textContent = `Current Bet: ₹${currentBet.toLocaleString()}`;
    currentBetDisplay.style.display = 'block';
}

function handleCellClick(col) {
    if (!gameActive || currentPlayer !== 'user') return;
    
    if (dropPiece(col, 'user')) {
        if (checkWin('user')) {
            endGame('user');
        } else if (isBoardFull()) {
            endGame('draw');
        } else {
            currentPlayer = 'bot';
            setTimeout(() => botMove(), 1000);
        }
    }
}

function dropPiece(col, player) {
    for (let row = ROWS - 1; row >= 0; row--) {
        if (board[row][col] === null) {
            board[row][col] = player;
            
            const cell = boardElement.children[row * COLS + col];
            const piece = document.createElement('div');
            piece.classList.add('piece', player === 'user' ? 'red' : 'yellow');
            
            // डायनामिक एनीमेशन पोजीशन
            const startY = -(row + 1) * (cell.clientHeight + 8); // 8px गैप के लिए
            piece.style.setProperty('--start-y-pos', `${startY}px`);
            
            cell.appendChild(piece);
            return true;
        }
    }
    return false; // कॉलम भरा हुआ है
}

function botMove() {
    if (!gameActive) return;
    
    let bestCol = findWinningMove('bot'); // जीतने की कोशिश करें
    if (bestCol === -1) bestCol = findWinningMove('user'); // उपयोगकर्ता को ब्लॉक करें
    if (bestCol === -1) bestCol = getRandomValidColumn(); // रैंडम चाल चलें
    
    if (bestCol !== -1 && dropPiece(bestCol, 'bot')) {
        if (checkWin('bot')) {
            endGame('bot');
        } else if (isBoardFull()) {
            endGame('draw');
        } else {
            currentPlayer = 'user';
        }
    }
}

function findWinningMove(player) {
    for (let col = 0; col < COLS; col++) {
        if (board[0][col] === null) { // केवल अगर कॉलम में जगह है
            for (let row = ROWS - 1; row >= 0; row--) {
                if (board[row][col] === null) {
                    board[row][col] = player; // अस्थायी रूप से चाल चलें
                    if (checkWin(player)) {
                        board[row][col] = null; // चाल वापस लें
                        return col;
                    }
                    board[row][col] = null; // चाल वापस लें
                    break; // इस कॉलम में और ऊपर जाँच करने की ज़रूरत नहीं
                }
            }
        }
    }
    return -1;
}

function getRandomValidColumn() {
    const validCols = [];
    for (let col = 0; col < COLS; col++) {
        if (board[0][col] === null) {
            validCols.push(col);
        }
    }
    return validCols.length > 0 ? validCols[Math.floor(Math.random() * validCols.length)] : -1;
}

function checkWin(player) {
    for (let row = 0; row < ROWS; row++) {
        for (let col = 0; col < COLS; col++) {
            if (board[row][col] === player) {
                if (checkWinAt(row, col, player)) {
                    return true;
                }
            }
        }
    }
    return false;
}

function checkWinAt(row, col, player) {
    const directions = [
        [0, 1], [1, 0], [1, 1], [1, -1]
    ];

    for (const [dr, dc] of directions) {
        const line = [[row, col]];
        
        // आगे की दिशा में
        for (let i = 1; i < 4; i++) {
            const newRow = row + dr * i;
            const newCol = col + dc * i;
            if (newRow >= 0 && newRow < ROWS && newCol >= 0 && newCol < COLS && board[newRow][newCol] === player) {
                line.push([newRow, newCol]);
            } else {
                break;
            }
        }

        // पीछे की दिशा में
        for (let i = 1; i < 4; i++) {
            const newRow = row - dr * i;
            const newCol = col - dc * i;
            if (newRow >= 0 && newRow < ROWS && newCol >= 0 && newCol < COLS && board[newRow][newCol] === player) {
                line.unshift([newRow, newCol]);
            } else {
                break;
            }
        }

        if (line.length >= 4) {
            line.forEach(([r, c]) => {
                const cell = boardElement.children[r * COLS + c];
                const piece = cell.querySelector('.piece');
                if (piece) piece.classList.add('win');
            });
            return true;
        }
    }
    return false;
}

function isBoardFull() {
    return board[0].every(cell => cell !== null);
}

function endGame(winner) {
    gameActive = false;
    boardElement.classList.add('game-over');
    
    let message = '';
    let reward = 0;
    
    if (winner === 'user') {
        message = 'You Win!';
        reward = currentBet * 2;
        playerBalance += reward;
        if (typeof confetti !== 'undefined') {
            confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
        }
    } else if (winner === 'bot') {
        message = 'You Lose!';
    } else {
        message = 'Draw!';
        reward = currentBet;
        playerBalance += reward;
    }
    
    winnerMessage.textContent = message;
    winnerMessage.style.display = 'block';
    
    setTimeout(() => {
        winnerMessage.style.display = 'none';
        currentBetDisplay.style.display = 'none';
        initializeBoard();
        updateBalanceDisplay();
    }, 3000);
}

// --- Event Listeners ---
startButton.addEventListener('click', openPopup);

howToPlayBtn.addEventListener('click', (e) => {
    e.preventDefault(); // पेज को जंप करने से रोकता है
    openHowToPlayPopup();
});

popupBackdrop.addEventListener('click', () => {
    closePopup(); 
    closeHowToPlayPopup(); 
});

betPopup.addEventListener('click', (e) => e.stopPropagation());
howToPlayPopup.addEventListener('click', (e) => e.stopPropagation());

document.getElementById('my-history').addEventListener('click', () => {
    alert('My History feature coming soon!');
});

document.getElementById('all-history').addEventListener('click', () => {
    alert('All History feature coming soon!');
});

// --- Initialize App ---
document.addEventListener('DOMContentLoaded', () => {
    fetchUserData();
    initializeBoard();
});
 
 </script>
 </body>
 </html>
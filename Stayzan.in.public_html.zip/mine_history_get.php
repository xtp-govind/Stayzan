<?php

// ✅ DB connection
$host = "localhost";
$user = "u976552851_party";
$password = "Govind@00#";
$database = "u976552851_party";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}


// कनेक्शन जांचें
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// 2. सेशन से यूजर आईडी प्राप्त करें (यह एक सुरक्षित तरीका है)
session_start();
if (!isset($_SESSION['unique_id'])) {
    // अगर यूजर लॉग इन नहीं है, तो खाली जवाब भेजें
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit();
}
$user_id = $_SESSION['unique_id']; // उदाहरण: 'AF2169'

// 3. डेटाबेस से डेटा प्राप्त करने के लिए SQL क्वेरी
// हाल के 10 रिकॉर्ड्स को सबसे नए से पुराने क्रम में लाएं
$sql = "SELECT grid_size, result, winnings, bet_amount, user_id FROM mine_bet WHERE user_id = ? ORDER BY played_at DESC LIMIT 10";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$history = [];
if ($result->num_rows > 0) {
  // हर एक रो को ऐरे में डालें
  while($row = $result->fetch_assoc()) {
    $history[] = $row;
  }
}

// 4. डेटा को JSON फॉर्मेट में आउटपुट करें
header('Content-Type: application/json');
echo json_encode(['status' => 'success', 'data' => $history]);

// कनेक्शन बंद करें
$stmt->close();
$conn->close();
?>

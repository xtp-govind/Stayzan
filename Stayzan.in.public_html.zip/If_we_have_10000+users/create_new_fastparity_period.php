<?php

// Database connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Function to distribute referral commission
function giveReferralCommission($conn, $from_user_id, $bet_amount) {
    $percentages = [1 => 1.0, 2 => 0.5, 3 => 0.3, 4 => 0.2, 5 => 0.1]; // %

    $stmt = $conn->prepare("SELECT * FROM referral_users WHERE unique_id = ?");
    $stmt->bind_param("s", $from_user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows == 0) return;

    $ref = $res->fetch_assoc();
    for ($level = 1; $level <= 5; $level++) {
        $to_user_id = $ref["level_$level"];
        if ($to_user_id) {
            $percent = $percentages[$level];
            $commission = ($bet_amount * $percent) / 100;

            // Insert commission record
            $stmtInsert = $conn->prepare("INSERT INTO referral_commissions (from_user_id, to_user_id, level, bet_amount, commission_percent, commission_amount)
                                          VALUES (?, ?, ?, ?, ?, ?)");
            $stmtInsert->bind_param("ssiidd", $from_user_id, $to_user_id, $level, $bet_amount, $percent, $commission);
            $stmtInsert->execute();

            // Update referral balance
            $stmtUpdate = $conn->prepare("UPDATE referral_rewards SET referral_balance = referral_balance + ? WHERE unique_id = ?");
            $stmtUpdate->bind_param("ds", $commission, $to_user_id);
            $stmtUpdate->execute();
        }
    }
}

// Step 1: Get active period
$sql = "SELECT period_id FROM fastparity_periods WHERE is_active = 1 ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows === 0) exit("No active period found.");
$current_period_id = $result->fetch_assoc()['period_id'];

// Step 2: Color map
$color_map = [
    'red' => [2, 4, 6, 8, 0],
    'green' => [1, 3, 7, 9, 5],
    'violet' => [0, 5]
];

// Step 3: Fetch all bets
$sql_bets = "SELECT unique_id, bet_type, bet_value, amount FROM fastparity_bets WHERE period_id = ?";
$stmt = $conn->prepare($sql_bets);
$stmt->bind_param("s", $current_period_id);
$stmt->execute();
$result = $stmt->get_result();

$all_bets = [];
foreach ($result as $row) $all_bets[] = $row;

// Step 4: Calculate minimum payout
$min_payout = PHP_INT_MAX;
$best_result = null;
$zero_bet_combinations = [];

for ($number = 0; $number <= 9; $number++) {
    $colors = ($number === 0 || $number === 5) ? ['violet'] : [];

    if ($number !== 0 && in_array($number, $color_map['red'])) $colors[] = 'red';
    if ($number !== 5 && in_array($number, $color_map['green'])) $colors[] = 'green';

    foreach ($colors as $color) {
        $total_payout = 0;
        $has_any_bet = false;

        foreach ($all_bets as $bet) {
            $amt = (float)$bet['amount'];

            // Color bet
            if ($bet['bet_type'] === 'color' && $bet['bet_value'] === $color) {
                $has_any_bet = true;
                if ($color === 'violet') $total_payout += $amt * 4.5;
                else $total_payout += $amt * 2;
            }

            // Number bet
            if ($bet['bet_type'] === 'number' && (int)$bet['bet_value'] === $number) {
                $has_any_bet = true;
                $total_payout += $amt * 9.5;
            }

            if ($bet['bet_type'] === 'color' && $bet['bet_value'] === 'red' && $number === 0) {
                $has_any_bet = true;
                $total_payout += $amt * 1.45;
            }

            if ($bet['bet_type'] === 'color' && $bet['bet_value'] === 'green' && $number === 5) {
                $has_any_bet = true;
                $total_payout += $amt * 1.45;
            }
        }

        if (!$has_any_bet) $zero_bet_combinations[] = ['number' => $number, 'color' => $color];

        if ($total_payout < $min_payout) {
            $min_payout = $total_payout;
            $best_result = ['number' => $number, 'color' => $color, 'payout' => $total_payout];
        }
    }
}

// Step 5: Final result choose
if (!empty($zero_bet_combinations)) {
    $chosen = $zero_bet_combinations[array_rand($zero_bet_combinations)];
    $winning_number = $chosen['number'];
    $winning_color = $chosen['color'];
} else {
    $winning_number = $best_result['number'];
    $winning_color = $best_result['color'];
}

// Step 6: Update result in DB
$sql_update = "UPDATE fastparity_periods SET is_active = 0, end_time = NOW(), winning_number = ?, winning_color = ? WHERE period_id = ?";
$stmt = $conn->prepare($sql_update);
$stmt->bind_param("iss", $winning_number, $winning_color, $current_period_id);
$stmt->execute();

// Step 7: Process each bet for win/loss and referral commission
foreach ($all_bets as $bet) {
    $uid = $bet['unique_id'];
    $amount = (float)$bet['amount'];
    $payout = 0;
    $is_win = false;

    // ✅ Referral commission
    giveReferralCommission($conn, $uid, $amount);

    // Check win condition
    if ($bet['bet_type'] === 'color') {
        if ($bet['bet_value'] === 'violet' && $winning_color === 'violet') {
            $payout = $amount * 4.5;
            $is_win = true;
        } elseif ($bet['bet_value'] === $winning_color && $winning_color !== 'violet' && !in_array($winning_number, [0, 5])) {
            $payout = $amount * 1.95;
            $is_win = true;
        } elseif ($bet['bet_value'] === 'red' && $winning_number == 0) {
            $payout = $amount * 1.45;
            $is_win = true;
        } elseif ($bet['bet_value'] === 'green' && $winning_number == 5) {
            $payout = $amount * 1.45;
            $is_win = true;
        }
    }

    if ($bet['bet_type'] === 'number' && (int)$bet['bet_value'] === $winning_number) {
        $payout += $amount * 9.45;
        $is_win = true;
    }

    if ($payout > 0) {
        $update_balance_sql = "UPDATE users SET balance = balance + ? WHERE unique_id = ?";
        $stmt = $conn->prepare($update_balance_sql);
        $stmt->bind_param("ds", $payout, $uid);
        $stmt->execute();
    }

    $status_amount = $is_win ? "+" . number_format($payout, 2, '.', '') : "-" . number_format($amount, 2, '.', '');

    $update_bet_sql = "UPDATE fastparity_bets SET result_number = ?, result_text = ?, status = ? WHERE period_id = ? AND unique_id = ? AND bet_type = ? AND bet_value = ?";
    $stmt = $conn->prepare($update_bet_sql);
    $stmt->bind_param("issssss", $winning_number, $winning_color, $status_amount, $current_period_id, $uid, $bet['bet_type'], $bet['bet_value']);
    $stmt->execute();
}

// Step 8: Create new period
$date_part = date('Ymd');
$seconds_since_midnight = time() - strtotime('today');
$period_number = floor($seconds_since_midnight / 30) + 1;
$new_period_id = $date_part . str_pad($period_number, 4, '0', STR_PAD_LEFT);

$sql_insert = "INSERT INTO fastparity_periods (period_id, start_time, is_active) VALUES (?, NOW(), 1)";
$stmt = $conn->prepare($sql_insert);
$stmt->bind_param("s", $new_period_id);
$stmt->execute();

echo "✅ Result: Number = $winning_number, Color = $winning_color, New Period: $new_period_id";
$conn->close();
?>
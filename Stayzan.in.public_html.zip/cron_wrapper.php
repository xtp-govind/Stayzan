<?php
// Increase script time limit to allow full 60 seconds
set_time_limit(60);

// Run the Fast Parity period script (first time)
file_get_contents("https://stayzan.in/create_new_fastparity_period.php");

// Wait 30 seconds
sleep(30);

// Run it again (second time)
file_get_contents("https://stayzan.in/create_new_fastparity_period.php");

echo "Fast Parity script executed twice with 30 seconds gap.";
?>
<?php
// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");


// Fetch all complaints
$result = $conn->query("SELECT * FROM complaints ORDER BY created_at DESC");

// Function to get status badge class
function getStatusClass($status)
{
    switch (strtolower($status)) {
        case 'resolved':
            return 'status-resolved';
        case 'in_progress':
            return 'status-in-progress';
        case 'closed':
            return 'status-closed';
        case 'pending':
        default:
            return 'status-pending';
    }
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="UTF-8">
  <title>एडमिन - शिकायत पैनल</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
      :root {
          --primary-color: #007bff;
          --success-color: #28a745;
          --warning-color: #ffc107;
          --info-color: #17a2b8;
          --secondary-color: #6c757d;
          --bg-color: #f4f7f9;
          --card-bg: #ffffff;
          --text-color: #333;
          --border-color: #e9ecef;
          --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
          --hover-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
      }
      body {
          font-family: 'Poppins', sans-serif;
          margin: 0;
          background-color: var(--bg-color);
          color: var(--text-color);
      }
      .container {
          padding: 20px;
          max-width: 1200px;
          margin: auto;
      }
      .header-container {
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
          margin-bottom: 25px;
      }
      .back-button {
          position: absolute;
          left: 0;
          top: 50%;
          transform: translateY(-50%);
          background: var(--card-bg);
          border: 1px solid var(--border-color);
          color: var(--primary-color);
          width: 40px;
          height: 40px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: var(--shadow);
      }
      .back-button:hover {
          background-color: var(--primary-color);
          color: white;
          transform: translateY(-50%) scale(1.1);
      }
      .page-header {
          margin: 0;
          font-size: 2rem;
          font-weight: 700;
          color: var(--primary-color);
      }
      .filter-container {
          background: var(--card-bg);
          padding: 15px 20px;
          border-radius: 12px;
          box-shadow: var(--shadow);
          margin-bottom: 25px;
          display: flex;
          flex-wrap: wrap;
          gap: 15px;
          align-items: center;
      }
      .filter-buttons {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          flex-grow: 1;
      }
      .filter-btn {
          background-color: #f0f0f0;
          border: 1px solid #ddd;
          color: #555;
          padding: 8px 18px;
          border-radius: 20px;
          cursor: pointer;
          font-weight: 500;
          transition: all 0.3s;
      }
      .filter-btn.active {
          background-color: var(--primary-color);
          color: white;
          border-color: var(--primary-color);
          box-shadow: 0 2px 8px rgba(0, 123, 255, 0.3);
      }
      .search-box {
          display: flex;
          align-items: center;
          position: relative;
      }
      .search-box i {
          position: absolute;
          left: 15px;
          color: #aaa;
      }
      #searchInput {
          padding: 8px 15px 8px 40px;
          border: 1px solid #ccc;
          border-radius: 20px;
          min-width: 220px;
          transition: border-color 0.3s;
      }
      #searchInput:focus {
          border-color: var(--primary-color);
          outline: none;
      }
      #no-results {
          display: none;
          text-align: center;
          padding: 40px;
          background: var(--card-bg);
          border-radius: 10px;
          box-shadow: var(--shadow);
          font-size: 1.2rem;
          color: var(--secondary-color);
      }
      #no-results i {
          font-size: 2.5rem;
          display: block;
          margin-bottom: 15px;
          color: var(--primary-color);
      }
      .desktop-table {
          width: 100%;
          border-collapse: collapse;
          background-color: var(--card-bg);
          box-shadow: var(--shadow);
          border-radius: 10px;
          overflow: hidden;
      }
      .desktop-table thead {
          background-color: var(--primary-color);
          color: white;
      }
      .desktop-table th, .desktop-table td {
          padding: 15px;
          text-align: left;
          vertical-align: middle;
      }
      .desktop-table tbody tr {
          border-bottom: 1px solid var(--border-color);
          transition: background-color 0.3s;
      }
      .desktop-table tbody tr:last-child {
          border-bottom: none;
      }
      .desktop-table tbody tr:hover {
          background-color: #f1f8ff;
      }
      .mobile-cards-container {
          display: none;
      }
      .complaint-card {
          background: var(--card-bg);
          border-radius: 12px;
          box-shadow: var(--shadow);
          margin-bottom: 20px;
          padding: 20px;
          border-left: 5px solid var(--primary-color);
          transition: all 0.3s ease;
      }
      .complaint-card:hover {
          transform: translateY(-5px);
          box-shadow: var(--hover-shadow);
      }
      .card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 15px;
          padding-bottom: 10px;
          border-bottom: 1px solid var(--border-color);
      }
      .card-header .ticket-id {
          font-weight: 600;
          font-size: 1.2rem;
          color: var(--primary-color);
      }
      .status-badge {
          padding: 5px 12px;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 600;
          color: #fff;
          text-transform: capitalize;
      }
      .status-pending { background-color: var(--warning-color); }
      .status-resolved { background-color: var(--success-color); }
      .status-in-progress { background-color: var(--info-color); }
      .status-closed { background-color: var(--secondary-color); }
      .card-body .info-row {
          display: flex;
          justify-content: space-between;
          padding: 8px 0;
          border-bottom: 1px solid #f5f5f5;
      }
      .card-body .info-row:last-child { border-bottom: none; }
      .card-body .info-row .label {
          font-weight: 600;
          color: #555;
          margin-right: 10px;
      }
      .card-body .info-row .value {
          text-align: right;
          color: #333;
          word-break: break-word;
      }
      .card-body .message, .card-body .admin-reply {
          margin-top: 15px;
          padding-top: 15px;
          border-top: 1px dashed var(--border-color);
      }
      .card-body .label {
          font-weight: 600;
          color: #555;
          display: block;
          margin-bottom: 5px;
      }
      .card-body .admin-reply p {
          margin: 0;
          padding: 10px;
          background: #f0f8ff;
          border-radius: 8px;
          font-style: italic;
          color: #005a9e;
      }
      .card-footer {
          margin-top: 20px;
          padding-top: 15px;
          border-top: 1px solid var(--border-color);
      }
      .card-footer .form-group {
          margin-bottom: 10px;
      }
      .card-footer label {
          display: block;
          font-weight: 600;
          margin-bottom: 5px;
      }
      select, input[type="text"] {
          padding: 10px 12px;
          border: 1px solid #ccc;
          border-radius: 8px;
          width: 100%;
          box-sizing: border-box;
          transition: border-color 0.3s;
      }
      select:focus, input[type="text"]:focus {
          border-color: var(--primary-color);
          outline: none;
      }
      .action-btn {
          background-color: var(--success-color);
          border: none;
          color: white;
          padding: 12px 15px;
          cursor: pointer;
          border-radius: 8px;
          font-weight: 600;
          width: 100%;
          text-align: center;
          transition: background-color 0.3s;
          font-size: 1rem;
      }
      .action-btn:hover {
          background-color: #218838;
      }
      .action-btn i { margin-right: 8px; }
      @media (max-width: 992px) {
          .desktop-table { display: none; }
          .mobile-cards-container { display: block; }
      }
      @media (max-width: 768px) {
          .filter-container { flex-direction: column; align-items: stretch; }
          .search-box { width: 100%; margin-top: 10px; }
          #searchInput { width: 100%; box-sizing: border-box; }
          .page-header { font-size: 1.8rem; }
          .back-button { width: 35px; height: 35px; }
      }
  </style>
</head>
<body>
  <div class="container">
    <div class="header-container">
        <a href="javascript:history.back()" class="back-button" aria-label="Go back">
            <i class="fas fa-arrow-left"></i>
        </a>
        <h1 class="page-header"><i class="fas fa-list-check"></i> शिकायत प्रबंधन</h1>
    </div>

    <div class="filter-container">
        <div class="filter-buttons">
            <button class="filter-btn active" data-status="all">All</button>
            <button class="filter-btn" data-status="pending">Pending</button>
            <button class="filter-btn" data-status="in_progress">In Progress</button>
            <button class="filter-btn" data-status="resolved">Resolved</button>
            <button class="filter-btn" data-status="closed">Closed</button>
        </div>
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Unique ID से खोजें...">
        </div>
    </div>

    <table class="desktop-table">
        <thead>
            <tr>
                <th>टिकट ID</th>
                <th>यूजर (Unique ID)</th>
                <th>समस्या</th>
                <th>स्टेटस</th>
                <th>जवाब</th>
                <th>एक्शन</th>
            </tr>
        </thead>
        <tbody id="desktop-tbody">
            <?php mysqli_data_seek($result, 0); ?>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr class="complaint-item" data-status="<?php echo strtolower($row['status']); ?>" data-unique-id="<?php echo htmlspecialchars($row['unique_id']); ?>">
                <td><strong><?php echo htmlspecialchars($row['ticket_id']); ?></strong></td>
                <td><?php echo htmlspecialchars($row['username']); ?> (<?php echo htmlspecialchars($row['unique_id']); ?>)</td>
                <td><?php echo htmlspecialchars($row['issue_type']); ?></td>
                <td>
                    <select id="status-desktop-<?php echo $row['id']; ?>">
                        <option value="pending" <?php if($row['status']=="pending") echo "selected"; ?>>Pending</option>
                        <option value="in_progress" <?php if($row['status']=="in_progress") echo "selected"; ?>>In Progress</option>
                        <option value="resolved" <?php if($row['status']=="resolved") echo "selected"; ?>>Resolved</option>
                        <option value="closed" <?php if($row['status']=="closed") echo "selected"; ?>>Closed</option>
                    </select>
                </td>
                <td><input type="text" id="status_text-desktop-<?php echo $row['id']; ?>" value="<?php echo htmlspecialchars($row['status_text']); ?>" placeholder="जवाब दें..."></td>
                <td><button class="action-btn" onclick="updateComplaint(<?php echo $row['id']; ?>, this, 'desktop')"><i class="fas fa-save"></i> Save</button></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <div class="mobile-cards-container" id="mobile-cards-container">
        <?php mysqli_data_seek($result, 0); ?>
        <?php while ($row = $result->fetch_assoc()): ?>
        <div class="complaint-card complaint-item" data-status="<?php echo strtolower($row['status']); ?>" data-unique-id="<?php echo htmlspecialchars($row['unique_id']); ?>">
            <div class="card-header">
                <div class="ticket-id"><?php echo htmlspecialchars($row['ticket_id']); ?></div>
                <div class="status-badge <?php echo getStatusClass($row['status']); ?>"><?php echo str_replace('_', ' ', $row['status']); ?></div>
            </div>
            <div class="card-body">
                <div class="info-row">
                    <span class="label">यूजर:</span>
                    <span class="value"><?php echo htmlspecialchars($row['username']); ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Unique ID:</span>
                    <span class="value"><?php echo htmlspecialchars($row['unique_id']); ?></span>
                </div>
                <div class="info-row">
                    <span class="label">समस्या:</span>
                    <span class="value"><?php echo htmlspecialchars($row['issue_type']); ?></span>
                </div>
                <div class="message">
                    <span class="label"><i class="fas fa-comment-dots"></i> संदेश:</span>
                    <p><?php echo htmlspecialchars($row['message']); ?></p>
                </div>
                <div class="admin-reply">
                    <span class="label"><i class="fas fa-user-shield"></i> एडमिन जवाब:</span>
                    <p><?php echo !empty($row['status_text']) ? htmlspecialchars($row['status_text']) : 'अभी कोई जवाब नहीं दिया गया है।'; ?></p>
                </div>
            </div>
            <div class="card-footer">
                <div class="form-group">
                    <label for="status-mobile-<?php echo $row['id']; ?>">स्टेटस बदलें</label>
                    <select id="status-mobile-<?php echo $row['id']; ?>">
                        <option value="pending" <?php if($row['status']=="pending") echo "selected"; ?>>Pending</option>
                        <option value="in_progress" <?php if($row['status']=="in_progress") echo "selected"; ?>>In Progress</option>
                        <option value="resolved" <?php if($row['status']=="resolved") echo "selected"; ?>>Resolved</option>
                        <option value="closed" <?php if($row['status']=="closed") echo "selected"; ?>>Closed</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status_text-mobile-<?php echo $row['id']; ?>">जवाब अपडेट करें</label>
                    <input type="text" id="status_text-mobile-<?php echo $row['id']; ?>" value="<?php echo htmlspecialchars($row['status_text']); ?>" placeholder="यहाँ नया जवाब टाइप करें...">
                </div>
                <button class="action-btn" onclick="updateComplaint(<?php echo $row['id']; ?>, this, 'mobile')">
                    <i class="fas fa-save"></i> अपडेट करें
                </button>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    
    <div id="no-results">
        <i class="fas fa-folder-open"></i>
        <p>कोई शिकायत नहीं मिली।<br>कृपया अपना फ़िल्टर बदल कर देखें।</p>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        const searchInput = document.getElementById('searchInput');
        const complaintItems = document.querySelectorAll('.complaint-item');
        const noResultsMessage = document.getElementById('no-results');
        let currentStatusFilter = 'all';

        function applyFilters() {
            const searchQuery = searchInput.value.toLowerCase().trim();
            let itemsFound = 0;

            complaintItems.forEach(item => {
                const itemStatus = item.getAttribute('data-status');
                const itemUniqueId = item.getAttribute('data-unique-id').toLowerCase();
                const statusMatch = (currentStatusFilter === 'all' || itemStatus === currentStatusFilter);
                const searchMatch = (itemUniqueId.includes(searchQuery));

                if (statusMatch && searchMatch) {
                    // For mobile cards
                    if (item.classList.contains('complaint-card')) {
                        item.style.display = 'block';
                    } 
                    // For desktop table rows
                    else {
                        item.style.display = 'table-row';
                    }
                    itemsFound++;
                } else {
                    item.style.display = 'none';
                }
            });

            noResultsMessage.style.display = itemsFound === 0 ? 'block' : 'none';
        }

        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                currentStatusFilter = this.getAttribute('data-status');
                applyFilters();
            });
        });

        searchInput.addEventListener('keyup', applyFilters);
        
        // Initial filter apply on load
        applyFilters();
    });
    
    function updateComplaint(id, button, view) {
        let status = document.getElementById("status-" + view + "-" + id).value;
        let status_text = document.getElementById("status_text-" + view + "-" + id).value;

        let postData = "id=" + id + "&status=" + status + "&status_text=" + encodeURIComponent(status_text);

        let originalButtonText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        button.disabled = true;

        let xhr = new XMLHttpRequest();
        // सुनिश्चित करें कि आप सही फ़ाइल नाम का उपयोग कर रहे हैं, जैसे 'update_complaint.php'
        xhr.open("POST", "user_complaints2", true); 
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

        xhr.onload = function () {
            if (this.status == 200 && this.responseText.trim() === "success") {
                alert("Complaint #" + id + " updated successfully!");
                window.location.reload();
            } else {
                alert("Error updating complaint: " + this.responseText);
                button.innerHTML = originalButtonText;
                button.disabled = false;
            }
        };

        xhr.onerror = function() {
            alert("Network error occurred.");
            button.innerHTML = originalButtonText;
            button.disabled = false;
        };

        xhr.send(postData);
    }
  </script>
</body>
</html>

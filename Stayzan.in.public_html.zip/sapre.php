<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chicken Road</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            color: white;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .logo-text {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .balance {
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 20px;
            border-radius: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            backdrop-filter: blur(10px);
        }

        .balance-amount {
            font-size: 18px;
            font-weight: bold;
        }

        .currency {
            background: #ffd700;
            color: #000;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .menu-btn {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 10px;
        }

        /* Game Stats */
        .game-stats {
            display: flex;
            gap: 30px;
            margin-bottom: 30px;
            padding: 0 10px;
        }

        .stat {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
        }

        .stat-indicator {
            color: #00ff88;
            font-size: 12px;
        }

        /* Game Area */
        .game-area {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 30px;
            min-height: 300px;
        }

        .road {
            width: 100%;
            max-width: 800px;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 15px;
            padding: 20px;
            backdrop-filter: blur(10px);
        }

        .lane {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            min-height: 80px;
            align-items: center;
        }

        .lane:last-child {
            margin-bottom: 0;
        }

        .multiplier-slot {
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .multiplier {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 16px;
            background: rgba(100, 120, 200, 0.8);
            border: 2px solid rgba(100, 120, 200, 1);
            transition: all 0.3s ease;
        }

        .multiplier.active {
            background: rgba(0, 255, 136, 0.8);
            border-color: #00ff88;
            box-shadow: 0 0 20px rgba(0, 255, 136, 0.5);
        }

        .chicken {
            font-size: 40px;
            animation: bounce 2s infinite;
        }

        .obstacle {
            font-size: 30px;
            animation: flicker 1s infinite alternate;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        @keyframes flicker {
            0% { opacity: 0.8; }
            100% { opacity: 1; }
        }

        /* Controls */
        .controls {
            background: rgba(0, 0, 0, 0.4);
            border-radius: 15px;
            padding: 25px;
            backdrop-filter: blur(10px);
        }

        .bet-controls {
            margin-bottom: 20px;
        }

        .bet-range {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 0 10px;
        }

        .range-label {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
        }

        .range-value {
            font-size: 18px;
            font-weight: bold;
        }

        .bet-amounts {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .bet-btn {
            flex: 1;
            min-width: 80px;
            padding: 12px 20px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border-radius: 10px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .bet-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.5);
        }

        .bet-btn.active {
            background: #ffd700;
            color: #000;
            border-color: #ffd700;
        }

        .difficulty-selector {
            margin-bottom: 20px;
        }

        .difficulty-dropdown {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .difficulty-dropdown option {
            background: #1a1a2e;
            color: white;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
        }

        .cash-out-btn {
            flex: 1;
            padding: 15px;
            background: #ffd700;
            color: #000;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }

        .cash-out-btn:hover {
            background: #ffed4e;
            transform: translateY(-2px);
        }

        .cash-amount {
            font-size: 14px;
            display: block;
            margin-top: 5px;
        }

        .play-btn {
            flex: 1;
            padding: 15px;
            background: #00ff88;
            color: #000;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            font-size: 18px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .play-btn:hover {
            background: #00e67a;
            transform: translateY(-2px);
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .logo-text {
                font-size: 20px;
            }
            
            .balance-amount {
                font-size: 16px;
            }
            
            .game-stats {
                justify-content: center;
                flex-wrap: wrap;
            }
            
            .road {
                padding: 15px;
            }
            
            .lane {
                min-height: 60px;
            }
            
            .multiplier-slot {
                width: 60px;
                height: 60px;
            }
            
            .multiplier {
                width: 50px;
                height: 50px;
                font-size: 14px;
            }
            
            .chicken {
                font-size: 30px;
            }
            
            .obstacle {
                font-size: 25px;
            }
            
            .controls {
                padding: 20px;
            }
            
            .bet-amounts {
                flex-direction: column;
            }
            
            .bet-btn {
                min-width: auto;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }

        @media (max-width: 480px) {
            .multiplier-slot {
                width: 45px;
                height: 45px;
            }
            
            .multiplier {
                width: 40px;
                height: 40px;
                font-size: 12px;
            }
            
            .chicken {
                font-size: 25px;
            }
            
            .obstacle {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <div class="logo">
                <div class="logo-icon">🐔</div>
                <span class="logo-text">CHICKEN ROAD</span>
            </div>
            <div class="header-right">
                <div class="balance">
                    <span class="balance-amount">1 000 000</span>
                    <span class="currency">$</span>
                </div>
                <button class="menu-btn">☰</button>
            </div>
        </header>

        <!-- Game Stats -->
        <div class="game-stats">
            <div class="stat">
                <span class="stat-label">Live wins</span>
                <span class="stat-indicator">●</span>
            </div>
            <div class="stat">
                <span class="stat-label">Online: 32884</span>
            </div>
        </div>

        <!-- Game Area -->
        <div class="game-area">
            <div class="road">
                <!-- Lane 1 -->
                <div class="lane">
                    <div class="multiplier-slot">
                        <div class="multiplier active">1.12x</div>
                    </div>
                    <div class="multiplier-slot">
                        <div class="multiplier">1.17x</div>
                    </div>
                    <div class="multiplier-slot">
                        <div class="multiplier">1.23x</div>
                    </div>
                    <div class="multiplier-slot">
                        <div class="multiplier">1.29x</div>
                    </div>
                    <div class="multiplier-slot">
                        <div class="multiplier">1.36x</div>
                    </div>
                    <div class="multiplier-slot">
                        <div class="multiplier">1.44x</div>
                    </div>
                </div>

                <!-- Lane 2 -->
                <div class="lane">
                    <div class="multiplier-slot">
                        <div class="chicken">🐔</div>
                    </div>
                    <div class="multiplier-slot">
                        <div class="obstacle">🔥</div>
                    </div>
                    <div class="multiplier-slot"></div>
                    <div class="multiplier-slot"></div>
                    <div class="multiplier-slot">
                        <div class="obstacle">🔥</div>
                    </div>
                    <div class="multiplier-slot"></div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <div class="controls">
            <div class="bet-controls">
                <div class="bet-range">
                    <span class="range-label">MIN</span>
                    <span class="range-value">0.6</span>
                    <span class="range-label">MAX</span>
                </div>
                
                <div class="bet-amounts">
                    <button class="bet-btn">0.5 $</button>
                    <button class="bet-btn active">1 $</button>
                    <button class="bet-btn">2 $</button>
                    <button class="bet-btn">7 $</button>
                </div>

                <div class="difficulty-selector">
                    <select class="difficulty-dropdown">
                        <option value="easy">Easy</option>
                        <option value="medium">Medium</option>
                        <option value="hard">Hard</option>
                        <option value="hardcore">Hardcore</option>
                    </select>
                </div>
            </div>

            <div class="action-buttons">
                <button class="cash-out-btn">
                    CASH OUT<br>
                    <span class="cash-amount">1.12 USD</span>
                </button>
                <button class="play-btn">GO</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Bet amount buttons
            const betButtons = document.querySelectorAll('.bet-btn');
            const cashOutBtn = document.querySelector('.cash-out-btn');
            const playBtn = document.querySelector('.play-btn');
            const difficultyDropdown = document.querySelector('.difficulty-dropdown');
            const chicken = document.querySelector('.chicken');
            const multipliers = document.querySelectorAll('.multiplier');
            
            let currentBet = 1;
            let gameActive = false;
            let currentMultiplier = 1.12;
            
            // Bet button functionality
            betButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Remove active class from all buttons
                    betButtons.forEach(btn => btn.classList.remove('active'));
                    // Add active class to clicked button
                    this.classList.add('active');
                    
                    // Extract bet amount from button text
                    currentBet = parseFloat(this.textContent.replace('$', '').trim());
                    updateCashOutAmount();
                });
            });
            
            // Difficulty selector
            difficultyDropdown.addEventListener('change', function() {
                const difficulty = this.value;
                updateMultipliers(difficulty);
            });
            
            // Play button functionality
            playBtn.addEventListener('click', function() {
                if (!gameActive) {
                    startGame();
                } else {
                    // Continue game logic
                    moveChicken();
                }
            });
            
            // Cash out button functionality
            cashOutBtn.addEventListener('click', function() {
                if (gameActive) {
                    cashOut();
                }
            });
            
            function startGame() {
                gameActive = true;
                playBtn.textContent = 'NEXT';
                playBtn.style.background = '#ff6b6b';
                
                // Reset chicken position
                resetChickenPosition();
                
                // Add some visual feedback
                chicken.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    chicken.style.transform = 'scale(1)';
                }, 200);
            }
            
            function moveChicken() {
                // Simulate chicken movement
                const lanes = document.querySelectorAll('.lane');
                const currentLane = Array.from(lanes).findIndex(lane => 
                    lane.querySelector('.chicken')
                );
                
                if (currentLane < lanes.length - 1) {
                    // Move chicken to next lane
                    const nextLane = lanes[currentLane + 1];
                    const currentChicken = lanes[currentLane].querySelector('.chicken');
                    
                    // Remove chicken from current position
                    currentChicken.remove();
                    
                    // Add chicken to next lane (first available slot)
                    const nextSlot = nextLane.querySelector('.multiplier-slot:not(:has(.multiplier)):not(:has(.obstacle))');
                    if (nextSlot) {
                        nextSlot.innerHTML = '<div class="chicken">🐔</div>';
                        
                        // Update multiplier
                        currentMultiplier += 0.05;
                        updateCashOutAmount();
                        
                        // Check if chicken reached the end
                        if (currentLane + 1 === lanes.length - 1) {
                            endGame(true);
                        }
                    } else {
                        // Hit obstacle
                        endGame(false);
                    }
                }
            }
            
            function cashOut() {
                if (gameActive) {
                    const winAmount = (currentBet * currentMultiplier).toFixed(2);
                    alert(`Cashed out! You won $${winAmount}`);
                    endGame(true);
                }
            }
            
            function endGame(won) {
                gameActive = false;
                playBtn.textContent = 'PLAY';
                playBtn.style.background = '#00ff88';
                
                if (!won) {
                    alert('Game Over! Chicken hit an obstacle.');
                }
                
                // Reset game state
                setTimeout(() => {
                    resetGame();
                }, 2000);
            }
            
            function resetGame() {
                currentMultiplier = 1.12;
                updateCashOutAmount();
                resetChickenPosition();
            }
            
            function resetChickenPosition() {
                // Remove chicken from all positions
                document.querySelectorAll('.chicken').forEach(chicken => chicken.remove());
                
                // Place chicken at starting position
                const firstLane = document.querySelector('.lane');
                const firstSlot = firstLane.querySelector('.multiplier-slot');
                firstSlot.innerHTML = '<div class="chicken">🐔</div>';
            }
            
            function updateCashOutAmount() {
                const cashAmount = document.querySelector('.cash-amount');
                const winAmount = (currentBet * currentMultiplier).toFixed(2);
                cashAmount.textContent = `${winAmount} USD`;
            }
            
            function updateMultipliers(difficulty) {
                const baseMultipliers = {
                    easy: [1.12, 1.17, 1.23, 1.29, 1.36, 1.44],
                    medium: [1.15, 1.22, 1.30, 1.39, 1.49, 1.60],
                    hard: [1.20, 1.30, 1.42, 1.56, 1.72, 1.90],
                    hardcore: [1.25, 1.40, 1.58, 1.80, 2.05, 2.35]
                };
                
                const multiplierValues = baseMultipliers[difficulty] || baseMultipliers.easy;
                
                multipliers.forEach((multiplier, index) => {
                    if (multiplierValues[index]) {
                        multiplier.textContent = `${multiplierValues[index]}x`;
                    }
                });
            }
            
            // Add some random obstacles
            function addRandomObstacles() {
                const lanes = document.querySelectorAll('.lane');
                lanes.forEach((lane, laneIndex) => {
                    if (laneIndex > 0) { // Skip first lane (where chicken starts)
                        const slots = lane.querySelectorAll('.multiplier-slot');
                        slots.forEach((slot, slotIndex) => {
                            if (Math.random() < 0.3 && !slot.querySelector('.multiplier')) {
                                slot.innerHTML = '<div class="obstacle">🔥</div>';
                            }
                        });
                    }
                });
            }
            
            // Initialize obstacles
            addRandomObstacles();
            
            // Add hover effects to multipliers
            multipliers.forEach(multiplier => {
                multiplier.addEventListener('mouseenter', function() {
                    this.style.transform = 'scale(1.1)';
                    this.style.boxShadow = '0 0 25px rgba(100, 120, 200, 0.8)';
                });
                
                multiplier.addEventListener('mouseleave', function() {
                    this.style.transform = 'scale(1)';
                    this.style.boxShadow = 'none';
                });
            });
            
            // Add click effect to buttons
            document.querySelectorAll('button').forEach(button => {
                button.addEventListener('click', function() {
                    this.style.transform = 'scale(0.95)';
                    setTimeout(() => {
                        this.style.transform = 'scale(1)';
                    }, 150);
                });
            });
            
            // Update balance animation
            function updateBalance() {
                const balanceAmount = document.querySelector('.balance-amount');
                const currentBalance = parseInt(balanceAmount.textContent.replace(/\s/g, ''));
                
                // Simulate balance changes
                setInterval(() => {
                    const change = Math.floor(Math.random() * 1000) - 500;
                    const newBalance = Math.max(0, currentBalance + change);
                    balanceAmount.textContent = newBalance.toLocaleString().replace(/,/g, ' ');
                }, 10000);
            }
            
            // Initialize balance updates
            updateBalance();
            
            // Add online count animation
            function updateOnlineCount() {
                const onlineStat = document.querySelector('.stat:last-child .stat-label');
                let count = 32884;
                
                setInterval(() => {
                    count += Math.floor(Math.random() * 10) - 5;
                    count = Math.max(30000, Math.min(35000, count));
                    onlineStat.textContent = `Online: ${count}`;
                }, 5000);
            }
            
            // Initialize online count updates
            updateOnlineCount();
        });
    </script>
</body>
</html>


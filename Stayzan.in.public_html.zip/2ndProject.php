<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Admin App</title>
    <style>
        /* --- Google Fonts --- */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap');

        /* --- CSS Variables (Theme) --- */
        :root {
            --primary-color: #5E56F0; /* Vibrant Purple */
            --background-color: #F7F7F9;
            --card-bg: #FFFFFF;
            --text-dark: #1A1A1A;
            --text-light: #8A8A8E;
            --shadow: 0 4px 25px rgba(0, 0, 0, 0.05);
            --border-radius: 20px;
        }

        * {
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            margin: 0;
            background-color: var(--background-color);
            color: var(--text-dark);
            /* Bottom padding to ensure content isn't hidden by the nav bar */
            padding-bottom: 90px; 
        }

        /* --- Main App Container --- */
        .app-container {
            padding: 20px;
        }

        /* --- App Header --- */
        .app-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .header-greeting h1 {
            font-size: 1.8em;
            font-weight: 800;
            margin: 0;
        }
        .header-greeting p {
            color: var(--text-light);
            font-size: 1em;
            margin: 0;
        }

        .header-profile img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }

        /* --- Summary Section --- */
        .section-title {
            font-size: 1.3em;
            font-weight: 700;
            margin-bottom: 15px;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: 1fr 1fr; /* Two columns */
            gap: 15px;
        }

        .summary-card {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: var(--shadow);
        }

        .summary-card .icon {
            font-size: 1.5em;
            margin-bottom: 12px;
            padding: 10px;
            border-radius: 12px;
            display: inline-block;
            color: #fff;
        }
        
        .summary-card .icon.users { background-color: #5E56F0; }
        .summary-card .icon.recharge { background-color: #34C759; }
        .summary-card .icon.withdrawal { background-color: #FF3B30; }
        .summary-card .icon.complaints { background-color: #FF9500; }

        .summary-card .value {
            font-size: 1.5em;
            font-weight: 800;
            margin-bottom: 4px;
        }

        .summary-card .label {
            font-size: 0.9em;
            color: var(--text-light);
            font-weight: 600;
        }
        
        /* --- Quick Actions Section --- */
        .actions-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
            margin-top: 30px;
        }

        .action-button {
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px 10px;
            text-align: center;
            box-shadow: var(--shadow);
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 600;
            font-size: 0.9em;
        }

        .action-button i {
            font-size: 1.6em;
            margin-bottom: 10px;
            color: var(--primary-color);
        }

        /* --- Bottom Tab Bar --- */
        .bottom-tab-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 75px;
            background-color: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-top: 1px solid #EFEFF4;
            display: flex;
            justify-content: space-around;
            align-items: center;
            padding: 0 10px;
        }

        .tab-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            color: var(--text-light);
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .tab-item i {
            font-size: 1.5em;
            margin-bottom: 4px;
        }

        .tab-item span {
            font-size: 0.75em;
            font-weight: 600;
        }

        .tab-item.active {
            color: var(--primary-color);
        }

    </style>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <div class="app-container">
        <!-- App Header -->
        <header class="app-header">
            <div class="header-greeting">
                <p>Welcome Back,</p>
                <h1>Admin</h1>
            </div>
            <div class="header-profile">
                <!-- You can use a real profile picture here -->
                <img src="https://i.pravatar.cc/100" alt="Profile">
            </div>
        </header>

        <!-- Summary Section -->
        <section class="summary-section">
            <h2 class="section-title">Today's Overview</h2>
            <div class="summary-grid">
                <div onclick="window.location.href='total_user_bta'" class="summary-card">
                    <div class="icon users"><i class="fas fa-users"></i></div>
                    <div class="value">1,250</div>
                    <div class="label">Total Users</div>
                </div>
                <div class="summary-card">
                    <div class="icon recharge"><i class="fas fa-arrow-up"></i></div>
                    <div class="value">₹50K</div>
                    <div class="label">Recharge</div>
                </div>
                <div onclick="window.location.href='user_withdrawal'" class="summary-card">
                    <div class="icon withdrawal"><i class="fas fa-arrow-down"></i></div>
                    <div class="value">₹22K</div>
                    <div class="label">Withdrawal</div>
                </div>
                <div onclick="window.location.href='user_complaints'" class="summary-card">
                    <div class="icon complaints"><i class="fas fa-exclamation-circle"></i></div>
                    <div class="value">15</div>
                    <div class="label">Complaints</div>
                </div>
            </div>
        </section>

        <!-- Quick Actions Section -->
        <section class="actions-section">
            <h2 class="section-title">Quick Actions</h2>
            <div class="actions-grid">
                <a href="#" class="action-button">
                    <i class="fas fa-bolt"></i>
                    <div>FastBet</div>
                </a>
                <a href="#" class="action-button">
                    <i class="fas fa-equals"></i>
                    <div>ParityBet</div>
                </a>
                <a href="#" class="action-button">
                    <i class="fas fa-trophy"></i>
                    <div>Leaderboard</div>
                </a>
            </div>
        </section>
    </div>

    <!-- Bottom Tab Bar -->
    <nav class="bottom-tab-bar">
        <a href="#" class="tab-item active">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="#" class="tab-item">
            <i class="fas fa-users"></i>
            <span>Users</span>
        </a>
        <a href="#" class="tab-item">
            <i class="fas fa-chart-bar"></i>
            <span>Reports</span>
        </a>
        <a href="#" class="tab-item">
            <i class="fas fa-cog"></i>
            <span>Settings</span>
        </a>
    </nav>

    <script>
        // JavaScript for active tab item
        const tabItems = document.querySelectorAll('.bottom-tab-bar .tab-item');
        tabItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                tabItems.forEach(i => i.classList.remove('active'));
                item.classList.add('active');
            });
        });
    </script>

</body>
</html>

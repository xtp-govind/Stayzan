<?php

session_start();

$prefill_message = '';
$prefill_issue_type = '';

if (isset($_GET['transaction_id'])) {

    $txn_id = htmlspecialchars($_GET['transaction_id']);
    $amount = htmlspecialchars($_GET['amount']);
    $status = htmlspecialchars($_GET['status']);
    $time = htmlspecialchars($_GET['time']);

    $prefill_message = "Regarding Transaction ID: {$txn_id}\n" .
                       "Amount: ₹{$amount}\n" .
                       "Status: {$status}\n" .
                       "Date: {$time}\n\n" .
                       "Please check this transaction.";
    
    $prefill_issue_type = 'Recharge';
    
    $_SESSION['active_tab_override'] = 'write_complaint';
}

// Database Connection
$host = "localhost"; $user = "u976552851_hellogovind"; $password = "Govind@00#"; $database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) { die("Database connection failed: " . $conn->connect_error); }

// Safely get session variables
$session_unique_id = $_SESSION['unique_id'] ?? null;
$session_username = $_SESSION['name'] ?? 'Guest';

if (is_null($session_unique_id)) {
    die("Authentication error: You must be logged in to view this page.");
}

// Check for a success message from the session (after redirect)
$form_message = $_SESSION['form_message'] ?? '';
$form_message_type = $_SESSION['form_message_type'] ?? '';
// Unset them so they don't show up again on the next refresh
unset($_SESSION['form_message']);
unset($_SESSION['form_message_type']);

 //active_tab_override here 
$active_tab = 'my_complaints'; 
if (isset($_SESSION['active_tab_override'])) {
    $active_tab = $_SESSION['active_tab_override'];
    unset($_SESSION['active_tab_override']);
} 

elseif (!empty($form_message)) {
    $active_tab = 'write_complaint';
}


// --- PRG Pattern Implementation ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_complaint'])) {
    $issue_type = $_POST['issue_type']; 
    $message = $_POST['message'];
    
    // Using a placeholder for the BIGINT user_id. You should replace this with the actual logged-in user's numeric ID.
    $complaint_user_id = $_SESSION['user_id_numeric'] ?? rand(1, 1000); 
    $ticket_id = 'TKT-' . strtoupper(substr(md5(time()), 0, 6));
    
    $stmt = $conn->prepare("INSERT INTO complaints (user_id, username, unique_id, issue_type, message, ticket_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $complaint_user_id, $session_username, $session_unique_id, $issue_type, $message, $ticket_id);
    
    if ($stmt->execute()) {
        // Store success message in session
        $_SESSION['form_message'] = "Your complaint has been submitted. Ticket ID: " . $ticket_id;
        $_SESSION['form_message_type'] = 'success';
    } else {
        // Store error message in session
        $_SESSION['form_message'] = "Error: " . $stmt->error;
        $_SESSION['form_message_type'] = 'error';
    }
    $stmt->close();

    // **REDIRECT STEP**
    // Redirect to the same page to prevent form resubmission.
    // The exit() is crucial to stop further script execution.
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Fetch complaints (this now runs on a clean GET request)
$complaints_result = $conn->query("SELECT ticket_id, issue_type, message, status, status_text, created_at FROM complaints WHERE unique_id = '$session_unique_id' ORDER BY created_at DESC");

function getIconForIssueType($issueType) {
    switch ($issueType) {
        case 'Payment Issue': return 'fa-wallet';
        case 'Technical Glitch': return 'fa-cogs';
        case 'Account Problem': return 'fa-user-circle';
        case 'Recharge': return 'fa-bolt';
        case 'Withdrawal': return 'fa-money-bill-wave';
        case 'Password Problem': return 'fa-key';
        case 'Signup': return 'fa-user-plus';
        case 'Bank or UPI': return 'fa-university';
        case 'Account Blocked': return 'fa-user-lock';
        case 'Referral': return 'fa-users';
        default: return 'fa-info-circle';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help & Support</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #007AFF; --primary-hover: #0056b3; --background-color: #f0f2f5;
            --card-background: #ffffff; --text-primary: #1d2129; --text-secondary: #606770;
            --border-color: #e9ecef; --shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
            --status-pending-bg: #fff8e1; --status-pending-text: #f57c00;
            --status-resolved-bg: #e8f5e9; --status-resolved-text: #388e3c;
            --status-in-progress-bg: #e3f2fd; --status-in-progress-text: #1976d2;
            --status-closed-bg: #fbe9e7; --status-closed-text: #d84315;
        }
        html { scroll-behavior: smooth; }
        body {
            font-family: 'Poppins', sans-serif; background-color: var(--background-color);
            color: var(--text-primary); margin: 0; padding-top: 125px;
        }
        .fixed-header {
            position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--border-color);
        }
        .top-bar {
            display: flex; justify-content: space-between; align-items: center;
            padding: 8px 16px;
        }
        .top-bar .title { font-size: 1.15em; font-weight: 600; }
        .top-bar .icon-btn {
            background: transparent; border: none; cursor: pointer; font-size: 1.2em;
            color: var(--text-secondary); width: 40px; height: 40px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center; transition: background-color 0.2s ease;
        }
        .top-bar .icon-btn:hover { background-color: #e9e9eb; }
        .tab-nav { display: flex; padding: 0 10px; }
        .tab-btn {
            flex: 1; padding: 12px; text-align: center; background: transparent; border: none;
            border-bottom: 3px solid transparent; font-size: 0.95em; font-weight: 600;
            color: var(--text-secondary); cursor: pointer; transition: color 0.3s, border-color 0.3s;
        }
        .tab-btn.active { color: var(--primary-color); border-bottom: 3px solid var(--primary-color); }
        .container { max-width: 800px; margin: 0 auto; padding: 15px; }
        .tab-content { display: none; }
        .tab-content.active { display: block; animation: fadeIn 0.5s; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        .card {
            background-color: var(--card-background); border-radius: 16px; padding: 25px;
            box-shadow: var(--shadow); border: 1px solid var(--border-color);
        }
        .card h2 {
            margin-top: 0; margin-bottom: 25px; font-size: 1.3em; font-weight: 600;
            border-bottom: 1px solid var(--border-color); padding-bottom: 15px;
        }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 8px; font-size: 0.9em; }
        .form-group select, .form-group textarea {
            width: 100%; padding: 12px; border: 1px solid #dcdfe6; border-radius: 10px;
            font-size: 1em; box-sizing: border-box; transition: border-color 0.3s, box-shadow 0.3s;
        }
        .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 3px rgba(0, 122, 255, 0.15);
        }
        .btn-submit {
            width: 100%; padding: 14px; background: var(--primary-color); color: white;
            border: none; border-radius: 10px; font-size: 1.05em; font-weight: 600;
            cursor: pointer; transition: background-color 0.2s, transform 0.2s;
        }
        .btn-submit:hover { background-color: var(--primary-hover); transform: translateY(-2px); }
        .form-message { margin-top: 15px; padding: 12px; border-radius: 10px; text-align: center; font-size: 0.9em; }
        .form-message.success { background-color: #e8f5e9; border: 1px solid #a5d6a7; color: #2e7d32; }
        .form-message.error { background-color: #ffebee; border: 1px solid #ef9a9a; color: #c62828; }

        .complaint-card-new {
            background: var(--card-background); border-radius: 12px; margin-bottom: 15px;
            box-shadow: var(--shadow); border: 1px solid var(--border-color); overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .complaint-card-new:hover { transform: translateY(-4px); box-shadow: 0 6px 25px rgba(0,0,0,0.08); }
        .card-main-content { display: flex; align-items: center; padding: 18px; }
        .card-icon { font-size: 1.8em; color: var(--primary-color); margin-right: 18px; width: 45px; text-align: center; }
        .card-details { flex-grow: 1; }
        .card-details h3 { margin: 0 0 4px 0; font-size: 1.05em; font-weight: 600; }
        .card-details .ticket-id { font-size: 0.85em; color: var(--text-secondary); font-family: monospace; }
        .card-footer-new {
            background-color: #f8f9fa; padding: 12px 18px; display: flex;
            justify-content: space-between; align-items: center; border-top: 1px solid var(--border-color);
        }
        .status-tag {
            display: inline-flex; align-items: center; padding: 5px 12px;
            border-radius: 20px; font-size: 0.8em; font-weight: 500;
        }
        .status-tag i { margin-right: 6px; }
        .status-pending { background-color: var(--status-pending-bg); color: var(--status-pending-text); }
        .status-resolved { background-color: var(--status-resolved-bg); color: var(--status-resolved-text); }
        .status-in-progress { background-color: var(--status-in-progress-bg); color: var(--status-in-progress-text); }
        .status-closed { background-color: var(--status-closed-bg); color: var(--status-closed-text); }
        .details-btn {
            background-color: var(--primary-color); color: white; text-decoration: none;
            padding: 7px 14px; border-radius: 8px; font-size: 0.85em; font-weight: 500;
            transition: background-color 0.2s ease; border: none; cursor: pointer;
        }
        .details-btn:hover { background-color: var(--primary-hover); }
        .no-complaints {
            text-align: center; padding: 40px; background: var(--card-background);
            border-radius: 16px; color: var(--text-secondary); border: 2px dashed var(--border-color);
        }

        /* --- Fixed Modal/Popup Styles --- */
        .modal-overlay {
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0, 0, 0, 0.6); z-index: 2000;
            display: flex; align-items: flex-end; justify-content: center;
            opacity: 0; visibility: hidden; transition: opacity 0.3s, visibility 0.3s;
        }
        .modal-overlay.active { opacity: 1; visibility: visible; }
        .modal-content {
            background: var(--background-color); width: 100%; max-width: 800px;
            border-radius: 20px 20px 0 0;
            box-shadow: 0 -5px 30px rgba(0,0,0,0.15);
            transform: translateY(100%); transition: transform 0.4s ease-out;
            max-height: 85vh; display: flex; flex-direction: column;
        }
        .modal-overlay.active .modal-content { transform: translateY(0); }
        
        .modal-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-color);
            background: white;
            border-radius: 20px 20px 0 0;
        }
        .modal-header-top {
            display: flex; justify-content: space-between; align-items: center;
        }
        .modal-header-top .ticket-id { font-size: 0.9em; color: var(--text-secondary); font-weight: 500; }
        .modal-close-btn {
            background: #e0e0e0; border: none; border-radius: 50%; width: 30px; height: 30px;
            font-size: 1em; cursor: pointer; display: flex; align-items: center; justify-content: center;
        }
        .modal-header-bottom {
            margin-top: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-header-bottom .subject { font-size: 1.2em; font-weight: 600; color: var(--text-primary); }
        
        .modal-body {
            padding: 20px;
            overflow-y: auto;
        }
        .chat-container { display: flex; flex-direction: column; gap: 20px; }
        .chat-message { max-width: 80%; padding: 12px 16px; border-radius: 18px; line-height: 1.5; }
        .chat-message .author { font-weight: 700; margin-bottom: 5px; font-size: 0.9em; }
        .user-message {
            background: var(--primary-color); color: white;
            border-bottom-left-radius: 4px; align-self: flex-start;
        }
        .support-message {
            background: var(--card-background); color: var(--text-primary);
            border: 1px solid var(--border-color); border-bottom-right-radius: 4px;
            align-self: flex-end;
        }
    </style>
</head>
<body>

    <!-- The rest of your HTML remains exactly the same... -->
    <header class="fixed-header">
        <div class="top-bar">
            <button class="icon-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
            <h1 class="title">Help & Support</h1>
            <button class="icon-btn"><i class="fas fa-question-circle"></i></button>
        </div>
        <nav class="tab-nav">
            <button class="tab-btn <?php echo ($active_tab == 'my_complaints') ? 'active' : ''; ?>" data-tab="my_complaints">My Complaints</button>
            <button class="tab-btn <?php echo ($active_tab == 'write_complaint') ? 'active' : ''; ?>" data-tab="write_complaint">Write Complaint</button>
        </nav>
    </header>

    <div class="container">
        <div id="my_complaints" class="tab-content <?php echo ($active_tab == 'my_complaints') ? 'active' : ''; ?>">
            <?php if ($complaints_result && $complaints_result->num_rows > 0): ?>
                <?php while($row = $complaints_result->fetch_assoc()):
                    $status_class = 'status-' . str_replace('_', '-', $row['status'] ?? 'pending');
                    $status_text = ucfirst(str_replace('_', ' ', $row['status'] ?? 'pending'));
                    $issue_icon = getIconForIssueType($row['issue_type']);
                    $status_icon = 'fa-clock';
                    if ($row['status'] == 'resolved') $status_icon = 'fa-check-circle';
                    if ($row['status'] == 'in_progress') $status_icon = 'fa-spinner fa-spin';
                    if ($row['status'] == 'closed') $status_icon = 'fa-times-circle';
                ?>
                <div class="complaint-card-new">
                    <div class="card-main-content">
                        <div class="card-icon"><i class="fas <?php echo $issue_icon; ?>"></i></div>
                        <div class="card-details">
                            <h3><?php echo htmlspecialchars($row['issue_type']); ?></h3>
                            <p class="ticket-id">Ticket ID: <?php echo htmlspecialchars($row['ticket_id']); ?></p>
                        </div>
                    </div>
                    <div class="card-footer-new">
                        <div class="status-tag <?php echo $status_class; ?>">
                            <i class="fas <?php echo $status_icon; ?>"></i><span><?php echo $status_text; ?></span>
                        </div>
                        <button class="details-btn" 
                            data-ticket-id="<?php echo htmlspecialchars($row['ticket_id']); ?>"
                            data-issue-type="<?php echo htmlspecialchars($row['issue_type']); ?>"
                            data-user-message="<?php echo htmlspecialchars($row['message']); ?>"
                            data-support-message="<?php echo htmlspecialchars($row['status_text'] ?? ''); ?>"
                            data-status-class="<?php echo $status_class; ?>"
                            data-status-text="<?php echo $status_text; ?>"
                            data-status-icon="<?php echo $status_icon; ?>">
                            View Details
                        </button>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="no-complaints"><p>You haven't submitted any complaints yet.</p></div>
            <?php endif; ?>
        </div>

        <div id="write_complaint" class="tab-content <?php echo ($active_tab == 'write_complaint') ? 'active' : ''; ?>">
            <div class="card">
                <h2>Submit a New Complaint</h2>
                <form action="" method="POST">
                    
<div class="form-group">
    <label for="issue_type">Type of Issue</label>
    <select id="issue_type" name="issue_type" required>
        <option value="" disabled <?php echo empty($prefill_issue_type) ? 'selected' : ''; ?>>-- Select an issue type --</option>
        <option value="Recharge" <?php echo ($prefill_issue_type == 'Recharge') ? 'selected' : ''; ?>>Recharge</option>
        <option value="Withdrawal" <?php echo ($prefill_issue_type == 'Withdrawal') ? 'selected' : ''; ?>>Withdrawal</option>
        <option value="Password Problem" <?php echo ($prefill_issue_type == 'Password Problem') ? 'selected' : ''; ?>>Password Problem</option>
        <option value="Signup" <?php echo ($prefill_issue_type == 'Signup') ? 'selected' : ''; ?>>Signup</option>
        <option value="Referral" <?php echo ($prefill_issue_type == 'Referral') ? 'selected' : ''; ?>>Referral</option>
        <option value="Bank or UPI" <?php echo ($prefill_issue_type == 'Bank or UPI') ? 'selected' : ''; ?>>Bank or UPI</option>
        <option value="Account Blocked" <?php echo ($prefill_issue_type == 'Account Blocked') ? 'selected' : ''; ?>>Account Blocked</option>
        <option value="Other" <?php echo ($prefill_issue_type == 'Other') ? 'selected' : ''; ?>>Other</option>
    </select>
</div>

                    
                    <div class="form-group">
                        <label for="message">Describe your issue</label>
                        <textarea id="message" name="message" rows="5" placeholder="Write your complaint here..." required><?php echo $prefill_message; ?></textarea>
                    </div>
                    <button type="submit" name="submit_complaint" class="btn-submit">Submit Complaint</button>
                </form>
                <?php if (!empty($form_message) && $active_tab == 'write_complaint'): ?>
                    <p class="form-message <?php echo $form_message_type; ?>"><?php echo $form_message; ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal Popup -->
    <div class="modal-overlay" id="details-modal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-header-top">
                    <span class="ticket-id" id="modal-ticket-id"></span>
                    <button class="modal-close-btn" id="modal-close"><i class="fas fa-times"></i></button>
                </div>
                <div class="modal-header-bottom">
                    <span class="subject" id="modal-subject"></span>
                    <div id="modal-status" class="status-tag"></div>
                </div>
            </div>
            <div class="modal-body">
                <div class="chat-container">
                    <div class="chat-message user-message">
                        <div class="author">Me</div>
                        <p id="modal-user-message"></p>
                    </div>
                    <div class="chat-message support-message" id="modal-support-block" style="display: none;">
                        <div class="author">Stayzan (Support)</div>
                        <p id="modal-support-message"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');
        const modalOverlay = document.getElementById('details-modal');
        const modalCloseBtn = document.getElementById('modal-close');
        const detailsButtons = document.querySelectorAll('.details-btn');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                button.classList.add('active');
                document.getElementById(button.dataset.tab).classList.add('active');
            });
        });

        detailsButtons.forEach(button => {
            button.addEventListener('click', () => {
                const data = button.dataset;
                
                document.getElementById('modal-ticket-id').textContent = `Ticket ID: ${data.ticketId}`;
                document.getElementById('modal-subject').textContent = data.issueType;
                
                const modalStatus = document.getElementById('modal-status');
                modalStatus.className = `status-tag ${data.statusClass}`;
                modalStatus.innerHTML = `<i class="fas ${data.statusIcon}"></i><span>${data.statusText}</span>`;
                
                document.getElementById('modal-user-message').textContent = data.userMessage;
                
                const supportBlock = document.getElementById('modal-support-block');
                if (data.supportMessage && data.supportMessage.trim() !== '') {
                    document.getElementById('modal-support-message').textContent = data.supportMessage;
                    supportBlock.style.display = 'block';
                } else {
                    supportBlock.style.display = 'none';
                }

                modalOverlay.classList.add('active');
            });
        });

        const closeModal = () => modalOverlay.classList.remove('active');
        modalCloseBtn.addEventListener('click', closeModal);
        modalOverlay.addEventListener('click', (e) => {
            if (e.target === modalOverlay) {
                closeModal();
            }
        });
    });
    </script>

</body>
</html>

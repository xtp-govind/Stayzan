<?php
session_start(); // session chalu karna zaruri hai
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'DB connection failed']);
    exit;
}

// ✅ Session se unique_id uthao
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit;
}
$unique_id = $_SESSION['unique_id'];

// ✅ Fetch referral commissions
$stmt = $conn->prepare("SELECT * FROM referral_commissions WHERE to_user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("s", $unique_id);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        'from_user' => $row['from_user_id'],
        'level' => $row['level'],
        'bet_amount' => $row['bet_amount'],
        'percent' => $row['commission_percent'],
        'commission' => $row['commission_amount'],
        'date' => $row['created_at']
    ];
}

echo json_encode([
    'status' => 'success',
    'total_records' => count($data),
    'commissions' => $data
]);

$conn->close();
<?php
session_start(); // ✅ Session start zaroori hai
// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['unique_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit;
}

$uid = $_SESSION['unique_id'];

// Prepare SQL statement to avoid SQL injection
$stmt = $conn->prepare("SELECT balance FROM users WHERE unique_id = ?");
$stmt->bind_param("s", $uid);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode(['status' => 'success', 'balance' => floatval($row['balance'])]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'User not found']);
}
?>
<?php
// ============== CONFIGURATION =================
date_default_timezone_set("Asia/Kolkata");
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
// बदला हुआ: यहाँ भी वही नई, सुरक्षित की डालें
$secret_key = "K#uT$8&z@!pLqW9*rE$vY2bN"; 
$reward_amount = 5;
$daily_limit = 2000;

// ============== DATABASE CONNECTION =================
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    die("⛔ A technical issue occurred. Please try again later.");
}

// ============== INITIALIZATION =================
$today = date("Y-m-d");
$notification = null;
$claimed = false;
$history = [];
$current_balance = null;

// ============== SECURITY CHECK (अब एक्सपायरी लॉजिक के साथ) =================
// 1. URL से सभी ज़रूरी पैरामीटर प्राप्त करें
if (!isset($_GET['lifafa_id']) || !isset($_GET['code']) || !isset($_GET['t'])) {
    die("⛔ Invalid link.");
}
$lifafa_id = $_GET['lifafa_id'];
$received_code = $_GET['code'];
$timestamp = $_GET['t'];

// 2. (नया) लिंक की उम्र जांचें - क्या यह 6 घंटे से ज़्यादा पुराना है?
$link_age_in_seconds = time() - $timestamp;
$six_hours_in_seconds = 6 * 60 * 60; // 6 घंटे * 60 मिनट * 60 सेकंड

if ($link_age_in_seconds > $six_hours_in_seconds) {
    die("⛔  Expired link.");
}

// 3. सही कोड जेनरेट करें और तुलना करें (timestamp के साथ)
$expected_code = md5($today . $lifafa_id . $timestamp . $secret_key);
if ($received_code !== $expected_code) {
    die("⛔ यह लिंक अमान्य है या इसके साथ छेड़छाड़ की गई है।");
}

// ============== FORM PROCESSING (यह हिस्सा पहले जैसा ही रहेगा) =================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mobile'])) {
    // ... (यहाँ से आगे का आपका पूरा FORM PROCESSING कोड जैसा था, वैसा ही रहेगा)
    // ... (यह lifafa_id के आधार पर क्लेम को चेक करेगा और इनाम देगा)
    $mobile = $_POST['mobile'];
    $stmt = $conn->prepare("SELECT unique_id, balance FROM users WHERE mobile = ?");
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $notification = ['type' => 'error', 'text' => 'This mobile number is not registered.'];
    } else {
        $userData = $result->fetch_assoc();
        $unique_id = $userData['unique_id'];
        $current_balance = $userData['balance'];

        $stmt_check = $conn->prepare("SELECT id FROM lucky_lifafa_rewards WHERE unique_id = ? AND reward_date = ? AND lifafa_id = ?");
        $stmt_check->bind_param("sss", $unique_id, $today, $lifafa_id);
        $stmt_check->execute();
        $already_claimed_result = $stmt_check->get_result();

        if ($already_claimed_result->num_rows > 0) {
            $notification = ['type' => 'warning', 'text' => 'You have already claimed this specific reward today.'];
        } else {
            $stmt_quota = $conn->prepare("SELECT COUNT(id) AS total FROM lucky_lifafa_rewards WHERE reward_date = ? AND lifafa_id = ?");
            $stmt_quota->bind_param("ss", $today, $lifafa_id);
            $stmt_quota->execute();
            $totalClaims = $stmt_quota->get_result()->fetch_assoc()['total'];

            if ($totalClaims >= $daily_limit) {
                $notification = ['type' => 'error', 'text' => "Today's quota for this specific lifafa has been reached."];
            } else {
                $conn->begin_transaction();
                try {
                    $stmt_update = $conn->prepare("UPDATE users SET balance = balance + ? WHERE unique_id = ?");
                    $stmt_update->bind_param("ds", $reward_amount, $unique_id);
                    $stmt_update->execute();
                    
                    $stmt_insert = $conn->prepare("INSERT INTO lucky_lifafa_rewards (unique_id, lifafa_id, amount, reward_date) VALUES (?, ?, ?, ?)");
                    $stmt_insert->bind_param("ssds", $unique_id, $lifafa_id, $reward_amount, $today);
                    $stmt_insert->execute();
                    
                    $conn->commit();
                    $claimed = true;
                    $current_balance += $reward_amount;
                } catch (mysqli_sql_exception $exception) {
                    $conn->rollback();
                    $notification = ['type' => 'error', 'text' => 'An error occurred. Please try again.'];
                    error_log("Transaction failed: " . $exception->getMessage());
                }
            }
        }
        
        if ($claimed || $already_claimed_result->num_rows > 0) {
            $stmt_history = $conn->prepare("SELECT reward_date, claimed_at, amount, lifafa_id FROM lucky_lifafa_rewards WHERE unique_id = ? ORDER BY claimed_at DESC LIMIT 10");
            $stmt_history->bind_param("s", $unique_id);
            $stmt_history->execute();
            $history_result = $stmt_history->get_result();
            while ($row = $history_result->fetch_assoc()) {
                $history[] = $row;
            }
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>🎁 Lucky Lifafa</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    /* (आपका पूरा CSS कोड यहाँ रहेगा... इसमें कोई बदलाव नहीं है) */
    :root { --primary-color: #ffc107; --success-color: #28a745; --error-color: #dc3545; --warning-color: #ffc107; --dark-bg: rgba(0, 0, 0, 0.65); --text-color: #ffffff; --dark-text: #000000; }
    body { margin: 0; font-family: 'Poppins', sans-serif; background: url('/logo/background_img.webp') no-repeat center center fixed; background-size: cover; color: var(--text-color); box-sizing: border-box; }
    .main-content { display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 15px; box-sizing: border-box; }
    .top-bar { position: fixed; top: 0; left: 0; width: 100%; height: 60px; display: flex; align-items: center; padding: 0 20px; z-index: 100; box-sizing: border-box; }
    .back-button { color: var(--text-color); font-size: 1.6rem; text-decoration: none; text-shadow: 1px 1px 5px rgba(0,0,0,0.5); transition: transform 0.2s; }
    .back-button:hover { transform: scale(1.1); }
    .lifafa-box { background: var(--dark-bg); padding: 25px; border-radius: 12px; text-align: center; width: 100%; max-width: 420px; box-shadow: 0 4px 15px rgba(0,0,0,0.4); z-index: 10; }
    h2 { margin-top: 0; font-size: 2rem; }
    input[type="tel"] { padding: 12px; width: 100%; border-radius: 8px; border: 1px solid #ccc; margin-bottom: 15px; font-size: 16px; box-sizing: border-box; }
    .btn { padding: 12px 25px; width: 100%; font-size: 18px; border: none; border-radius: 8px; background-color: var(--primary-color); color: var(--dark-text); cursor: pointer; font-weight: bold; }
    .spinner { margin: 20px auto; width: 40px; height: 40px; border: 5px solid #fff; border-top: 5px solid var(--primary-color); border-radius: 50%; animation: spin 1s linear infinite; display: none; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .balance-section { margin: 20px 0; font-size: 1.2rem; }
    .balance-section span { font-weight: 700; color: var(--primary-color); }
    .history-section { margin-top: 25px; }
    table { margin-top: 15px; width: 100%; border-collapse: collapse; font-size: 14px; }
    table td, table th { padding: 8px; border: 1px solid #555; color: var(--text-color); }
    table th { background: #444; }
    .top-notification { position: fixed; top: -100px; left: 50%; transform: translateX(-50%); padding: 12px 25px; border-radius: 8px; color: #fff; font-weight: 600; box-shadow: 0 4px 10px rgba(0,0,0,0.3); z-index: 9999; transition: top 0.5s ease-in-out; text-align: center; min-width: 280px; }
    .top-notification.show { top: 20px; }
    .top-notification.error { background-color: var(--error-color); }
    .top-notification.warning { background-color: var(--warning-color); color: var(--dark-text); }
    #confetti-canvas { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 1000; pointer-events: none; }
    .popup-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.7); display: flex; align-items: center; justify-content: center; z-index: 999; opacity: 0; visibility: hidden; transition: opacity 0.3s, visibility 0.3s; }
    .popup-overlay.active { opacity: 1; visibility: visible; }
    .popup-content { transform: scale(0.5); transition: transform 0.4s cubic-bezier(0.18, 0.89, 0.32, 1.28); }
    .popup-overlay.active .popup-content { transform: scale(1); }
    .reward-text { font-size: 6rem; font-weight: 700; color: var(--success-color); text-shadow: 2px 2px 0 #fff, 4px 4px 0 rgba(0,0,0,0.2); }
  </style>
</head>
<body>

<div class="top-bar">
  <a href="https://stayzan.in" class="back-button">
    <i class="fas fa-arrow-left"></i>
  </a>
</div>

<div id="notification-container"></div>
<div class="popup-overlay" id="successPopup">
  <div class="popup-content">
    <div class="reward-text">+₹<?= number_format($reward_amount, 0) ?></div>
  </div>
</div>
<canvas id="confetti-canvas"></canvas>

<div class="main-content">
  <div class="lifafa-box">
    <h2>🎁 Lucky Lifafa</h2>

    <!-- बदला हुआ: यह फॉर्म सिर्फ पेज के पहली बार लोड होने पर दिखेगा -->
    <?php if ($_SERVER['REQUEST_METHOD'] !== 'POST'): ?>
      <form method="POST" action="" onsubmit="showSpinner()">
        <input type="tel" name="mobile" placeholder="Enter your mobile number" required pattern="\d{10}" title="Please enter a valid 10-digit mobile number" /><br>
        <div class="spinner" id="spinner"></div>
        <button type="submit" class="btn" id="claimButton">🎁 Claim ₹5 Now</button>
      </form>
    <?php endif; ?>

    <!-- यह सेक्शन सिर्फ क्लेम सफल होने पर दिखेगा -->
    <?php if ($claimed): ?>
      <div class="balance-section">
        Your Updated Wallet Balance: <span>₹<?= number_format($current_balance, 2) ?></span>
      </div>
      <?php if (!empty($history)): ?>
        <div class="history-section">
          <h3>📜 Reward History</h3>
          <table>
            <thead>
              <tr><th>Date</th><th>Time</th><th>Amount</th></tr>
            </thead>
            <tbody>
              <?php foreach ($history as $h): ?>
                <tr>
                  <td><?= date("d-m-Y", strtotime($h['reward_date'])) ?></td>
                  <td><?= date("h:i A", strtotime($h['claimed_at'])) ?></td>
                  <td>₹<?= number_format($h['amount'], 2) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    
    <!-- यह सेक्शन तब दिखेगा जब यूज़र पहले ही क्लेम कर चुका हो -->
    <?php if (isset($already_claimed_result) && $already_claimed_result->num_rows > 0): ?>
        <div class="balance-section">
            Your Wallet Balance: <span>₹<?= number_format($current_balance, 2) ?></span>
        </div>
        <?php if (!empty($history)): ?>
        <div class="history-section">
          <h3>📜 Reward History</h3>
          <table>
            <thead>
              <tr><th>Date</th><th>Time</th><th>Amount</th></tr>
            </thead>
            <tbody>
              <?php foreach ($history as $h): ?>
                <tr>
                  <td><?= date("d-m-Y", strtotime($h['reward_date'])) ?></td>
                  <td><?= date("h:i A", strtotime($h['claimed_at'])) ?></td>
                  <td>₹<?= number_format($h['amount'], 2) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    <?php endif; ?>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>
<script>
  // (आपका पूरा जावास्क्रिप्ट कोड यहाँ रहेगा... कोई बदलाव नहीं)
  function showSpinner() { document.getElementById('claimButton').style.display = 'none'; document.getElementById('spinner').style.display = 'block'; }
  document.addEventListener('DOMContentLoaded', function() {
    <?php if ($notification): ?>
      showTopNotification('<?= addslashes($notification['text']) ?>', '<?= $notification['type'] ?>');
    <?php endif; ?>
    <?php if ($claimed): ?>
      handleSuccessClaim();
    <?php endif; ?>
  });
  function showTopNotification(text, type = 'error') { const container = document.getElementById('notification-container'); const notif = document.createElement('div'); notif.className = `top-notification ${type}`; notif.textContent = text; container.appendChild(notif); setTimeout(() => { notif.classList.add('show'); }, 100); setTimeout(() => { notif.classList.remove('show'); setTimeout(() => { container.removeChild(notif); }, 500); }, 4000); }
  function handleSuccessClaim() { const successPopup = document.getElementById('successPopup'); const myCanvas = document.getElementById('confetti-canvas'); const myConfetti = confetti.create(myCanvas, { resize: true, useWorker: true }); successPopup.classList.add('active'); fireConfetti(myConfetti); setTimeout(() => { successPopup.classList.remove('active'); }, 3000); }
  function fireConfetti(myConfetti) { const duration = 3 * 1000; const animationEnd = Date.now() + duration; const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 1000 }; function randomInRange(min, max) { return Math.random() * (max - min) + min; } const interval = setInterval(function() { const timeLeft = animationEnd - Date.now(); if (timeLeft <= 0) return clearInterval(interval); const particleCount = 50 * (timeLeft / duration); myConfetti(Object.assign({}, defaults, { particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } })); myConfetti(Object.assign({}, defaults, { particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } })); }, 250); }
</script>

</body>
</html>

<?php
// =================================================================
// 1. DATABASE CONNECTION (आपके दिए गए विवरण के साथ)
// =================================================================
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";

// कनेक्शन बनाएँ
$conn = new mysqli($host, $user, $password, $database);

// कनेक्शन की जाँच करें
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// =================================================================
// 2. HANDLE STATUS UPDATES (APPROVE/REJECT)
// =================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $id = (int)$_POST['id'];
    $table = $_POST['table'];
    $status = $_POST['status'];

    if ($id > 0 && in_array($table, ['rafer_withdrawals', 'withdrawals']) && in_array($status, ['completed', 'rejected'])) {
        $stmt = $conn->prepare("UPDATE `$table` SET `status` = ? WHERE `id` = ?");
        $stmt->bind_param("si", $status, $id);
        $stmt->execute();
        $stmt->close();
        
        // URL को साफ रखने के लिए रीडायरेक्ट करें
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// =================================================================
// 3. FETCH DATA WITH FILTERS
// =================================================================
$filter_status = isset($_GET['status']) ? $_GET['status'] : 'all';
$filter_unique_id = isset($_GET['unique_id']) ? $_GET['unique_id'] : '';

$sql = "
    (SELECT id, unique_id, method, amount, account, status, created_at, 'rafer_withdrawals' as source_table FROM rafer_withdrawals)
    UNION ALL
    (SELECT id, unique_id, method, amount, account, status, created_at, 'withdrawals' as source_table FROM withdrawals)
";

$where_clauses = [];
if ($filter_status !== 'all' && in_array($filter_status, ['pending', 'processing', 'completed', 'rejected'])) {
    $where_clauses[] = "status = '" . $conn->real_escape_string($filter_status) . "'";
}
if (!empty($filter_unique_id)) {
    $where_clauses[] = "unique_id LIKE '%" . $conn->real_escape_string($filter_unique_id) . "%'";
}

$final_sql = "SELECT * FROM ($sql) AS combined_withdrawals";
if (!empty($where_clauses)) {
    $final_sql .= " WHERE " . implode(' AND ', $where_clauses);
}
$final_sql .= " ORDER BY created_at DESC";

$result = $conn->query($final_sql);

?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawal Management</title>
    <!-- Font Awesome CDN for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a90e2;
            --success-color: #eaf7ec;
            --danger-color: #fdecec;
            --warning-color: #fffbeb;
            --info-color: #e8f7f9;
            --light-gray: #f8f9fa;
            --dark-gray: #6c757d;
            --text-color: #333;
            --border-color: #dee2e6;
            --card-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-gray);
            margin: 0;
            padding: 15px;
            color: var(--text-color);
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .back-button {
            background: #fff;
            border: 1px solid var(--border-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            cursor: pointer;
            color: var(--dark-gray);
            margin-right: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            transition: all 0.2s ease;
        }
        .back-button:hover {
            background-color: #f1f1f1;
            transform: scale(1.1);
        }
        .header h1 {
            font-size: 24px;
            margin: 0;
            font-weight: 600;
        }
        .filters {
            background: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: var(--card-shadow);
            margin-bottom: 20px;
        }
        .filter-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 15px;
        }
        .filter-group button {
            flex-grow: 1;
            padding: 10px;
            border: 1px solid var(--border-color);
            background-color: #fff;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }
        .filter-group button.active {
            background-color: var(--primary-color);
            color: #fff;
            border-color: var(--primary-color);
        }
        .search-bar { display: flex; }
        .search-bar input {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 16px;
        }
        .request-card {
            background: #fff;
            border-radius: 8px;
            box-shadow: var(--card-shadow);
            margin-bottom: 15px;
            overflow: hidden;
            border-left: 5px solid var(--primary-color);
        }
        .request-card.status-pending { border-left-color: var(--warning-color); }
        .request-card.status-processing { border-left-color: var(--info-color); }
        .request-card.status-completed { border-left-color: var(--success-color); }
        .request-card.status-rejected { border-left-color: var(--danger-color); }
        
        .card-body { padding: 15px; }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        .card-header .unique-id {
            font-weight: 600;
            font-size: 18px;
            color: var(--text-color);
        }
        .card-header .status {
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 500;
            text-transform: capitalize;
        }
        /* Color contrast improvements */
        .status-pending { background-color: var(--warning-color); color: blue; }
        .status-processing { background-color: var(--info-color); color: orange; }
        .status-completed { background-color: var(--success-color); color: green; }
        .status-rejected { background-color: var(--danger-color); color: red; }

        .card-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            font-size: 14px;
            color: var(--dark-gray);
        }
        .detail-item { display: flex; flex-direction: column; }
        .detail-item span:first-child { font-weight: 500; color: #555; }
        .card-footer {
            background-color: var(--light-gray);
            padding: 10px 15px;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            font-size: 14px;
        }
        .btn-approve { background-color: var(--success-color); color: #fff; }
        .btn-reject { background-color: var(--danger-color); color: #fff; }
        .no-results {
            text-align: center;
            padding: 40px;
            background: #fff;
            border-radius: 8px;
            color: var(--dark-gray);
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <button class="back-button" onclick="window.history.back()" title="Go Back">
            <i class="fa-solid fa-arrow-left"></i>
        </button>
        <h1>Withdrawals</h1>
    </div>

    <!-- Filters Section -->
    <div class="filters">
        <form id="filterForm" method="GET" action="">
            <div class="filter-group">
                <button type="button" class="filter-btn <?php echo ($filter_status == 'all') ? 'active' : ''; ?>" data-status="all">All</button>
                <button type="button" class="filter-btn <?php echo ($filter_status == 'pending') ? 'active' : ''; ?>" data-status="pending">Pending</button>
                <button type="button" class="filter-btn <?php echo ($filter_status == 'completed') ? 'active' : ''; ?>" data-status="completed">Completed</button>
                <button type="button" class="filter-btn <?php echo ($filter_status == 'processing') ? 'active' : ''; ?>" data-status="processing">Processing</button>
                <button type="button" class="filter-btn <?php echo ($filter_status == 'rejected') ? 'active' : ''; ?>" data-status="rejected">Rejected</button>
            </div>
            <div class="search-bar">
                <input type="search" name="unique_id" placeholder="Search by Unique ID..." value="<?php echo htmlspecialchars($filter_unique_id); ?>" onkeypress="if(event.key === 'Enter') { event.preventDefault(); this.form.submit(); }">
            </div>
            <input type="hidden" name="status" id="statusInput" value="<?php echo htmlspecialchars($filter_status); ?>">
        </form>
    </div>

    <!-- Requests List -->
    <div class="requests-list">
        <?php
        if ($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
        ?>
            <div class="request-card status-<?php echo htmlspecialchars($row['status']); ?>">
                <div class="card-body">
                    <div class="card-header">
                        <div class="unique-id"><?php echo htmlspecialchars($row['unique_id']); ?></div>
                        <div class="status status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo htmlspecialchars($row['status']); ?></div>
                    </div>
                    <div class="card-details">
                        <div class="detail-item">
                            <span>Amount</span>
                            <strong>₹<?php echo htmlspecialchars(number_format($row['amount'], 2)); ?></strong>
                        </div>
                        <div class="detail-item">
                            <span>Method</span>
                            <span><?php echo htmlspecialchars($row['method']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span>Account</span>
                            <span><?php echo htmlspecialchars($row['account']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span>Date</span>
                            <span><?php echo date("d M Y, h:i A", strtotime($row['created_at'])); ?></span>
                        </div>
                    </div>
                </div>
                <?php if ($row['status'] == 'pending' || $row['status'] == 'processing'): ?>
                <div class="card-footer">
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="hidden" name="table" value="<?php echo $row['source_table']; ?>">
                        <input type="hidden" name="status" value="rejected">
                        <button type="submit" class="btn btn-reject">Reject</button>
                    </form>
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="hidden" name="table" value="<?php echo $row['source_table']; ?>">
                        <input type="hidden" name="status" value="completed">
                        <button type="submit" class="btn btn-approve">Approve</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        <?php
            }
        } else {
            echo "<div class='no-results'><h3>No requests found</h3><p>Try adjusting your filters.</p></div>";
        }
        $conn->close();
        ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.getElementById('filterForm');
    const statusInput = document.getElementById('statusInput');
    const filterButtons = document.querySelectorAll('.filter-btn');

    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            statusInput.value = this.dataset.status;
            filterForm.submit();
        });
    });
});
</script>

</body>
</html>

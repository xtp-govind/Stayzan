<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recharge</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* आपका मौजूदा CSS यहाँ रहेगा... */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); color: #333; padding-bottom: 50px; min-height: 100vh; }
        .container { width: 100%; max-width: 100%; padding: 15px; }
        .card { background: white; padding: 25px; margin-bottom: 20px; border-radius: 20px; box-shadow: 0 8px 32px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px 20px; text-align: center; border-bottom-left-radius: 30px; border-bottom-right-radius: 30px; box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3); }
        .header h1 {
            font-size: 2em;
            font-weight: 700;
        }
        .balance-card { text-align: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        .balance-card .label { font-size: 1.1em; margin-bottom: 10px; }
        .balance-card .amount { font-size: 3em; font-weight: 800; }
        .form-title { font-size: 1.4em; font-weight: 700; margin-bottom: 25px; text-align: center; }
        .input-group { position: relative; margin-bottom: 25px; }
        .input-group .icon { position: absolute; left: 20px; top: 50%; transform: translateY(-50%); font-size: 1.4em; color: #667eea; }
        .amount-input { width: 100%; padding: 20px 20px 20px 20px; border: 2px solid #e0e0e0; border-radius: 15px; font-size: 1.6em; font-weight: bold; text-align: center; }
        .quick-amounts { display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 15px; margin-bottom: 30px; }
        .quick-amount-btn { background: #f8f9fa; border: 2px solid #dee2e6; border-radius: 12px; padding: 15px 10px; font-size: 1em; font-weight: 700; cursor: pointer; }
        .quick-amount-btn.selected { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-color: #667eea; }
        .recharge-btn { width: 100%; padding: 18px; border: none; border-radius: 15px; background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; font-size: 1.2em; font-weight: bold; cursor: pointer; }
        
.recharge-history {
    background-color: #f7f8fc;
    border-radius: 24px;
    padding: 20px;
    margin-top: 20px;
}

.history-title {
    font-size: 1.5em;
    font-weight: 700;
    margin-bottom: 20px;
    color: #1d2a4d;
    display: flex;
    align-items: center;
    gap: 12px;
}

.history-title i {
    color: #667eea;
}

#historyList {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 15px; /* हर आइटम के बीच गैप */
}

.accordion-item {
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
    overflow: hidden; /* एनिमेशन के लिए ज़रूरी */
    transition: box-shadow 0.3s ease;
}

.accordion-item.active {
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
}

.accordion-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 18px;
    cursor: pointer;
}

.header-left, .header-right {
    display: flex;
    align-items: center;
    gap: 12px;
}

.header-icon {
    font-size: 1.4em;
}
.header-icon.status-success { color: #28a745; }
.header-icon.status-pending { color: #ffc107; }
.header-icon.status-failed { color: #dc3545; }

.header-amount {
    font-size: 1.2em;
    font-weight: 600;
    color: #1d2a4d;
}

.header-date {
    font-size: 0.9em;
    color: #5a6a85;
}

.expand-icon {
    font-size: 0.9em;
    color: #8492a6;
    transition: transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.accordion-content {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.content-inner {
    padding: 0 20px 20px 20px;
    border-top: 1px solid #f0f2f5;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.9em;
    word-break: break-all;
}
.detail-row strong {
    color: #5a6a85;
    margin-right: 10px;
}
.detail-row span {
    color: #1d2a4d;
    font-weight: 500;
    display: flex;
    align-items: center;
    text-align: right;
}

.copy-btn {
    background: none; border: none; color: #667eea;
    cursor: pointer; font-size: 1em; margin-left: 8px;
}

.detail-status.status-success { color: #28a745; }
.detail-status.status-pending { color: #ffc107; }
.detail-status.status-failed { color: #dc3545; }

.complaint-wrapper {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px dashed #e0e0e0;
}
.complaint-btn {
    width: 100%;
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
    border-radius: 10px;
    padding: 10px;
    font-size: 0.9em;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}
.complaint-btn:hover {
    background-color: #f1b0b7;
}

.no-history {
    text-align: center; padding: 40px 20px; color: #95a5a6;
}
.no-history i {
    display: block; font-size: 3em; margin-bottom: 15px; color: #bdc3c7;
}

.back-btn {
    position: absolute;
    top: -10px;
    left: -10px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: none;
    background-color: #f0f2f5;
    color: #495057; 
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 1.1em;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); 
    transition: all 0.2s ease; 
}

.back-btn:hover {
    background-color: #e9ecef; /* हॉवर पर थोड़ा गहरा रंग */
    transform: scale(1.05); /* हल्का सा बड़ा होने का इफ़ेक्ट */
}

.back-btn:active {
    transform: scale(0.95); /* क्लिक पर छोटा होने का इफ़ेक्ट */
}

        
        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e9ecef;
            padding: 10px 0;
            z-index: 1000;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 100%;
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #666;
            min-width: 60px;
        }

        .nav-item:hover {
            background: #f8f9fa;
            color: #667eea;
            transform: translateY(-2px);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .nav-item i {
            font-size: 1.3em;
            margin-bottom: 4px;
        }

        .nav-item .nav-text {
            font-size: 0.75em;
            font-weight: 600;
        }

        #payment-details-section {
              display: none; 
              text-align: center;
              position: relative;
              padding-top: 20px;
}


        .qr-code-wrapper {
            margin: 20px auto;
            padding: 15px;
            background: white;
            border-radius: 15px;
            display: inline-block;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .qr-code-wrapper img {
            width: 180px;
            height: 180px;
            display: block;
        }

.upi-info {
    background: #f0f2f5;
    padding: 12px 15px;
    border-radius: 12px;
    margin: 20px 0;
    display: flex;
    justify-content: space-between; /* यह आइटम्स को दूर-दूर रखेगा */
    align-items: center; /* यह आइटम्स को वर्टिकली सेंटर में रखेगा */
    gap: 10px;
}


.upi-id-text {
    font-weight: 600;
    font-size: 1.1em;
    color: #333;
    flex-grow: 1; 
    text-align: left;
    word-break: break-all;
}

.upi-actions {
    display: flex;
    align-items: center;
    gap: 10px; /* दोनों बटनों के बीच गैप */
}

/* कॉपी और पे बटन के लिए कॉमन स्टाइल */
.upi-action-btn {
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    font-size: 0.9em;
    padding: 10px 15px;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: transform 0.2s ease;
}
.upi-action-btn:active {
    transform: scale(0.95); /* क्लिक पर छोटा सा इफ़ेक्ट */
}

/* सिर्फ कॉपी आइकॉन वाले बटन के लिए स्टाइल */
.upi-copy-icon-btn {
    background-color: #e9ecef;
    color: #495057;
    padding: 10px; /* इसे चौकोर बनाने के लिए */
    font-size: 1.1em; /* आइकॉन बड़ा करने के लिए */
}

/* पे बटन के लिए स्टाइल */
.upi-pay-btn {
    background: #28a745; /* हरा रंग */
    color: white;
}


        #upload-box {
            margin-top: 20px;
            border: 2px dashed #ccc;
            padding: 20px;
            border-radius: 15px;
        }
        #upload-box p { font-size: 0.9em; color: #666; margin-bottom: 15px; }
        #preview { max-width: 100%; margin-top: 15px; border-radius: 10px; display: none; }
        #submit-screenshot-btn {
            width: 100%; padding: 18px; border: none; border-radius: 15px;
            background: #667eea; color: white; font-size: 1.2em; font-weight: bold;
            cursor: pointer; margin-top: 20px;
        }
        #submit-screenshot-btn:disabled { background: #aaa; cursor: not-allowed; }

        /* --- ✅ टाइमर सेक्शन CSS --- */
        #timer-section {
            display: none;
            text-align: center;
        }
        #timer { font-size: 4em; font-weight: bold; color: #667eea; margin: 20px 0; }
        #status { font-size: 1.2em; color: #555; }
        .loading-spinner {
            border: 8px solid #f3f3f3;
            border-top: 8px solid #667eea;
            border-radius: 50%;
            width: 80px;
            height: 80px;
            animation: spin 1.5s linear infinite;
            margin: 20px auto;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        


/* --- ✅ नया एनिमेशन कंटेनर CSS --- */
#animation-container {
    position: relative;
    width: 250px; /* Lottie एनिमेशन की चौड़ाई के बराबर */
    height: 250px; /* Lottie एनिमेशन की ऊंचाई के बराबर */
    margin: 20px auto; /* इसे बीच में लाने के लिए */
    display: flex;
    justify-content: center;
    align-items: center;
}

/* स्पिनर को कंटेनर के अंदर सेट करें */
#animation-container .loading-spinner {
    position: absolute; /* ताकि यह Lottie के ऊपर-नीचे आ सके */
    margin: 0; /* ऑटो मार्जिन हटाएं */
}

/* Lottie कंटेनर को भी सेट करें */
#lottie-success-container {
    width: 100%;
    height: 100%;
}


    </style>
</head>
<body>
    
    <div class="header"><h1>Recharge Account</h1></div>

    <div class="container">
        <div class="card balance-card">
            <div class="label">Current Balance</div>
            <div class="amount">₹<span id="currentBalance">0.00</span></div>
        </div>

        <!-- यह कार्ड अब डायनामिक रूप से बदलेगा -->
        <div id="main-card" class="card">
            <!-- चरण 1: राशि दर्ज करें -->
            <div id="amount-entry-section">
                <h2 class="form-title">Enter Recharge Amount</h2>
                <div class="input-group">
                    <span class="icon">₹</span>
                    <input type="number" id="amountInput" class="amount-input" placeholder="0.00" min="530">
                </div>
                <div class="quick-amounts">
                    <button class="quick-amount-btn" onclick="setAmount(530, this)">₹530</button>
                    <button class="quick-amount-btn" onclick="setAmount(700, this)">₹700</button>
                    <button class="quick-amount-btn" onclick="setAmount(1000, this)">₹1000</button>
                    <button class="quick-amount-btn" onclick="setAmount(2000, this)">₹2000</button>
                </div>
                <button class="recharge-btn" onclick="showPaymentDetails()">Proceed to Pay</button>
            </div>

<div id="payment-details-section">
    <button class="back-btn" onclick="showAmountEntry()"><i class="fas fa-arrow-left"></i></button>
    <h2 class="form-title">Complete Your Payment</h2>
    
                <p>Scan the QR code or copy the UPI ID to pay <strong id="payment-amount">₹0.00</strong></p>
                
                <div class="qr-code-wrapper">
                    <!-- ⚠️ अपनी UPI ID से QR कोड जेनरेट करके उसका URL यहाँ डालें -->
                    <img id="qr-code-img" src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=tk95879747612@ybl" alt="UPI QR Code">
                </div>

<div class="upi-info">
    <span id="upi-id-text" class="upi-id-text">tk95879747612@ybl</span>
    
    <div class="upi-actions">
        <!-- कॉपी आइकॉन बटन -->
        <button class="upi-action-btn upi-copy-icon-btn" title="Copy UPI ID" onclick="copyToClipboard(UPI_ID)">
            <i class="far fa-copy"></i>
        </button>
        
        <!-- पे बटन (यह एक लिंक है) -->
        <a href="#" id="upi-pay-link" class="upi-action-btn upi-pay-btn">
            <i class="fas fa-paper-plane"></i>
            <span>Pay</span>
        </a>
    </div>
</div>



                <div id="upload-box">
                    <p>After payment, upload the screenshot here.</p>
                    <input type="file" id="screenshotInput" accept="image/*">
                    <img id="preview">
                </div>

                <button id="submit-screenshot-btn" disabled>Submit Screenshot</button>
            </div>


<div id="timer-section">
    <h2 class="form-title">Verifying Payment</h2>
    
    <!-- ✅✅✅ यह हमारा नया कंटेनर है जो स्पिनर और Lottie को संभालेगा ✅✅✅ -->
    <div id="animation-container">
        <!-- स्पिनर अब इसके अंदर है -->
        <div class="loading-spinner"></div>
        
        <!-- Lottie एनिमेशन भी यहीं बनेगा (अभी खाली है) -->
        <div id="lottie-success-container" style="display: none;"></div> 
    </div>

    <div id="timer">60</div>
    <div id="status">Your request is being processed...</div>
</div>


        </div>

<div class="card recharge-history">
           <h3 class="history-title"><i class="fas fa-history"></i> Payment History</h3>
            <ul id="historyList">
                <!-- History items will be dynamically loaded here -->
            </ul>
</div>
</div>    

<div class="bottom-nav">  
    <div class="nav-container">  
        <a href="index.php" class="nav-item"><i class="fas fa-home"></i><div class="nav-text">Home</div></a>  
        <a href="invite.php" class="nav-item"><i class="fas fa-users"></i><div class="nav-text">Invite</div></a>  
        <a href="recharge.php" class="nav-item active"><i class="fas fa-credit-card"></i><div class="nav-text">Recharge</div></a>  
        <a href="profile.php" class="nav-item"><i class="fas fa-user"></i><div class="nav-text">My</div></a>  
    </div>  
</div>  

<script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.6.2/dist/dotlottie-wc.js" type="module"></script>
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>

<script>
        // --- कॉन्फ़िगरेशन ---
        const UPI_ID = "tk95879747612@ybl"; // ⚠️ अपनी UPI ID यहाँ डालें
        const UPI_NAME = " Stayzan "; // ⚠️ अपना नाम यहाँ डालें

        // --- DOM एलिमेंट्स ---
        const amountInput = document.getElementById('amountInput');
        const amountEntrySection = document.getElementById('amount-entry-section');
        const paymentDetailsSection = document.getElementById('payment-details-section');
        const timerSection = document.getElementById('timer-section');
        const paymentAmountEl = document.getElementById('payment-amount');
        const qrCodeImg = document.getElementById('qr-code-img');
        const upiIdText = document.getElementById('upi-id-text');
        const screenshotInput = document.getElementById('screenshotInput');
        const previewImg = document.getElementById('preview');
        const submitBtn = document.getElementById('submit-screenshot-btn');
        const timerEl = document.getElementById('timer');
        const statusEl = document.getElementById('status');
        const balanceCard = document.querySelector('.balance-card');
        const historyCard = document.querySelector('.recharge-history');

        let rechargeAmount = 0;

        function setAmount(amount, element) {
            amountInput.value = amount;
            document.querySelectorAll('.quick-amount-btn').forEach(btn => btn.classList.remove('selected'));
            element.classList.add('selected');
        }

// --- UI कंट्रोल फंक्शन्स ---
function showAmountEntry() {
    balanceCard.style.display = 'block';
    historyCard.style.display = 'block';
    amountEntrySection.style.display = 'block';
    paymentDetailsSection.style.display = 'none';
    timerSection.style.display = 'none';
}

function showPaymentDetails() {
    rechargeAmount = parseFloat(amountInput.value);
    if (isNaN(rechargeAmount) || rechargeAmount < 530) { 
        showAlert('Minimum recharge amount is ₹530.');
        return;
    }

    // UI अपडेट करें
    paymentAmountEl.innerText = `₹${rechargeAmount.toFixed(2)}`;
    document.getElementById('upi-id-text').innerText = UPI_ID; // span का टेक्स्ट सेट करें

    // --- ✅✅✅ UPI डीप लिंक बनाने का लॉजिक ✅✅✅ ---
    // यह लिंक मोबाइल पर UPI ऐप्स को खोलेगा
    const upiDeepLink = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(UPI_NAME)}&am=${rechargeAmount.toFixed(2)}&cu=INR`;

    // QR कोड का डेटा भी इसी लिंक से बनेगा
    qrCodeImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiDeepLink)}`;

    // 'Pay' वाले लिंक का href सेट करें
    document.getElementById('upi-pay-link').href = upiDeepLink;

    // सेक्शन बदलें और गैर-जरूरी कार्ड छिपाएं
    balanceCard.style.display = 'none';
    historyCard.style.display = 'none';
    amountEntrySection.style.display = 'none';
    paymentDetailsSection.style.display = 'block';
}



function showTimer() {
    paymentDetailsSection.style.display = 'none';
    timerSection.style.display = 'block';
    startTimer();
}

        screenshotInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    previewImg.src = e.target.result;
                    previewImg.style.display = 'block';
                    submitBtn.disabled = false; // बटन को एनेबल करें
                };
                reader.readAsDataURL(file);
            }
        });

submitBtn.addEventListener('click', async function() {
    const file = screenshotInput.files[0];
    if (!file) { return; }

    this.disabled = true;
    this.innerText = 'Submitting...';
    showTimer();

    const formData = new FormData();
    formData.append('amount', rechargeAmount);
    formData.append('screenshot', file);

    try {
        const response = await fetch('upload_screenshot', { method: 'POST', body: formData });

        // ✅ पहले JSON में बदलने की कोशिश करें
        const result = await response.json();

        if (!response.ok) {
        
            throw new Error(result.error || 'An unknown server error occurred.');
        }

        // अगर PHP से 'ok': true आया है
        console.log('Submission successful:', result.message);
        // टाइमर को सामान्य रूप से चलने दें

    } catch (error) {
        
        console.error('Error:', error);
        statusEl.innerText = `Error: ${error.message}`; // उपयोगकर्ता को स्पष्ट एरर दिखाएं
        clearInterval(timerInterval);
        timerEl.style.display = 'none';
        document.querySelector('#timer-section .loading-spinner').style.display = 'none'; // स्पिनर छिपाएं
    }
});


let timerInterval;
let statusCheckInterval;

function startTimer() {
    let timeLeft = 60;
    timerEl.innerText = timeLeft;

    timerInterval = setInterval(() => {
        timeLeft--;
        timerEl.innerText = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            clearInterval(statusCheckInterval);
            statusEl.innerHTML = "Time's up! Your request is being processed. You can check the history later.";
            timerEl.style.display = 'none';
            setTimeout(showAmountEntry, 4000);
        }
    }, 1000);

statusCheckInterval = setInterval(async () => {
    try {
        const res = await fetch("new_recharge_status_check.php");
        const data = await res.json();

        if (data.status && data.status.toLowerCase() === "success") {
            clearInterval(timerInterval);
            clearInterval(statusCheckInterval);
            
            // --- ✅✅✅ स्पिनर की जगह Lottie दिखाने का नया तरीका ✅✅✅ ---

            // 1. पुराने एलिमेंट्स छिपाएं
            document.querySelector('#timer-section .loading-spinner').style.display = 'none';
            timerEl.style.display = 'none';

            // 2. स्टेटस मैसेज और टाइटल अपडेट करें
            document.querySelector('#timer-section .form-title').innerText = 'Recharge Successful!';
            statusEl.innerHTML = `<span style="color: #28a745; font-weight: bold;">Your amount has been credited.</span>`;

            // 3. Lottie कंटेनर को ढूंढें और दिखाएं
            const lottieContainer = document.getElementById('lottie-success-container');
            lottieContainer.style.display = 'block';
            lottieContainer.innerHTML = ''; // पहले से कुछ हो तो साफ़ करें

            // 4. नया Lottie Player बनाएं और कॉन्फ़िगर करें
            const dotlottiePlayer = document.createElement('dotlottie-wc');
            dotlottiePlayer.style.width = '250px';
            dotlottiePlayer.style.height = '250px';
            dotlottiePlayer.src = 'https://lottie.host/be7d745d-1fbc-4c72-aabf-00eac42bdbd6/cH37HONkso.lottie';
            dotlottiePlayer.autoplay = true;
            dotlottiePlayer.loop = true;

            // 5. Lottie प्लेयर को कंटेनर में जोड़ें
            lottieContainer.appendChild(dotlottiePlayer);

            // 6. कन्फ़ेटी इफ़ेक्ट चलाएं
            if (typeof confetti === 'function') {
                triggerConfetti();
            }

            // 7. 4 सेकंड बाद सब कुछ रीसेट करके मुख्य पेज पर जाएं
            setTimeout(() => {
                // UI को वापस डिफ़ॉल्ट स्थिति में रीसेट करें
                document.querySelector('#timer-section .form-title').innerText = 'Verifying Payment';
                statusEl.innerText = 'Your request is being processed...';
                document.querySelector('#timer-section .loading-spinner').style.display = 'block';
                timerEl.style.display = 'block';
                lottieContainer.style.display = 'none';
                lottieContainer.innerHTML = '';

                // मुख्य पेज दिखाएं
                showAmountEntry();
                loadRechargeData();
            }, 4000);
            
        } else if (data.status && data.status.toLowerCase() === "failed") {
            // ... (फेल होने वाला कोड वैसा ही रहेगा)
        }
    } catch (err) {
        console.error("Status check failed:", err);
    }
}, 3000);



}


// ✅ कन्फ़ेटी इफ़ेक्ट चलाने के लिए नया फंक्शन
function triggerConfetti() {
    // स्क्रीन के बीच से शुरू करें
    confetti({
        particleCount: 150,
        spread: 90,
        origin: { y: 0.6 }
    });

    // थोड़ा और मज़ेदार बनाने के लिए, कुछ और एनिमेशन
    setTimeout(() => { confetti({ particleCount: 100, spread: 120, startVelocity: 45, angle: 90, origin: { x: 0.5, y: 0.5 } }); }, 100);
    setTimeout(() => { confetti({ particleCount: 100, spread: 120, startVelocity: 45, angle: 45, origin: { x: 0, y: 0.5 } }); }, 200);
    setTimeout(() => { confetti({ particleCount: 100, spread: 120, startVelocity: 45, angle: 135, origin: { x: 1, y: 0.5 } }); }, 200);
}


function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                showAlert('UPI ID copied!');
            }).catch(err => {
                showAlert('Failed to copy.');
            });
        }

// Improved data loading with better error handling
        async function loadRechargeData() {
            try {
                const response = await fetch("recharge_history.php", {
                    method: 'GET',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                
                if (data.error) {
                    throw new Error(data.error);
                }
                
                // Update balance
                currentBalance = parseFloat(data.balance) || 0;
                document.getElementById("currentBalance").textContent = currentBalance.toFixed(2);
                
                // Update history
                updateHistoryDisplay(data.history || []);
                
            } catch (error) {
                console.error("Data loading failed:", error);
                
                // Show sample data if server request fails
                const sampleData = [
                    { amount: 200, updated_at: '2025-07-28 14:45:00', status: 'success' },
                    { amount: 500, updated_at: '2025-07-27 09:10:00', status: 'pending' },
                    { amount: 100, updated_at: '2025-07-25 17:30:00', status: 'failed' }
                ];
                updateHistoryDisplay(sampleData);
                
                showAlert("Could not load data from server." );
            }
        }


// ✅ इस पूरे फंक्शन को नए वाले से बदलें
function updateHistoryDisplay(historyData) {
    const historyList = document.getElementById("historyList");
    historyList.innerHTML = "";
    
    if (!historyData || historyData.length === 0) {
        historyList.innerHTML = '<li class="no-history"><i class="fas fa-folder-open"></i>No transactions yet.</li>';
        return;
    }
    
    historyData.forEach((item, index) => {
        const li = document.createElement("li");
        li.className = "accordion-item";
        
        const status = item.status.toLowerCase();
        const statusClass = `status-${status}`;
        
        let iconClass = 'fa-check-circle'; // Success
        if (status === 'pending') iconClass = 'fa-hourglass-half';
        else if (status === 'failed') iconClass = 'fa-times-circle';

        const date = new Date(item.updated_at);
        const formattedDate = date.toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
        
        const transactionId = item.payment_id || item.id || `N/A`;


const complaintButtonHTML = (status === 'pending' || status === 'failed') 
    ? `<button class="complaint-btn" onclick="fileComplaint('${transactionId}', '${item.amount}', '${item.status}', '${formattedDate}')"><i class="fas fa-exclamation-triangle"></i> Report Issue</button>` 
    : '';

        li.innerHTML = `
            <div class="accordion-header" onclick="toggleAccordion(this)">
                <div class="header-left">
                    <i class="fas ${iconClass} header-icon ${statusClass}"></i>
                    <span class="header-amount">₹${parseFloat(item.amount).toFixed(2)}</span>
                </div>
                <div class="header-right">
                    <span class="header-date">${formattedDate}</span>
                    <i class="fas fa-chevron-down expand-icon"></i>
                </div>
            </div>
            <div class="accordion-content">
                <div class="content-inner">
                    <div class="detail-row">
                        <strong>Transaction ID:</strong>
                        <span>
                            ${transactionId}
                            <button class="copy-btn" title="Copy ID" onclick="copyToClipboard('${transactionId}')"><i class="far fa-copy"></i></button>
                        </span>
                    </div>
                    <div class="detail-row">
                        <strong>Status:</strong>
                        <span class="detail-status ${statusClass}">${item.status}</span>
                    </div>
                    ${complaintButtonHTML ? `<div class="complaint-wrapper">${complaintButtonHTML}</div>` : ''}
                </div>
            </div>
        `;
        
        historyList.appendChild(li);
    });
}


// ✅ यह नया फंक्शन स्क्रिप्ट में कहीं भी जोड़ें
function toggleAccordion(element) {
    const item = element.parentElement;
    const content = element.nextElementSibling;
    const icon = element.querySelector('.expand-icon');

    if (item.classList.contains('active')) {
        item.classList.remove('active');
        icon.style.transform = 'rotate(0deg)';
        content.style.maxHeight = null;
    } else {
        // Optional: Close other active accordions
        document.querySelectorAll('.accordion-item.active').forEach(activeItem => {
            activeItem.classList.remove('active');
            activeItem.querySelector('.expand-icon').style.transform = 'rotate(0deg)';
            activeItem.querySelector('.accordion-content').style.maxHeight = null;
        });

        item.classList.add('active');
        icon.style.transform = 'rotate(180deg)';
        content.style.maxHeight = content.scrollHeight + "px";
    }
}

function fileComplaint(transactionId, amount, status, time) {
    // 1. एक URL बनाएं जिसमें सारी जानकारी हो
    const supportURL = new URL('support', window.location.origin + window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/')) + '/');
    
    // 2. URL में पैरामीटर जोड़ें
    supportURL.searchParams.append('transaction_id', transactionId);
    supportURL.searchParams.append('amount', amount);
    supportURL.searchParams.append('status', status);
    supportURL.searchParams.append('time', time);

    // 3. यूज़र को नए URL पर भेजें
    window.location.href = supportURL.href;
}


// ✅ यह नया हेल्पर फंक्शन जोड़ें
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showAlert('Transaction ID copied!', 'success');
    }).catch(err => {
        showAlert('Failed to copy ID.', 'error');
    });
}
        // Get localized status text
        function getStatusText(status) {
            const statusMap = {
                'success': 'Success',
                'pending': 'Pending',
                'failed': 'Failed'
            };
            return statusMap[status.toLowerCase()] || status;
        }

        // Improved alert system
        function showAlert(message, type = 'info') {
            // Remove existing alerts
            const existingAlert = document.querySelector('.custom-alert');
            if (existingAlert) {
                existingAlert.remove();
            }
            
            const alert = document.createElement('div');
            alert.className = `custom-alert alert-${type}`;
            alert.innerHTML = `
                <div class="alert-content">
                    <span class="alert-icon">${getAlertIcon(type)}</span>
                    <span class="alert-message">${message}</span>
                    <button class="alert-close" onclick="this.parentElement.parentElement.remove()">×</button>
                </div>
            `;
            
            // Add alert styles
            alert.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 10000;
                background: white;
                border-radius: 10px;
                box-shadow: 0 8px 32px rgba(0,0,0,0.2);
                padding: 15px 20px;
                max-width: 90%;
                animation: slideDown 0.3s ease;
            `;
            
            document.body.appendChild(alert);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (alert.parentElement) {
                    alert.remove();
                }
            }, 5000);
        }

        // Get alert icon based on type
        function getAlertIcon(type) {
            const icons = {
                'success': '✅',
                'error': '❌',
                'warning': '⚠️',
                'info': 'ℹ️'
            };
            return icons[type] || 'ℹ️';
        }

        // Add CSS for alerts
        const alertStyles = document.createElement('style');
        alertStyles.textContent = `
            @keyframes slideDown {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }
            
            .custom-alert .alert-content {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .alert-close {
                background: none;
                border: none;
                font-size: 20px;
                cursor: pointer;
                color: #666;
                margin-left: auto;
            }
            
            .alert-success { border-left: 4px solid #28a745; }
            .alert-error { border-left: 4px solid #dc3545; }
            .alert-warning { border-left: 4px solid #ffc107; }
            .alert-info { border-left: 4px solid #17a2b8; }
        `;
        document.head.appendChild(alertStyles);

        // Initialize on page load
        window.addEventListener('load', function() {
            loadRechargeData();
            
// Add input validation  
        const amountInput = document.getElementById('amountInput');  
        amountInput.addEventListener('input', function() {  
            const value = parseFloat(this.value);  
            if (value > 100000) {  
                this.value = 100000;  
                showAlert('Maximum recharge amount is ₹100,000.', 'warning');  
            }  
        });


            
            // Add keyboard support for quick amounts
            document.addEventListener('keydown', function(e) {
                if (e.key >= '1' && e.key <= '4' && e.ctrlKey) {
                    const amounts = [530, 700, 1000, 2000];
                    const index = parseInt(e.key) - 1;
                    if (amounts[index]) {
                        setAmount(amounts[index]);
                    }
                }
            });
        });

        // Add service worker for offline support (optional)
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
                // Register service worker if available
            });
        }
        
</script>

<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>

</body>
</html>

<?php
// Headers to allow cross-origin requests (CORS)
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    http_response_code(503); // Service Unavailable
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $conn->connect_error]);
    die();
}
$conn->set_charset("utf8mb4");

// अनुरोध का मेथड
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        getUsers($conn);
        break;
    case 'POST':
        handlePostRequest($conn);
        break;
    case 'PUT': // ⭐️ नया मेथड: ब्लॉक/अनब्लॉक के लिए
        toggleBlockStatus($conn);
        break;
    case 'DELETE':
        deleteUser($conn);
        break;
    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
        break;
}

// ✅ सभी यूज़र्स प्राप्त करो
function getUsers($conn) {
    $sql = "SELECT id, unique_id, name, email, mobile, balance, blocked FROM users ORDER BY id DESC";
    $result = $conn->query($sql);
    if ($result === false) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Failed to fetch users: ' . $conn->error]);
        return;
    }
    $users = [];
    while($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    echo json_encode(['status' => 'success', 'data' => $users]);
}

// ⭐️ नया फंक्शन: ब्लॉक/अनब्लॉक स्थिति को टॉगल करें
function toggleBlockStatus($conn) {
    $data = json_decode(file_get_contents("php://input"));

    if (!isset($data->unique_id) || !isset($data->status)) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Unique ID and status are required.']);
        return;
    }

    $unique_id = $conn->real_escape_string($data->unique_id);
    $status = (int)$data->status; // 0 या 1

    if ($status !== 0 && $status !== 1) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid status value. Must be 0 or 1.']);
        return;
    }

    $sql = "UPDATE users SET blocked = $status WHERE unique_id = '$unique_id'";
    if ($conn->query($sql) === TRUE) {
        if ($conn->affected_rows > 0) {
            echo json_encode(['status' => 'success', 'message' => 'User status updated successfully.']);
        } else {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'User not found.']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Error updating user status: ' . $conn->error]);
    }
}


// ✅ POST: Create/Update user
function handlePostRequest($conn) {
    $data = json_decode(file_get_contents("php://input"));

    if (empty($data->name) || empty($data->email) || empty($data->mobile)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Incomplete data. Name, email, and mobile are required.']);
        return;
    }

    $name = $conn->real_escape_string($data->name);
    $email = $conn->real_escape_string($data->email);
    $mobile = $conn->real_escape_string($data->mobile);
    $balance = isset($data->balance) ? (float)$data->balance : 20.00;

    if (isset($data->unique_id) && !empty($data->unique_id)) {
        // Update
        $unique_id = $conn->real_escape_string($data->unique_id);
        $sql = "UPDATE users SET name='$name', email='$email', mobile='$mobile', balance=$balance WHERE unique_id='$unique_id'";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['status' => 'success', 'message' => 'User updated successfully.']);
        } else {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Error updating user: ' . $conn->error]);
        }
    } else {
        // Create
        if (empty($data->password)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Password is required for new users.']);
            return;
        }
        $unique_id = strtoupper(substr($name, 0, 2)) . rand(1000, 9999);
        $password = password_hash($data->password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (name, email, mobile, balance, password, unique_id) VALUES ('$name', '$email', '$mobile', $balance, '$password', '$unique_id')";
        if ($conn->query($sql) === TRUE) {
            http_response_code(201);
            echo json_encode(['status' => 'success', 'message' => 'User created successfully.', 'unique_id' => $unique_id]);
        } else {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Error creating user: ' . $conn->error]);
        }
    }
}

// ✅ DELETE by unique_id
function deleteUser($conn) {
    if (!isset($_GET['unique_id'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Unique ID not provided.']);
        return;
    }

    $unique_id = $conn->real_escape_string($_GET['unique_id']);
    $sql = "DELETE FROM users WHERE unique_id = '$unique_id'";

    if ($conn->query($sql) === TRUE) {
        if ($conn->affected_rows > 0) {
            echo json_encode(['status' => 'success', 'message' => 'User deleted successfully.']);
        } else {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'User not found.']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Error deleting user: ' . $conn->error]);
    }
}

$conn->close();
?>

<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["error" => "User not logged in"]);
    exit;
}

$unique_id = $_SESSION['unique_id'];

// Database connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Fetch only latest 30 bets for logged-in user
$sql = "SELECT * FROM parity_bets WHERE unique_id = ? ORDER BY id DESC LIMIT 30";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $unique_id);
$stmt->execute();
$result = $stmt->get_result();

// Prepare output
$bets = [];
while ($row = $result->fetch_assoc()) {
    $bets[] = $row;
}

// Output JSON
header('Content-Type: application/json');
echo json_encode($bets);

$conn->close();
?>
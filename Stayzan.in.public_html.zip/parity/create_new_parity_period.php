<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


define('WELCOME_WIN_THRESHOLD', 33.00);      // (बैलेंस + बेट) की सीमा, इससे कम होने पर खिलाड़ी को जिताने की कोशिश।
define('WINNING_BALANCE_THRESHOLD', 250.00); // (बैलेंस + संभावित जीत) की सीमा, इससे ज़्यादा होने पर खिलाड़ी को हराने की कोशिश।
define('PLAYER_THRESHOLD', 1);               // खिलाड़ियों की संख्या की सीमा, इससे ज़्यादा होने पर हमेशा कंपनी का फायदा देखा जाएगा।
define('MAX_CONSECUTIVE_WINS', 3);           // लगातार इतनी जीत के बाद खिलाड़ी को हराने की कोशिश।
define('MAX_CONSECUTIVE_LOSSES', 2);         // लगातार इतनी हार के बाद खिलाड़ी को जिताने की कोशिश।

// ===================================================================
// सहायक फंक्शन्स
// ===================================================================

/**
 * रेफरल कमीशन देने के लिए फंक्शन।
 */
function giveReferralCommission($conn, $from_user_id, $bet_amount) {
    $percentages = [1 => 1.0, 2 => 0.5, 3 => 0.3, 4 => 0.2, 5 => 0.1];
    $stmt = $conn->prepare("SELECT * FROM referral_users WHERE unique_id = ?");
    if(!$stmt) return;
    $stmt->bind_param("s", $from_user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows == 0) return;
    $ref = $res->fetch_assoc();
    for ($level = 1; $level <= 5; $level++) {
        $to_user_id = $ref["level_$level"];
        if ($to_user_id) {
            $percent = $percentages[$level];
            $commission = ($bet_amount * $percent) / 100;
            $stmtInsert = $conn->prepare("INSERT INTO referral_commissions (from_user_id, to_user_id, level, bet_amount, commission_percent, commission_amount) VALUES (?, ?, ?, ?, ?, ?)");
            if($stmtInsert){
                $stmtInsert->bind_param("ssiidd", $from_user_id, $to_user_id, $level, $bet_amount, $percent, $commission);
                $stmtInsert->execute();
            }
            $stmtUpdate = $conn->prepare("UPDATE referral_rewards SET referral_balance = referral_balance + ? WHERE unique_id = ?");
            if($stmtUpdate){
                $stmtUpdate->bind_param("ds", $commission, $to_user_id);
                $stmtUpdate->execute();
            }
        }
    }
}

/**
 * किसी नंबर के लिए कौन-कौन से रंग होते हैं, यह बताता है।
 */
function getColorForNumber($number) {
    $colors = [];

    if (in_array($number, [2, 4, 6, 8])) $colors[] = 'red';
    if (in_array($number, [1, 3, 7, 9])) $colors[] = 'green';

    if ($number === 0) {
        $colors[] = 'red';    // half red
        $colors[] = 'violet';
    }

    if ($number === 5) {
        $colors[] = 'green';  // half green
        $colors[] = 'violet';
    }

    return $colors;
}

/**
 * किसी बेट पर संभावित जीत की राशि की गणना करता है।
 */
function calculatePotentialWin($bet) {
    $amt = (float)$bet['amount'];
    $type = $bet['bet_type'];
    $value = $bet['bet_value'];

    if ($type === 'number') {
        return $amt * 9.45; // नंबर पर जीत
    }
    if ($type === 'color') {
        if ($value === 'violet') return $amt * 4.5; // वायलेट पर जीत
        // रेड और ग्रीन के लिए, हम औसत 1.95x मान लेते हैं
        return $amt * 1.95;
    }
    return 0;
}

// ===================================================================
// मुख्य लॉजिक (Main Logic)
// ===================================================================

// चरण 1: सक्रिय पीरियड (Active Period) की जानकारी प्राप्त करें
$sql_period = "SELECT period_id FROM parity_periods WHERE is_active = 1 ORDER BY id DESC LIMIT 1";
$result_period = $conn->query($sql_period);
if ($result_period->num_rows === 0) exit("No active period found.");
$current_period_id = $result_period->fetch_assoc()['period_id'];

// चरण 2: इस पीरियड में लगी सभी बेट्स और खिलाड़ियों की जानकारी निकालें
$sql_bets = "SELECT unique_id, bet_type, bet_value, amount FROM parity_bets WHERE period_id = ?";
$stmt_bets = $conn->prepare($sql_bets);
$stmt_bets->bind_param("s", $current_period_id);
$stmt_bets->execute();
$result_bets = $stmt_bets->get_result();

$all_bets = [];
$player_bets = [];
while ($row = $result_bets->fetch_assoc()) {
    $all_bets[] = $row;
    $uid = $row['unique_id'];
    if (!isset($player_bets[$uid])) $player_bets[$uid] = 0;
    $player_bets[$uid] += (float)$row['amount'];
}
$unique_player_ids = array_keys($player_bets);
$total_unique_players = count($unique_player_ids);

// चरण 3: विजेता का निर्धारण करें (यह सबसे महत्वपूर्ण हिस्सा है)
$decision_method = ""; // यह बताएगा कि रिजल्ट किस आधार पर तय हुआ
$winning_number = null; // अंतिम विजेता नंबर

// केस 1: अगर कोई बेट नहीं लगी है
if ($total_unique_players == 0) {
    $decision_method = "Random (No Bets)"; // कोई नहीं खेल रहा, तो रैंडम नंबर
} 
// केस 2: अगर बहुत सारे खिलाड़ी हैं (3 से ज़्यादा)
elseif ($total_unique_players > PLAYER_THRESHOLD) {
    $decision_method = "Min Payout (High Player Count)"; // कंपनी का फायदा देखो, ऐसा नंबर चुनो जिससे सबसे कम पैसे देने पड़ें
} 
// केस 3: अगर कम खिलाड़ी हैं (1 से 3)
else {
    // स्मार्ट नियम लागू करें
    if (!empty($unique_player_ids)) {
        $placeholders = implode(',', array_fill(0, count($unique_player_ids), '?'));
        $types = str_repeat('s', count($unique_player_ids));
        
        $sql_data = "SELECT unique_id, balance, consecutive_wins, consecutive_losses FROM users WHERE unique_id IN ($placeholders)";
        $stmt_data = $conn->prepare($sql_data);
        
        if ($stmt_data) {
            $stmt_data->bind_param($types, ...$unique_player_ids);
            $stmt_data->execute();
            $data_result = $stmt_data->get_result();
            
            $user_to_force_win = null;
            $users_data = [];
            while($user = $data_result->fetch_assoc()){
                $users_data[$user['unique_id']] = $user;
            }

            // पहले खिलाड़ी का डेटा जाँचें
            $player_to_check = reset($users_data); 
            $uid = $player_to_check['unique_id'];
            $total_bet_amount = $player_bets[$uid] ?? 0;
            $current_balance = (float)$player_to_check['balance'];
            $combined_balance_for_welcome = $current_balance + $total_bet_amount;

            // खिलाड़ी की सभी बेट्स पर कुल संभावित जीत की गणना करें
            $potential_winnings = 0;
            foreach ($all_bets as $bet) {
                if ($bet['unique_id'] === $uid) {
                    $potential_winnings += calculatePotentialWin($bet);
                }
            }
            $combined_balance_for_win = $current_balance + $potential_winnings;

            // नियम 1 (सबसे पहली प्राथमिकता): वेलकम विन
            if ($combined_balance_for_welcome < WELCOME_WIN_THRESHOLD) {
                $user_to_force_win = $uid;
                $decision_method = "Forced Win (Welcome Win)";
            } 
            // नियम 2: बैलेंस + जीत की राशि ₹450 से ज़्यादा है? (आपका नया लॉजिक)
            elseif ($combined_balance_for_win >= WINNING_BALANCE_THRESHOLD) {
                $decision_method = "Min Payout (Winning Balance Threshold Met)"; // खिलाड़ी को हराओ
            }
            // नियम 3: लगातार 3 जीत हो चुकी हैं?
            elseif ((int)$player_to_check['consecutive_wins'] >= MAX_CONSECUTIVE_WINS) {
                $decision_method = "Forced Loss (Max Wins Reached)"; // खिलाड़ी को हराओ
            }
            // नियम 4: लगातार 2 हार हो चुकी हैं?
            elseif ((int)$player_to_check['consecutive_losses'] >= MAX_CONSECUTIVE_LOSSES) {
                $user_to_force_win = $uid;
                $decision_method = "Forced Win (Max Losses Reached)"; // खिलाड़ी को जिताओ
            }
            
            // अगर किसी नियम के तहत खिलाड़ी को जिताना है
            if($user_to_force_win){
                foreach($all_bets as $bet) {
                    if ($bet['unique_id'] === $user_to_force_win) {
                        if ($bet['bet_type'] === 'number') {
                            $winning_number = (int)$bet['bet_value'];
                        } else { // color bet
                            $color_to_win = $bet['bet_value'];
                            $numbers_for_color = [];
                            for($i=0; $i<=9; $i++){ if(in_array($color_to_win, getColorForNumber($i))){ $numbers_for_color[] = $i; } }
                            if(!empty($numbers_for_color)){ $winning_number = $numbers_for_color[array_rand($numbers_for_color)]; }
                        }
                        if($winning_number !== null) break; // जैसे ही जिताने वाला नंबर मिले, लूप तोड़ दो
                    }
                }
            }
        }
    }
    // अगर ऊपर के किसी भी नियम से फैसला नहीं हुआ, तो रैंडम
    if(empty($decision_method)) $decision_method = "Random (Balanced)";
}

// चरण 4: अगर नतीजा अभी तक तय नहीं हुआ है, तो उसे अब चुनें
if ($winning_number === null) {
    // अगर खिलाड़ी को हराना है (Min Payout या Forced Loss)
    if (strpos($decision_method, 'Min Payout') !== false || strpos($decision_method, 'Forced Loss') !== false) {
        // न्यूनतम भुगतान लॉजिक: ऐसा नंबर चुनो जिससे कंपनी को सबसे कम पैसे देने पड़ें
        $min_payout = PHP_INT_MAX;
        $best_result_num = null;
        for ($num_check = 0; $num_check <= 9; $num_check++) {
            $total_payout = 0;
            foreach ($all_bets as $bet) {
                $amt = (float)$bet['amount'];
                $is_win = false;
                $colors_of_num = getColorForNumber($num_check);
                if ($bet['bet_type'] === 'number' && (int)$bet['bet_value'] === $num_check) $is_win = true;
                elseif ($bet['bet_type'] === 'color' && in_array($bet['bet_value'], $colors_of_num)) $is_win = true;
                if($is_win) $total_payout += $amt * 2; // अनुमानित भुगतान
            }
            if ($total_payout < $min_payout) {
                $min_payout = $total_payout;
                $best_result_num = $num_check;
            }
        }
        $winning_number = $best_result_num ?? rand(0, 9);
    } else {
        // रैंडम मोड: कोई भी नंबर चुन लो
        $winning_number = rand(0, 9);
    }
}

// विजेता रंग निर्धारित करें
if (in_array($winning_number, [0, 5])) {
    $winning_color = 'violet';
} else {
    $possible_colors = getColorForNumber($winning_number);
    $winning_color = $possible_colors[array_rand($possible_colors)];
}

// चरण 5: डेटाबेस में रिजल्ट अपडेट करें
$sql_update_period = "UPDATE parity_periods SET is_active = 0, end_time = NOW(), winning_number = ?, winning_color = ? WHERE period_id = ?";
$stmt_update_period = $conn->prepare($sql_update_period);
$stmt_update_period->bind_param("iss", $winning_number, $winning_color, $current_period_id);
$stmt_update_period->execute();

// चरण 6: सभी खिलाड़ियों की जीत/हार प्रोसेस करें
foreach ($player_bets as $uid => $total_bet) {
    $payout = 0;
    $is_win_for_user = false;
    foreach ($all_bets as $bet) {
        if ($bet['unique_id'] === $uid) {
            $amt = (float)$bet['amount'];
            $current_payout = 0;
            $is_current_bet_win = false;
            // जीत की शर्तों की जाँच
            if ($bet['bet_type'] === 'color') {
                if ($bet['bet_value'] === 'violet' && in_array($winning_number, [0, 5])) {
                    $is_current_bet_win = true; $current_payout = $amt * 4.5;
                } elseif ($bet['bet_value'] === 'red' && in_array($winning_number, [2, 4, 6, 8])) {
                    $is_current_bet_win = true; $current_payout = $amt * 1.95;
                } elseif ($bet['bet_value'] === 'green' && in_array($winning_number, [1, 3, 7, 9])) {
                    $is_current_bet_win = true; $current_payout = $amt * 1.95;
                } elseif ($bet['bet_value'] === 'red' && $winning_number == 0 && $winning_color == 'violet') {
                    $is_current_bet_win = true; $current_payout = $amt * 1.45;
                } elseif ($bet['bet_value'] === 'green' && $winning_number == 5   && $winning_color == 'violet') {
                    $is_current_bet_win = true; $current_payout = $amt * 1.45;
                }
            }
            if ($bet['bet_type'] === 'number' && (int)$bet['bet_value'] === $winning_number) {
                $is_current_bet_win = true; $current_payout += $amt * 9.45;
            }
            
            if ($is_current_bet_win) {
                $is_win_for_user = true;
                $payout += $current_payout;
            }
            // बेट का स्टेटस अपडेट करें
            $status_amount = $is_current_bet_win ? "+" . number_format($current_payout, 2, '.', '') : "-" . number_format($amt, 2, '.', '');
            $update_bet_sql = "UPDATE parity_bets SET result_number = ?, result_text = ?, status = ? WHERE period_id = ? AND unique_id = ? AND bet_type = ? AND bet_value = ? AND amount = ?";
            $stmt_bet_update = $conn->prepare($update_bet_sql);
            $stmt_bet_update->bind_param("issssssd", $winning_number, $winning_color, $status_amount, $current_period_id, $uid, $bet['bet_type'], $bet['bet_value'], $amt);
            $stmt_bet_update->execute();
        }
    }
    // यूजर का बैलेंस और जीत/हार की गिनती अपडेट करें
    if ($is_win_for_user) {
        $update_user_sql = "UPDATE users SET balance = balance + ?, consecutive_wins = consecutive_wins + 1, consecutive_losses = 0 WHERE unique_id = ?";
        $stmt_user_update = $conn->prepare($update_user_sql);
        $stmt_user_update->bind_param("ds", $payout, $uid);
    } else {
        $update_user_sql = "UPDATE users SET consecutive_losses = consecutive_losses + 1, consecutive_wins = 0 WHERE unique_id = ?";
        $stmt_user_update = $conn->prepare($update_user_sql);
        $stmt_user_update->bind_param("s", $uid);
    }
    $stmt_user_update->execute();
    // रेफरल कमीशन दें
    giveReferralCommission($conn, $uid, $total_bet);
}

// चरण 7: नया पीरियड बनाएं
$date_part = date('Ymd');
$seconds_since_midnight = time() - strtotime('today');
$period_number = floor($seconds_since_midnight / 60) + 1;
$new_period_id = $date_part . str_pad($period_number, 4, '0', STR_PAD_LEFT);
$sql_insert_period = "INSERT INTO parity_periods (period_id, start_time, is_active) VALUES (?, NOW(), 1)";
$stmt_new_period = $conn->prepare($sql_insert_period);
$stmt_new_period->bind_param("s", $new_period_id);
$stmt_new_period->execute();

// अंतिम आउटपुट
echo "✅ Result: Number = $winning_number, Color = $winning_color, New Period: $new_period_id, Method: $decision_method";
$conn->close();

?>
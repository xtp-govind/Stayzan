<?php
// Disable browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Content-Type: application/json");


// Database connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get limit from query string (default 15)
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 30;
if ($limit <= 0 || $limit > 100) $limit = 30; // limit protection

// Fetch the last completed periods (where winning_number is not null)
$sql = "SELECT * FROM parity_periods 
        WHERE winning_number IS NOT NULL 
        ORDER BY id DESC 
        LIMIT ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $limit);
$stmt->execute();
$result = $stmt->get_result();

// Format response
$periods = [];
while ($row = $result->fetch_assoc()) {
    $periods[] = $row;
}

echo json_encode([
    'success' => true,
    'periods' => $periods
]);

$stmt->close();
$conn->close();
?>
<?php

// Disable browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Content-Type: application/json");

// Database connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM parity_periods WHERE is_active = 1 ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $period = $result->fetch_assoc();
    
    // Bereken de resterende tijd
    $startTime = new DateTime($period['start_time']);
    $now = new DateTime();
    $elapsed = $now->getTimestamp() - $startTime->getTimestamp();
    $remaining = max(0, 60 - $elapsed);

    echo json_encode([
        'success' => true,
        'period' => $period,
        'remaining_seconds' => $remaining
    ]);
} else {
    echo json_encode(['success' => false, 'error' => 'No active period found']);
}

$conn->close();
?>

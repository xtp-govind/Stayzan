<?php

file_put_contents("fastparity_bet_debug.txt", "RAW INPUT:\n" . file_get_contents("php://input"));

// 🧠 Disable browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Content-Type: application/json");

// Start session
session_start();

// 🧠 Database credentials
$servername = "localhost";
$username = "u976552851_hellogovind";
$password = "Govind@00#";
$dbname = "u976552851_hellogovind";

// 🧠 Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed.']);
    exit();
}

// 🧠 Check if user is logged in
if (!isset($_SESSION['unique_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Authentication required.']);
    exit();
}
$unique_id = $_SESSION['unique_id'];

$rawInput = file_get_contents("php://input");
file_put_contents("parity_bet_debug.txt", "RAW INPUT:\n" . $rawInput); // ✅ DEBUG

$data = json_decode($rawInput, true);

// 🧠 Validate JSON
if (
    !is_array($data) ||
    !isset($data['periodId'], $data['betType'], $data['betValue'], $data['amount']) ||
    !is_numeric($data['amount']) ||
    floatval($data['amount']) <= 0
) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON or missing bet data.']);
    exit();
}

// 🧠 Sanitize input
$periodId = $data['periodId'];
$betType = $data['betType'];
$betValue = $data['betValue'];
$amount = floatval($data['amount']);

// 🧠 Start transaction
$conn->begin_transaction();

try {
    // 1. Check balance
    $stmt_balance = $conn->prepare("SELECT balance FROM users WHERE unique_id = ? FOR UPDATE");
    $stmt_balance->bind_param("s", $unique_id);
    $stmt_balance->execute();
    $result_balance = $stmt_balance->get_result();
    $user = $result_balance->fetch_assoc();

    if (!$user || $user['balance'] < $amount) {
        throw new Exception('Insufficient balance.');
    }

    // 2. Deduct balance
    $newBalance = $user['balance'] - $amount;
    $stmt_update = $conn->prepare("UPDATE users SET balance = ? WHERE unique_id = ?");
    $stmt_update->bind_param("ds", $newBalance, $unique_id);
    $stmt_update->execute();

    // 3. Insert bet
    $stmt_bet = $conn->prepare("INSERT INTO parity_bets (unique_id, period_id, bet_type, bet_value, amount) VALUES (?, ?, ?, ?, ?)");
    $stmt_bet->bind_param("ssssd", $unique_id, $periodId, $betType, $betValue, $amount);
    $stmt_bet->execute();

    // 4. Commit transaction
    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Bet placed successfully!',
        'newBalance' => $newBalance
    ]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
<?php
// एक लॉग फ़ाइल का नाम, यह हमें बताएगी कि क्या हो रहा है
$logFile = 'webhook_activity.log';

// फंक्शन जो लॉग फ़ाइल में संदेश लिखेगा
function write_log($message) {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[{$timestamp}] " . $message . "\n", FILE_APPEND);
}

write_log("--- वेबहुक शुरू हुआ ---");

// --- कॉन्फ़िगरेशन ---
$botToken = "8404477667:AAFH_4wVwvyTTqFEHFWPbNparq557Txpgzo";

// --- डेटाबेस कनेक्शन ---
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    write_log("डेटाबेस कनेक्शन विफल: " . $conn->connect_error);
    exit();
}
write_log("डेटाबेस सफलतापूर्वक कनेक्ट हो गया।");

// --- टेलीग्राम से इनपुट प्राप्त करें ---
$updateJson = file_get_contents("php://input");
$update = json_decode($updateJson, true);

if (!$update) {
    write_log("टेलीग्राम से कोई डेटा नहीं मिला या JSON अमान्य है।");
    exit();
}

write_log("टेलीग्राम से डेटा मिला: " . $updateJson);

if (isset($update["callback_query"])) {
    $callbackQuery = $update["callback_query"];
    $data = $callbackQuery['data'];
    $chatId = $callbackQuery['message']['chat']['id'];
    $messageId = $callbackQuery['message']['message_id'];
    $originalCaption = $callbackQuery['message']['caption'];

    write_log("Callback Query प्राप्त हुई: " . $data);

    list($status, $transactionId) = explode(':', $data, 2);
    $responseText = '';

    // --- ट्रांजेक्शन की स्थिति जांचें ---
    $stmt = $conn->prepare("SELECT unique_id, amount, status FROM transactions WHERE id = ?");
    $stmt->bind_param("i", $transactionId);
    $stmt->execute();
    $result = $stmt->get_result();
    $transaction = $result->fetch_assoc();
    $stmt->close();

    if ($transaction) {
        write_log("ट्रांजेक्शन ID {$transactionId} डेटाबेस में मिला। वर्तमान स्थिति: " . $transaction['status']);
        if ($transaction['status'] === 'pending') {
            if ($status === 'success') {
                $conn->begin_transaction();
                try {
                    // 1. transactions टेबल में स्थिति अपडेट करें
                    $stmt1 = $conn->prepare("UPDATE transactions SET status = 'success' WHERE id = ?");
                    $stmt1->bind_param("i", $transactionId);
                    $stmt1->execute();
                    $stmt1->close();
                    write_log("transactions टेबल अपडेट की गई -> success");

                    // 2. users टेबल में बैलेंस अपडेट करें
                    $stmt2 = $conn->prepare("UPDATE users SET balance = balance + ? WHERE unique_id = ?");
                    $stmt2->bind_param("ds", $transaction['amount'], $transaction['unique_id']);
                    $stmt2->execute();
                    $stmt2->close();
                    write_log("users टेबल में बैलेंस अपडेट किया गया। User: " . $transaction['unique_id'] . ", Amount: " . $transaction['amount']);
                    
                    $conn->commit();
                    $responseText = "✅ ट्रांजेक्शन सफल! बैलेंस अपडेट कर दिया गया है।";
                    $newStatus = "SUCCESS";
                } catch (Exception $e) {
                    $conn->rollback();
                    write_log("डेटाबेस त्रुटि (Exception): " . $e->getMessage());
                    $responseText = "❌ डेटाबेस त्रुटि!";
                    $newStatus = "ERROR";
                }
            } elseif ($status === 'failed') {
                $stmt = $conn->prepare("UPDATE transactions SET status = 'failed' WHERE id = ?");
                $stmt->bind_param("i", $transactionId);
                $stmt->execute();
                $stmt->close();
                write_log("transactions टेबल अपडेट की गई -> failed");
                $responseText = "❌ ट्रांजेक्शन को 'विफल' के रूप में चिह्नित किया गया है।";
                $newStatus = "FAILED";
            }

            // --- मूल टेलीग्राम संदेश को अपडेट करें ---
            $newCaption = $originalCaption . "\n\n*स्थिति: " . $newStatus . "*";
            $telegramApiUrl = "https://api.telegram.org/bot{$botToken}/editMessageCaption";
            $postFields = ['chat_id' => $chatId, 'message_id' => $messageId, 'caption' => $newCaption, 'parse_mode' => 'Markdown'];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_exec($ch);
            curl_close($ch);
            write_log("टेलीग्राम संदेश को अपडेट किया गया।");

        } else {
            write_log("ट्रांजेक्शन पहले ही प्रोसेस हो चुका है। स्थिति: " . $transaction['status']);
            $responseText = "⚠️ यह ट्रांजेक्शन पहले ही प्रोसेस हो चुका है।";
        }
    } else {
        write_log("ट्रांजेक्शन ID {$transactionId} डेटाबेस में नहीं मिला।");
        $responseText = "❌ ट्रांजेक्शन नहीं मिला!";
    }

    // टेलीग्राम को बताएं कि क्वेरी प्राप्त हो गई है
    $answerUrl = "https://api.telegram.org/bot{$botToken}/answerCallbackQuery?callback_query_id={$callbackQuery['id']}&text=" . urlencode($responseText);
    file_get_contents($answerUrl);
}

$conn->close();
write_log("--- वेबहुक समाप्त ---");
?>

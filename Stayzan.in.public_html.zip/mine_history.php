<?php

// ✅ DB connection
$host = "localhost";
$user = "u976552851_party";
$password = "Govind@00#";
$database = "u976552851_party";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}


// 2. यूज़र की पहचान करें (सेशन या टोकन के माध्यम से)
session_start();

// सुरक्षा जांच: सुनिश्चित करें कि यूज़र लॉग इन है
if (!isset($_SESSION['unique_id'])) {
    // अगर यूज़र लॉग इन नहीं है, तो एरर भेजें
    header('Content-Type: application/json');
    http_response_code(401); // Unauthorized
    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
    exit(); // स्क्रिप्ट को रोक दें
}

// लॉग-इन यूज़र की आईडी प्राप्त करें
$userId = $_SESSION['unique_id'];

// 3. जावास्क्रिप्ट से भेजा गया JSON डेटा प्राप्त करें
$data = json_decode(file_get_contents('php://input'), true);

// 4. डेटा की जाँच करें (सुनिश्चित करें कि सभी ज़रूरी जानकारी मौजूद है)
if (
    !isset($data['bet_amount']) ||
    !isset($data['grid_size']) ||
    !isset($data['result']) ||
    !isset($data['winnings'])
) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Missing required game data.']);
    exit();
}

// 5. डेटा को वैरिएबल में सुरक्षित रूप से स्टोर करें
$betAmount = floatval($data['bet_amount']);
$gridSize = $data['grid_size']; // यह एक स्ट्रिंग है, जैसे '3x3'
$result = $data['result'];       // यह 'win', 'loss', या 'cashout' में से एक होना चाहिए
$winnings = floatval($data['winnings']);

// सुरक्षा: सुनिश्चित करें कि 'result' का मान ENUM में से ही एक है
$allowedResults = ['win', 'loss', 'cashout'];
if (!in_array($result, $allowedResults)) {
    header('Content-Type: application/json');
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid result value.']);
    exit();
}

// 6. डेटाबेस में डेटा डालने के लिए SQL क्वेरी तैयार करें (Prepared Statement का उपयोग करके)
// यह SQL इंजेक्शन से बचाता है और सबसे सुरक्षित तरीका है।
$sql = "INSERT INTO mine_bet (user_id, bet_amount, grid_size, result, winnings) VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if ($stmt === false) {
    // अगर क्वेरी तैयार करने में कोई एरर आता है
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database query preparation failed.']);
    exit();
}

// 7. वैरिएबल को क्वेरी से बाइंड करें
// "idssd" का मतलब है: i=integer, d=double, s=string
$stmt->bind_param("ssssd", $userId, $betAmount, $gridSize, $result, $winnings);

// 8. क्वेरी को चलाएं
if ($stmt->execute()) {
    // अगर डेटा सफलतापूर्वक सेव हो गया है
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Game history recorded successfully.']);
} else {
    // अगर डेटा सेव करने में कोई एरर आता है
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to record game history.']);
}

// 9. स्टेटमेंट और कनेक्शन को बंद करें
$stmt->close();
$conn->close();

?>

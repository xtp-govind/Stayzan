<?php
header('Content-Type: application/json');
session_start();

// ✅ 1. कनेक्शन और सुरक्षा जाँच (कोई बदलाव नहीं)
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit();
}

if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["status" => "error", "message" => "Authentication required."]);
    exit();
}

// ✅ 2. इनपुट प्राप्त करें और जाँचें (कोई बदलाव नहीं)
$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['grid_size'], $input['opened_boxes'], $input['outcome'], $input['current_winnings'], $input['bet_amount'])) {
    echo json_encode(["status" => "error", "message" => "Invalid request data."]);
    exit();
}

$userId = $_SESSION['unique_id'];
$grid_size = intval($input['grid_size']);
$opened_boxes = $input['opened_boxes'];
$initial_outcome = $input['outcome'];
$current_game_winnings = floatval($input['current_winnings']);
$bet_amount = floatval($input['bet_amount']);
$total_boxes = $grid_size * $grid_size;
$last_clicked_index = end($opened_boxes);
$opened_count = count($opened_boxes);

// ✅ 3. यूज़र का प्रॉफ़िट साइकिल प्राप्त करें (कोई बदलाव नहीं)
$query = "SELECT total_won_mine, total_lost_mine FROM users WHERE unique_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$user_data = $stmt->get_result()->fetch_assoc();
$stmt->close();
$profit_cycle = $user_data['total_won_mine'] - $user_data['total_lost_mine'];
$projected_total_profit = $profit_cycle + $current_game_winnings;


// --- ग्रिड के आकार के आधार पर नियम सेट करें ---
if ($grid_size == 2) {
    // 2x2 ग्रिड के लिए सख्त नियम
    $min_clicks_for_risk = 1; // 1 क्लिक के बाद ही रिस्क शुरू
    $min_clicks_for_loss = rand(1, 2); // 1 या 2 क्लिक के बाद हराओ
} else {
    // 3x3 और 4x4 ग्रिड के लिए सामान्य नियम
    $min_clicks_for_risk = 3; // 3 क्लिक के बाद रिस्क
    $min_clicks_for_loss = rand(2, 3); // 2 या 3 क्लिक के बाद हराओ
}

$should_lose = false;
$decision_reason = "Default: Player is safe.";

// --- चरण 1: प्रॉफ़िट कंट्रोल (अब ज़्यादा सख्त) ---
// अगर अनुमानित प्रॉफ़िट ₹100 से ज़्यादा है
if ($projected_total_profit >= 100) {
    // पहले क्लिक पर प्रॉफ़िट पार हो तो भी एक मौका दो, लेकिन दूसरे पर पक्का हराओ
    if ($opened_count > 0) {
        $should_lose = true;
        $decision_reason = "Phase 1 (Profit Control): Projected profit (₹{$projected_total_profit}) is over the ₹100 limit. Forcing loss on click {$opened_count}.";
    } else {
        // यह पहला क्लिक है, अभी सुरक्षित है
        $decision_reason = "Phase 1 (Profit Control): Profit limit reached on first click. Player is safe for now, but will likely lose on the next click.";
    }
}

// --- चरण 2: रिकवरी और रिस्क (डायनामिक) ---
// यह नियम तभी लागू होगा जब ऊपर वाला नियम लागू नहीं हुआ हो।
else if (!$should_lose && $initial_outcome === 'win') {
    $is_bet_recovered = ($current_game_winnings >= $bet_amount * 0.9);
    // यहाँ डायनामिक वैरिएबल का उपयोग करें
    $has_opened_enough = ($opened_count >= $min_clicks_for_risk);

    if ($is_bet_recovered && $has_opened_enough) {
        // 30% चांस है कि वह अब हार जाएगा।
        if (rand(1, 100) <= 30) {
            $should_lose = true;
            $decision_reason = "Phase 2 (Risk): Bet recovered and opened enough boxes ({$opened_count}). Introducing a 30% chance of loss.";
        } else {
            $decision_reason = "Phase 2 (Risk): Survived the 30% chance of loss.";
        }
    } else {
        $decision_reason = "Phase 2 (Safe): Player has not met risk conditions yet.";
    }
}

// --- चरण 3: अगर गेम शुरू से ही हारने वाला था (डायनामिक) ---
else if (!$should_lose && $initial_outcome === 'loss') {
    // यहाँ भी डायनामिक वैरिएबल का उपयोग करें
    if ($opened_count >= $min_clicks_for_loss) {
        $should_lose = true;
        $decision_reason = "Phase 3 (Initial Loss): Game was set to 'loss'. Forcing loss after {$opened_count} clicks (limit was {$min_clicks_for_loss}).";
    } else {
        $decision_reason = "Phase 3 (Initial Loss): Game is set to 'loss', but waiting for {$min_clicks_for_loss} clicks to force loss.";
    }
}

// ✅ 4. बम की पोजीशन तय करें (कोई बदलाव नहीं)
if ($should_lose) {
    // अगर हराना है, तो बम को आखिरी क्लिक पर रखो।
    $bomb_position = $last_clicked_index;
} else {
    // अगर नहीं हराना है, तो बम को किसी सुरक्षित जगह पर रखो जहाँ क्लिक नहीं हुआ है।
    do {
        $bomb_position = rand(0, $total_boxes - 1);
    } while (in_array($bomb_position, $opened_boxes));
}

// ✅ 5. JSON रिस्पॉन्स भेजें (कोई बदलाव नहीं)
echo json_encode([
    'status' => 'success',
    'bomb_position' => $bomb_position,
    'debug_info' => [
        'decision_reason' => $decision_reason,
        'should_lose' => $should_lose,
        'opened_count' => $opened_count,
        'profit_cycle' => $profit_cycle,
        'current_game_winnings' => $current_game_winnings,
        'projected_total_profit' => $projected_total_profit,
        'dynamic_min_clicks_for_loss' => $min_clicks_for_loss // डीबगिंग के लिए यह उपयोगी हो सकता है
    ]
]);

$conn->close();
?>

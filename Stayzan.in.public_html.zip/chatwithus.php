<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>हमसे संपर्क करें - Stayzan.in</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #1a237e; /* Dark Blue */
            text-align: center;
        }
        .contact-info, .contact-form {
            margin-bottom: 25px;
        }
        .contact-info p {
            text-align: center;
            font-size: 1.1em;
        }
        a {
            color: #1a237e;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box; /* Important for padding */
        }
        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }
        .submit-btn {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: #28a745; /* Green */
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1.2em;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .submit-btn:hover {
            background-color: #218838; /* Darker Green */
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 0.9em;
            color: #777;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>हमसे संपर्क करें</h1>
        <p style="text-align:center;">हमारे पास आपके लिए कोई प्रश्न या प्रतिक्रिया है? हम आपकी सहायता के लिए यहां हैं!</p>

        <div class="contact-info">
            <h2>ईमेल सपोर्ट</h2>
            <p>
                किसी भी प्रश्न या सहायता के लिए, कृपया हमें ईमेल करें। हम 24 घंटे के भीतर जवाब देने की पूरी कोशिश करते हैं।
            </p>
            <p>
                <strong><a href="mailto:support@stayzan.in">support@stayzan.in</a></strong>
            </p>
        </div>

        <hr>

        <div class="contact-form">
            <h2>हमें एक संदेश भेजें</h2>
            <!-- Note: This form is for frontend display only. 
                 To make it work, you need backend PHP code to process the form data. -->
            <form action="handle_form.php" method="POST">
                <div class="form-group">
                    <label for="name">आपका नाम</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">आपका ईमेल</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="subject">विषय</label>
                    <input type="text" id="subject" name="subject" required>
                </div>
                <div class="form-group">
                    <label for="message">आपका संदेश</label>
                    <textarea id="message" name="message" required></textarea>
                </div>
                <button type="submit" class="submit-btn">संदेश भेजें</button>
            </form>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2025 Stayzan.in | सभी अधिकार सुरक्षित।</p>
    </div>

</body>
</html>

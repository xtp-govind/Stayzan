<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StayZan - खेलें, जीतें और कमाएं | India's #1 Prediction Game</title>
    <meta name="description" content="StayZan - भारत का #1 colour prediction gaming platform। Fast-Parity, Parity games खेलें और instant पैसे जीतें। ₹100 welcome bonus!">
    <meta name="keywords" content="prediction game, fast parity, online gaming, earn money, stayzan">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header Styles */
        .header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(45deg, #fbbf24, #f97316);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }

        .logo-text {
            font-size: 1.5rem;
            font-weight: bold;
            color: white;
        }

        .nav {
            display: flex;
            gap: 2rem;
        }

        .nav a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }

        .nav a:hover {
            color: #fbbf24;
        }

        .signup-btn {
            background: linear-gradient(45deg, #fbbf24, #f97316);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .signup-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(251, 191, 36, 0.4);
        }

        /* Background */
        .main-bg {
            background: linear-gradient(135deg, #7c3aed 0%, #2563eb 50%, #7c3aed 100%);
            min-height: 100vh;
        }

        /* Hero Section */
        .hero {
            padding: 4rem 0;
            text-align: center;
            color: white;
        }

        .hero-content {
            max-width: 800px;
            margin: 0 auto;
        }

        .welcome-badge {
            background: #fbbf24;
            color: black;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 2rem;
            display: inline-block;
        }

        .hero-title {
            font-size: 3.5rem;
            font-weight: bold;
            margin-bottom: 1rem;
            background: linear-gradient(45deg, #fde047, #fb923c);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero-subtitle {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: #dbeafe;
        }

        .hero-description {
            font-size: 1.1rem;
            margin-bottom: 2rem;
            color: #bfdbfe;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .hero-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-bottom: 3rem;
            flex-wrap: wrap;
        }

        .btn-primary {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 1rem 2rem;
            border: none;
            border-radius: 25px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(16, 185, 129, 0.4);
        }

        .btn-secondary {
            background: transparent;
            color: white;
            padding: 1rem 2rem;
            border: 2px solid white;
            border-radius: 25px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-secondary:hover {
            background: white;
            color: #7c3aed;
        }

        /* Benefits Grid */
        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }

        .benefit-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 1.5rem;
            border-radius: 15px;
            text-align: center;
            transition: all 0.3s;
        }

        .benefit-card:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-5px);
        }

        .benefit-icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        /* Section Styles */
        .section {
            padding: 4rem 0;
        }

        .section-alt {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(5px);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 1rem;
            color: white;
        }

        .section-subtitle {
            font-size: 1.2rem;
            text-align: center;
            margin-bottom: 3rem;
            color: #bfdbfe;
        }

        /* Game Cards */
        .games-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            max-width: 1000px;
            margin: 0 auto;
        }

        .game-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s;
        }

        .game-card:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: scale(1.05);
        }

        .game-image {
            width: 100%;
            height: 600px;
            object-fit: cover;
        }

        .game-content {
            padding: 1.5rem;
        }

        .game-title {
            font-size: 1.3rem;
            font-weight: bold;
            color: white;
            margin-bottom: 0.5rem;
        }

        .game-description {
            color: #bfdbfe;
            margin-bottom: 1rem;
        }

        .feature-list {
            list-style: none;
        }

        .feature-list li {
            color: white;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .check-icon {
            color: #10b981;
            font-weight: bold;
        }

        /* How It Works */
        .steps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            max-width: 1000px;
            margin: 0 auto;
        }

        .step-card {
            text-align: center;
            color: white;
        }

        .step-number {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 1.5rem;
            font-weight: bold;
            color: white;
        }

        .step-1 { background: linear-gradient(45deg, #fbbf24, #f97316); }
        .step-2 { background: linear-gradient(45deg, #10b981, #059669); }
        .step-3 { background: linear-gradient(45deg, #3b82f6, #1d4ed8); }
        .step-4 { background: linear-gradient(45deg, #8b5cf6, #7c3aed); }

        .step-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .step-description {
            color: #bfdbfe;
        }

        /* Features Grid */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            max-width: 1000px;
            margin: 0 auto;
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 2rem;
            border-radius: 15px;
            text-align: center;
            transition: all 0.3s;
        }

        .feature-card:hover {
            background: rgba(255, 255, 255, 0.15);
        }

        .feature-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .feature-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: white;
            margin-bottom: 0.5rem;
        }

        .feature-description {
            color: #bfdbfe;
        }

        /* Download Section */
        .download-section {
            background: linear-gradient(45deg, #7c3aed, #2563eb);
            border-radius: 20px;
            padding: 3rem;
            text-align: center;
            margin: 2rem 0;
        }

        .download-icon {
            font-size: 4rem;
            color: white;
            margin-bottom: 1.5rem;
        }

        .download-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-download {
            background: white;
            color: #7c3aed;
            padding: 1rem 2rem;
            border: none;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-download:hover {
            background: #f3f4f6;
        }

        /* CTA Section */
        .cta-section {
            background: linear-gradient(45deg, #fbbf24, #f97316);
            padding: 4rem 0;
            text-align: center;
        }

        .cta-form {
            max-width: 400px;
            margin: 2rem auto;
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .cta-input {
            flex: 1;
            padding: 1rem;
            border: none;
            border-radius: 25px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            font-size: 1rem;
            min-width: 250px;
        }

        .cta-input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .cta-submit {
            background: white;
            color: #f97316;
            padding: 1rem 2rem;
            border: none;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .cta-submit:hover {
            background: #f3f4f6;
        }

        /* Footer */
        .footer {
            background: #1f2937;
            color: white;
            padding: 3rem 0 1rem;
        }

        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .footer-section h4 {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .footer-section ul {
            list-style: none;
        }

        .footer-section ul li {
            margin-bottom: 0.5rem;
        }

        .footer-section ul li a {
            color: #9ca3af;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-section ul li a:hover {
            color: white;
        }

        .footer-bottom {
            border-top: 1px solid #374151;
            padding-top: 2rem;
            text-align: center;
            color: #9ca3af;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav {
                display: none;
            }
            
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .benefits-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .cta-form {
                flex-direction: column;
            }
            
            .cta-input {
                min-width: auto;
            }
        }

        @media (max-width: 480px) {
            .benefits-grid {
                grid-template-columns: 1fr;
            }
            
            .hero-title {
                font-size: 2rem;
            }
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }

        /* Smooth scrolling */
        html {
            scroll-behavior: smooth;
        }
    </style>
</head>
<body>
    <div class="main-bg">
        <!-- Header -->
        <header class="header">
            <div class="container">
                <div class="header-content">
                    <div class="logo">
                        <div class="logo-icon">🏆</div>
                        <div class="logo-text">StayZan</div>
                    </div>
                    
                    <nav class="nav">
                        <a href="#games">Games</a>
                        <a href="#features">Features</a>
                        <a href="#download">Download</a>
                    </nav>
                    
                    <a href="#" class="signup-btn" onclick="handleSignup()">Signup करें</a>
                </div>
            </div>
        </header>

        <!-- Hero Section -->
        <section class="hero">
            <div class="container">
                <div class="hero-content fade-in-up">
                    <div class="welcome-badge">
                        🎉 Welcome Bonus: ₹100 Free!
                    </div>
                    
                    <h1 class="hero-title">
                        खेलें, जीतें और कमाएं
                    </h1>
                    
                    <p class="hero-subtitle">
                        भारत का #1  colour Prediction Game Platform
                    </p>
                    
                    <p class="hero-description">
                        Fast-Parity, Parity और अन्य exciting games खेलें। सिर्फ 2 मिनट में predict करें और instant पैसे जीतें!
                    </p>
                    
                    <div class="hero-buttons">
                        <a href="#" class="btn-primary" onclick="handleSignup()">
                            ▶️ अभी खेलना शुरू करें
                        </a>
                        
                        <a href="#games" class="btn-secondary">
                            🎯 Games देखें
                        </a>
                    </div>
                    
                    <!-- Key Benefits -->
                    <div class="benefits-grid">
                        <div class="benefit-card">
                            <div class="benefit-icon">🎁</div>
                            <p><strong>₹100 Bonus</strong></p>
                        </div>
                        <div class="benefit-card">
                            <div class="benefit-icon">⏰</div>
                            <p><strong>Instant Withdraw</strong></p>
                        </div>
                        <div class="benefit-card">
                            <div class="benefit-icon">👥</div>
                            <p><strong>Referral Rewards</strong></p>
                        </div>
                        <div class="benefit-card">
                            <div class="benefit-icon">🛡️</div>
                            <p><strong>100% Safe</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Game Showcase -->
        <section id="games" class="section section-alt">
            <div class="container">
                <div class="section-title">हमारे Popular Games</div>
                <div class="section-subtitle">Multiple game modes में अपना luck try करें</div>
                
                <div class="games-grid">
                    <!-- Fast-Parity Game -->
                    <div class="game-card">
                        <img src="logo/parity.jpg" alt="Fast-Parity Game Interface" class="game-image">
                        <div class="game-content">
                            <div class="game-title">Fast-Parity</div>
                            <div class="game-description">1 मिनट का quick prediction game</div>
                            <ul class="feature-list">
                                <li><span class="check-icon">✓</span> Color और Number prediction</li>
                                <li><span class="check-icon">✓</span> 1 मिनट में result</li>
                                <li><span class="check-icon">✓</span> High winning odds</li>
                            </ul>
                        </div>
                    </div>

                    <!-- Game Dashboard -->
                    <div class="game-card">
                        <img src="logo/home.jpg" alt="Game Dashboard" class="game-image">
                        <div class="game-content">
                            <div class="game-title">Game Dashboard</div>
                            <div class="game-description">आपका personal gaming hub</div>
                            <ul class="feature-list">
                                <li><span class="check-icon">✓</span> Wallet management</li>
                                <li><span class="check-icon">✓</span> Daily rewards</li>
                                <li><span class="check-icon">✓</span> Tournament access</li>
                            </ul>
                        </div>
                    </div>

                    <!-- Referral Program -->
                    <div class="game-card">
                        <img src="logo/rafer.jpg" alt="Referral Program" class="game-image">
                        <div class="game-content">
                            <div class="game-title">Referral Program</div>
                            <div class="game-description">Friends को invite करें और कमाएं</div>
                            <ul class="feature-list">
                                <li><span class="check-icon">✓</span> हर referral पर bonus</li>
                                <li><span class="check-icon">✓</span> Instant withdrawal</li>
                                <li><span class="check-icon">✓</span> Unlimited earning</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- How It Works -->
        <section class="section">
            <div class="container">
                <div class="section-title">कैसे खेलें?</div>
                <div class="section-subtitle">सिर्फ 4 आसान steps में शुरू करें</div>
                
                <div class="steps-grid">
                    <div class="step-card">
                        <div class="step-number step-1">1</div>
                        <div class="step-title">Sign Up करें</div>
                        <div class="step-description">Account बनाएं और ₹100 welcome bonus पाएं</div>
                    </div>
                    
                    <div class="step-card">
                        <div class="step-number step-2">2</div>
                        <div class="step-title">Game चुनें</div>
                        <div class="step-description">Fast-Parity या अन्य games में से कोई भी चुनें</div>
                    </div>
                    
                    <div class="step-card">
                        <div class="step-number step-3">3</div>
                        <div class="step-title">Predict करें</div>
                        <div class="step-description">Color या number predict करें और wait करें</div>
                    </div>
                    
                    <div class="step-card">
                        <div class="step-number step-4">4</div>
                        <div class="step-title">Win करें</div>
                        <div class="step-description">जीतें और instant अपने account में पैसे पाएं</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Features -->
        <section id="features" class="section section-alt">
            <div class="container">
                <div class="section-title">क्यों चुनें StayZan?</div>
                <div class="section-subtitle">India का most trusted gaming platform</div>
                
                <div class="features-grid">
                    <div class="feature-card">
                        <div class="feature-icon" style="color: #10b981;">⏰</div>
                        <div class="feature-title">Instant Withdrawals</div>
                        <div class="feature-description">जीते हुए पैसे तुरंत अपने bank account में transfer करें</div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon" style="color: #3b82f6;">📱</div>
                        <div class="feature-title">Mobile Friendly</div>
                        <div class="feature-description">किसी भी device पर seamless gaming experience</div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon" style="color: #8b5cf6;">🛡️</div>
                        <div class="feature-title">100% Safe & Secure</div>
                        <div class="feature-description">आपका data और money पूरी तरह safe है</div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon" style="color: #fbbf24;">👥</div>
                        <div class="feature-title">Referral Rewards</div>
                        <div class="feature-description">Friends को invite करें और unlimited earning करें</div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon" style="color: #f97316;">🏆</div>
                        <div class="feature-title">Daily Tournaments</div>
                        <div class="feature-description">रोज नए tournaments में participate करें</div>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon" style="color: #10b981;">💰</div>
                        <div class="feature-title">Multiple Payment Options</div>
                        <div class="feature-description">UPI, Bank Transfer, और अन्य payment methods</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Download App -->
        <section id="download" class="section">
            <div class="container">
                <div class="download-section">
                    <div class="download-icon">📱</div>
                    <div class="section-title" style="margin-bottom: 1rem;">Mobile App Download करें</div>
                    <p style="color: #dbeafe; font-size: 1.1rem; margin-bottom: 2rem; max-width: 600px; margin-left: auto; margin-right: auto;">
                        Better experience के लिए हमारा mobile app download करें। Faster loading, better graphics और exclusive features।
                    </p>
                    
                    <div class="download-buttons">
                        <a href="#" class="btn-download" onclick="downloadApp()">
                            📱 Android App Download
                        </a>
                        
                        <a href="#" class="btn-secondary" onclick="joinTelegram()">
                            Telegram Join करें
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <h2 style="font-size: 2.5rem; font-weight: bold; color: white; margin-bottom: 1rem;">
                अभी शुरू करें और ₹100 Free पाएं!
            </h2>
            <p style="font-size: 1.2rem; color: rgba(255, 255, 255, 0.9); margin-bottom: 2rem;">
                हजारों players already कमा रहे हैं। आप भी join करें!
            </p>
            
            <form class="cta-form" onsubmit="handleEmailSignup(event)">
                <input 
                    type="email" 
                    class="cta-input" 
                    placeholder="आपका email address" 
                    required
                    id="email-input"
                >
                <button type="submit" class="cta-submit">Start Playing</button>
            </form>
            
            <p style="font-size: 0.9rem; color: rgba(255, 255, 255, 0.8);">
                Sign up करके आप हमारे Terms & Conditions से agree करते हैं
            </p>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-section">
                    <div class="logo" style="margin-bottom: 1rem;">
                        <div class="logo-icon">🏆</div>
                        <div class="logo-text">StayZan</div>
                    </div>
                    <p style="color: #9ca3af;">
                        India का #1 prediction gaming platform। Safe, secure और fair gaming experience।
                    </p>
                </div>
                
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#games">Games</a></li>
                        <li><a href="#features">Features</a></li>
                        <li><a href="#download">Download</a></li>
                        <li><a href="#" onclick="openSupport()">Support</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Legal</h4>
                    <ul>
                        <li><a href="#" onclick="openTerms()">Terms & Conditions</a></li>
                        <li><a href="#" onclick="openPrivacy()">Privacy Policy</a></li>
                        <li><a href="#" onclick="openResponsibleGaming()">Responsible Gaming</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Contact</h4>
                    <ul>
                        <li>Email: support@stayzan.in</li>
                        <li>Telegram: @stayzann</li>
                        <li>24/7 Customer Support</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 StayZan. All rights reserved. | Made with ❤️ in India</p>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Handle signup button clicks
        function handleSignup() {
            // You can replace this URL with your actual signup page
            window.open('https://stayzan.in/login', '_blank');
        }

        // Handle email signup form
        function handleEmailSignup(event) {
            event.preventDefault();
            const email = document.getElementById('email-input').value;
            
            // You can add email validation and API call here
            if (email) {
                alert('धन्यवाद! हम जल्दी ही आपसे संपर्क करेंगे।');
                // Redirect to signup page
                window.open('https://stayzan.in/login', '_blank');
            }
        }

        // Download app function
        function downloadApp() {
            window.open('https://stayzan.in/download', '_blank');
        }

        // Join Telegram function
        function joinTelegram() {
            window.open('https://t.me/stayzann', '_blank');
        }

        // Footer link functions
        function openSupport() {
            window.open('https://t.me/stayzan_bot', '_blank');
        }

        function openTerms() {
            window.open('https://stayzan.in/terms', '_blank');
        }

        function openPrivacy() {
            window.open('https://stayzan.in/privacy', '_blank');
        }

        function openResponsibleGaming() {
            window.open('https://stayzan.in/responsible-gaming', '_blank');
        }

        // Add fade-in animation on scroll
        function animateOnScroll() {
            const elements = document.querySelectorAll('.game-card, .feature-card, .step-card');
            
            elements.forEach(element => {
                const elementTop = element.getBoundingClientRect().top;
                const elementVisible = 150;
                
                if (elementTop < window.innerHeight - elementVisible) {
                    element.classList.add('fade-in-up');
                }
            });
        }

        // Run animation on scroll
        window.addEventListener('scroll', animateOnScroll);

        // Run animation on page load
        document.addEventListener('DOMContentLoaded', function() {
            animateOnScroll();
            
            // Add loading animation to hero section
            setTimeout(() => {
                document.querySelector('.hero-content').classList.add('fade-in-up');
            }, 100);
        });

        // Add hover effects to cards
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.game-card, .feature-card, .benefit-card');
            
            cards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-10px) scale(1.02)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });
        });

        // Mobile menu toggle (if needed)
        function toggleMobileMenu() {
            const nav = document.querySelector('.nav');
            nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
        }

        // Add click tracking for analytics (you can integrate with Google Analytics)
        function trackClick(eventName, elementName) {
            // Example: gtag('event', eventName, { element: elementName });
            console.log('Tracked:', eventName, elementName);
        }

        // Add click tracking to important buttons
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.signup-btn, .btn-primary, .btn-download').forEach(button => {
                button.addEventListener('click', function() {
                    trackClick('button_click', this.textContent.trim());
                });
            });
        });
    </script>
</body>
</html>
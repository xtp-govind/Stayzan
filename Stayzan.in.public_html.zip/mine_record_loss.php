<?php
// हेडर को JSON के रूप में सेट करें
header('Content-Type: application/json');

// ✅ DB कनेक्शन (अपनी डिटेल्स यहाँ डालें)
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// डेटाबेस कनेक्शन जांचें
if ($conn->connect_error) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    exit();
}

// सेशन शुरू करें
session_start();

// 1. सुरक्षा जांच: सुनिश्चित करें कि यूज़र लॉग इन है
if (!isset($_SESSION['unique_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['status' => 'error', 'message' => 'Authentication required.']);
    exit();
}

$userId = $_SESSION['unique_id'];

// 2. जावास्क्रिप्ट से भेजा गया डेटा प्राप्त करें
$data = json_decode(file_get_contents('php://input'), true);

// सुनिश्चित करें कि 'bet_amount' भेजा गया है और वह एक नंबर है
if (!isset($data['bet_amount']) || !is_numeric($data['bet_amount']) || $data['bet_amount'] <= 0) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid bet amount provided.']);
    exit();
}

$lostAmount = floatval($data['bet_amount']);

// 3. 'total_lost' कॉलम को अपडेट करने के लिए SQL क्वेरी// ... (आपकी PHP फ़ाइल का कोड) ...

$sql = "UPDATE users SET total_lost_mine = total_lost_mine + ?, last_game_result_mine = 'loss' WHERE unique_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ds", $lostAmount, $userId);

if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Failed to prepare statement.']);
    $conn->close();
    exit();
}



// 4. क्वेरी चलाएं और नतीजा जांचें
if ($stmt->execute()) {
    // सफलता का संदेश भेजें
    echo json_encode(['status' => 'success', 'message' => 'Loss recorded successfully.']);
} else {
    // अगर अपडेट फेल होता है
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Failed to update loss record.']);
}

// स्टेटमेंट और कनेक्शन बंद करें
$stmt->close();
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Fast-Parity Game</title>
  <style>
    /* General styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      overflow-x: hidden;
    }

    .container {
      max-width: 400px;
      margin: 0 auto;
      background: #fff;
      min-height: 100vh;
      position: relative;
      box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }

    /* Top bar */
    .topbar {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 15px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: relative;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

.back-btn {
width: 28px;
height: 28px;
border-radius: 50%;
background: rgba(255,255,255,0.2);
display: flex;
align-items: center;
justify-content: center;
cursor: pointer;
border: none;
color: white;
font-size: 10px;
}

.back-btn img {
  width: 18px;
  height: 18px;
  object-fit: contain;
  
}

    .topbar .center-title {
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      font-size: 20px;
      font-weight: 600;
    }

    .user-balance {
      font-size: 14px;
      font-weight: 600;
      background: rgba(255,255,255,0.2);
      padding: 5px 10px;
      border-radius: 15px;
    }

    .dots {
      font-size: 24px;
      cursor: pointer;
    }

    /* Period and countdown */
    .period-countdown {
      display: flex;
      justify-content: space-between;
      padding: 16px 20px;
      background: #fff;
      border-bottom: 1px solid #e9ecef;
      font-size: 14px;
    }

    .period-left span:first-child,
    .countdown-right span:first-child {
      color: #6c757d;
      display: block;
      margin-bottom: 2px;
    }

    .period-left span:last-child,
    .countdown-right span:last-child {
      font-weight: 600;
      font-size: 16px;
      color: #333;
    }

    .countdown-timer {
      color: #dc3545 !important;
    }

    /* Color buttons */
    .color-buttons {
      display: flex;
      justify-content: space-around;
      padding: 25px 15px;
      gap: 10px;
    }

    .color-button {
      flex: 1;
      height: 90px;
      border: none;
      border-radius: 15px;
      color: #fff;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .color-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }

    .green { background: linear-gradient(135deg, #28a745, #20c997); }
    .violet { background: linear-gradient(135deg, #6f42c1, #e83e8c); }
    .red { background: linear-gradient(135deg, #dc3545, #fd7e14); }

.numbers-container {
  width: 100%;
}

.number-ratio {
  text-align: center;
  font-size: 13px;
  color: #888;
  margin-top: -13px;
}

.numbers-grid {  
  display: grid;  
  grid-template-columns: repeat(5, 1fr);  
  gap: 15px;  
  padding: 25px 20px;  
}

    .number-button {
      padding: 20px 0;
      font-size: 18px;
      font-weight: 600;
      background: linear-gradient(135deg, #f8f9fa, #e9ecef);
      border: 2px solid #dee2e6;
      border-radius: 12px;
      cursor: pointer;
      transition: all 0.3s ease;
      color: #333;
    }

    .number-button:hover {
      background: linear-gradient(135deg, #667eea, #764ba2);
      color: white;
      transform: translateY(-2px);
    }

    /* History section */
    .record-section {
      padding: 20px;
      background: #f8f9fa;
      margin: 10px;
      border-radius: 15px;
    }

    .record-heading {
      margin-bottom: 15px;
    }

    .record-title-text {
      font-size: 18px;
      font-weight: 600;
      color: #333;
      text-align: center;
      margin-bottom: 10px;
    }

    .record-subtitle {
      font-size: 12px;
      color: #6c757d;
      text-align: center;
      margin-bottom: 15px;
    }

    .record-circles {
      display: grid;
      grid-template-columns: repeat(8, 1fr);
      gap: 8px;
      justify-items: center;
      max-width: 100%;
    }

    .circle {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 13px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      transition: transform 0.2s ease;
    }

    .circle:hover {
      transform: scale(1.1);
    }

    .circle.green { background: linear-gradient(135deg, #28a745, #20c997); }
    .circle.red { background: linear-gradient(135deg, #dc3545, #fd7e14); }
    .circle.violet { background: linear-gradient(135deg, #6f42c1, #e83e8c); }

.circle.gray {
  width: 26px;
  height: 26px;
  background-color: #999;
  border-radius: 50%;
  color: white;
  font-size: 13px;
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: center;
}

    /* Popup for betting */
    .popup-overlay {
      position: fixed;
      bottom: -100%;
      left: 0;
      right: 0;
      background: #fff;
      border-top-left-radius: 20px;
      border-top-right-radius: 20px;
      transition: bottom 0.4s ease;
      z-index: 9999;
      padding: 25px;
      box-shadow: 0 -5px 25px rgba(0,0,0,0.2);
      max-height: 80vh;
      overflow-y: auto;
    }

    .popup-overlay.show {
      bottom: 0;
    }

    .popup-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      z-index: 9998;
      display: none;
    }

    .popup-backdrop.show {
      display: block;
    }

    .popup-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    .popup-title {
      font-size: 20px;
      font-weight: 600;
      color: #333;
      margin: 0;
    }

    .popup-close {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background: #f8f9fa;
      border: 1px solid #dee2e6;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 18px;
      color: #6c757d;
      transition: all 0.3s ease;
    }

    .popup-close:hover {
      background: #e9ecef;
      color: #495057;
    }

    .popup-section {
      margin-bottom: 20px;
    }

    .popup-section > div:first-child {
      font-weight: 600;
      margin-bottom: 10px;
      color: #333;
      font-size: 16px;
    }
    
.money-options {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  width: 100%; /* ✅ Full width le container ka */
  box-sizing: border-box;
  margin-bottom: 20px;
}

.money-options button {
  padding: 12px 8px;
  border: 2px solid #dee2e6;
  border-radius: 8px;
  background: #f8f9fa;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;
  font-size: 14px;
  width: 100%; /* Ensure full width in grid cell */
  box-sizing: border-box;
}

    .money-options button:hover {
      border-color: #667eea;
      background: #e7f1ff;
      transform: translateY(-1px);
    }

    .money-options button.selected {
      background: linear-gradient(135deg, #667eea, #764ba2);
      color: white;
      border-color: #667eea;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    }

    .quantity-controls {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 15px;
    }

    .quantity-controls button {
      width: 40px;
      height: 40px;
      border: 2px solid #667eea;
      border-radius: 50%;
      background: #f8f9fa;
      color: #667eea;
      font-size: 18px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .quantity-controls button:hover {
      background: #667eea;
      color: white;
      transform: scale(1.1);
    }

    .quantity-controls span {
      font-size: 18px;
      font-weight: 600;
      min-width: 30px;
      text-align: center;
      color: #333;
    }

    .popup-balance {
      text-align: center;
      margin-bottom: 15px;
      padding: 12px;
      background: linear-gradient(135deg, #e3f2fd, #f3e5f5);
      border-radius: 10px;
      font-weight: 600;
      color: #333;
      border: 1px solid #e1bee7;
    }

    .popup-total {
      text-align: center;
      font-size: 18px;
      font-weight: 600;
      margin-bottom: 20px;
      color: #333;
      padding: 10px;
      background: #f8f9fa;
      border-radius: 8px;
      border: 2px solid #dee2e6;
    }

    .popup-confirm {
      width: 100%;
      padding: 15px;
      background: linear-gradient(135deg, #28a745, #20c997);
      color: white;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
    }

    .popup-confirm:hover {
      background: linear-gradient(135deg, #20c997, #28a745);
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(40, 167, 69, 0.4);
    }

    .popup-confirm:disabled {
      background: #6c757d;
      cursor: not-allowed;
      transform: none;
      box-shadow: none;
    }

/* Error and Success Messages */
.error-message, .success-message {
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  max-width: 90%;
  padding: 14px 20px;
  border-radius: 12px;
  font-size: 15px;
  font-weight: 600;
  text-align: left;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  z-index: 9999;
  display: flex;
  align-items: center;
  gap: 10px;
  animation: fadeSlide 0.4s ease;
}

.error-message {
  background: #ffe5e7;
  color: #d32f2f;
  border-left: 5px solid #d32f2f;
}

.success-message {
  background: #e6f4ea;
  color: #2e7d32;
  border-left: 5px solid #2e7d32;
}

/* Icons inside messages */
.error-message::before, .success-message::before {
  font-family: 'Arial';
  font-weight: bold;
  font-size: 18px;
}

.error-message::before {
  content: "⚠️";
}

.success-message::before {
  content: "✅";
}

/* Fade Slide Animation */
@keyframes fadeSlide {
  from {
    opacity: 0;
    transform: translateX(-50%) translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }
}

    @keyframes slideDown {
      from { transform: translateY(-20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    /* Responsive design */
    @media (max-width: 480px) {
      .container {
        max-width: 100%;
      }
      
      .topbar {
        padding: 12px 15px;
      }
      
      .topbar .center-title {
        font-size: 18px;
      }
      
      .user-balance {
        font-size: 12px;
        padding: 4px 8px;
      }
      
      .color-buttons {
        padding: 20px 10px;
        gap: 8px;
      }
      
      .color-button {
        height: 80px;
        font-size: 12px;
      }
      
      .numbers-grid {
        padding: 20px 15px;
        gap: 12px;
      }
      
      .number-button {
        padding: 15px 0;
        font-size: 16px;
      }
      
      .record-section {
        padding: 15px;
        margin: 8px;
      }
      
      .record-circles {
        gap: 6px;
      }
      
      .circle {
        width: 26px;
        height: 26px;
        font-size: 11px;
      }
      
      .popup-overlay {
        padding: 20px;
      }
      
      .money-options {
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
      }
      
      .money-options button {
        padding: 10px 6px;
        font-size: 14px;
      }
    }
    
.toggle-buttons {
  display: flex;
  justify-content: center;
  gap: 16px;
  margin-top: 30px;
}

.toggle-btn {
  display: inline-block;
  padding: 14px 28px;
  font-size: 16px;
  font-weight: 600;
  color: #fff;
  border-radius: 50px;
  cursor: pointer;
  background: linear-gradient(145deg, rgba(80, 80, 80, 0.35), rgba(40, 40, 40, 0.35)); /* 🔥 This is the default background for inactive */
  backdrop-filter: blur(8px);
  overflow: hidden;
  transition: all 0.3s ease;
  user-select: none;
  border: none;
  position: relative;
  -webkit-tap-highlight-color: transparent;
}

/* Ripple Effect */
.toggle-btn::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  background: rgba(255, 255, 255, 0.1);
  transform: translate(-50%, -50%);
  border-radius: 50%;
  transition: width 0.6s ease, height 0.6s ease;
  z-index: 0;
}

.toggle-btn:active::before {
  width: 300%;
  height: 300%;
}

/* Press feel */
.toggle-btn:active {
  transform: scale(0.96);
}

/* Active state */
.toggle-btn.active {
  background: linear-gradient(135deg, #00c6ff, #0072ff);
  box-shadow: 0 0 20px #00c6ff88, 0 0 30px #0072ff55;
  color: #fff;
}

/* Hover shine */
.toggle-btn::after {
  content: '';
  position: absolute;
  top: 0;
  left: -75%;
  width: 50%;
  height: 100%;
  background: linear-gradient(
    120deg,
    transparent,
    rgba(255, 255, 255, 0.3),
    transparent
  );
  transform: skewX(-20deg);
  transition: left 0.75s ease;
  z-index: 1;
}

.toggle-btn:hover::after {
  left: 130%;
}

/* No outline ever */
.toggle-btn:focus {
  outline: none !important;
  box-shadow: none !important;
}

.order-section {
  margin-top: 10px;
}

/* Common row style for both sections */
.order-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr); /* 4 equal columns */
  align-items: center;
  padding: 6px 10px;
  background-color: #f3f3f3;
  border-radius: 6px;
  margin-bottom: 6px;
  font-size: 14px;
  gap: 10px;
  text-align: center;
}

/* Circle styling */
.color-number .circle {
  width: 24px;
  height: 24px;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  margin: 0 auto;
}

/* Number: Gray filled with number */
.circle.number {
  background-color: gray;
  color: white;
  font-weight: bold;
}

/* Color circle: Only border */
.circle.color {
  background-color: transparent;
  border: 0.5px solid;
  font-size: 0;
}

.circle.color.red { border-color: red; }
.circle.color.green { border-color: green; }
.circle.color.violet { border-color: purple; }

.status-win {
  color: green;
  font-weight: bold;
}
.status-loss {
  color: red;
  font-weight: bold;
}

/* win loss popup-overlay */

.zen-popup {
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.6);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 99999;
    }

    .zen-popup.hidden {
      display: none;
    }

    .zen-popup-box {
      background: #fff;
      border-radius: 18px;
      padding: 25px 30px;
      width: 90%;
      max-width: 400px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      animation: bounceIn 0.4s ease-out;
      font-family: 'Poppins', sans-serif;
      text-align: center;
      position: relative;
    }

    @keyframes bounceIn {
      0% {
        transform: scale(0.5);
        opacity: 0;
      }
      60% {
        transform: scale(1.1);
        opacity: 1;
      }
      100% {
        transform: scale(1);
      }
    }

    .zen-popup-header {
      font-size: 28px;
      font-weight: 800;
      color: #fff;
      padding: 12px 0;
      border-radius: 14px;
      margin-bottom: 20px;
      text-transform: uppercase;
      letter-spacing: 1px;
      background: linear-gradient(to right, #4caf50, #2ecc71);
    }

    .zen-popup-header.loss {
      background: linear-gradient(to right, #e53935, #c62828);
    }

    .zen-popup-crown {
      position: absolute;
      top: -28px;
      left: 50%;
      transform: translateX(-50%);
      font-size: 36px;
      animation: crownBounce 0.8s infinite alternate;
    }

    @keyframes crownBounce {
      from { transform: translateX(-50%) translateY(0); }
      to   { transform: translateX(-50%) translateY(-5px); }
    }

    .zen-popup-number {
      width: 80px;
      height: 80px;
      margin: 0 auto 15px;
      border-radius: 50%;
      font-size: 30px;
      font-weight: bold;
      color: #fff;
      line-height: 80px;
      background: #444;
      text-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
      transition: background 0.3s ease;
    }

    .zen-popup-info {
      font-size: 16px;
      color: #333;
    }

    .zen-popup-info p {
      margin: 6px 0;
    }

    .zen-popup-amount-large {
      font-size: 32px;
      font-weight: bold;
      color: #28a745;
      margin-top: 10px;
      animation: pulse 1s infinite alternate;
    }

    .zen-popup-amount-large.loss {
      color: #e53935;
    }

    @keyframes pulse {
      from { transform: scale(1); }
      to   { transform: scale(1.1); }
    }

    .zen-popup-ok {
      margin-top: 25px;
      padding: 14px 30px;
      background: #007bff;
      color: white;
      font-size: 16px;
      font-weight: bold;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.2s ease;
      box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
    }

    .zen-popup-ok:hover {
      background: #0056b3;
    }
/* win loss popup-overlay close */

.order-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 6px 10px;
  font-size: 13px;
  border-bottom: 1px solid rgba(255,255,255,0.1);
  gap: 6px;
}

.order-row div {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  padding: 3px 4px;
}

/* Custom column widths */
.order-row div:nth-child(1) { flex: 1.4; text-align: left; }  /* Period */
.order-row div:nth-child(2) { flex: 0.9; }                  /* Select */
.order-row div:nth-child(3) { flex: 1.1; }                  /* Amount */
.order-row div:nth-child(4) { flex: 1.1; }                    /* Status */
  </style>
</head>
<body>
  <div class="container">
    <div class="topbar">
       <button class="back-btn" onclick="window.history.back()">
          <img src="/logo/back2.png" alt="Back">
       </button>

      <div class="center-title">Fast-Parity</div>
      <div class="user-balance" id="userBalance">₹0</div>
    </div>

    <div class="period-countdown">
      <div class="period-left">
        <span>Period</span>
        <span id="periodId">Loading...</span>
      </div>
      <div class="countdown-right">
        <span>Countdown</span>
        <span class="countdown-timer" id="timer">00:30</span>
      </div>
    </div>

    <div class="color-buttons">
      <button class="color-button green" onclick="selectBet('color', 'green')">
        Join Green<br><small>1:2</small>
      </button>
      <button class="color-button violet" onclick="selectBet('color', 'violet')">
        Join Violet<br><small>1:4.5</small>
      </button>
      <button class="color-button red" onclick="selectBet('color', 'red')">
        Join Red<br><small>1:2</small>
      </button>
    </div>
    
    <div class="numbers-container">
  <div class="numbers-grid" id="numbersGrid"></div>
  <div class="number-ratio">1:9</div>
</div>



    <div class="record-section">
      <div class="record-heading">
        <div class="record-title-text">Previous Record</div>
      </div>
      <div class="record-circles" id="recordLine"></div>
    </div>

    <div class="popup-overlay" id="popup">
      <div class="popup-header">
        <div class="popup-title" id="popupTitle"></div>
        <button class="popup-close" onclick="closePopup()">×</button>
      </div>
      <div class="popup-balance" id="popupBalance">Available Balance: ₹0</div>
      <div class="popup-section">
        <div>Select Money</div>
        <div class="money-options">
          <button onclick="selectMoney(10)">₹10</button>
          <button onclick="selectMoney(50)">₹50</button>
          <button onclick="selectMoney(100)" class="selected">₹100</button>
          <button onclick="selectMoney(1000)">₹1000</button>
          <button onclick="selectMoney(5000)">₹5000</button>
          <button onclick="selectMoney(10000)">₹10000</button>
        </div>
      </div>
      <div class="popup-section">
        <div>Quantity</div>
        <div class="quantity-controls">
          <button onclick="changeQuantity(-1)">-</button>
          <span id="qtyDisplay">1</span>
          <button onclick="changeQuantity(1)">+</button>
        </div>
      </div>
      <div class="popup-total" id="popupTotal">Total: ₹100</div>
      <button class="popup-confirm" onclick="confirmBet()">Confirm</button>
    </div>
    
<div class="toggle-buttons">
  <button id="everyoneBtn" class="toggle-btn active">Everyone's Order</button>
  <button id="myOrderBtn" class="toggle-btn">My Order</button>
</div>

<div class="order-section" id="everyoneOrders">
  <!-- Fake order rows will go here -->
</div>

<div class="order-section" id="myOrders" style="display: none;">
  <!-- My order rows from backend will go here -->
</div>

    <div class="popup-backdrop" id="popupBackdrop"></div>
  
<!-- 🟢 Win/Loss ZEN Popup -->
<div id="zenResultPopup" class="zen-popup hidden">
  <div class="zen-popup-box">
    <div class="zen-popup-header" id="zenPopupResultBox">
      <span id="zenPopupResultText">WIN</span>
      <div class="zen-popup-crown">👑</div>
    </div>
    <div class="zen-popup-number" id="zenPopupNumber">7</div>
    <div class="zen-popup-info">
      <p><strong>Period ID:</strong> <span id="zenPopupPeriod"></span></p>
      <p><strong>Select:</strong> <span id="zenPopupSelect"></span></p>
      <p><strong>Bet Amount:</strong> <span id="zenPopupPoint"></span></p>
    </div>
    <div class="zen-popup-amount-large" id="zenPopupAmount">+₹150</div>
    <button class="zen-popup-ok" onclick="closeZenPopup()">OK</button>
  </div>
</div>
    
  </div>
  

  <script>
    // --- State Variables ---
    let selectedColor = "";
    let selectedNumber = "";
    let selectedMoney = 100;
    let quantity = 1;
    let userBalance = 0; 
    let currentPeriod = null;
    let remainingSeconds = 30;
    let betEnabled = true; 
    let countdownInterval = null;

    // --- Event Listeners ---
    document.addEventListener("DOMContentLoaded", function() {
      initializeNumbersGrid();
      document.getElementById("popupBackdrop").addEventListener("click", closePopup);
      
      // Fetch user data first, then start the game updates
      fetchUserDataAndStartGame();
    });

    // --- Core Functions ---
    async function fetchUserDataAndStartGame() {
        try {
            const response = await fetch(`fetch_login_user.php`); 
            const data = await response.json();

            if (data.status === "success") {
                const user = data.data;
                userBalance = parseFloat(user.balance.replace(/,/g, '')); 
                updateUserBalanceDisplay();
                console.log("Welcome", user.name);
            } else {
                showError(data.error || "You are not logged in.");
                return;
            }
        } catch (error) {
            showError("Could not fetch user data.");
            return;
        }

        // Now that we have user data, start the game
        await fetchCurrentPeriod();
        await fetchPeriodHistory();
        startPeriodicUpdates();
    }

    async function fetchCurrentPeriod() {
      try {
        const response = await fetch(`current_fastparity_period.php`);
        const data = await response.json();
        
        if (data.success) {
          currentPeriod = data.period;
          remainingSeconds = parseInt(data.remaining_seconds, 10);
          updatePeriodDisplay();
        } else {
          showError('Failed to fetch current period.');
        }
      } catch (error) {
        showError('Connection error while fetching period.');
      }
    }

    async function fetchPeriodHistory() {
      try {
        const response = await fetch(`history_fastparity.php`);
        const data = await response.json();
        
        if (data.success) {
          updateGameHistory(data.periods);
        }
      } catch (error) {
        showError('Could not fetch history.');
      }
    }

    async function fetchUserBalance() {
      try {
        const response = await fetch(`fetch_login_user.php`); 
        const data = await response.json();

        if (data.status === "success") {
          const user = data.data;
          const newBalance = parseFloat(user.balance.replace(/,/g, ''));
          
          // Only update if balance has changed to avoid unnecessary DOM updates
          if (newBalance !== userBalance) {
            userBalance = newBalance;
            updateUserBalanceDisplay();
          }
        }
      } catch (error) {
        // Silently fail for balance updates to avoid spamming error messages
        console.error('Could not fetch user balance:', error);
      }
    }

    function startPeriodicUpdates() {
      // Clear any existing interval
      if (countdownInterval) {
        clearInterval(countdownInterval);
      }
      
      // Update every second
      countdownInterval = setInterval(async () => {
        // Fetch fresh data from server every second
        await fetchCurrentPeriod();
        
        // Disable betting in the last 5 seconds
        if (remainingSeconds <= 5) {
            betEnabled = false;
            document.querySelector('.countdown-timer').style.color = '#ffc107';
        } else {
            betEnabled = true;
            document.querySelector('.countdown-timer').style.color = '#dc3545';
        }

        // Update display with fresh data
        updatePeriodDisplay();
      }, 1000);
      
      // Also update history every 5 seconds
      setInterval(async () => {
        await fetchPeriodHistory();
      }, 1000);
      
      // Update user balance every 10 seconds
      setInterval(async () => {
        await fetchUserBalance();
      }, 1000);
    }

    async function confirmBet() {
        if (!betEnabled) {
            showError("Betting is closed for this period. Please wait for the next one.");
            return;
        }

        const total = selectedMoney * quantity;
        if (total > userBalance) {
            showError("Insufficient balance!");
            return;
        }

        // Prepare the data to send to the server
        const betData = {
            periodId: currentPeriod.period_id,
            betType: selectedColor ? 'color' : 'number',
            betValue: selectedColor || selectedNumber,
            amount: total
        };
     
     
        // Disable the confirm button to prevent multiple clicks
        const confirmButton = document.querySelector('.popup-confirm');
        confirmButton.disabled = true;
        confirmButton.textContent = 'Placing...';

        try {
            
            const response = await fetch("place_fastparity_bet", {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(betData),
            });

            const result = await response.json();

            if (result.success) {
                userBalance = parseFloat(result.newBalance);
                updateUserBalanceDisplay();
                showSuccess(result.message || 'Bet placed successfully!');
                closePopup();
            } else {
                showError(result.error || 'Failed to place bet.');
            }
        } catch (error) {
            showError('Connection error while placing bet.');
        } finally {
            // Re-enable the button
            confirmButton.disabled = false;
            confirmButton.textContent = 'Confirm';
        }
    }

    // --- UI Helper Functions ---
    function updateUserBalanceDisplay() {
        document.getElementById("userBalance").textContent = `₹${userBalance.toLocaleString()}`;
        document.getElementById("popupBalance").textContent = `Available Balance: ₹${userBalance.toLocaleString()}`;
    }

    function updatePeriodDisplay() {
      if (currentPeriod) {
        document.getElementById("periodId").textContent = currentPeriod.period_id;
      }
      
      const minutes = Math.floor(remainingSeconds / 60);
      const seconds = remainingSeconds % 60;
      document.getElementById("timer").textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }

    
    function initializeNumbersGrid() {
const numbersGrid = document.getElementById("numbersGrid");
numbersGrid.innerHTML = '';
for (let i = 0; i <= 9; i++) {
const button = document.createElement("button");
button.className = "number-button";
button.textContent = i;
button.onclick = () => selectBet("number", i.toString());
numbersGrid.appendChild(button);
 }
}

function updateGameHistory(periods) {
  const recordLine = document.getElementById("recordLine");
  recordLine.innerHTML = '';

  // Filter last 23 with results and reverse (oldest at top)
  const recentPeriods = periods
    .filter(p => p.winning_number !== null)
    .slice(0, 23)
    .reverse();

  let latestPeriodLast2 = '00'; // default
  if (recentPeriods.length > 0) {
    latestPeriodLast2 = recentPeriods[recentPeriods.length - 1].period_id.toString().slice(-2);
  }

  // Calculate next period ID (last 2 digits)
  let nextIdNum = (parseInt(latestPeriodLast2, 10) + 1) % 100;
  let nextPeriodId = nextIdNum.toString().padStart(2, '0');

  // Add each period
  recentPeriods.forEach(period => {
    const wrapper = document.createElement('div');
    wrapper.style.display = 'flex';
    wrapper.style.flexDirection = 'column';
    wrapper.style.alignItems = 'center';
    wrapper.style.margin = '2px';

    const circle = document.createElement('div');
    circle.className = `circle ${period.winning_color}`;
    circle.textContent = period.winning_number;

    const idText = document.createElement('span');
    idText.textContent = period.period_id.toString().slice(-2);
    idText.style.fontSize = '10px';
    idText.style.color = '#ccc';
    idText.style.marginTop = '2px';

    wrapper.appendChild(circle);
    wrapper.appendChild(idText);
    recordLine.appendChild(wrapper);
  });

  // Add gray circle for next period
  const nextWrapper = document.createElement('div');
  nextWrapper.style.display = 'flex';
  nextWrapper.style.flexDirection = 'column';
  nextWrapper.style.alignItems = 'center';
  nextWrapper.style.margin = '2px';

  const nextCircle = document.createElement('div');
  nextCircle.className = 'circle gray';
  nextCircle.textContent = '?';

  const nextIdText = document.createElement('span');
  nextIdText.textContent = nextPeriodId;
  nextIdText.style.fontSize = '10px';
  nextIdText.style.color = '#ccc';
  nextIdText.style.marginTop = '2px';

  nextWrapper.appendChild(nextCircle);
  nextWrapper.appendChild(nextIdText);
  recordLine.appendChild(nextWrapper);
}
   
    function selectBet(type, value) {
      if (!betEnabled) {
        showError("Betting is closed for the current period.");
        return;
      }
      
      if (type === 'color') {
        selectedColor = value;
        selectedNumber = "";
        document.getElementById("popupTitle").textContent = `Join ${value.charAt(0).toUpperCase() + value.slice(1)}`;
      } else {
        selectedColor = "";
        selectedNumber = value;
        document.getElementById("popupTitle").textContent = `Join Number - ${value}`;
      }
      
      resetPopup();
      document.getElementById("popup").classList.add("show");
      document.getElementById("popupBackdrop").classList.add("show");
    }
    
    function resetPopup() {
        selectedMoney = 100;
        quantity = 1;
        updatePopupTotal();
        updateMoneySelection();
        updateQuantityDisplay();
        updateUserBalanceDisplay();
    }

    function selectMoney(amount) {
      selectedMoney = amount;
      updateMoneySelection();
      updatePopupTotal();
    }

    function updateMoneySelection() {
      document.querySelectorAll('.money-options button').forEach(btn => {
        btn.classList.remove('selected');
        if (parseInt(btn.textContent.replace('₹', '')) === selectedMoney) {
          btn.classList.add('selected');
        }
      });
    }

    function changeQuantity(delta) {
      quantity = Math.max(1, quantity + delta);
      updateQuantityDisplay();
      updatePopupTotal();
    }

    function updateQuantityDisplay() {
      document.getElementById("qtyDisplay").textContent = quantity;
    }

    function updatePopupTotal() {
      document.getElementById("popupTotal").textContent = `Total: ₹${(selectedMoney * quantity).toLocaleString()}`;
    }

    function closePopup() {
      document.getElementById("popup").classList.remove("show");
      document.getElementById("popupBackdrop").classList.remove("show");
    }

    function showError(message) {
      const errorDiv = document.createElement('div');
      errorDiv.className = 'error-message';
      errorDiv.textContent = message;
      document.querySelector('.container').prepend(errorDiv);
      setTimeout(() => errorDiv.remove(), 2000);
    }

    function showSuccess(message) {
      const successDiv = document.createElement('div');
      successDiv.className = 'success-message';
      successDiv.textContent = message;
      document.querySelector('.container').prepend(successDiv);
      setTimeout(() => successDiv.remove(), 2000);
    }
    
 //section show button start 
const myOrders = document.getElementById("myOrders");
const everyoneOrders = document.getElementById("everyoneOrders");
const myOrderBtn = document.getElementById("myOrderBtn");
const everyoneBtn = document.getElementById("everyoneBtn");

// Toggle buttons
myOrderBtn.onclick = () => {
  myOrderBtn.classList.add("active");
  everyoneBtn.classList.remove("active");
  myOrders.style.display = "block";
  everyoneOrders.style.display = "none";
};

everyoneBtn.onclick = () => {
  everyoneBtn.classList.add("active");
  myOrderBtn.classList.remove("active");
  myOrders.style.display = "none";
  everyoneOrders.style.display = "block";
};

let fakeOrderInterval;
let fakeCount = 0;

// 1️⃣ Track previous period
let lastPeriodId = null;

// 2️⃣ Check for period change every second
setInterval(() => {
  const currentPeriod = document.getElementById("periodId")?.textContent.trim();
  if (currentPeriod && currentPeriod !== "Loading..." && currentPeriod !== lastPeriodId) {
    lastPeriodId = currentPeriod;
    loadMyOrders(); // Reload only when period changes
  }
}, 1000);

// 3️⃣ Load Fake Orders
function startFakeOrders() {
  clearInterval(fakeOrderInterval);

  // 🔁 Remove existing rows & add heading only once
  everyoneOrders.innerHTML = `
    <div class="order-row header-row">
      <div>Period</div>
      <div>User ID</div>
      <div>Select</div>
      <div>Amount</div>
    </div>
  `;

  fakeOrderInterval = setInterval(() => {
    const periodIdSpan = document.getElementById("periodId");
    const period_id = periodIdSpan ? periodIdSpan.textContent.trim() : null;
    if (!period_id || period_id === "Loading...") return;

    const isColor = Math.random() < 0.5;
    const colors = ['red', 'green', 'violet'];
    const bet_value = isColor
      ? colors[Math.floor(Math.random() * colors.length)]
      : Math.floor(Math.random() * 10);

    const unique_id =
      String.fromCharCode(65 + Math.floor(Math.random() * 26)) +
      String.fromCharCode(65 + Math.floor(Math.random() * 26)) +
      Math.floor(1000 + Math.random() * 9000);

    const amountList = [
      10, 20, 60, 100, 200, 500, 850, 70, 1680, 9010,
      110, 11150, 1190, 15500, 800, 1740, 13660, 9930,
      13650, 370, 230, 290, 30, 40, 1240, 18330,
      17740, 18850, 160, 1070, 180, 190, 490, 7310, 6230
    ];

    const amount = Math.random() < 0.6
      ? amountList[Math.floor(Math.random() * amountList.length)]
      : Math.floor(Math.random() * 500 + 1) * 10;

    const row = document.createElement("div");
    row.className = "order-row";

    let circleHtml = '';
    if (typeof bet_value === 'number') {
      circleHtml = `<div class="circle number">${bet_value}</div>`;
    } else {
      circleHtml = `<div class="circle color ${bet_value}"></div>`;
    }

    row.innerHTML = `
      <div>${period_id}</div>
      <div>${unique_id}</div>
      <div class="color-number">${circleHtml}</div>
      <div>₹${amount}</div>
    `;

    // Insert *after* the heading row
    everyoneOrders.insertBefore(row, everyoneOrders.children[1]);

    if (everyoneOrders.children.length > 51) {
      everyoneOrders.removeChild(everyoneOrders.lastChild);
    }
  }, 500);
}

// Track orders which were in "waiting" state (status = "" or 0)
let previousWaitingOrders = {};

function loadMyOrders() {
  fetch('my_fastparity_bet.php')
    .then(res => res.json())
    .then(data => {
      myOrders.innerHTML = `
        <div class="order-row header-row">
          <div>Period</div>
          <div>Select</div>
          <div>Amount</div>
          <div>Status</div>
        </div>
      `;

      const currentWaitingOrders = {};

      data.forEach(order => {
        const row = document.createElement("div");
        row.className = "order-row";

        let circleHtml = '';
        if (order.bet_type === 'number') {
          circleHtml = `<div class="circle number">${order.bet_value}</div>`;
        } else {
          const color = order.bet_value.toLowerCase();
          circleHtml = `<div class="circle color ${color}"></div>`;
        }

        let statusText = "Wait";
        let statusClass = "";
        const status = order.status;
        const numericStatus = parseFloat(status);
        const isResolved = !isNaN(numericStatus) && numericStatus !== 0;

        if (isResolved) {
          const absAmount = Math.abs(numericStatus).toFixed(2);
          const symbol = numericStatus >= 0 ? "+₹" : "-₹";
          statusText = symbol + absAmount;
          statusClass = numericStatus >= 0 ? "status-win" : "status-loss";
        } else {
          const uniqueKey = order.period_id + "-" + order.bet_value;
          currentWaitingOrders[uniqueKey] = true;
        }

        row.innerHTML = `
          <div>${order.period_id}</div>
          <div class="color-number">${circleHtml}</div>
          <div>₹${order.amount}</div>
          <div class="${statusClass}">${statusText}</div>
        `;

        myOrders.appendChild(row);

        const uniqueKey = order.period_id + "-" + order.bet_value;
        if (isResolved && previousWaitingOrders[uniqueKey]) {
          showZenPopup(order);
        }
      });

      previousWaitingOrders = currentWaitingOrders;
    });
}

function showZenPopup(order) {
  const popup = document.getElementById('zenResultPopup');
  const resultText = document.getElementById('zenPopupResultText');
  const number = document.getElementById('zenPopupNumber');
  const period = document.getElementById('zenPopupPeriod');
  const select = document.getElementById('zenPopupSelect');
  const point = document.getElementById('zenPopupPoint');
  const amount = document.getElementById('zenPopupAmount');

  const isWin = parseFloat(order.status) > 0;

  resultText.textContent = isWin ? "WIN" : "LOSS";
  resultText.parentElement.classList.toggle("win", isWin);
  resultText.parentElement.classList.toggle("loss", !isWin);

  const color = order.result_text.toLowerCase(); // red/green/violet
  number.textContent = order.result_number || order.bet_value;
  number.style.background = getColorGradient(color);

  period.textContent = order.period_id;
  select.textContent = order.bet_value.toUpperCase();
  point.textContent = order.amount;
  amount.innerHTML = (isWin ? "+₹" : "-₹") + Math.abs(order.status);

  popup.classList.remove('hidden');

  setTimeout(() => {
    popup.classList.add('hidden');
  }, 5000);
}

function getColorGradient(color) {
  switch (color) {
    case 'red':
      return 'linear-gradient(145deg, #ff4d4d, #cc0000)';
    case 'green':
      return 'linear-gradient(145deg, #4dff88, #009933)';
    case 'violet':
      return 'linear-gradient(145deg, #d29eff, #8000ff)';
    default:
      return '#888';
  }
}

function closeZenPopup() {
  document.getElementById('zenResultPopup').classList.add('hidden');
}



// INIT
setInterval(loadMyOrders, 1000);
startFakeOrders();

</script>
</body>
</html>
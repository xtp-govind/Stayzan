<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["success" => false, "message" => "User not logged in"]);
    exit;
}

$unique_id = $_SESSION['unique_id'];

// Read JSON input
$data = json_decode(file_get_contents('php://input'), true);
$amount = isset($data['amount']) ? floatval($data['amount']) : 0;
$from = trim($data['from_account']);
$to = trim($data['to_account']);

if ($amount <= 0 || empty($from) || empty($to)) {
    echo json_encode(["success" => false, "message" => "Invalid input"]);
    exit;
}

if ($from === $to) {
    echo json_encode(["success" => false, "message" => "From and To account cannot be the same"]);
    exit;
}

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->begin_transaction(); // Start transaction

try {
    // Fetch balances
    $stmt1 = $conn->prepare("SELECT balance FROM users WHERE unique_id = ?");
    $stmt1->bind_param("s", $unique_id);
    $stmt1->execute();
    $userRes = $stmt1->get_result()->fetch_assoc();
    $user_balance = floatval($userRes['balance']);

    $stmt2 = $conn->prepare("SELECT wallet_balance FROM referral_rewards WHERE unique_id = ?");
    $stmt2->bind_param("s", $unique_id);
    $stmt2->execute();
    $refRes = $stmt2->get_result()->fetch_assoc();
    $ref_balance = floatval($refRes['wallet_balance']);

    // Define transfer logic
    if ($from === "Wallet Balance" && $to === "Gaming Balance") {
        if ($ref_balance < $amount) throw new Exception("Insufficient wallet balance");
        
        // - Deduct from referral_rewards
        $stmt3 = $conn->prepare("UPDATE referral_rewards SET wallet_balance = wallet_balance - ? WHERE unique_id = ?");
        $stmt3->bind_param("ds", $amount, $unique_id);
        $stmt3->execute();

        // + Add to users.balance
        $stmt4 = $conn->prepare("UPDATE users SET balance = balance + ? WHERE unique_id = ?");
        $stmt4->bind_param("ds", $amount, $unique_id);
        $stmt4->execute();

    } elseif ($from === "Gaming Balance" && $to === "Wallet Balance") {
        // ❌ Block this transfer
        throw new Exception("This feature coming soon");

    } else {
        throw new Exception("Invalid account types");
    }

    // ✅ Optional logging
    $stmtLog = $conn->prepare("INSERT INTO wallet_exchange_log (unique_id, amount, from_account, to_account, transferred_at) VALUES (?, ?, ?, ?, NOW())");
    $stmtLog->bind_param("sdss", $unique_id, $amount, $from, $to);
    $stmtLog->execute();

    $conn->commit(); // All good

    echo json_encode([
        "success" => true,
        "message" => "₹$amount transferred from $from to $to"
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}

$conn->close();
?>
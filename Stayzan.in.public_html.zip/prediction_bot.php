<?php
// bot.php

// ===== CONFIG - replace these =====
$API_TOKEN = "8223156804:AAGf3CsJH9PtpjVVRQRLDZPSXgM1saM00S0";

$ADMIN_ID  = 1733227695;

$GROUP_ID  = "-1003031124136";   

file_put_contents(__DIR__ . "/telegram_updates.log", date('c') . " RAW: " . file_get_contents('php://input') . PHP_EOL, FILE_APPEND);

// read update
$input = file_get_contents('php://input');
$update = json_decode($input, true);
if(!$update) exit;

// normalize to get a $message array
$message = null;
if (isset($update['message'])) $message = $update['message'];
elseif (isset($update['edited_message'])) $message = $update['edited_message'];
elseif (isset($update['channel_post'])) $message = $update['channel_post'];
else exit;

if (!isset($message['text'])) exit;
$text = trim($message['text']);
$chat_type = isset($message['chat']['type']) ? $message['chat']['type'] : '';
$chat_id = $message['chat']['id'];
$from_id = $message['from']['id'];

// Only accept admin and only via private chat (so control is private)
if ($from_id != $ADMIN_ID) {
    if (strpos($text, '/predict') === 0) {
        sendMessage($chat_id, "⛔ You are not authorized!");
    }
    exit;
}

if ($chat_type !== 'private') {
    // enforce private commands
    sendMessage($chat_id, "❗ Please DM me privately for admin commands.");
    exit;
}

// handle /predict command
if (strpos($text, '/predict') === 0) {
    $parts = explode(' ', $text, 2);
    if (count($parts) < 2 || trim($parts[1]) === '') {
        sendMessage($chat_id, "❌ Usage: /predict <text>");
    } else {
        $prediction = trim($parts[1]);
        // escape prediction for HTML
        $safe = htmlspecialchars($prediction, ENT_QUOTES, 'UTF-8');
        $group_msg = "🎯 Fast Parity Prediction: <b>$safe</b>";

        // send to group
        $sent = sendMessage($GROUP_ID, $group_msg, true);

        // reply to admin
        if ($sent) sendMessage($chat_id, "✅ Sent to group: $prediction");
        else sendMessage($chat_id, "❌ Failed to send to group. Check logs/webhook.");
    }
}

// helper: sendMessage
function sendMessage($chat_id, $text, $html = false) {
    global $API_TOKEN;
    $url = "https://api.telegram.org/bot$API_TOKEN/sendMessage";
    $post = ['chat_id' => $chat_id, 'text' => $text];
    if ($html) $post['parse_mode'] = 'HTML';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    $res = curl_exec($ch);
    if ($res === false) {
        file_put_contents(__DIR__ . "/telegram_errors.log", date('c') . " CURL ERROR: " . curl_error($ch) . PHP_EOL, FILE_APPEND);
        curl_close($ch);
        return false;
    }
    curl_close($ch);
    file_put_contents(__DIR__ . "/telegram_send.log", date('c') . " RESPONSE: " . $res . PHP_EOL, FILE_APPEND);
    return true;
}
?>
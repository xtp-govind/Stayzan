<?php
session_start();
header('Content-Type: application/json');

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$unique_id = $_SESSION['unique_id'] ?? null;
$type = $_POST['type'] ?? '';
$response = [];

if (!$unique_id) {
    die("Unauthorized Access");
}

// ✅ Add account
if ($type === "UPI") {
    $upi_id = trim($_POST['upi_id'] ?? '');

    if (!$upi_id) {
        die("Please enter UPI ID");
    }

    $stmt = $conn->prepare("INSERT INTO user_accounts (unique_id, type, upi_id) VALUES (?, 'UPI', ?)");
    $stmt->bind_param("ss", $unique_id, $upi_id);
    $stmt->execute();

    header("Location: withdrawal"); // ✅ Redirect after success
    exit();
}
elseif ($type === "BANK") {
    $acc_holder = trim($_POST['acc_holder'] ?? '');
    $acc_number = trim($_POST['acc_number'] ?? '');
    $ifsc = trim($_POST['ifsc'] ?? '');

    if (!$acc_holder || !$acc_number || !$ifsc) {
        die("All fields are required for Bank account");
    }

    $stmt = $conn->prepare("INSERT INTO user_accounts (unique_id, type, acc_holder, acc_number, ifsc) VALUES (?, 'BANK', ?, ?, ?)");
    $stmt->bind_param("ssss", $unique_id, $acc_holder, $acc_number, $ifsc);
    $stmt->execute();

    header("Location: withdrawal"); // ✅ Redirect after success
    exit();
}
else {
    die("Invalid account type");
}
?>
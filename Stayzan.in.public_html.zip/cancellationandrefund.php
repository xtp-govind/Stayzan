<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>कैंसलेशन और रिफंड पॉलिसी - Stayzan.in</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #1a237e; /* Dark Blue for a professional look */
        }
        .policy-section {
            margin-bottom: 25px;
        }
        ul {
            padding-left: 20px;
        }
        li {
            margin-bottom: 10px;
        }
        .highlight {
            color: #c62828; /* Red for important notes */
            font-weight: bold;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 0.9em;
            color: #777;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Stayzan.in - कैंसलेशन और रिफंड पॉलिसी</h1>
        <p><i>अंतिम अपडेट: 27 अगस्त, 2025</i></p>

        <div class="policy-section">
            <h2>1. सामान्य अवलोकन</h2>
            <p>यह पॉलिसी Stayzan.in पर आयोजित होने वाले सभी eSports टूर्नामेंटों के लिए रजिस्ट्रेशन पर लागू होती है। हमारा उद्देश्य सभी खिलाड़ियों और टीमों के लिए एक निष्पक्ष और पारदर्शी प्रणाली सुनिश्चित करना है। टूर्नामेंट के लिए रजिस्टर करने से पहले कृपया इन नियमों को ध्यान से पढ़ें।</p>
        </div>

        <div class="policy-section">
            <h2>2. रजिस्ट्रेशन कैंसलेशन</h2>
            <p>यदि आप या आपकी टीम किसी टूर्नामेंट से अपना रजिस्ट्रेशन कैंसिल करना चाहते हैं, तो आपको हमारी वेबसाइट पर अपने Stayzan अकाउंट में लॉग इन करके या हमें <a href="mailto:support@stayzan.in">support@stayzan.in</a> पर एक ईमेल भेजकर अनुरोध करना होगा।</p>
        </div>

        <div class="policy-section">
            <h2>3. रिफंड की शर्तें (प्रवेश शुल्क के लिए)</h2>
            <p>रिफंड की पात्रता इस बात पर निर्भर करती है कि कैंसलेशन का अनुरोध कब किया गया है:</p>
            <ul>
                <li><strong>टूर्नामेंट शुरू होने से 48 घंटे पहले कैंसलेशन:</strong> आपकी प्रवेश शुल्क (Entry Fee) का 100% रिफंड किया जाएगा।</li>
                <li><strong>टूर्नामेंट शुरू होने से 24 से 48 घंटे पहले कैंसलेशन:</strong> प्रवेश शुल्क का 50% रिफंड किया जाएगा।</li>
                <li><span class="highlight"><strong>टूर्नामेंट शुरू होने से 24 घंटे से कम समय में कैंसलेशन:</strong> कोई रिफंड नहीं दिया जाएगा।</span></li>
            </ul>
            <p><strong>ध्यान दें:</strong> कुछ विशेष या प्रायोजित टूर्नामेंटों के लिए अलग नियम हो सकते हैं, जिनकी जानकारी रजिस्ट्रेशन के समय दी जाएगी।</p>
        </div>

        <div class="policy-section">
            <h2>4. टूर्नामेंट रद्द होने की स्थिति में</h2>
            <p>यदि Stayzan.in द्वारा किसी तकनीकी समस्या, अपर्याप्त प्रतिभागियों या किसी अन्य कारण से कोई टूर्नामेंट रद्द कर दिया जाता है, तो सभी पंजीकृत खिलाड़ियों/टीमों को उनकी प्रवेश शुल्क का <strong>पूरा 100% रिफंड</strong> दिया जाएगा।</p>
        </div>

        <div class="policy-section">
            <h2>5. रिफंड प्रक्रिया</h2>
            <p>एक बार आपका रिफंड अनुरोध स्वीकृत हो जाने के बाद, राशि 7-10 व्यावसायिक दिनों के भीतर आपके मूल भुगतान स्रोत में वापस जमा कर दी जाएगी।</p>
        </div>

        <div class="policy-section">
            <h2>6. संपर्क करें</h2>
            <p>इस पॉलिसी के बारे में किसी भी प्रश्न या चिंता के लिए, कृपया हमें ईमेल करें:</p>
            <p><strong>ईमेल:</strong> <a href="mailto:support@stayzan.in">support@stayzan.in</a></p>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2025 Stayzan.in | सभी अधिकार सुरक्षित।</p>
    </div>

</body>
</html>

<?php
header('Content-Type: application/json');
session_start();

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}


$unique_id = $_SESSION['unique_id'] ?? null;
$task_id = $_POST['task_id'] ?? null;

if (!$unique_id || !$task_id) {
    echo json_encode(["status" => "error", "message" => "Missing data"]);
    exit;
}

// ✅ Check if claim is valid
$check = $conn->prepare("SELECT status FROM user_tasks WHERE user_id = ? AND task_id = ?");
$check->bind_param("ss", $unique_id, $task_id);
$check->execute();
$res = $check->get_result();
$row = $res->fetch_assoc();

if (!$row || $row['status'] !== 'available') {
    echo json_encode(["status" => "error", "message" => "Task not available for claiming"]);
    exit;
}

// ✅ Get reward
$reward = 0;
$rewardSql = $conn->prepare("SELECT reward FROM task_master WHERE id = ?");
$rewardSql->bind_param("s", $task_id);
$rewardSql->execute();
$rewardRes = $rewardSql->get_result();
if ($rewardRow = $rewardRes->fetch_assoc()) {
    $reward = $rewardRow['reward'];
}

// ✅ Update user's balance
$conn->query("UPDATE users SET balance = balance + $reward WHERE unique_id = '$unique_id'");

// ✅ Mark task as completed
$now = date('Y-m-d H:i:s');
$update = $conn->prepare("UPDATE user_tasks SET status = 'completed', completed_at = ? WHERE user_id = ? AND task_id = ?");
$update->bind_param("sss", $now, $unique_id, $task_id);
$update->execute();

echo json_encode(["status" => "success", "message" => "Reward claimed successfully", "reward" => $reward]);
?>
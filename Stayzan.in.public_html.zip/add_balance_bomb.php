<?php

// ✅ DB connection
// ... (आपका बाकी का कनेक्शन कोड) ...

// --- डीबगिंग कोड यहाँ डालें ---
$raw_data = file_get_contents('php://input');
$log_message = "[" . date('Y-m-d H:i:s') . "] Raw Data: " . $raw_data . "\n";
file_put_contents('debug_log.txt', $log_message, FILE_APPEND);
// --- डीबगिंग कोड खत्म ---



// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

session_start();

// सुरक्षा जांच: सुनिश्चित करें कि यूज़र लॉग इन है
if (!isset($_SESSION['unique_id'])) {
    header('Content-Type: application/json');
    http_response_code(401); // Unauthorized
    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
    exit();
}

$userId = $_SESSION['unique_id'];

// 3. जावास्क्रिप्ट से भेजा गया डेटा प्राप्त करें
$data = json_decode(file_get_contents('php://input'), true);

// सुनिश्चित करें कि डेटा सही है
if (!isset($data['amount']) || !is_numeric($data['amount']) || !isset($data['reason'])) { // 'reason' को भी जांचें
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Invalid data provided.']);
    exit();
}

$amountToUpdate = floatval($data['amount']);
$reason = $data['reason']; // कारण को एक वैरिएबल में स्टोर करें

// --- स्टेप 4 का नया लॉजिक यहाँ से शुरू ---

if (($reason === 'cashout_win' || $reason === 'full_win') && isset($data['winnings']) && $data['winnings'] > 0) {
    
    $netWinnings = floatval($data['winnings']);
    
    // total_won_mine और last_game_result को एक साथ अपडेट करें
    $stats_sql = "UPDATE users SET total_won_mine = total_won_mine + ?, last_game_result_mine = 'win' WHERE unique_id = ?";
    $stats_stmt = $conn->prepare($stats_sql);
    $stats_stmt->bind_param("ds", $netWinnings, $userId);
    $stats_stmt->execute();
    $stats_stmt->close();
}

// --- स्टेप 4 का लॉजिक यहाँ खत्म ---
// अगर बैलेंस घटाना है (यानी बेट लगाना है)
if ($amountToUpdate < 0) {
    $checkStmt = $conn->prepare("SELECT balance FROM users WHERE unique_id = ?");
    $checkStmt->bind_param("s", $userId);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $user = $result->fetch_assoc();
    $checkStmt->close(); // स्टेटमेंट को तुरंत बंद करें

    if ($user['balance'] < abs($amountToUpdate)) {
        // अगर पर्याप्त बैलेंस नहीं है
        header('Content-Type: application/json');
        http_response_code(400);
        echo json_encode([
            'success' => false, 
            'message' => 'Insufficient balance.',
            'new_balance' => $user['balance']
        ]);
        $conn->close(); // कनेक्शन बंद करके स्क्रिप्ट रोकें
        exit();
    }
}

// अब बैलेंस को अपडेट करें
$updateStmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE unique_id = ?");
$updateStmt->bind_param("ds", $amountToUpdate, $userId);
$updateSuccess = $updateStmt->execute();

if ($updateSuccess) {
    // 5. अपडेट किया गया नया बैलेंस प्राप्त करें और वापस भेजें
    $selectStmt = $conn->prepare("SELECT balance FROM users WHERE unique_id = ?");
    $selectStmt->bind_param("s", $userId);
    $selectStmt->execute();
    $result = $selectStmt->get_result();
    $updatedUser = $result->fetch_assoc();
    $newBalance = $updatedUser['balance'];

    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'new_balance' => $newBalance
    ]);
} else {
    // अगर डेटाबेस अपडेट में कोई एरर आता है
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Failed to update balance in the database.']);
}

// स्टेटमेंट और कनेक्शन बंद करें
$updateStmt->close();
$selectStmt->close();
$conn->close();

?>

<?php
session_start();
header('Content-Type: application/json');

// ✅ DB connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "DB connection failed"]));
}

// ✅ Get logged-in user
if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit;
}

$my_id = $_SESSION['unique_id'];
$levels = [1, 2, 3, 4, 5];
$response = [];

// ✅ Referral counts
$total_invites = 0;

foreach ($levels as $level) {
    $level_col = "level_$level";

    $stmt = $conn->prepare("SELECT unique_id FROM referral_users WHERE $level_col = ?");
    $stmt->bind_param("s", $my_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row['unique_id'];
        $total_invites++;
    }

    $response["level_$level"] = $users;
}

// ✅ Total commission (from referral_commission table's 'commission' column)
$total_commission = 0;
$stmt = $conn->prepare("SELECT SUM(commission_amount) as total FROM referral_commissions WHERE to_user_id = ?");
$stmt->bind_param("s", $my_id);
$stmt->execute();
$res2 = $stmt->get_result()->fetch_assoc();
if ($res2 && $res2['total']) {
    $total_commission = isset($res2['total']) ? floatval($res2['total']) : 0;
}

echo json_encode([
    "status" => "success",
    "my_unique_id" => $my_id,
    "total_invites" => $total_invites,
    "total_commission" => $total_commission,
    "referrals" => $response
]);
?>
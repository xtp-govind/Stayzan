<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aviator Game</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
            overflow-x: hidden;
            color: white;
            width: 100%;
        }

        .container {
            width: 100%;
            max-width: 100vw;
            margin: 0 auto;
            background: #1e293b;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            width: 100%;
        }

        .back-btn {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .header-title {
            font-size: 20px;
            font-weight: 600;
            color: white;
        }

        .balance {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
            font-weight: 500;
        }

        /* Game Area */
        .game-area {
            background: #000000;
            padding: 15px;
            margin: 15px;
            border-radius: 15px;
            position: relative;
            overflow: hidden;
            min-height: 250px;
            width: calc(100% - 30px);
            border: 2px solid #333;
        }

        .game-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: repeating-linear-gradient(
                45deg,
                transparent,
                transparent 10px,
                rgba(255, 255, 255, 0.03) 10px,
                rgba(255, 255, 255, 0.03) 20px
            );
            z-index: 1;
        }

        .multiplier-display {
            text-align: center;
            position: relative;
            z-index: 3;
            margin-bottom: 15px;
        }

        .multiplier {
            font-size: 48px;
            font-weight: bold;
            color: #ffffff;
            text-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
            animation: pulse 2s infinite;
        }

        .status-text {
            font-size: 14px;
            color: #94a3b8;
            margin-top: 5px;
        }

        .plane {
            position: absolute;
            font-size: 0;
            z-index: 4;
            transition: none;
            transform-origin: center;
            width: 30px;
            height: 15px;
            pointer-events: none;
            /* ONLY FIX: Flipped the helicopter to face left */
            transform: scaleX(-1);
        }

        .plane-icon {
            width: 100%;
            height: 100%;
            fill: #dc2626;
            filter: drop-shadow(0 0 8px rgba(220, 38, 38, 0.8));
        }

        /* Graph Canvas */
        .graph-container {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 150px;
            z-index: 2;
        }

        #gameGraph {
            width: 100%;
            height: 100%;
        }

        /* Axis dots */
        .axis-dots {
            position: absolute;
            bottom: 5px;
            left: 0;
            right: 0;
            height: 10px;
            z-index: 3;
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .axis-dot {
            width: 4px;
            height: 4px;
            background: white;
            border-radius: 50%;
            opacity: 0.6;
        }

        /* Betting Section */
        .betting-section {
            padding: 0 15px 15px;
            width: 100%;
        }

        .bet-controls {
            background: #334155;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            width: 100%;
        }

        .bet-input-group {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 15px;
            width: 100%;
        }

        .bet-input {
            flex: 1;
            background: #475569;
            border: 1px solid #64748b;
            border-radius: 8px;
            padding: 10px;
            color: white;
            font-size: 14px;
            min-width: 0;
        }

        .bet-input:focus {
            outline: none;
            border-color: #3b82f6;
        }

        .quick-bet-buttons {
            display: flex;
            gap: 6px;
            margin-bottom: 15px;
            width: 100%;
        }

        .quick-bet-btn {
            flex: 1;
            background: #475569;
            border: 1px solid #64748b;
            color: white;
            padding: 8px 6px;
            border-radius: 6px;
            font-size: 11px;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 0;
        }

        .quick-bet-btn:hover {
            background: #3b82f6;
            border-color: #3b82f6;
        }

        .bet-button {
            width: 100%;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
            color: white;
            padding: 15px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .bet-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
        }

        .bet-button:disabled {
            background: #6b7280;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .cashout-button {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        }

        /* Live Players */
        .live-players {
            background: #334155;
            margin: 0 15px 15px;
            border-radius: 12px;
            padding: 15px;
            width: calc(100% - 30px);
        }

        .live-players-header {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 15px;
            font-size: 14px;
            font-weight: 600;
        }

        .live-indicator {
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
            animation: blink 1s infinite;
        }

        .players-list {
            max-height: 120px;
            overflow-y: auto;
        }

        .player-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 0;
            border-bottom: 1px solid #475569;
            font-size: 11px;
        }

        .player-item:last-child {
            border-bottom: none;
        }

        .player-name {
            color: #94a3b8;
            flex: 1;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .player-bet {
            color: #fbbf24;
            font-weight: 500;
            margin: 0 8px;
        }

        .player-multiplier {
            color: #10b981;
            font-weight: 600;
        }

        /* Order History */
        .order-history {
            background: #334155;
            margin: 0 15px 15px;
            border-radius: 12px;
            padding: 15px;
            width: calc(100% - 30px);
        }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .order-title {
            font-size: 14px;
            font-weight: 600;
            color: white;
        }

        .order-tabs {
            display: flex;
            gap: 4px;
            margin-bottom: 15px;
        }

        .order-tab {
            flex: 1;
            background: #475569;
            border: none;
            color: #94a3b8;
            padding: 8px 6px;
            border-radius: 6px;
            font-size: 11px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .order-tab.active {
            background: #3b82f6;
            color: white;
        }

        .order-list {
            max-height: 150px;
            overflow-y: auto;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid #475569;
            font-size: 11px;
        }

        .order-item:last-child {
            border-bottom: none;
        }

        .order-time {
            color: #94a3b8;
            flex: 1;
            min-width: 0;
        }

        .order-bet {
            color: #fbbf24;
            margin: 0 8px;
        }

        .order-result {
            font-weight: 600;
        }

        .order-result.win {
            color: #10b981;
        }

        .order-result.loss {
            color: #ef4444;
        }

        /* Withdrawal Notification */
        .withdrawal-notification {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            display: none;
            text-align: center;
            animation: slideIn 0.5s ease;
            max-width: 90vw;
        }

        .withdrawal-amount {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .withdrawal-text {
            font-size: 14px;
            opacity: 0.9;
        }

        /* Animations */
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        @keyframes blink {
            0%, 50% { opacity: 1; }
            51%, 100% { opacity: 0.3; }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translate(-50%, -50%) scale(0.8);
            }
            to {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }
        }

        /* Mobile Responsive */
        @media (max-width: 480px) {
            .container {
                max-width: 100vw;
                width: 100%;
            }
            
            .header {
                padding: 12px 15px;
            }
            
            .header-title {
                font-size: 18px;
            }
            
            .balance {
                font-size: 12px;
            }
            
            .game-area {
                margin: 10px;
                padding: 12px;
                min-height: 220px;
                width: calc(100% - 20px);
            }
            
            .multiplier {
                font-size: 40px;
            }
            
            .betting-section {
                padding: 0 10px 10px;
            }
            
            .bet-controls {
                padding: 12px;
            }
            
            .bet-input {
                padding: 8px;
                font-size: 13px;
            }
            
            .quick-bet-btn {
                padding: 6px 4px;
                font-size: 10px;
            }
            
            .live-players, .order-history {
                margin: 0 10px 10px;
                padding: 12px;
                width: calc(100% - 20px);
            }
            
            .player-item, .order-item {
                font-size: 10px;
                padding: 5px 0;
            }
            
            .order-tab {
                font-size: 10px;
                padding: 6px 4px;
            }
        }

        /* Extra small screens */
        @media (max-width: 360px) {
            .header {
                padding: 10px 12px;
            }
            
            .game-area {
                margin: 8px;
                padding: 10px;
                width: calc(100% - 16px);
            }
            
            .multiplier {
                font-size: 36px;
            }
            
            .betting-section {
                padding: 0 8px 8px;
            }
            
            .live-players, .order-history {
                margin: 0 8px 8px;
                width: calc(100% - 16px);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <button class="back-btn" onclick="goBack()">
                <i class="fas fa-arrow-left"></i>
            </button>
            <div class="header-title">Aviator</div>
            <div class="balance">
                <i class="fas fa-wallet"></i>
                ₹<span id="balance">1,250.00</span>
            </div>
        </div>

        <!-- Game Area -->
        <div class="game-area">
            <div class="multiplier-display">
                <div class="multiplier" id="multiplier">1.00x</div>
                <div class="status-text" id="status">Waiting for next round...</div>
            </div>
            <div class="plane" id="plane">
                <svg class="plane-icon" viewBox="0 0 30 15" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 7.5 L12 2 L28 6 L26 7.5 L28 9 L12 13 L2 7.5 Z M12 6 L20 7.5 L12 9 Z"/>
                </svg>
            </div>
            
            <!-- Graph Canvas -->
            <div class="graph-container">
                <canvas id="gameGraph"></canvas>
            </div>
            
            <!-- Axis dots -->
            <div class="axis-dots">
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
                <div class="axis-dot"></div>
            </div>
        </div>

        <!-- Betting Section -->
        <div class="betting-section">
            <div class="bet-controls">
                <div class="bet-input-group">
                    <input type="number" class="bet-input" id="betAmount" placeholder="Bet Amount" value="10" min="1">
                    <input type="number" class="bet-input" id="autoWithdraw" placeholder="Auto Withdraw at" value="1.50" min="1.01" step="0.01">
                </div>
                
                <div class="quick-bet-buttons">
                    <button class="quick-bet-btn" onclick="setBetAmount(10)">₹10</button>
                    <button class="quick-bet-btn" onclick="setBetAmount(50)">₹50</button>
                    <button class="quick-bet-btn" onclick="setBetAmount(100)">₹100</button>
                    <button class="quick-bet-btn" onclick="setBetAmount(500)">₹500</button>
                </div>
                
                <button class="bet-button" id="betButton" onclick="placeBet()">
                    Place Bet
                </button>
            </div>
        </div>

        <!-- Live Players -->
        <div class="live-players">
            <div class="live-players-header">
                <div class="live-indicator"></div>
                Live Players
                <span style="margin-left: auto; color: #94a3b8;">Online: 247</span>
            </div>
            <div class="players-list">
                <div class="player-item">
                    <div class="player-name">Priya306</div>
                    <div class="player-bet">₹350</div>
                    <div class="player-multiplier">2.51x</div>
                </div>
                <div class="player-item">
                    <div class="player-name">Priya884</div>
                    <div class="player-bet">₹108</div>
                    <div class="player-multiplier">3.84x</div>
                </div>
                <div class="player-item">
                    <div class="player-name">Pooja856</div>
                    <div class="player-bet">₹170</div>
                    <div class="player-multiplier">2.16x</div>
                </div>
                <div class="player-item">
                    <div class="player-name">Anjali302</div>
                    <div class="player-bet">₹379</div>
                    <div class="player-multiplier">3.78x</div>
                </div>
                <div class="player-item">
                    <div class="player-name">Vikash930</div>
                    <div class="player-bet">₹151</div>
                    <div class="player-multiplier">2.95x</div>
                </div>
            </div>
        </div>

        <!-- Order History -->
        <div class="order-history">
            <div class="order-header">
                <div class="order-title">My Bets</div>
            </div>
            <div class="order-tabs">
                <button class="order-tab active" onclick="showTab('all')">All</button>
                <button class="order-tab" onclick="showTab('win')">Win</button>
                <button class="order-tab" onclick="showTab('loss')">Loss</button>
            </div>
            <div class="order-list" id="orderList">
                <!-- Order history will be populated here -->
                <div style="text-align: center; color: #94a3b8; padding: 20px; font-size: 12px;">
                    No bets placed yet
                </div>
            </div>
        </div>

        <!-- Withdrawal Notification -->
        <div class="withdrawal-notification" id="withdrawalNotification">
            <div class="withdrawal-amount" id="withdrawalAmount">₹0</div>
            <div class="withdrawal-text">Successfully withdrawn!</div>
        </div>
    </div>

    <script>
        // Game variables
        let gameState = 'waiting'; // 'waiting', 'flying', 'crashed'
        let currentMultiplier = 1.00;
        let gameCanvas = null;
        let gameCtx = null;
        let animationId = null;
        let gameStartTime = Date.now();
        let planeElement = null;
        let graphPoints = [];
        let gameSpeed = 1;
        let playerBets = [];
        let currentBet = null;

        // Initialize game
        function initGame() {
            gameCanvas = document.getElementById('gameGraph');
            gameCtx = gameCanvas.getContext('2d');
            planeElement = document.getElementById('plane');
            
            // Set canvas size
            resizeCanvas();
            window.addEventListener('resize', resizeCanvas);
            
            // Start game cycle
            startWaitingPhase();
        }

        function resizeCanvas() {
            const container = gameCanvas.parentElement;
            gameCanvas.width = container.offsetWidth;
            gameCanvas.height = container.offsetHeight;
        }

        function startWaitingPhase() {
            gameState = 'waiting';
            currentMultiplier = 1.00;
            document.getElementById('multiplier').textContent = '1.00x';
            document.getElementById('status').textContent = 'Waiting for next round...';
            
            // Reset plane position
            planeElement.style.left = '20px';
            planeElement.style.bottom = '20px';
            
            // Clear canvas only when starting new round
            if (gameCtx) {
                gameCtx.clearRect(0, 0, gameCanvas.width, gameCanvas.height);
            }
            
            // Enable betting
            document.getElementById('betButton').disabled = false;
            document.getElementById('betButton').textContent = 'Place Bet';
            document.getElementById('betButton').className = 'bet-button';
            
            // Start flying after 5 seconds
            setTimeout(startGameLoop, 5000);
        }

        function startGameLoop() {
            gameStartTime = Date.now();
            graphPoints = [];
            gameState = 'flying';
            currentMultiplier = 1.00;
            
            // Update status
            document.getElementById('status').textContent = 'Flying...';
            
            // Disable betting, enable cashout if player has bet
            document.getElementById('betButton').disabled = true;
            if (currentBet) {
                document.getElementById('betButton').textContent = 'Cash Out';
                document.getElementById('betButton').className = 'bet-button cashout-button';
                document.getElementById('betButton').disabled = false;
                document.getElementById('betButton').onclick = cashOut;
            }
            
            animate();
        }

        function animate() {
            if (gameState !== 'flying') return;
            
            const elapsed = (Date.now() - gameStartTime) / 1000;
            
            // Calculate multiplier
            currentMultiplier = 1 + Math.pow(elapsed * 0.6, 1.2);
            
            // Update multiplier display
            document.getElementById('multiplier').textContent = currentMultiplier.toFixed(2) + 'x';
            
            // Calculate plane position to match exact graph coordinates
            const canvasWidth = gameCanvas.width;
            const canvasHeight = gameCanvas.height;
            
            const progress = Math.min(elapsed / 8, 1); // 8 seconds max
            const x = progress * canvasWidth * 0.9;
            const y = canvasHeight - (Math.pow(progress, 0.8) * canvasHeight * 0.7 + 30);
            
            // Update plane position to be exactly on the curve - using same coordinates as graph
            // Adjusted for helicopter's width and height to center it on the line
            planeElement.style.left = (x - (planeElement.offsetWidth / 2)) + 'px';
            planeElement.style.bottom = (canvasHeight - y - (planeElement.offsetHeight / 2)) + 'px';
            
            // Add point to graph
            graphPoints.push({x: x, y: y});
            
            // Keep all points to show full trajectory from start to crash
            // Removed the limit to ensure graph doesn't break from behind
            
            // Draw graph
            drawGraph();
            
            // Continue animation
            animationId = requestAnimationFrame(animate);
            
            // Random crash (for demo)
            if (Math.random() < 0.002 && elapsed > 1) {
                crashGame();
            }
        }

        function drawGraph() {
            // Only clear canvas if game is flying, preserve graph after crash
            if (gameState === 'flying') {
                gameCtx.clearRect(0, 0, gameCanvas.width, gameCanvas.height);
            }
            
            if (graphPoints.length < 2) return;
            
            // Draw curve
            gameCtx.strokeStyle = '#dc2626';
            gameCtx.lineWidth = 3;
            gameCtx.lineCap = 'round';
            gameCtx.lineJoin = 'round';
            
            // Create gradient for the area under curve
            const gradient = gameCtx.createLinearGradient(0, 0, 0, gameCanvas.height);
            gradient.addColorStop(0, 'rgba(220, 38, 38, 0.3)');
            gradient.addColorStop(1, 'rgba(220, 38, 38, 0.05)');
            
            // Draw filled area
            gameCtx.fillStyle = gradient;
            gameCtx.beginPath();
            gameCtx.moveTo(graphPoints[0].x, gameCanvas.height);
            
            for (let i = 0; i < graphPoints.length; i++) {
                gameCtx.lineTo(graphPoints[i].x, graphPoints[i].y);
            }
            
            gameCtx.lineTo(graphPoints[graphPoints.length - 1].x, gameCanvas.height);
            gameCtx.closePath();
            gameCtx.fill();
            
            // Draw line
            gameCtx.beginPath();
            gameCtx.moveTo(graphPoints[0].x, graphPoints[0].y);
            
            for (let i = 1; i < graphPoints.length; i++) {
                gameCtx.lineTo(graphPoints[i].x, graphPoints[i].y);
            }
            
            gameCtx.stroke();
        }

        function crashGame() {
            gameState = 'crashed';
            cancelAnimationFrame(animationId);
            
            document.getElementById('status').textContent = 'Crashed at ' + currentMultiplier.toFixed(2) + 'x';
            
            // Handle current bet
            if (currentBet) {
                // Player lost
                addToHistory(currentBet.amount, currentMultiplier.toFixed(2) + 'x', 'loss');
                currentBet = null;
            }
            
            // Reset after 3 seconds
            setTimeout(startWaitingPhase, 3000);
        }

        // Betting functions
        function setBetAmount(amount) {
            document.getElementById('betAmount').value = amount;
        }

        function placeBet() {
            if (gameState !== 'waiting') return;
            
            const betAmount = parseInt(document.getElementById('betAmount').value);
            const autoWithdraw = parseFloat(document.getElementById('autoWithdraw').value);
            
            if (!betAmount || betAmount < 1) {
                alert('Please enter a valid bet amount');
                return;
            }
            
            const currentBalance = parseInt(document.getElementById('balance').textContent.replace(',', ''));
            if (betAmount > currentBalance) {
                alert('Insufficient balance');
                return;
            }
            
            // Place bet
            currentBet = {
                amount: betAmount,
                autoWithdraw: autoWithdraw
            };
            
            // Update balance
            updateBalance(-betAmount);
            
            // Update UI
            document.getElementById('betButton').textContent = 'Bet Placed';
            document.getElementById('betButton').disabled = true;
        }

        function cashOut() {
            if (gameState !== 'flying' || !currentBet) return;
            
            const winAmount = Math.floor(currentBet.amount * currentMultiplier);
            updateBalance(winAmount);
            
            // Show withdrawal notification
            showWithdrawalNotification(winAmount);
            
            // Add to history
            addToHistory(currentBet.amount, currentMultiplier.toFixed(2) + 'x', 'win');
            
            currentBet = null;
            
            // Update UI
            document.getElementById('betButton').textContent = 'Cashed Out';
            document.getElementById('betButton').disabled = true;
            document.getElementById('betButton').className = 'bet-button';
        }

        function updateBalance(amount) {
            const balanceElement = document.getElementById('balance');
            const currentBalance = parseInt(balanceElement.textContent.replace(',', ''));
            const newBalance = currentBalance + amount;
            balanceElement.textContent = newBalance.toLocaleString();
        }

        function showWithdrawalNotification(amount) {
            const notification = document.getElementById('withdrawalNotification');
            document.getElementById('withdrawalAmount').textContent = '₹' + amount;
            notification.style.display = 'block';
            
            setTimeout(() => {
                notification.style.display = 'none';
            }, 3000);
        }

        function addToHistory(betAmount, multiplier, result) {
            const orderList = document.getElementById('orderList');
            const time = new Date().toLocaleTimeString();
            
            const orderItem = document.createElement('div');
            orderItem.className = 'order-item';
            orderItem.innerHTML = `
                <div class="order-time">${time}</div>
                <div class="order-bet">₹${betAmount}</div>
                <div class="order-result ${result}">${multiplier}</div>
            `;
            
            // Remove "no bets" message if it exists
            if (orderList.children.length === 1 && orderList.children[0].textContent.includes('No bets')) {
                orderList.innerHTML = '';
            }
            
            orderList.insertBefore(orderItem, orderList.firstChild);
            
            // Keep only last 10 items
            while (orderList.children.length > 10) {
                orderList.removeChild(orderList.lastChild);
            }
        }

        function showTab(tab) {
            // Update tab appearance
            document.querySelectorAll('.order-tab').forEach(t => t.classList.remove('active'));
            event.target.classList.add('active');
            
            // Filter orders (simplified for demo)
            console.log('Showing tab:', tab);
        }

        function goBack() {
            // Simulate going back
            console.log('Going back...');
        }

        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', initGame);
    </script>
</body>
</html>


<?php
// user_complaints2.php
// ✅ Complaint Update Backend (Production Ready)

// DB Connection
$host = "localhost";
$user = "u976552851_hellogovind";
$password = "Govind@00#";
$database = "u976552851_hellogovind";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    http_response_code(500);
    exit("Database connection failed");
}
$conn->set_charset("utf8mb4");

// Check required fields
if (empty($_POST['id']) || empty($_POST['status']) || !isset($_POST['status_text'])) {
    http_response_code(400);
    exit("Missing required fields");
}

$id = intval($_POST['id']);
$status = trim($_POST['status']);
$status_text = trim($_POST['status_text']);

// Prepare & execute query
$stmt = $conn->prepare("UPDATE complaints SET status = ?, status_text = ? WHERE id = ?");
if (!$stmt) {
    http_response_code(500);
    exit("SQL error");
}

$stmt->bind_param("ssi", $status, $status_text, $id);

if ($stmt->execute()) {
    echo "success"; // ✅ frontend expects this
} else {
    http_response_code(500);
    echo "error";
}

$stmt->close();
$conn->close();
?>